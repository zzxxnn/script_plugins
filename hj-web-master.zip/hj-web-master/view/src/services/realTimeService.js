import xhr from './xhr/'

class RealTimeService {

	getDevRes() {
		return xhr({
			url: '/real_time/dev_res.php',
		})
	}
/****************物理端口*****************/
	getEthsState() {
		return xhr({
			url: 'stats/get?t=9',
		})
	}
/****************设备资源*****************/
getEquipment(){
	return xhr({
		url:'stats/get?t=3|5|6|8'
	})
}
/****************用户监控*****************/
  getUserMonitor(page,row,order,by,groupid){
		return xhr({
			url:'stats/get?t=11',
			method:'GET',
			body:{
				page11:page,
				row11:row,
				order11:order,
				orderby11:by,
				groupid11:groupid
			}
		})
	}
	clearSession() {
		return xhr({
			url:'utils/clearsession',
		})
	}
/*****************在线节点***********/
getOnlineNode(page,row,order,by,params) {
	return xhr({
		url: 'stats/get?t=10',
		method: 'GET',
		body: {
			page10: page,
			row10: row,
			order10: order,
			orderby10: by,

			mac10: params.mac,
			desc10: params.desc,
			rip10: params.rip,
			vip10: params.vip,
			wip10: params.wip,
			name10: params.name,
			groupid10: params.groupid,
			vlanid10: params.vlanid,
			start_time10: params.start_time,
			end_time10: params.end_time
		}

	})
}

delOnlineNode(params) {
	return xhr({
		url: 'stats/del?t=10',
		method: 'POST',
		body: params
	})
}

setBlock(ipmac,oper){
	return xhr({
		url:'utils/setblock',
		method:'POST',
		body:{
			oper:oper,
			ipmac:ipmac
		}
	})
}

/*************封堵列表**************/
getBlockList(page,row,order,by,params) {
	return xhr({
		url: 'stats/get?t=12',
		method: 'GET',
		body: {
			page12: page,
			row12: row,
			order12: order,
			orderby12: by,

			source12: params.source,
			desc12: params.desc,
			start_time12: params.start_time,
			end_time12: params.end_time
		}

	})
}
/**********白名单************/
getWhiteList(page,row,order,by,params) {
	return xhr({
		url:'safe/get?t=5',
		method:"GET",
		body:{
			page: page,
			row: row,
			order: order,
			by: by,

			ip_mac: params.mac,
			start_time:params.start_time,
			end_time: params.end_time
		}
	})
}

addWhiteList(conf) {
	return xhr({
		url:'safe/add?t=5',
		method:"POST",
		body:{
			'5':conf
		}
	})
}

delWhiteList(ids) {
	return xhr({
		url:'safe/del?t=5',
		method:"POST",
		body:{
			'5':ids
		}
	})
}
/**********黑名单************/
getBlackList(page,row,order,by,params) {
	return xhr({
		url:'safe/get?t=4',
		method:"GET",
		body:{
			page: page,
			row: row,
			order: order,
			by: by,

			ip_mac: params.mac,
			start_time:params.start_time,
			end_time: params.end_time
		}
	})
}

addBlackList(conf) {
	return xhr({
		url:'safe/add?t=4',
		method:"POST",
		body:{
			'4':conf
		}
	})
}

delBlackList(ids) {
	return xhr({
		url:'safe/del?t=4',
		method:"POST",
		body:{
			'4':ids
		}
	})
}

}

export default new RealTimeService()