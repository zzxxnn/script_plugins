import xhr from './xhr/'

/**
 * 对应后端涉及到用户认证的 API
 */
class SystemService {

  getLicense () {
    return xhr({
      url: 'license/read'
    })
  }

  saveConfig () {
    return xhr({
      url: '/sys_conf/xmsd/SaveConfig.php'
    })
  }

  changePwd (old_pwd, new_pwd) {
    return xhr({
      url: '/user/change_password.php',
      method: 'post',
      body: {old_pwd: old_pwd, new_pwd: new_pwd}
    })
  }

  sysUpload (file) {
    return xhr({
      url: '/sys_conf/UploadImage.php',
      method: 'post',
      body: file
    })
  }

  exportConf () {
    return xhr({
      url: '/sys_conf/xmsd/ExportConfig.php'
    })
  }

  sysReset () {
    return xhr({
      url: 'sysconf/command?t=11',
      method: 'get'
    })
  }

  bkconfUpload (file) {
    return xhr({
      url: 'sys_conf/xmsd/UploadConfig.php',
      method: 'post',
      body: {file}
    })
  }

  // 关机7，重启8
  command (cmd) {
    return xhr({
      url: `sysconf/command?t=${cmd}`,
      method: 'get'
    })
  }

  checkStart (cmd) {
    return xhr({
      url: 'utils/checkstart',
      method: 'get'
    })
  }
/** *******时间日期**************/
  getTime () {
    return xhr({ url: 'sysconf/get?t=5' })
  }

  setTime (systime) {
    return xhr({
      url: 'sysconf/update?t=5',
      method: 'post',
      body: {
        '5': systime
      }
    })
  }

  getSntpConf () {
    return xhr({
      url: 'sys-conf/sntp-conf',
      method: 'get'
    })
  }

  setSntpConf (params) {
    return xhr({
      url: 'sys-conf/sntp-conf',
      method: 'post',
      body: params
    })
  }

/** ******获取系统版本**********/
  getSysinfo () {
    return xhr({ url: 'stats/get?t=23|20|24|4' })
  }

  doBypass (bypass) {
    return xhr({
      url: '/sys_conf/bypass.php',
      method: 'post',
      body: {oper: bypass.oper, group: bypass.group}
    })
  }
  /** ******集中管理***********/
  getSysPolice (params) {
    return xhr({
      url: 'sysconf/get?t=4'
    })
  }
  setSysPolice (params) {
    return xhr({
      url: 'sysconf/update?t=4',
      method: 'post',
      body: {
        4: params
      }
    })
  }
  /** *******系统策略*********/
  getNetParams () {
    return xhr({
      url: 'sysconf/get?t=1|2|3'
    })
  }
  setNetParams (params) {
    return xhr({
      url: 'sysconf/update?t=1|2|3',
      method: 'post',
      body: params
    })
  }
  getNetMangage (params) {
    return xhr({
      url: 'sysconf/get',
      method: 'get',
      body: params
    })
  }
  addNetMangage (params) {
    return xhr({
      url: 'sysconf/add?t=6',
      method: 'post',
      body: params
    })
  }
  editNetMangage (params) {
    return xhr({
      url: 'sysconf/update?t=6',
      method: 'post',
      body: params
    })
  }
  delNetMangage (params) {
    return xhr({
      url: 'sysconf/del?t=6',
      method: 'post',
      body: params
    })
  }

  // 网络诊断
  getNetDiagnose (params) {
    return xhr({
      url: `utils/ping?t=${t}`,
      method: 'get',
      body: {
        ip: params.ip,
        times: params.times,
        length: params.length,
        min_ttl: params.min_ttl,
        max_ttl: params.max_ttl
      },
      datatype: 'String'
    })
  }

  getPing (params) {
    return xhr({
      url: 'utils/ping?t=1',
      method: 'post',
      body: {
        ip: params.ip,
        times: params.times,
        length: params.length
      }
    })
  }
  getPingResult () {
    return xhr({
      url: 'utils/ping?t=2',
      method: 'get'
    })
  }

  getTraceRoute (params) {
    return xhr({
      url: 'utils/traceroute?t=1',
      method: 'post',
      body: {
        ip: params.ip,
        min_ttl: params.min_ttl,
        max_ttl: params.max_ttl
      }
    })
  }
  getTraceRouteResult () {
    return xhr({
      url: 'utils/traceroute?t=2',
      method: 'get'
    })
  }

  getLine () {
    return xhr({
      url: 'utils/ethgroups',
      method: 'get'
    })
  }

}

// 实例化后再导出
export default new SystemService()
