import xhr from './xhr/'
//console.log(process.env.NODE_ENV)
/**
 * 对应后端涉及到用户认证的 API
 */
class NetService {

  getGlobal() {
    return xhr({ url: 'netmgmt/get?t=1|2|3|4|5|6|7|8'})
  }
  
	setGlobal(params) {
		return xhr({ 
    	url: 'netmgmt/update?t=1|2|3|4|5|6|7|8',
    	method: 'POST',
    	body: params
    })
	}
  
  /****************************** 内部IP网段 ******************************/
  // 获取内部IP网段
  getRealIpRange({page = 1, size = 10, order = 'desc', by = ''}) {
    return xhr({ 
    	url: `netmgmt/get?t=9&page=${page}&row=${size}&order=${order}&by=${by}`,
    	method: 'get'
    })
  }
  // 设置内部IP网段
  createRealIpRange(params) {
    return xhr({ 
      url: 'netmgmt/add?t=9',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  // 编辑内部IP网段
  updateRealIpRange(params) {
    return xhr({ 
      url: 'netmgmt/update?t=9',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  // 删除内部IP网段
  destroyRealIpRange(params) {
    return xhr({ 
      url: 'netmgmt/del?t=9',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  /****************************** 内部IP保留网段 ******************************/
  // 获取内部IP保留网段
  getRealIpReservedRange({page = 1, size = 10, order = 'desc', by = ''}) {
    return xhr({ 
    	url: `netmgmt/get?t=10&page=${page}&row=${size}&order=${order}&by=${by}`,
    	method: 'get'
    })
  }

  // 设置内部IP保留网段
  createRealIpReservedRange(params) {
    return xhr({ 
    	url: 'netmgmt/add?t=10',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  // 编辑内部IP保留网段
  updateRealIpReservedRange(params) {
    return xhr({ 
    	url: 'netmgmt/update?t=10',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  // 删除内部IP保留网段
  destroyRealIpReservedRange(params) {
    return xhr({ 
    	url: 'netmgmt/del?t=10',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  /****************************** 动态IP网段 ******************************/
  // 获取动态IP网段
  getVIPRange({page = 1, size = 10, order = 'desc', by = ''}) {
    return xhr({ 
    	url: `netmgmt/get?t=11&page=${page}&row=${size}&order=${order}&by=${by}`,
    	method: 'get'
    })
  }

  // 设置动态IP网段
  createVIPRange(params) {
    return xhr({ 
      url: 'netmgmt/add?t=11',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  // 编辑动态IP网段
  updateVIPRange(params) {
    return xhr({ 
      url: 'netmgmt/update?t=11',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  // 删除动态IP网段
  destroyVIPRange(params) {
    return xhr({ 
      url: 'netmgmt/del?t=11',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  /****************************** 动态IP保留网段 ******************************/
  // 获取动态IP保留网段
  getVIPReservedRange({page = 1, size = 10, order = 'desc', by = ''}) {
    return xhr({ 
    	url: `netmgmt/get?t=12&page=${page}&row=${size}&order=${order}&by=${by}`,
    	method: 'get'
    })
  }

  // 设置动态IP保留网段
  createVIPReservedRange(params) {
    return xhr({ 
      url: 'netmgmt/add?t=12',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  // 编辑动态IP保留网段
  updateVIPReservedRange(params) {
    return xhr({ 
      url: 'netmgmt/update?t=12',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  // 删除动态IP保留网段
  destroyVIPReservedRange(params) {
    return xhr({ 
      url: 'netmgmt/del?t=12',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  /****************************** 外部IP网段 ******************************/
  // 获取外部IP网段
  getWIPRange({page = 1, size = 10, order = 'desc', by = ''}) {
    return xhr({ 
      url: `netmgmt/get?t=13&page=${page}&row=${size}&order=${order}&by=${by}`,
      method: 'get'
    })
  }

  // 设置外部IP网段
  createWIPRange(params) {
    return xhr({ 
      url: 'netmgmt/add?t=13',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  // 编辑外部IP网段
  updateWIPRange(params) {
    return xhr({ 
      url: 'netmgmt/update?t=13',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  // 删除外部IP网段
  destroyWIPRange(params) {
    return xhr({ 
      url: 'netmgmt/del?t=13',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }


  /****************************** 外部IP保留网段 ******************************/
  // 获取外部IP保留网段
  getWIPReservedRange({page = 1, size = 10, order = 'desc', by = ''}) {
    return xhr({ 
      url: `netmgmt/get?t=14&page=${page}&row=${size}&order=${order}&by=${by}`,
      method: 'get'
    })
  }

  
  // 设置外部IP保留网段
  createWIPReservedRange(params) {
    return xhr({ 
      url: 'netmgmt/add?t=14',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  // 编辑外部IP保留网段
  updateWIPReservedRange(params) {
    return xhr({ 
      url: 'netmgmt/update?t=14',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  // 删除外部IP保留网段
  destroyWIPReservedRange(params) {
    return xhr({ 
      url: 'netmgmt/del?t=14',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  /****************************** 虚拟网络网段 ******************************/
  // 获取虚拟网络网段
  getVNetRange({page = 1, size = 10, order = 'desc', by = ''}) {
    return xhr({ 
      url: `netmgmt/get?t=15&page=${page}&row=${size}&order=${order}&by=${by}`,
      method: 'get'
    })
  }

  // 设置虚拟网络网段
  createVNetRange(params) {
    return xhr({ 
      url: 'netmgmt/add?t=15',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  // 编辑虚拟网络网段
  updateVNetRange(params) {
    return xhr({ 
      url: 'netmgmt/update?t=15',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  // 删除虚拟网络网段
  destroyVNetRange(params) {
    return xhr({ 
      url: 'netmgmt/del?t=15',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  /****************************** 虚拟网络保留网段 ******************************/
  // 获取虚拟网络保留网段
  getVNetReservedRange({page = 1, size = 10, order = 'desc', by = ''}) {
    return xhr({ 
      url: `netmgmt/get?t=16&page=${page}&row=${size}&order=${order}&by=${by}`,
      method: 'get'
    })
  }

  // 设置虚拟网络保留网段
  createVNetReservedRange(params) {
    return xhr({ 
      url: 'netmgmt/add?t=16',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  // 编辑虚拟网络保留网段
  updateVNetReservedRange(params) {
    return xhr({ 
      url: 'netmgmt/update?t=16',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  // 删除虚拟网络保留网段
  destroyVNetReservedRange(params) {
    return xhr({ 
      url: 'netmgmt/del?t=16',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  /****************************** 虚假响应配置 ******************************/
  // 获取虚假响应配置
  getVResRange() {
    return xhr({ 
      url: 'netmgmt/get?t=17|18|19|20|21|22',
      method: 'get'
    })
  }
  // 修改虚假响应配置
  updateVResRange(params) {
    return xhr({ 
      url: 'netmgmt/update?t=17|18|19|20|21|22',
      method: 'post',
      body: params
    })
  }
  
  updateVResRangeCmd() {
    return xhr({ 
      url: 'utils/vnetalter',
      method: 'get'
    })
  }

  setVhost(vhost) {
    return xhr({ 
    	url: '/net_conf/net.php',
    	method: 'POST',
    	body: { 
        type:vhost.oper,
        linux_num:vhost.linux_num,
        linux_port:vhost.linux_port,
        windows_num:vhost.windows_num,
        windows_port:vhost.windows_port,
        server_num:vhost.server_num,
        server_port:vhost.server_port,
        virtual_port_percent:vhost.virtual_port_percent,
        virtual_mac:vhost.virtual_mac,
        hash_code:vhost.hash_code
       }
    })
  }
  /****************************静态地址**************************/
  getBindIp(page,row,order,by){
    return xhr({ 
      url: `netmgmt/get?t=23`,
      method:'GET',
      body:{
        page: page,
        row: row,
        order: order,
        by: by
      }
    })
  }
  addBindIp(conf){
    return xhr({ 
      url: `netmgmt/add?t=23`,
      method:'POST',
      body:{
       '23':conf
      }
    })
  }
  editBindIp(conf){
    return xhr({ 
      url: `netmgmt/update?t=23`,
      method:'POST',
      body:{
       '23':conf
      }
    })
  }
  delBindIp(ids){
    return xhr({
      url:'netmgmt/del?t=23',
      method: 'POST',
    	body: { 
       '23':ids
      }
    })
  }
  /************************ 静态路由*********************/
  getBindRoute(page,row,order,by){
    return xhr({ 
      url: `netmgmt/get?t=24`,
      method:'GET',
      body:{
        page: page,
        row: row,
        order: order,
        by: by
      }
    })
  }
  addBindRoute(conf){  
    return xhr({
      url:'netmgmt/add?t=24',
      method: 'POST',
    	body: { 
       '24':conf
      }
    })
  }
  editBindRoute(conf){
    return xhr({
      url:'netmgmt/update?t=24',
      method: 'POST',
    	body: { 
       '24':conf
      }
    })
  }
  delBindRoute(ids){
    return xhr({
      url:'netmgmt/del?t=24',
      method: 'POST',
    	body: { 
       '24':ids
      }
    })
  }
  /************************** 主机透传****************************/
  getDoTrunk(page,row,order, by) {
    return xhr({ 
      url: `netmgmt/get?t=25`,
      method: 'GET',
    	body: {
        page: page,
        row: row,
        order: order,
        by: by
      }
    })
  }
  addDoTrunk(conf){
    return xhr({ 
      url: `netmgmt/add?t=25`,
      method: 'POST',
    	body: {
        '25':conf
      }
    })
  }
  editDoTrunk(conf){
    return xhr({ 
      url: `netmgmt/update?t=25`,
      method: 'POST',
    	body: {
        '25':conf
      }
    })
  }
  delDoTrunk(ids){
    return xhr({ 
      url: `netmgmt/del?t=25`,
      method: 'POST',
      body: {
        '25':ids
      }
    })
  }

/***************软件ByPAss*************************/

  getBypass(){
    return xhr({
      url: `netmgmt/get?t=29`,
    })
  }
  addBypass(conf){
    return xhr({ 
      url: `netmgmt/add?t=29`,
      method: 'POST',
    	body: {
        '29':conf
      }
    })
  }
  delBypass(ids){
    return xhr({ 
      url: `netmgmt/del?t=29`,
      method: 'POST',
      body: {
        '29':ids
      }
    })
  }



  getProtocolpass() {
    return xhr({ 
    	url: 'netmgmt/get?t=26|27'
    })
  }
  
  setProtocolpass(conf) {
    return xhr({ 
    	url: 'netmgmt/update?t=26|27',
    	method: 'POST',
    	body: { 
        '26':conf.stp_switch,
        '27':conf.cr_switch
       }
    })
  }

  loadMaskData(params) {
    return xhr({ 
    	url: '/net_conf/server_mask.php',
    	method: 'POST',
    	body: { 
        oper:params.oper,
        name:params.name,
        rip:params.rip,
        vip:params.vip,
        ids:params.ids,
        id:params.id,
        vlanid:params.vlanid,
        groupid:params.groupid
       }
    })
  }

  loadTrapData(params) {
    return xhr({ 
    	url: '/net_conf/server_trap.php',
    	method: 'POST',
    	body: { 
        oper:params.oper,
        name:params.name,
        target:params.target,
        target_type:params.target_type,
        target_port:params.target_port,
        source_ip:params.source_ip,
        source_port:params.source_port,
        groupid:params.groupid,
        vlanid:params.vlanid,
        ids:params.ids,
        id:params.id
       }
    })
  }
  
  loadTrapWlist(params) {
      return xhr({ 
        url: '/net_conf/server_trap_white.php',
        method: 'POST',
        body: { 
          oper:params.oper,
          target:params.target,
          target_port:params.target_port,
          ids:params.ids,
          id:params.id
       }
    })
  }

  /***************高可靠性*************************/
  getHiRel() {
    return xhr({
      url: 'netmgmt/get?t=30',
      method: 'GET'
    })
  }

  // 配置文件同步，主机信息表同步
  hiRelSync(type) {
    return xhr({ 
			url: `sync/handle?t=${type}`,
      method: 'GET',
      timeout: 5000
		})
  }
  pingRemoteIp(ip) {
    return xhr({ 
			url: 'utils/pingremoteip',
      method: 'POST',
      timeout: 5000,
      body: {ip: ip}
		})
  }
  updateHiRel(params) {
    return xhr({ 
			url: 'netmgmt/update?t=30',
      method: 'POST',
      contentType: 'json',
      body: params
		})
  }
  
}

// 实例化后再导出
export default new NetService()