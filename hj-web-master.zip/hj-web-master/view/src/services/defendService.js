import xhr from './xhr/'

/**
 * 对应后端涉及到用户认证的 API
 */
class defendService {
	getSafePolt(t, params) {
		return xhr({
			url: 'safe/get?t=' + t,
			method: 'get',
			body: params
		})
	}
	addSafePolt (t, params) {
		return xhr({
			url: 'safe/add?t=' + t,
			method: 'post',
			body: params
		})
	}
	editSafePolt (t, params) {
		return xhr({
			url: 'safe/update?t=' + t,
			method: 'post',
			body: params
		})
	}
	delSafePolt (t, params) {
		return xhr({
			url: 'safe/del?t=' + t,
			method: 'post',
			body: params
		})
	}
	getLetIn () {
		return xhr({
			url: 'netmgmt/get?t=28'
		})
	}
	setLetIn (params) {
		return xhr({
			url: 'netmgmt/update?t=28',
			method: 'post',
			body: params
		})
	}
	/*******快速修改备注********/
	setDesc (params) {
		return xhr({
			url: 'safe/add?t=3&quick=true',
			method: 'post',
			body: params
		})
	}

	getHostComputer(params) {	
		return xhr({
			url: '/firewall/honey.php',
			method: 'POST',
			body: {
			  oper:params.oper,
			  abcd:params.ip,//添加
			  vport:params.vport,//添加
			  rport:params.rport,//添加
			  ids:params.ids//删除
			}
		})
	}
	
	getSelfset(params) {
		return xhr({
			url:'/firewall/mac_info.php',
			method:'POST',
			body:{
				oper:params.oper,
				macs:params.macs,
				gid:params.gid,
				desc:params.desc,
				mac:params.mac,
				description:params.description
			}
		})
	}

	hostStap(params) {
		return xhr({
			url:'/firewall/mac_filter.php',
			method:'POST',
			body:{
				oper:params.oper,
				mac:params.mac,
				macs:params.macs,
				mac_filter_switch:params.satus,
				desc:params.desc
			}
		})
	}
	
	getAccessStrategy(params) {
		return xhr({
			url: 'safe/get?t=10',
			method: 'get',
			body: params
		})
	}
	addAccessStrategy(params) {
		return xhr({
			url: 'safe/add?t=10',
			method: 'post',
			contentType: 'json',
			body: params
		})
	}
	updateAccessStrategy(params) {
		return xhr({
			url: 'safe/update?t=10',
			method: 'post',
			contentType: 'json',
			body: params
		})
	}
	deleteAccessStrategy(params) {
		return xhr({
			url: 'safe/del?t=10',
			method: 'post',
			contentType: 'json',
			body: params
		})
	}
	clearCount(params) {
		return xhr({
			url: 'safe/update?t=10&zero=true',
			method: 'post',
			contentType: 'json',
			body: params
		})
		
	}
}
// 实例化后再导出
export default new defendService()