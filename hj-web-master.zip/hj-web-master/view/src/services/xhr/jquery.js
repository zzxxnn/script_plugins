import { rootPath } from './config'
import Vue from 'vue'
import store from 'src/vuex/store'

// [object Object]
function toType (obj) {
  return Object.prototype.toString.call(obj).match(/\s([a-zA-Z]+)/)[1].toLowerCase()
}
// 参数过滤函数
function filterNull (param) {
  for (var key in param) {
    if (param[key] == null) {
      delete param[key]
    }
    if (toType(param[key]) === 'string') {
      param[key] = param[key].trim()
    } else if (toType(param[key]) === 'object') {
      param[key] = filterNull(param[key])
    } else if (toType(param[key]) === 'array') {
      param[key] = filterNull(param[key])
    }
  }
  return param
}

const retry = {}
const retryMax = 3

const xhr = ({ url, body = null, method = 'get', timeout = 100000000, contentType = 'application/x-www-form-urlencoded' }) => {
  const defer = $.Deferred()
  
  const devUrl = rootPath + debugUrl(url)
  const prodUrl = rootPath + url

  body = filterNull(body)  //参数过滤

  if (contentType.toLocaleLowerCase() === 'json') {
    if (method.toLocaleLowerCase() === 'post') {
      body = JSON.stringify(body)
    }
    contentType = 'application/json'
  }

  // 错误提示次数
  if (!retry[url]) {
    retry[url] = 0
  }

  $.ajax({
    type: method,
    url: __DEV__ ? devUrl : prodUrl,
    contentType: contentType,
    dataType: 'json',
    timeout: timeout,
    data: body
  })
  .done(function (res) {
      // 非500 响应，重置retry次数
      retry[url] = 0
      if (Number(res.errcode) === 0) {
        return defer.resolve({...res, errcode: 0})
      } else {
        // 需要登录
        if (Number(res.errcode) === 15005) {
          window.sessionStorage.setItem('login', false)
          store.state.login = false
          store.state.status++
          if (url !== 'session/login' && window.location.pathname !== '/login') {
            setTimeout(() => {
              Vue.prototype.$Modal.error({
                title: '会话超时',
                content: '<a style="color:#fa5555" href="/login">需要登录, 点击登录</a>',
                'mask-closable': false,
                scrollable: false,
                closable: false,
                onOk: () => {
                    window.location.href = '/login'
                }
              })
            }, 250)
          }
        } else {
          let errcode = Number(res.errcode)
          let needTip = (errcode !== 10003 && errcode !== 10004 && errcode !== 15006) 
          
          if (errcode === 10021 && (url === 'utils/ping?t=2' || url === 'utils/traceroute?t=2')) {
            needTip = false
          }
          if (needTip && !store.state.modalFormVisible) {
            setTimeout(() => {
              Vue.prototype.$Modal.error({
                title: '提示',
                content: Vue.prototype.$t('error_code.' + res.errcode),
                scrollable: false
              })
            }, 250)
          }
        }
        return defer.resolve({...res, errcode: Number(res.errcode)})
      }
    })
    .fail(function (res) {
      if (res.statusText === 'timeout') {
        return defer.reject(res)
      }
      let message = '服务异常或者检查网络, 请刷新重试'
      let errcode = res.responseJSON ? res.responseJSON.errcode : res.errcode
      if (errcode) {
        message = Vue.prototype.$t('error_code.' + errcode)
      } 

      // 需要登录
      if (Number(errcode) === 15005) {
        window.sessionStorage.setItem('login', false)
        store.state.login = false
        if (!store.state.modalFormVisible) {
          setTimeout(() => {
            Vue.prototype.$Modal.error({
              title: '提示',
              content: message,
              scrollable: false
            })
          }, 250)
        }
        return defer.reject(res)
      }

      if (/^5\d\d$/.test(res.status)) {
        if (url !== 'utils/checkstart') {
          if (retry[url] < retryMax && !store.state.modalFormVisible) {
            setTimeout(() => {
              Vue.prototype.$Modal.error({
                title: '提示',
                content: message,
                scrollable: false
              })
            }, 250)
            retry[url]++
          }
        }
      } else {
        if (retry[url] < retryMax && !store.state.modalFormVisible) {
          if (url !== 'utils/checkstart') {
            setTimeout(() => {
              Vue.prototype.$Modal.error({
                title: '提示',
                content: message,
                scrollable: false
              })
            }, 250)
          }
          retry[url]++
        }
      }

      return defer.reject(res)
    })

  return defer.promise()
}

function debugUrl (url) {
  let ret = ''
  if (url.indexOf('?') !== -1) {
    ret = url + '&debug=true'
  } else {
    ret = url + '?debug=true'
  }
  return ret
}
export default xhr
