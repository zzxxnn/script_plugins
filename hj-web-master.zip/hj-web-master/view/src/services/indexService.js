import xhr from './xhr/'
/**
 * 对应后端涉及到用户认证的 API
 */
class IndexService {

  // 攻击状态 stats/get?t=15

  // 最近攻击记录 stats/get?t=16&recent=10

  // 活跃终端 stats/get?t=17&limit=5

  // 主机在线 stats/get?t=4

  // 并发连接数 stats/get?t=18

  // 安全域 stats/get?t=21
 
  // 开机时间 stats/get?t=19

  // 运行时间 stats/get?t=20

  // 物理接口状态 stats/get?t=9&orderby=name&order=asc

  // CPU stats/get?t=1

  // 内存 stats/get?t=2

  // 系统版本 stats/get?t=23

  // 系统时间 stats/get?t=24

  // 最近事件记录 stats/get?t=22&recent22=8



  setBlock(params) {
    return xhr({
      url: 'utils/setblock',
      method: 'POST',
      body: params
    })
  }

  getState() {
    return xhr({
      url: 'stats/get?t=15|16|17|18|19|20|21|22|23|24|1|2|4|9&limit=5',
      method: 'get'
    })
  }
}
// 实例化后再导出
export default new IndexService()