import xhr from './xhr/'

/**
 * 对应后端涉及到用户认证的 API
 */
class UserService {

	searchList (filter) {
		return xhr({ 
			url: '/userlist',
			method: 'POST',
			body: filter,
			other: {contentType: 'application/json; charset=utf-8'}
		})
  }

	getUser() {
		return xhr({url:'usermgmt/get'})
	}

	getLoginInfo () {
		return xhr({url:'session/info'})
	}

	addUser(data) {
		return xhr({ 
			url: 'usermgmt/add?t=1',
			method: 'POST',
			body: {
				user: data
			}
		})
	}

	expire(conf) {
		return xhr({ 
			url: '/user/expire.php',
			method: 'POST',
			body: {
				oper:conf.oper,
				conf_value:conf.conf_value,
				is_active:conf.is_active
			}
		})
	}

	updateUser(user) {
		return xhr({ 
			url: 'usermgmt/update?t=1',
			method: 'POST',
			body: {
				user: user
			}
		})
	}

	deleteUser(id) {
		return xhr({ 
			url: 'usermgmt/del?t=1',
			method: 'POST',
			body: {
				ids:id
			}
		})
	}

	changePwd(user) {
		return xhr({ 
			url: 'usermgmt/update?t=2',
			method: 'POST',
			body: {
				pwd: user
			}
		})
	}

	login(username, password) {
		return xhr({
			url: 'session/login',
			method: 'POST',
			body: {
				username: username,
				password: password
			}
		})
	}

	logout() {
		return xhr({ url:'session/logout' })
	}

}

// 实例化后再导出
export default new UserService()