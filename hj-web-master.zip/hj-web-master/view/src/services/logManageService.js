import xhr from './xhr/'

/**
 * 对应后端涉及到用户认证的 API
 */
class logManageService {
	getCheckCount() {
		return xhr({
			url: '/main/check_attack_count.php'
		})
	} //用户威胁次数查看时间

	// 渗透日志
	getPermeateLog({attack_source = '', orderby = '', order = 'desc', page = 1, size = 10, start_time = '', end_time = ''}) {
		return xhr({
			url: `logs/get?t=1&attack_source=${attack_source}&orderby=${orderby}&order=${order}&page=${page}&row=${size}&start_time=${start_time}&end_time=${end_time}`,
			method: 'get'
		})
	}

	// 固定攻击源概况
	getPermeateLogByMac({attack_source = '', orderby = '', order = 'desc', page = 1, size = 10}) {
		return xhr({
			url: `logs/get?t=2&attack_source=${attack_source}&orderby=${orderby}&order=${order}&page=${page}&row=${size}`,
			method: 'get'
		})
	}

	/***********日志服务器*************/
	getServer(page,row) {
		return xhr({
			url: 'sysconf/get?t=7',
			method: 'GET',
			body: {
				page: page,
				row: row,
			}
		})
	}

	addServer(conf){
		return xhr({
			url:'sysconf/add?t=7',
			method:'POST',
			body:{
				'7':conf
			}
		})
	}

	delServer(ids){
		return xhr({
			url:'sysconf/del?t=7',
			method:'POST',
			body:{
				'7':ids
			}
		})
	}

	editServer(conf){
		return xhr({
			url:'sysconf/update?t=7',
			method:'POST',
			body:{
				'7':conf
			}
		})
	}
/*************封堵解封*****************/
getUnblockLog(order,by,page,row,type,params) {
	return xhr({
		url: 'logs/get?t=8',
		method: 'GET',
		body: {
			order:order,
			orderby:by,
			page:page,
			row:row,
			type:type,

			source:params.source,
			start_time:params.start_time,
			end_time:params.end_time,
		}
	})
}

/************IP变换/主机日志上下线******** */
getTerminalLog(order,by,page,row,t,params) {
	return xhr({
		url: `logs/get?t=${t}`,
		method: 'GET',
		body: {
			
			order:order,
			orderby:by,
			page:page,
			row:row,

			groupid:params.groupid,
			mac:params.mac,
			start_time:params.start_time,
			end_time:params.end_time,
		}
	})
}
//详情
getDetail(id,order='',by='',page=1,row=10){
	return xhr({
		url: 'logs/get?t=6',
		method: 'GET',
		body: {
			order:order,
			orderby:by,
			page:page,
			row:row,
			log_id:id,
		}
	})
}

	getStatistic({subt = 1, attack_source = '', limit = 10}) {
		return xhr({
			url: `logs/get?t=4&subt=${subt}&attack_source=${attack_source}&limit=${limit}`,
			method: 'get'
		})
	}

	getStatisticDetail({log_id = '', orderby = '', order = 'desc', page = 1, size = 10}) {
		return xhr({
			url: `logs/get?t=3&log_id=${log_id}&orderby=${orderby}&order=${order}&page=${page}&row=${size}`,
			method: 'get'
			// body:{
			// 	detail:true,
			// 	phy_port:data.phy_port,
			// 	macip:data.macip,
			//     type:data.type,
			// 	end_time:data.end_time,
			// 	page:data.page
			// }
		})
	}

	getOrderLog(params) {
		return xhr({
			url: 'logs/get',
			method: 'get',
			body: params
		})
	}
	
	getEventLog(params) {
		return xhr({
			url: 'logs/get',
			method: 'get',
			body: params 
		})
	}

	// 清空渗透日志
	clearPermeateLog() {
		return xhr({
			url: 'logs/clear?t=1',
			method: 'get'
		})
	}

	// 清空主机日志
	clearTerminalLog(type) {
		return xhr({
			url: `logs/clear?t=${type}`,
			method: 'get'
		})
	}

	// 清空操作日志
	clearOrderLog() {
		return xhr({
			url: 'logs/clear?t=9',
			method: 'get'
		})
	}

	// 清空封堵解封日志
	clearUnblockLog(type) {
		return xhr({
			url: `logs/clear?t=8&type=${type}`,
			method: 'get'
		})
	}

	// 清空事件日志
	clearEventLog() {
		return xhr({
			url: 'logs/clear?t=10',
			method: 'get'
		})
	}

}

// 实例化后再导出
export default new logManageService()