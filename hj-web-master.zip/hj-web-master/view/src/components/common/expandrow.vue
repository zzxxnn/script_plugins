<template>
    <div class="wrap" id="expandrow">    
        <div class="table_wrap">
            <table>               
                <tbody>
                    <tr>
                        <td style="width:20%">渗透目标</td>
                        <td style="width:18%">协 议</td>
                        <td style="width:40%;">端 口</td>
                        <td style="width:22%">时 间</td>
                    </tr>
                    <tr v-for='(item, index) in table' :key="index">
                        <td style="width:20%">{{item.target_ip}}</td>
                        <td style="width:18%">{{item.target_protocol}}</td>
                        <td style="width:40%;">{{item.target_port == 0 ? '-' : item.target_port}} {{showPort(item.target_port)}}</td>
                        <td style="width:22%">{{item.attack_time}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <Page :total="Number(num)"  size="small" :page-size="10" @on-change = "getData" ></Page>
    </div>
</template>
<script>
    import attackType from 'libs/attackType'
    export default{
        props:{
            table: {
                required: true
            },
            num: {            
                required: true
            },
        },
        methods:{
            getData(page) {
                this.$emit("pageData",page)
            },
            showPort(value) {
                if (value==0) {
                    return ''
                }
                let val = attackType.value(value)
                if (val!=null) {
                    val = "( "+val+" )"
                } else {
                    val =''
                }
                return val
            }
        }
    }
</script>