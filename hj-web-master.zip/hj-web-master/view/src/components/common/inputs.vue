<template>  
    <div style="display: inline-block">
        <!--正常输入框-->
        <template v-if="type === 'text'">
            <input type="text" :class="text_class" :style="inputStyle" :disabled='disabled' v-model="edit_val" @focus="noEmpty($event)" @blur="sentval(edit_val, $event)">
        </template>
        <!-- 下拉框 -->
        <template v-else-if="type === 'select'">
            <select v-model="edit_val" :class="text_class" @change="sentval(edit_val, $event)" @blur="sentval(edit_val, $event)">
                <option v-for="(item, index) in emums" :selected="index === 0" :value="item" :key="index" >
                  {{item}}
                </option>
            </select>
        </template>
        <!-- textarea -->
        <template v-else-if="type === 'textarea'">
            <textarea rows="4" :class="text_class" v-model="edit_val" :style="inputStyle" @blur="sentval(edit_val, $event)"></textarea>
        </template>
        <!-- IP输入框 -->
        <template v-else-if="type === 'ipinput'">
            <div class="input_wrap">     
                <input v-model="ips.a" maxlength="3" class="ip_input" type="number" @keyup="upnext($event)" @keydown="nextInput($event)" @change="getIPVal($event)"  @focus = "focusStyle($event)" @paste = "copy($event)"> . 
                <input v-model="ips.b" maxlength="3" class="ip_input" type="number" @keyup="upnext($event)" @keydown="nextInput($event)" @change="getIPVal($event)"  @focus = "focusStyle($event)"> . 
                <input v-model="ips.c" maxlength="3" class="ip_input" type="number" @keyup="upnext($event)" @keydown="nextInput($event)" @change="getIPVal($event)"  @focus = "focusStyle($event)"> .
                <input v-model="ips.d" maxlength="3" class="ip_input" type="number" @keyup="upnext($event)" @keydown="nextInput($event)" @change="getIPVal($event)"  @focus = "focusStyle($event)">
            </div>
        </template>  
        <!-- mac输入框 -->
        <template v-else-if="type === 'macinput'">
             <div class="input_wrap">
                <input v-model="macs.a" maxlength="2" class="mac_input" type="text" @keydown="nextInput($event)" @keyup="upnext($event)" @change = "getMacVal($event)" @focus = "focusStyle($event)"  @paste = "copy($event)" > : 
                <input v-model="macs.b" maxlength="2" class="mac_input" type="text" @keydown="nextInput($event)" @keyup="upnext($event)" @change = "getMacVal($event)" @focus = "focusStyle($event)"> : 
                <input v-model="macs.c" maxlength="2" class="mac_input" type="text" @keydown="nextInput($event)" @keyup="upnext($event)" @change = "getMacVal($event)" @focus = "focusStyle($event)"> :
                <input v-model="macs.d" maxlength="2" class="mac_input" type="text" @keydown="nextInput($event)" @keyup="upnext($event)" @change = "getMacVal($event)" @focus = "focusStyle($event)"> :
                <input v-model="macs.e" maxlength="2" class="mac_input" type="text" @keydown="nextInput($event)" @keyup="upnext($event)" @change = "getMacVal($event)" @focus = "focusStyle($event)"> :
                <input v-model="macs.f" maxlength="2" class="mac_input" type="text" @keydown="nextInput($event)" @keyup="upnext($event)" @change = "getMacVal($event)" @focus = "focusStyle($event)">
            </div>	
        </template>
        <!-- checkBox -->
        <template v-else-if="type === 'checkinput'">
            <div style="display: flex;align-items: center;">
                <div v-for="(item ,index) in emums" style="margin-right: 10px;" :key="index">
                    <input type="checkbox" :disabled='disabled' :checked="checkCheckedStatus(item.value)" @change="changecheckVal(item.value, $event)">
                    <span :style="disabled ? 'color:#e2e2e2' : ''">{{item.label}}</span>
                </div> 
            </div>                
        </template>
        <!-- 特殊IP -->
        <template v-else-if="type === 'sipinput'">  
            <div class="input_wrap" style="width: 220px;">
                <input v-model="sips.a" maxlength="3" class="ip_input" type="number" @keyup="upnext($event)" @keydown="nextInput($event)" @change="getSIPVal($event)"  @focus="focusStyle($event)" @paste="copy($event)"> . 
                <input v-model="sips.b" maxlength="3" class="ip_input" type="number" @keyup="upnext($event)" @keydown="nextInput($event)" @change="getSIPVal($event)"  @focus="focusStyle($event)"> . 
                <input v-model="sips.c" maxlength="3" class="ip_input" type="number" @keyup="upnext($event)" @keydown="nextInput($event)" @change="getSIPVal($event)"  @focus="focusStyle($event)"> .
                <input v-model="sips.d" maxlength="3" class="ip_input" type="number" @keyup="upnext($event)" @keydown="nextInput($event)" @change="getSIPVal($event)"  @focus="focusStyle($event)">/
                <input v-model="sips.e" maxlength="2" class="ip_input" type="number" @keyup="upnext($event)" @keydown="nextInput($event)" @change="getSIPVal($event)" @focus="focusStyle($event)">
            </div>
        </template>
        <!-- 日志 -->
        <template v-else-if="type === 'logs'">
            <div>
                <ul class="logLabel">
                    <li>
                        <label class="labels">日志类型：</label>									
                        <span class="line"></span>									
                        <input :disabled="disabled" style="margin-left: 10px;" type="checkbox" :checked="checkAllStatus"  @click='checkedall($event)' />
                        <label style=" font-weight: 500; margin-left: 3px;">全选</label>
                        <span class="mi">（* 不能少于一种）</span>	
                    </li>													
                </ul>
                <ul class="logs">
                    <li>
                        <input type="checkbox" :disabled="disabled" :checked="String(this.logs).indexOf(1)>=0" @change="logsVal('1',$event)"/>
                        <label >渗透日志</label>
                    </li>
                    <li>
                        <input type="checkbox"  :disabled="disabled" :checked="String(this.logs).indexOf(4)>=0"  @change="logsVal('4',$event)"/>
                        <label >主机下线日志</label>
                    </li>
                    <li>
                        <input type="checkbox"  :disabled="disabled" :checked="String(this.logs).indexOf(5)>=0"  @change="logsVal('5',$event)"/>
                        <label>封堵日志</label>
                    </li>
                    <li>
                        <input type="checkbox"  :disabled="disabled" :checked="String(this.logs).indexOf(6)>=0"  @change="logsVal('6',$event)"/>								
                        <label >解封日志</label>
                    </li>							
                    <br/>							
                    <li>
                        <input type="checkbox"  :disabled="disabled"  :checked="String(this.logs).indexOf(8)>=0" @change="logsVal('8',$event)"/>
                        <label >命令日志</label>
                    </li>
                    <li>
                        <input type="checkbox"  :disabled="disabled" :checked="String(this.logs).indexOf(7)>=0" @change="logsVal('7',$event)"/>								
                        <label >主机变换日志</label>
                    </li>								
                    <li>
                        <input type="checkbox"  :disabled="disabled" :checked="String(this.logs).indexOf(9)>=0" @change="logsVal('9',$event)"/>					
                        <label >事件日志</label>
                    </li>
                </ul>		
            </div>      
        </template>
    </div>  		
</template>
<script>
import formatTest from 'libs/formatTest'
export default {
     props: {
       type: {
           type: String
       },
       required: {
           type: Boolean,
       },
       special: {
           type: Boolean
       },
       name: {
           type: String,
       },
       regex: {},
       emums: {
           type: Array,
       },
       val: {},
       disabled: {},
       id: {},
       index: {},
       inputStyle: {
           type: String,
           default: ''
       }
    },
    data() {
        return { 
            edit_val: this.val,
            text_class: 'normal',
            checkbox_val: (this.val && this.type=='checkinput') ?
                String(this.val).split(",") : [],
            ips: this.val && this.type == 'ipinput' ? {
                a: this.val.split('.')[0], 
                b: this.val.split('.')[1],
                c: this.val.split('.')[2],
                d: this.val.split('.')[3]
            } : { a: '', b: '', c: '', d: ''},
            sips: this.val && this.type == 'sipinput' ? {
                a: this.val.split('.')[0], 
                b: this.val.split('.')[1],
                c: this.val.split('.')[2],
                d: this.val.split('.')[3].split('/')[0],
                e: this.val.split('.')[3].split('/')[1]
            } : { a: '', b: '', c: '', d: '',e: ''},
            macs: this.val && this.type == 'macinput' ? {
                a: this.val.split(':')[0],
                b: this.val.split(':')[1],
                c: this.val.split(':')[2],
                d: this.val.split(':')[3],
                e: this.val.split(':')[4],
                f: this.val.split(':')[5]
                } : {a: '',b: '',c: '',d: '',e: '',f: ''},
            logs: this.val&&this.type=='logs' ? this.val.split(',') : []
        }
    },
    mounted () {
        this.bus.$on('resetEditVal', () => {
            this.edit_val = ''
            this.text_class = 'normal'
        })
        // if (this.type === 'select' && this.edit_val === undefined) {
        //     if (typeof this.emums[0] === 'object') {
        //         this.edit_val = this.emums[0].value
        //     } else {
        //         this.edit_val = this.emums[0]
        //     }
            
        // }
    },
    watch:{
        val() {   
            this.edit_val = this.val
            this.checkbox_val = (this.val && this.type === 'checkinput') ?
                String(this.val).split(",") : []
            if (this.type=='ipinput') {
                this.putIPVal(this.edit_val)
            } else if (this.type=='sipinput') {
                this.putSIPVal(this.edit_val)
            } else if (this.type=='macinput') {
                this.putMacVal(this.edit_val)
            } else if (this.type=='logs') {
                this.logs = this.val&&this.type=='logs'?this.val.split(',') : []
            }
        }
    },
    computed:{
        checkAllStatus() {  
            return this.logs.length >= 7
        },
    },
    methods:{
        logsVal(val,event) {
            let nohas = true        
            for(let [k,v] of this.logs.entries()) {
                if (v==val) {
                   this.logs.splice(k,1)
                   nohas = false
                }
            }
            if (nohas) {       
                this.logs = [...this.logs,val]
            } 
            let log_str = this.logs.join(',')
            this.sentval(log_str,event)
        },
        checkedall(event) {
            if (this.logs.length<7) {
                this.logs = ['1','4','5','6','7','8','9']
            } else {
                this.logs = []
            }   
            let log_str = this.logs.join(',')  
            this.sentval(log_str,event)
        },
        checkCheckedStatus(val) {  
           return this.checkbox_val.indexOf(val) !== -1
        },
        changecheckVal(val, event) {
            let index = this.checkbox_val.indexOf(val) 
            if (index !== -1) {
                this.checkbox_val.splice(index, 1)
            } else {
                this.checkbox_val.push(val)
            }
            this.sentval(this.checkbox_val.join(','), event)
        },
        sentval(val, event) {
            let ele = null
            if (typeof val == 'string') {
                val = val && val.replace(/\r\n/g, '').replace(/\n/g, '')
            }
            if (this.type=='ipinput'||this.type=='macinput'||this.type=='sipinput') {
                ele =  $(event.currentTarget).parent()
                if (val==':::::'||val=='...'||val=='.../') {
                    val =""
                }
            } else if (this.type=='checkinput') {
                ele =  null
            } else {
                ele =  $(event.currentTarget)
            }
            let format = this.testFormat(val, ele)
            this.$emit('getVal',this.name, val, format, this.id)
        },
        testFormat(val, ele) {
            // 为空情况，判断是否必填
            if (val == null || val === '') {
                if (this.required) {
                    this.text_class = 'normal error_foramt animated shake'
                    setTimeout(() => {
                        this.text_class = 'normal error_foramt'
                    }, 200)
                    // if ($(ele).parent().parent().find('.mi').length) {
                    //     $(ele).parent().parent().find('.mi').css('color', '#b63039')
                    // } else {
                    //     $(ele).parent().parent().parent().find('.mi').css('color', '#b63039')
                    // }
                    return false
                } else {
                    this.text_class = 'normal'
                    return true
                }
            }

            if (val === '0.0.0.0') {
                this.text_class = 'normal error_foramt animated shake'
                setTimeout(() => {
                    this.text_class = 'normal error_foramt'
                }, 200)
                return false
            }

            if (this.regex == null || this.regex.test(val)) {
                if (typeof val == 'string' && val.indexOf('/') !== -1) {
                    let ips = val.split('/')
                    let ip = ips[0]
                    let mask = ips[1]

                    if (this.name == 't_ip_mac' || this.name == "v_ip") {
                        if (ip == '0.0.0.0' || mask == 0) {
                            this.text_class = 'normal error_foramt animated shake'
                            setTimeout(() => {
                                this.text_class = 'normal error_foramt'
                            }, 200)
                            return false
                        }
                    }
                }

                if (this.name == 't_port') {
                    
                    if (val.split(',').length > 10) {
                        this.text_class = 'normal error_foramt animated shake'
                        setTimeout(() => {
                            this.text_class = 'normal error_foramt'
                        }, 200)
                        return false
                    }
                    let valArr = val.split(",")
                    let ret = true
                    for(let i = 0; i < valArr.length; i++) {
                        if (valArr[i].indexOf(':') != -1) {
                            let portArr = valArr[i].split(":")
                            let p1 = Number(portArr[0])
                            let p2 = Number(portArr[1])		
                            if (p1 >= p2 || p1 > 65535 || p2 > 65535) {
                                this.text_class = 'normal error_foramt animated shake'
                                setTimeout(() => {
                                    this.text_class = 'normal error_foramt'
                                }, 200)
                                ret = false
                                break
                            }
                        } else {
                            if (valArr[i] > 65535) {
                                this.text_class = 'normal error_foramt animated shake'
                                setTimeout(() => {
                                    this.text_class = 'normal error_foramt'
                                }, 200)
                                ret = false
                                break
                            }
                        }
                    }
                    if (!ret) return ret
                }


                if (this.name == 'gid') {
                    if (/^0(\d)+$/.test(val)) {
                        this.text_class = 'normal error_foramt animated shake'
                        setTimeout(() => {
                            this.text_class = 'normal error_foramt'
                        }, 200)
                        return false
                    }
                }

                if (typeof val == 'string' && val.indexOf('-') !== -1) {
                    let ips = val.split('-')
                    let ip1 = Number(ips[0].replace(/\./g, ''))
                    let ip2 = Number(ips[1].replace(/\./g, ''))

                    if (this.name == 't_ip_mac'  || this.name == "v_ip") {
                        if (ips[0] == '0.0.0.0' || ips[1] == '0.0.0.0') {
                            this.text_class = 'normal error_foramt animated shake'
                            setTimeout(() => {
                                this.text_class = 'normal error_foramt'
                            }, 200)
                            return false
                        }
                    }
                    // 可能还有备注中包含-, 这里只能是IP范围这种情况
                    if (!Number.isNaN(ip1) && !Number.isNaN(ip2)) {
                        let ip1Nums = ips[0].split('.')
                        let ip11 = Number(ip1Nums[0])
                        let ip12 = Number(ip1Nums[1])
                        let ip13 = Number(ip1Nums[2])
                        let ip14 = Number(ip1Nums[3])

                        let ip2Nums = ips[1].split('.')
                        let ip21 = Number(ip2Nums[0])
                        let ip22 = Number(ip2Nums[1])
                        let ip23 = Number(ip2Nums[2])
                        let ip24 = Number(ip2Nums[3])

                  
                        if (!((ip11 < ip21) || 
                            (ip11 == ip21 && ip11 < ip22) ||
                            (ip11 == ip21 && ip12 == ip22 && ip13 < ip23) ||
                            (ip11 == ip21 && ip12 == ip22 && ip13 == ip23 && ip14 < ip24))
                        ) {
                            this.text_class = 'normal error_foramt animated shake'
                            setTimeout(() => {
                                this.text_class = 'normal error_foramt'
                            }, 200)
                            return false
                        }
                    }
                }
                this.text_class = 'normal'
                return true
            }
            this.text_class = 'normal error_foramt animated shake'
            setTimeout(() => {
                this.text_class = 'normal error_foramt'
            }, 200)

            return false
        },
        noEmpty(event) {
            this.text_class = 'normal'
            // let ele = $(event.currentTarget)
            // if ($(ele).parent().parent().find('.mi').length) {
            //     $(ele).parent().parent().find('.mi').css('color', '#d2d2d2')
            // } else {
            //     $(ele).parent().parent().parent().find('.mi').css('color', '#d2d2d2')
            // }
        },
        putIPVal(val) {
           if (!val) {
                this.ips.a = ''
                this.ips.b = ''
                this.ips.c = ''
                this.ips.d = ''
                return
           }
           let val_arr = val.split('.')
           this.ips.a = val_arr[0]
           this.ips.b = val_arr[1]
           this.ips.c = val_arr[2]
           this.ips.d = val_arr[3]
        },
        putSIPVal(val) {
            if (!val) {
                this.sips.a = ''
                this.sips.b = ''
                this.sips.c = ''
                this.sips.d = ''
                this.sips.e = ''
                return
           }
           let val_arr = val.split('.')
           this.sips.a = val_arr[0]
           this.sips.b = val_arr[1]
           this.sips.c = val_arr[2]
           this.sips.d = val_arr[3].split('/')[0]
           this.sips.e = val_arr[3].split('/')[1]
        },
        putMacVal(val) {
           if (!val) {
               this.macs.a = ''
                this.macs.b = ''
                this.macs.c = ''
                this.macs.d = ''
                this.macs.e = ''
                this.macs.f = ''
                return
           }
           let val_arr = val.split(':')
           this.macs.a = val_arr[0]
           this.macs.b = val_arr[1]
           this.macs.c = val_arr[2]
           this.macs.d = val_arr[3]
           this.macs.e = val_arr[4]
           this.macs.f = val_arr[5]
        },
        getIPVal(event) {
            let ip_val = this.ips.a +"."+this.ips.b+"."+this.ips.c+"."+this.ips.d 
            this.sentval(ip_val,event)   
        },
        getSIPVal(event) {
            let ip_val = this.sips.a +"."+this.sips.b+"."+this.sips.c+"."+this.sips.d+"/"+ this.sips.e
            this.sentval(ip_val,event)   
        },
        getMacVal($event) {
            let mac_val = this.macs.a+":"+this.macs.b+":"+this.macs.c+":"+this.macs.d+":"+this.macs.e+":"+this.macs.f
            this.sentval(mac_val,event)
        },
        focusStyle(event) {
          let parent=  $(event.currentTarget).parent()
          parent.removeClass("error_foramt")
        },
        copy(event) {
            event.preventDefault()
            let content =  $('.copyText').html()
            if (this.type =="ipinput") {
                this.putIPVal(content)
                this.getIPVal(event)
            } else if (this.type=="macinput") {
                this.putMacVal(content)
                this.getMacVal(event)
            }
        },
        nextInput(event) {            
            if ((this.type=='ipinput'&&event.keyCode==69)||event.keyCode==229) {
                 event.preventDefault()        
             } //不能输入字母e            
            if (event.keyCode==110||event.keyCode==190) {//.
               event.preventDefault()
               let val = $(event.currentTarget).val() 
               if (val) {
                   $(event.currentTarget).next().focus() 
                   $(event.currentTarget).next().select()
               }
            } 
            if (event.keyCode==39) {//right
               event.preventDefault()
               $(event.currentTarget).next().focus() 
               $(event.currentTarget).next().select()
            } 
            if (event.keyCode==37) {//left
                event.preventDefault()
               $(event.currentTarget).prev().focus()
               $(event.currentTarget).prev().select()    
            } 
            if ($(event.currentTarget).val().length==0&&event.keyCode==8) {//backspace
                event.preventDefault()
                $(event.currentTarget).prev().focus()  
                $(event.currentTarget).prev().select() 
                return     
            }
            $(event.currentTarget).val($(event.currentTarget).val().slice(0,3))
        },
        upnext(event) {   //自动下一个
            let max_long = false
            if (this.type=='macinput') {
               max_long = $(event.currentTarget).val().length > 1
            } else {
               max_long = $(event.currentTarget).val().length > 2
            }             
            if (max_long && (event.keyCode != 37) && (event.keyCode != 39) && (event.keyCode != 8)) {
                $(event.currentTarget).next().focus()   
                $(event.currentTarget).next().select() 
                $(event.currentTarget).val($(event.currentTarget).val().slice(0,3))
                return    
            }   
            
        },

    }
}

</script>
<style scoped lang="less">
.normal,select,textarea{
    width: 150px;  
    border: 1px solid #e8e8e8;
    border-radius: 3px;
    box-sizing: border-box;
    padding: 0 10px;
}
textarea{
    resize: vertical;
    max-height: 500px;
}
input.normal,select{
    height: 25px;
}
.error_foramt{
    border: 1px solid #b63039;
}
/*日志类型*/
.line {
    border-left: 1px solid #E0E0E0;
    height: 15px;
    vertical-align: middle;
}
.logs {
    display: flex;
    vertical-align: top;
    margin-left: 70px;
    margin-top: 10px;
    width: 600px;
    flex-wrap: wrap;
}
.logs label {		
    font-weight: 500;
    margin-left: 3px;	
}
.logs li {
    display: flex;
    align-items: center;
    border: 1px solid #E2E2E2;
    border-radius: 3px;
    padding: 4px 10px;
    margin: 0 40px 20px 0;
}
</style>