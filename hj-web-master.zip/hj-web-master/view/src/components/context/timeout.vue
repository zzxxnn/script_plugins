<template>
	<div class="modal" id="timeout"  aria-hidden="true" data-backdrop="static">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h3 class="modal-title" id="myModalLabel">登录超时</h3>
				</div>
				<div class="modal-body">
					<img src="../img/cry.png"/>
					<span sytle="margin-left: 10px;font-size: 16px">WebUI超时，请重新登录</span>
				</div>
				<div class="modal-footer">
				    <button class="sure-btn button button--aylen" @click="jumpTo()" data-dismiss="modal">确定</button>									
				</div>
			</div>
		</div>
	</div>
</template>
<script>
	import userService from 'services/userService'
	export default {
		methods: {
			jumpTo: function() {
				this.$store.commit('EDIT_LOGIN', {"is_login":false, "username":null, "user_group":null, "windows":false})
				this.$router.push('/login')
		    } 
		}
	}
</script>