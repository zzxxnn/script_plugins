<template>
		<div  class="container current-wrap">
	    <div class="row">
	      <leftnavbar :menudata='menudata' class="navBar col-sm-2 col-md-2 col-lg-2"  :screen_with = "screen_with" :class="[screen_with != 'big'?'samll_width':'']" @comeOut="comeOut" @goIn="goIn"></leftnavbar>
	      <div class="view col-sm-10 col-md-10 col-lg-10" :class="[screen_with == 'small'?'small_content':screen_with == 'mid'?'mid_content':'']">
	        <router-view></router-view>
	      </div>
	    </div>
	  </div>
</template>
<script>		
  import leftnavbar from 'src/components/navbar/leftbar.vue'
  export default {
    components: {
      leftnavbar
    },
     data() {
    	return{
    		screen_with:'',
				menudata:[
					{
						name:'全局配置',
						path:'/network/global',
						img:'/static/img/globalconf.png'
					},

					{
						name:'网络配置',
						path:'/network/rip',
						img:'/static/img/ripconf.png',
						children:[
							{
								name:'内部IP配置',
								path:'/network/rip'
							},
							
							{
								name:'动态IP配置',
								path:'/network/vip'
							},
							
							{
								name:'外部IP配置',
								path:'/network/wip'
							},
							
							{
								name:'虚拟网络配置',
								path:'/network/vnetwork'
							},
							
							{
								name:'虚假响应配置',
								path:'/network/virtual_response'
							}
						]
					},

					{
						name:'静态地址',
						path:'/network/static_wip',
						img:'/static/img/staticaddr.png'
					},
					
					{
						name:'静态路由',
						path:'/network/static_route',
						img:'/static/img/staticroute.png'
					},
					
					{
						name:'主机透传',
						path:'/network/host_passthrough',
						img:'/static/img/trunk.png'
					},
					
					// {
					// 	name:'协议透传',
					// 	path:'/network/proto_passthrough',
					// 	img:'/static/img/agreement.png'
					// },

					{
						name:'软件bypass',
						path:'/network/bypass',
						img:'/static/img/softbypass.png'
					},

					{
						name:'高可靠性',
						path:'/network/ha',
						img:'/static/img/globalconf.png'
					}
				]
    	}
    },
    created() {
      this.getScreenWidth()
      let _this = this
      $(window).resize(function() {
      	  _this.getScreenWidth()
      })
    },
    methods: {
    	getScreenWidth() {
      	let  screen_with = $(window).width()
      	if (screen_with>1470) {
      		this.screen_with = 'big'
      	} else if (screen_with<=1470&&screen_with>1280) {
      		this.screen_with = 'mid'
      	} else {
      		this.screen_with = 'small'     	
      	}
      },
			comeOut() {
			  $('.samll_width').addClass('out').removeClass('in')
			},
			goIn() {
				$('.samll_width').addClass('in').removeClass("out")
			}
		}
  }
</script>
<style scoped>
.container{
	height: 100%;
}
.un_accredit{
	width: 1240px;
}
.row{
	height: 100%;
}
.current-wrap{
  min-width: 1500px;
}
.view,.navBar{
   display: inline-block;
   vertical-align: top;
}
.view{
	margin-bottom: 60px;
}
.samll_width{
	position: relative;
	z-index: 10;
	left: -220px;
	transition: 0.5s;
}
.small_content{
	margin-left: -250px;
}
.mid_content{
	margin-left: -200px;
} 
.in{
	left:-220px;
}
.out{
	left:-20px;
}
</style>
