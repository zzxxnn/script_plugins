<template>
  <!-- 高可靠性 -->
  <div class="ha wrap">
    <div class="page-title">
      <h3>高可靠性</h3>
    </div>
    <div class="table-wrap">
      <table>
        <thead class="thead-bottom-line">
          <tr>
            <th style="width: 1200px;" colspan="4">
              配置
              <ul class="titile-butn">
                <li @click.stop="submit()">
                  <img style="vertical-align: -2px;" :src="`/static/${themeColor}-img/bule_sure.png`">
                  <span>确定</span>
                </li>
              </ul>
            </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="padding-left:20px;font-weight:bold;">基础配置</td>
          </tr>
          <tr>
            <td>
              <div>
                <div class="conf-item">
                  <label>同步端口：</label>
                  <div>
                    <RadioGroup v-model="formData.mgt" @on-change="mgtChange">
                      <Radio label="MGT1"></Radio>
                      <Radio label="MGT2"></Radio>
                      <Radio label="无"></Radio>
                    </RadioGroup>
                  </div>    
                </div>

                <div class="conf-item"> 
                  <label>本机地址：</label>
                  <div>
                    <span style="margin-right:30px;height:24px;">
                      {{formData.localIp[formData.mgt]}}
                    </span>
                    <span class="mi">提示：确定好配置端口后，先到系统配置-全局配置里边配置对应接口IP地址，再回到本页面进行其它配置</span>
                  </div>              
                </div>

                <div class="conf-item">
                  <label>对端地址：</label>
                  <div>
                    <input
                      :class="[remoteipCls, 'num-input']"
                      v-model="formData.remoteIp" 
                      :disabled="formData.mgt == '无'"
                      style="width: 125px;"
                      @blur="checkData">
                    <Button style="margin-left:15px" @click="handlePingRemoteIp" :loading="remoteIpTesting" :disabled="formData.mgt == '无'">
                      <span v-if="!remoteIpTesting">测试</span>
                      <span v-else>正在测试中...</span>
                    </Button>
                  </div>
                </div>

                <div class="conf-item"> 
                  <label>本机心跳间隔：</label>
                  <div>
                    <input 
                      :class="[heartbeat_cls, 'num-input']"
                      v-model="formData.heartbeat"
                      style="width: 80px;"
                      @blur="checkData">(1-120s)
                  </div>      
                </div>

                <div class="conf-item">
                  <label>对端心跳超时：</label>
                  <div>
                    <input 
                      :class="[ttlCls, 'num-input']"
                      v-model="formData.ttl"
                      style="width: 80px;"
                      @blur="checkData">(1-300s)
                  </div>
                </div>

                <div class="conf-item">
                  <label>自动同步开关：</label>
                  <div class="on_off_but">              
                    <button @click.stop="switchStatus('synswitch', 1)" :class="{'btn-active': formData.synswitch}" class="on_but">启用</button>
                    <button @click.stop="switchStatus('synswitch', 0)" :class="{'btn-active': !formData.synswitch}" class="off_but">禁用</button>
                  </div>
                </div>

                <div class="conf-item">
                  <label>端口伴随开关：</label>
                  <div class="on_off_but">              
                    <button @click.stop="switchStatus('ports_follow_switch', 1)" :class="{'btn-active': formData.ports_follow_switch}" class="on_but">启用</button>
                    <button @click.stop="switchStatus('ports_follow_switch', 0)" :class="{'btn-active': !formData.ports_follow_switch}" class="off_but">禁用</button>
                  </div>
                </div>

                <div class="conf-item">
                  <label>端口监测：</label>
                  <div class="on_off_but">              
                    <button @click.stop="switchStatus('ethswitch', 1)" :class="{'btn-active': formData.ethswitch}" class="on_but">启用</button>
                    <button @click.stop="switchStatus('ethswitch', 0)" :class="{'btn-active': !formData.ethswitch}" class="off_but">禁用</button>
                  </div>
                </div>

                <div class="conf-item" v-if="formData.ethswitch">
                  <label style="vertical-align:top">监听端口：</label>
                  <div> 
                    <div style="display:flex;justify-content:space-around">
                      <div class="monitor-list-wrap">
                        <ul class="monitor-list">
                          <li class="monitor-item left-eth-item" 
                              v-for="(item, index) in this.originData.avail_eths" 
                              :key="index" 
                              @click.prevent="((evt) => { handleSelectLeftEth(evt, item) })">
                            <p>{{item}}</p>
                          </li>
                        </ul>
                      </div>

                      <div style="display:flex;flex-direction:column;justify-content:center;align-items:center;margin:0 20px;"> 
                        <Button style="margin-bottom: 20px;" @click="handleAddEth">增加</Button>
                        <Button @click="handleRemoveEth">移除</Button>
                      </div>

                      <div :class="[monitorCls, 'monitor-list-wrap']">
                        <ul class="monitor-list">
                          <li class="monitor-item right-eth-item" 
                              v-for="(item, index) in this.formData.eth_monitor" 
                              :key="index" 
                              @click.prevent="((evt) => { handleSelectRightEth(evt, item) })">
                            <p>{{item}}</p>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </td>
          </tr>
          
          <tr>
            <td style="padding-left:20px;font-weight:bold;">高级配置</td>
          </tr>
          <tr>
            <td>
              <div class="conf-item">
                <label>高级配置开关：</label>
                <div class="on_off_but">              
                  <button @click.stop = "switchStatus('gaojiswitch', 1)" :class="{'btn-active': formData.gaojiswitch}" class="on_but">启用</button>
                  <button @click.stop = "switchStatus('gaojiswitch', 0)" :class="{'btn-active': !formData.gaojiswitch}" class="off_but">禁用</button>
                </div>
              </div>
              <div class="conf-item" v-show="formData.gaojiswitch">
                <label></label>
                <div>              
                  <RadioGroup v-model="formData.mode" @on-change="modeChange">
                    <Radio label="STP"></Radio>
                    <Radio label="MSTP"></Radio>
                  </RadioGroup>
                </div>
              </div>
              <div class="conf-item" v-if="formData.gaojiswitch && formData.mode == 'STP'">
                  <label>优先级：</label>
                  <div>
                    <input 
                      :class="[priorityCls, 'num-input']"
                      v-model="formData.stp.priority"
                      style="width: 80px;"
                      @blur="checkData">(1-255)
                  </div>
                </div>
              <div class="conf-item" v-if="formData.gaojiswitch && formData.mode == 'MSTP'">
                <label style="vertical-align:top">VLAN：</label>
                <div> 
                    <div style="display:flex;justify-content:space-around">
                      <div class="monitor-list-wrap">
                        <ul class="monitor-list">
                          <li class="monitor-item left-vlan-item" 
                              v-for="(item, index) in this.originData.avail_vlans" 
                              :key="index"
                              @click.prevent="((evt) => { handleSelectLeftVlan(evt, item) })">
                            <p>{{`VLAN ${item}`}}</p>
                          </li>
                        </ul>
                      </div>

                      <div style="display:flex;flex-direction:column;justify-content:center;align-items:center;margin:0 20px;"> 
                        <Button style="margin-bottom: 20px;" @click="handleAddVlan">增加</Button>
                        <Button @click="handleRemoveVlan">移除</Button>
                      </div>

                      <div :class="[vlansCls, 'monitor-list-wrap']">
                        <ul class="monitor-list">
                          <li class="monitor-item right-vlan-item" 
                              v-for="(item ,index) in this.formData.vlans" 
                              :key="index"
                              @click.prevent="((evt) => { handleSelectRightVlan(evt, item) })">
                            <p>{{`VLAN ${item}`}}</p>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
              </div>

              <div class="conf-item" style="text-align:center;">
                <Button type="primary" style="padding:6px 15px;width:200px" @click.stop="submit()">保存配置</Button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>

      <table style="margin-top: 40px">
        <thead class="thead-bottom-line">
          <tr>
            <th style="width: 1200px;" colspan="4">
              手动同步
            </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <div class="conf-item">
                <label>配置文件同步：</label>
                <div>
                  <Button type="primary" style="margin-right:15px;padding:3px 21px;" @click="handleSync(1)" :loading="syncLoading1">
                    <span v-if="!syncLoading1">配置文件同步</span>
                    <span v-else>配置文件同步中...</span>
                  </Button>
                </div>
              </div>

              <div class="conf-item">
                <label>主机信息表同步：</label>
                <div>
                  <Button type="primary" @click="handleSync(2)" :loading="syncLoading2">
                    <span v-if="!syncLoading2">主机信息表同步</span>
                    <span v-else>主机信息表同步中...</span>
                  </Button>
                </div>
              </div>
            </td>
          </tr>
         
        </tbody>
      </table>
    </div>
  </div>
</template>
<script>
  import inputs from 'components/common/inputs'
  import NetService from 'services/netService'

  export default {
    components: {
      inputs
		},
		data() {
			return {
        originData: {
          avail_eths: [],
          avail_vlans: []
        },
        formData: {
          mgt: '',
          localIp: '',
          remoteIp: '',
          heartbeat: 1,
          ttl: 1,
          synswitch: 0,
          ports_follow_switch: 0,
          ethswitch: 1,
          gaojiswitch: 0,
          mode: '',
          stp: {
            priority: 1
          },
          eth_monitor: [],
          vlans: []
        },
        active: false,
        remoteIpTesting: false,
        syncLoading1: false,
        syncLoading2: false,
        selectedLeftEth: '',
        selectedRightEth: '',
        selectedLeftVlan: '',
        selectedRightVlan: '',
        selectedEthType: '', // left, right
        selectedVlanType: '',
        formatError: false,
        heartbeat_cls: '',
        ttlCls: '',
        remoteipCls: '',
        priorityCls: '',
        monitorCls: '',
        vlansCls: '',
        ipRegx: /^((2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)$/,
        intRegx: /^[1-9]\d*$/,
        statusText: {
          '3': '两台设备HA模式不一致',
          '4': '当前为STP模式，两台设备优先级配置冲突',
          '5': '当前为MSTP模式，两台设备VLAN配置冲突'
        }
			}
		},
    created() {
			this.getHiRel()         
    },
    watch: {
      'formData.eth_monitor': function(val) {
        if (val.length > 0) {
          this.removeErrorCls('monitorCls')
        } else {
          this.addErrorCls('monitorCls')
        }
      },
      'formData.vlans': function(val) {
        if (val.length > 0) {
          this.removeErrorCls('vlansCls')
        } else {
          this.addErrorCls('vlansCls')
        }
      }
    },
		methods: {
      modeWarn(content) {
        setTimeout(() => {
          this.$Modal.warning({
            title: '高可靠性',
            content: content,
            scrollable: false
          })
        }, 300)
      },
			getHiRel() {
				NetService.getHiRel()
				  .then((res) => {
						if (res.errcode === 0) {
              this.originData = res['30']
              this.formData.mgt = this.originData.mgt == 1 ? 'MGT1' :
                                  this.originData.mgt == 2 ? 'MGT2' : 
                                  '无'
              let mgts = this.originData.mgts.split(',')
              this.formData.localIp = {
                "MGT1": mgts[0] || 'N/A',
                "MGT2": mgts[1] || 'N/A',
                "无": 'N/A'
              }
              this.formData.remoteIp = this.originData.remoteip
              this.formData.heartbeat = this.originData.heartbeat
              this.formData.ttl = this.originData.ttl
              this.formData.synswitch = !!this.originData.synswitch // 自动同步
              this.formData.ports_follow_switch = !!this.originData.ports_follow_switch // 端口伴随开关
              this.formData.ethswitch = this.originData.eth.switch // 端口监测
              this.formData.gaojiswitch = this.originData.mode == 'ports_pile' ? 0 : 1// 高级配置
              this.formData.mode = this.originData.mode == 'ports_pile' ? 'STP' : this.originData.mode.toUpperCase()
                                          
              this.formData.eth_monitor = this.originData.eth.monitor ? this.originData.eth.monitor.split(',') : [] // 当前已监测的端口
              this.originData.eths = this.originData.eths ? this.originData.eths.split(',') : [] // 所有可检测的端口
              this.originData.avail_eths = this.originData.eths.filter((item) => {
                return this.originData.eth.monitor.indexOf(item) === -1
              })
              this.formData.stp.priority = this.originData.stp.priority
              this.formData.vlans = this.originData.mstp.vlanid.length ? this.originData.mstp.vlanid.split(',') : []
              this.originData.vlans = this.originData.vlans ? this.originData.vlans.split(',') : []
              this.originData.avail_vlans = this.originData.vlans.filter((item) => {
                return this.formData.vlans.indexOf(item) === -1
              })

              let statusContent = this.statusText[this.originData.status]
              if (statusContent) {
                this.modeWarn(statusContent)
              }
						}
					})
      },
      handleSync(type) {
        let title = type == 1 ? '配置文件' : '主机信息表'
        let localIp = this.formData.localIp[this.formData.mgt]
        let remoteIp = this.formData.remoteIp
        if (localIp == 'N/A' || !this.ipRegx.test(remoteIp)) {
          this.$Modal.error({
            title: title,
            content: '本机地址或对端地址有误，无法同步',
            scrollable: false
          })
          return false
        }

        this[`syncLoading${type}`] = true
        
        NetService.hiRelSync(type)
          .then((res) => {
            if (res.errcode === 0) {
              this.$Modal.success({
                title: title,
                content: '同步成功',
                scrollable: false
              })
            }
          }, (err) => {
            if (err.statusText == 'timeout') {
              setTimeout(() => {
                this.$Modal.error({
                  title: '提示',
                  content: '同步失败',
                  scrollable: false
                })
              }, 250)
            }
            this[`syncLoading${type}`] = false
          })
          .always(() => {
            this[`syncLoading${type}`] = false
          })
      },
      handlePingRemoteIp() {
        this.remoteIpTesting = true
        NetService.pingRemoteIp(this.formData.remoteIp)
          .then((res) => {
            if (res.errcode === 0) {
              this.$Modal.success({
                title: '对端地址',
                content: '对端地址网络可达',
                scrollable: false
              })
            }
          }, (err) => {
             this.$Modal.error({
                title: '提示',
                content: '对端地址网络不可达',
                scrollable: false
              })
          })
          .always(() => {
            this.remoteIpTesting = false
          })
      },
      switchStatus(name, val) {
        this.formData[name] = val
      },
      handleSelectLeftEth(evt, item) {
        this.selectedLeftEth = item
        this.selectedEthType = 'left'
        $('.left-eth-item').removeClass('item-active')
        $('.right-eth-item').removeClass('item-active')
        $(evt.currentTarget).addClass('item-active')
      },
      handleSelectRightEth(evt, item) {
        this.selectedRightEth = item
        this.selectedEthType = 'right'
        $('.left-eth-item').removeClass('item-active')
        $('.right-eth-item').removeClass('item-active')
        $(evt.currentTarget).addClass('item-active')
      },
      // 添加监测端口
      handleAddEth() {
        if (this.selectedEthType == 'left' && this.selectedLeftEth) {
          let index = this.originData.avail_eths.findIndex((item) => {
            return item == this.selectedLeftEth
          })
          this.originData.avail_eths.splice(index, 1)
          
          this.formData.eth_monitor.push(this.selectedLeftEth)
          this.selectedLeftEth = ''

          $('.left-eth-item').removeClass('item-active')
          $('.right-eth-item').removeClass('item-active')
        }
      },
      // 删除监测端口
      handleRemoveEth() {
        if (this.selectedEthType == 'right' && this.selectedRightEth) {
          let index = this.formData.eth_monitor.findIndex((item) => {
            return item == this.selectedRightEth
          })
          
          this.formData.eth_monitor.splice(index, 1)
          
          $('.left-eth-item').removeClass('item-active')
          $('.right-eth-item').removeClass('item-active')
          // 检查Vlan是否在全部可用范围内，如果不在，提示，不再添加到左边
          let ethIndex = this.originData.eths.findIndex((item) => {
            return item == this.selectedRightEth
          })

          if (ethIndex != -1) {
            this.originData.avail_eths.push(this.selectedRightEth)
            this.selectedRightEth = ''
          } else {
            this.$Modal.info({
                title: '高可靠性',
                content: `${this.selectedRightEth}不存在，将从端口列表中移除`,
                scrollable: false
              })
          }
        }
      },

      // MSTP Vlan 选择
      handleSelectLeftVlan(evt, item) {
        this.selectedLeftVlan = item
        this.selectedVlanType = 'left'
        $('.left-vlan-item').removeClass('item-active')
        $('.right-vlan-item').removeClass('item-active')
        $(evt.currentTarget).addClass('item-active')
      },
      handleSelectRightVlan(evt, item) {
        this.selectedRightVlan = item
        this.selectedVlanType = 'right'
        $('.left-vlan-item').removeClass('item-active')
        $('.right-vlan-item').removeClass('item-active')
        $(evt.currentTarget).addClass('item-active')
      },
      handleAddVlan() {
        if (this.selectedVlanType == 'left' && this.selectedLeftVlan) {
          let index = this.originData.avail_vlans.findIndex((item) => {
            return item == this.selectedLeftVlan
          })
          this.originData.avail_vlans.splice(index, 1)
          
          this.formData.vlans.push(this.selectedLeftVlan)
          this.selectedLeftVlan = ''
          $('.left-vlan-item').removeClass('item-active')
          $('.right-vlan-item').removeClass('item-active')
        }
      },
      handleRemoveVlan() {
        if (this.selectedVlanType == 'right' && this.selectedRightVlan) {
          let index = this.formData.vlans.findIndex((item) => {
            return item == this.selectedRightVlan
          })
          this.formData.vlans.splice(index, 1)
          $('.left-vlan-item').removeClass('item-active')
          $('.right-vlan-item').removeClass('item-active')

          // 检查Vlan是否在全部可用范围内，如果不在，提示，不再添加到左边
          let vlanIndex = this.originData.vlans.findIndex((item) => {
            return item == this.selectedRightVlan
          })

          if (vlanIndex != -1) {
            this.originData.avail_vlans.push(this.selectedRightVlan)
            this.selectedRightVlan = ''
          } else {
            this.$Modal.info({
                title: '高可靠性',
                content: `VLAN ${this.selectedRightVlan}不存在，将从VLAN列表中移除`,
                scrollable: false
              })
          }
        }
      },
      getVal(name, val, format_test) {
        if (name === 'localIp') {
          this.formData.localIp[this.formData.mgt] = val
        } 

        if (name === 'remoteIp') {
          this.formData.remoteIp = val
        }

        if (format_test) {
          this.formatError = false
        } else {
          this.formatError = true
        }
      },
      mgtChange(val) {
        this.formData.mgt = val
        if (val == '无') {
          this.removeErrorCls('remoteipCls')
        }
      },
      modeChange(val) {
        this.formData.mode = val
      },
      setUpParams() {
        let ret = {
          "30": {
            eth: {
              switch: this.formData.ethswitch,
              monitor: this.formData.eth_monitor.length ? this.formData.eth_monitor.join(',') : ''
            },
            heartbeat: Number(this.formData.heartbeat),
            mgt: this.formData.mgt == 'MGT1' ? 1 : this.formData.mgt == 'MGT2' ? 2 : 0,
            mode: this.formData.gaojiswitch ? this.formData.mode.toLowerCase() : 'ports_pile',
            mstp: {
              vlanid: this.formData.vlans.length ? this.formData.vlans.join(',') : ''
            },
            remoteip: this.formData.mgt == '无' ? '' : this.formData.remoteIp,
            stp: {
              priority: Number(this.formData.stp.priority)
            },
            synswitch: this.formData.synswitch ? 1 : 0,
            ports_follow_switch: this.formData.ports_follow_switch ? 1 : 0,
            ttl: Number(this.formData.ttl),
          }
        }
        return ret
      },
      addErrorCls(cls) {
        this[cls] = 'normal error_foramt animated shake'
        setTimeout(() => {
            this[cls] = 'normal error_foramt'
        }, 200)
        this.formatError = true
        return false
      },
      removeErrorCls(cls) {
        this[cls] = 'normal'
        this.formatError = false
        return false
      },
      checkData() {
        let remoteIp = this.formData.remoteIp
        let heartbeat = this.formData.heartbeat
        let ttl = this.formData.ttl
        let priority = this.formData.stp.priority

        if (!this.ipRegx.test(remoteIp) && this.formData.mgt != '无') {
          return this.addErrorCls('remoteipCls')
        } else {
          this.removeErrorCls('remoteipCls')
        }
        if (Number.isNaN(heartbeat) || !this.intRegx.test(heartbeat) || heartbeat < 1 || heartbeat > 120) {
          return this.addErrorCls('heartbeat_cls')
        } else {
          this.removeErrorCls('heartbeat_cls')
        }

        if (Number.isNaN(ttl) || !this.intRegx.test(ttl) || ttl < 1 || ttl > 300) {
          return this.addErrorCls('ttlCls')
        } else {
          this.removeErrorCls('ttlCls')
        }

        if (this.formData.ethswitch) {
          if (this.formData.eth_monitor.length == 0) {
            return this.addErrorCls('monitorCls')
          } else {
            this.removeErrorCls('monitorCls')
          }
        }

        // 如果启用了高级配置
        if (this.formData.gaojiswitch) {
          if (this.formData.mode == 'STP') {
            if (Number.isNaN(priority) || !this.intRegx.test(priority) || priority < 1 || priority > 255) {
              return this.addErrorCls('priorityCls')
            } else {
              this.removeErrorCls('priorityCls')
            }
          }

          if (this.formData.mode == 'MSTP') {
            if (this.formData.vlans.length == 0) {
              return this.addErrorCls('vlansCls')
            } else {
              this.removeErrorCls('vlansCls')
            }
          }
        }
      },
      submit() {
        this.checkData()
        if (this.formatError) {
          return false
        }
        NetService.updateHiRel(this.setUpParams())
          .then((res) => {
            if (res.errcode === 0) {
              this.$Modal.success({
                title: '高可靠性',
                content: '保存成功！',
                scrollable: false,
                onOk: () => {
                  this.getHiRel()
                }
              })
            }
          })
      }
		}
  }
    
</script>
