<template>
    <div>
        <Tables 
            :title ='title' 
            :btns = 'btns' 
            :field = 'field' 
            :tableData ='tableData' 
            :totalNum="total_num"
            :perNum='size' 
            :collectField = "collect_field"
            :curPage ="cur_page" 
            :clearSelectItems="selectedItems"
            :rankable ="true"
            :pageSize='pageSize'
            @reset="reset" 
            @rankData = "rankData"
            @loadData ="getData"
            @sentSelectedItems="getSelectedItems"
            @sentEditData="getEditData"
            @changePageSize = 'changePageSize'
            @delEvent = "delData"
            >
            <div slot="filter">
                <flieImport :type="'staticaddr'" :title="title"  @getData='fileReload'></flieImport>
            </div>
        </Tables>
        <Modals 
            :id ="'modal'" 
            :title ='title' 
            :field = 'field' 
            :collectField = "collect_field"
            :status = "status" 
            :errorMsg="errorMsg" 
            :type="type"
            :selectedItems="selectedItems" 
            :editData = "edit_data"  
            @sentErrorMsg = "getErrorMsg"
            @addEvent ="addData" 
            @editEvent = "editData" 
            >
        </Modals>
    </div>
</template>
<script>
    import Tables from 'components/common/Tables'
    import Modals from 'components/common/Modals'
    import NetService from 'services/netService' 
    import flieImport from 'components/common/flieImport'
    let btns = [
         {
            type:'add',
            name:'添加',
            event:'addEvent',
            icon:'/static/img/add.png',
            class:'add_btn',
        },
        {
            type:'del',
            name:'删除',
            event:'delEvent',
            icon:'/static/img/delete.png',
            class:'del_btn',
        },
        {
            type:'edit',
            name:'编辑',
            event:'editEvent',
            icon:'/static/img/modpic.png',
            class:'edit_btn',
        }
    ]
    let field = [
        {
            type:'checkbox',
        },
        {
            type:'rank',
        },
        {
            type:'text',
            label:'MAC地址',
            name:'mac',          
            regex: /^[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}$/,
            required:true, 
            remark:'*必填'
        },
        {
            type:'text',
            label:'IP地址',
            name:'ip',
            regex:/^((2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)$/,
            required:true, 
            remark:'*必填',
            style:'width: 350px'
        },
        {
            type:'none',
            label:'备注',
            name:'description',
			editable:true,
            regex:/^[\S\s]{0,32}$/,
            style:'width: 250px' 
        }
    ]
    export default {
		components: {
		    Tables,
            Modals,
            flieImport
	    },
        data() {
            return {
                title:'静态地址',
                btns:btns,
                field:field,
                tableData:[],
                total_num:1,
                cur_page:1,
                pageSize:[10, 20, 40, 80],
                size:20,
                collect_field:'id',
                status:"",
                errorMsg:'',
                type:'',
                selectedItems:[],
                edit_data:{},
                order:'',
                by:''
            }
        },
        created() {
            this.getData()
        },
        methods:{
            getSelectedItems(selectedItems) {
                this.selectedItems = selectedItems
            },
            getErrorMsg(msg) {
                this.errorMsg = msg
            },
            getEditData(editdata) {
                this.edit_data = editdata 
            },
            reset(type) {
                this.status = ""
                this.errorMsg = ''
                this.type = type
                $('.inputs_wrap .error_foramt').removeClass('error_foramt')
            }, 
            rankData(param){
                this.order = param.order
                this.by = param.by
                this.getData()
            },
            changePageSize (nowpage, size) {
                this.cur_page = nowpage
                this.size = size
                this.getData()
            }, 
            fileReload () {
                this.getData()
            },
            getData(){
                NetService.getBindIp(this.cur_page, this.size, this.order, this.by)
                .then((res)=>{
                    if(res.errcode === 0){
                        this.tableData = res['23'].data
                        this.total_num = res['23'].count
                    }
                })
            },
            addData(params) {
                 let conf = `${params.mac}|${params.ip}`
                 this.status ='ing'
                 NetService.addBindIp(conf)
                .then((res) => {      
                    if(res.errcode === 0){
                        this.status = 'ok'
                        this.errorMsg = ''
                        this.$Modal.success({
                            title: '静态地址',
                            content: '添加成功！',
                            scrollable: false,
                            onOk: () => {
                                this.getData()
                            }
                        })
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)	
                    }
                })
            },
            editData(params) {
                let conf = `${params.id}|${params.mac}|${params.ip}`
                this.status ='ing'
                NetService.editBindIp(conf)
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''                       
                        this.$Modal.success({
                            title: '静态地址',
                            content: '修改成功！',
                            scrollable: false,
                            onOk: () => {
                                this.getData()
                                this.selectedItems = []
                            }
                        })
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)	
                    }
                })
            },
            delData(params) {
                this.status ='ing'        
                NetService.delBindIp(params.ids)
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        this.selectedItems = []
                        setTimeout(() => {
                            this.$Modal.success({
                                title: '静态地址',
                                content: '删除成功！',
                                scrollable: false
                            })
                        }, 250)
                        this.getData()
                    }
                })
            }
        }
    }
</script>