<template>
    <div>
        <Tables 
            :title='title'
            :btns='btns' 
            :field='field' 
            :tableData='tableData' 
            :totalNum="total_num" 
            :perNum='size' 
            :collectField="collect_field"
            :curPage="cur_page" 
            :pageSize='pageSize' 
            :clearSelectItems="selectedItems"
            :rankable="true"
            @reset="reset" 
            @loadData="getData" 
            @sentSelectedItems="getSelectedItems"
            @sentEditData="getEditData"
            @changePageSize="changePageSize"
            @rankData="rankData"
            @delEvent="delDada">
        </Tables>
        <Modals 
            :id="'modal'"
            :title='title' 
            :field='field' 
            :collectField="collect_field"
            :status="status" 
            :errorMsg="errorMsg" 
            :type="type" 
            :momalNotice="'注：目的网段可配置成0.0.0.0/0，表示全网段'"
            :selectedItems="selectedItems" 
            :editData="edit_data"  
            @sentErrorMsg="getErrorMsg"
            @addEvent="addData" 
            @editEvent="editData" 
            >
        </Modals>
    </div>
</template>
<script>
    import Tables from 'components/common/Tables'
    import Modals from 'components/common/Modals'
    import NetService from 'services/netService' 
    let btns = [
         {
            type:'add',
            name:'添加',
            event:'addEvent',
            icon:'/static/img/add.png',
            class:'add_btn',
        },
        {
            type:'del',
            name:'删除',
            event:'delEvent',
            icon:'/static/img/delete.png',
            class:'del_btn',
        },
        {
            type:'edit',
            name:'编辑',
            event:'editEvent',
            icon:'/static/img/modpic.png',
            class:'edit_btn',
        }
    ]
    let field = [
        {
            type:'checkbox',
        },
        {
            type:'rank',
        },
        {
            type:'text',
            label:'目的网段',
            name:'ip',          
            regex:/^((2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)(\/([1-9]|[1-2]\d|3[0-2]))$|^(0\.0\.0\.0\/0)$/,
            required:true, 
            remark:'*必填',
            style:'width:480px'
        },
        {
            type:'text',
            label:'网关地址',
            name:'gateway',
            regex:/^((2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)$/,
            required:true, 
            remark:'*必填',
            style:'width:480px'
        }
    ]
    export default {
		components: {
		    Tables,
            Modals
	    },
        data() {
            return {
                title:'静态路由',
                btns:btns,
                field:field,
                tableData:[],
                pageSize:[10, 20, 40, 80],
                total_num:1,
                cur_page:1,
                size: 20,
                collect_field:'id',
                status:'',
                errorMsg:'',
                type:'',
                selectedItems:[],
                edit_data:{},
                order:'',
                by:''
            }
        },
        created() {
            this.getData()
        },
        methods: {
            getSelectedItems(selectedItems) {
                this.selectedItems = selectedItems
            },
            getErrorMsg(msg) {
                this.errorMsg = msg
            },
            getEditData(editdata) {
                this.edit_data = editdata 
            },
            reset(type) {
                this.status = ""
                this.errorMsg = ''
                this.type = type
                $('.inputs_wrap .error_foramt').removeClass('error_foramt')
            },
            changePageSize(nowpage, size) {
                this.cur_page = nowpage
                this.size = size
                this.getData()
            },
            rankData(param) {
                this.order = param.order
                this.by = param.by
                this.getData()
            },
            getData() {
                NetService.getBindRoute(this.cur_page, this.size, this.order, this.by)
                .then((res) => {
                    if (res.errcode === 0) {
                        this.tableData = res['24'].data
                        this.total_num = res['24'].count
                    }
                })
            }, 
            addData(params) {
                let conf = `${params.ip}|${params.gateway}`
                this.status = 'ing'
                NetService.addBindRoute(conf)
                    .then((res) => {
                        if (res.errcode === 0) {
                            this.status = 'ok'
                            this.errorMsg = ''
                    
                            this.$Modal.success({
                                title: '静态路由',
                                content: '添加成功！',
                                scrollable: false,
                                onOk: () => {
                                    this.getData()
                                }
                            })
                        } else {
                            this.status = 'error'
                            this.errorMsg = this.$t('error_code.' + res.errcode)
                        }
                    })
            }, 
            editData(params) {
                let conf = `${params.id}|${params.ip}|${params.gateway}`
                this.status = 'ing'
                NetService.editBindRoute(conf)
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                 
                        this.$Modal.success({
                            title: '静态路由',
                            content: '修改成功！',
                            scrollable: false,
                            onOk: () => {
                                this.getData()
                                this.selectedItems = []
                            }
                        })
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
                })
            },
            delDada(params) {
                this.status = 'ing'
                NetService.delBindRoute(params.ids)
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        setTimeout(() => {
                            this.$Modal.success({
                                title: '静态路由',
                                content: '删除成功！',
                                scrollable: false
                            })
                        }, 250)
                        this.selectedItems = []
                        this.getData()
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)	
                    }
                })
            }
        }
    }
</script>