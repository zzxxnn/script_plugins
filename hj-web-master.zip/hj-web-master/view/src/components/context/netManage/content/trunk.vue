<template>
    <div>
        <Tables
          :title ='title' 
          :btns = 'btns' 
          :field = 'field' 
          :tableData ='tableData' 
          :totalNum="total_num"
          :perNum='size' 
          :pageSize='pageSize' 
          :collectField = "collect_field"
          :curPage ="cur_page" 
          :clearSelectItems="selectedItems"
          :rankable ="true"
           @rankData = "rankData"
           @reset="reset"  
           @loadData ="getData" 
           @sentSelectedItems="getSelectedItems"
           @sentEditData="getEditData"
           @changePageSize = 'changePageSize'
           @delEvent = "delDada"
           >
            <div slot="filter">
                <flieImport :type="'trunk'" :title="title"  @getData='fileReload'></flieImport>
            </div>
        </Tables>
        <Modals 
            :id ="'modal'" 
            :title ='title' 
            :field = 'field' 
            :collectField = "collect_field"
            :selectItem = "select_item" 
            :status = "status" 
            :errorMsg="errorMsg" 
            :type="type" 
            :selectedItems="selectedItems" 
            :editData = "edit_data"  
            @sentErrorMsg = "getErrorMsg"
            @addEvent ="addData" 
            @editEvent = "editData" 
            >
        </Modals>
    </div>
</template>
<script>
    import Tables from 'components/common/Tables'
    import Modals from 'components/common/Modals'
    import NetService from 'services/netService' 
    import flieImport from 'components/common/flieImport'
    import SystemService from 'services/systemService'
    let btns = [
         {
            type:'add',
            name:'添加',
            event:'addEvent',
            icon:'/static/img/add.png',
            class:'add_btn',
        },
        {
            type:'del',
            name:'删除',
            event:'delEvent',
            icon:'/static/img/delete.png',
            class:'del_btn',
        },
        {
            type:'edit',
            name:'编辑',
            event:'editEvent',
            icon:'/static/img/modpic.png',
            class:'edit_btn',
        }
    ]
    let field = [
        {
            type:'checkbox',
        },
        {
            type:'rank',
        },
        {
            type:'text',
            label:'MAC地址',
            name:'mac',          
            regex: /^[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}$/,
            required:true, 
            remark:'*必填',
           
        },
        {
            type:'text',
            label:'IP地址',
            name:'ip',
            regex:/^((2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)$/,
            required:true, 
            remark:'*必填',
            style:'width: 200px'  
        },
        {
            type:'text',
            label:'VLAN',
            name:'vlan_id',
            regex:/^\d$|^[1-9]\d{0,2}$|^[1-3]\d{3}$|^40\d[0-4]$/,
            required:true, 
            remark:'*必填 (0~4094的整数)',
            style:'width: 150px'   
        },
        {
            type:'select',
            label:'物理线路',
            name:'group_id',
            regex:/\S/,
            required:false, 
            remark:'*选填 (物理线路不填时，VLAN配置不生效，被置为0)',
            style:'width: 150px' 
        },    
        {
            type:'none',
            label:'备注',
            name:'description',
            editable:true,
            regex:/^[\S\s]{0,32}$/,
            style:'width: 200px'
        }
    ]
    export default {
		components:{
		    Tables,
            Modals,
            flieImport
	    },
        data() {
            return{
                title:'主机透传',
                btns:btns,
                field:field,
                tableData:[],
                total_num:1,
                cur_page:1,
                pageSize:[10, 20, 40, 80],
                size:20,
                collect_field:'id',
                status:"",
                errorMsg:'',
                type:'',
                selectedItems:[],
                edit_data:{},
                select_item:[],
                order:'',
                by:''
            }
        },
        created() {
            this.getData()
            this.getLine()
        },
        methods:{
            getSelectedItems(selectedItems) {
                this.selectedItems = selectedItems
            },
            getErrorMsg(msg) {
                this.errorMsg = msg
            },
            getEditData(editdata) {
                this.edit_data = editdata 
            },
            reset(type) {
                this.status = ""
                this.errorMsg = ''
                this.type = type
                $('.inputs_wrap .error_foramt').removeClass('error_foramt')
            }, 
            getLine() {
                SystemService.getLine()
                .then((res) => {        
                    if (res.errcode === 0) {
                        this.select_item = res.group_id.map((item)=>{
                            return  '线路' + item
                        })
                    }
                })
            }, 
            changePageSize (nowpage, size) {
                this.cur_page = nowpage
                this.size = size
                this.getData()
            }, 
            rankData(param){
                this.order = param.order
                this.by =  param.by
                this.getData()
            },
            fileReload () {
                this.cur_page = 1
                this.getData()
            },
            getData() {
                NetService.getDoTrunk(this.cur_page, this.size, this.order, this.by)
                .then((res) => {
                    if (res.errcode === 0) {
                        this.tableData = res['25'].data.map((item)=>{
                            item.group_id = item.group_id ? '线路' + item.group_id : '-'
                            
                            return item
                        })
                        this.total_num = res['25'].count
                    }
                })
            },
            addData(params) {                 
                if (!params.vlan_id) {
                    params.vlan_id = 0
                    params.group_id = 0
                } else {
                    if (!params.group_id) {
                        params.vlan_id = 0
                        params.group_id = 0
                    }
                }
                if (params.group_id) {
                    params.group_id = params.group_id.replace(/[^0-9]/ig,'')//取线路数字
                }
            
                let conf = `${params.mac}|${params.ip}|${params.vlan_id}|${params.group_id}`
                this.status ='ing'
                NetService.addDoTrunk(conf)
                .then((res) => {      
                    if(res.errcode === 0){
                       this.status = 'ok'
                       this.errorMsg = ''
             
                       this.$Modal.success({
                            title: '主机透传',
                            content: '添加成功！',
                            scrollable: false,
                            onOk: () => {
                                this.getData()
                            }
                        })
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)	
                    }
                })
            },
            editData(params) {
                 let group_id = params.group_id.replace(/[^0-9]/ig,'')//取线路数字
                 if (!group_id) {
                     group_id = 0
                 }
                 let conf = `${params.id}|${params.mac}|${params.ip}|${params.vlan_id}|${group_id}`
                  this.status ='ing'
                 NetService.editDoTrunk(conf)
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok' 
                        this.errorMsg = ''                      
              
                        this.$Modal.success({
                            title: '主机透传',
                            content: '修改成功！',
                            scrollable: false,
                            onOk: () => {
                                this.getData()
                                this.selectedItems = []
                            }
                        })
                        
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)	
                    }
                })
            },
            delDada(params) {
                 this.status ='ing'
                 NetService.delDoTrunk(params.ids)
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        setTimeout(() => {
                            this.$Modal.success({
                                title: '主机透传',
                                content: '删除成功！',
                                scrollable: false
                            })
                        }, 250)
                        this.getData()
                        this.selectedItems = []
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)	
                    }
                })
            }

        }
    }
</script>