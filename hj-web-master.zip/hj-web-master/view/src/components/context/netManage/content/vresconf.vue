<template>
	<div class="wrap">
		<div class="page-title">
			<h3>网络配置</h3>
		</div>
		<div class="table-wrap">
			<table>
				<thead class="thead-bottom-line">
					<tr>
						<th >虚假响应配置</th>
                        <th >
                            <ul class="butn">
                                <li v-on:click='setVhost()'>          
                                    <img :src="`/static/${themeColor}-img/bule_sure.png`">
                                    <span>确定</span>
                                </li>
                            </ul>
                        </th>
					</tr>
				</thead>
				<tbody>
					<tr>
                        <td >
                            Linux主机比例：
                            <input 
                                type="number"  
                                class="linuxpp"  
                                @blur="chkLinuxpp()" 
                                v-model="linuxpp" 
                                max="100" 
                                min="0" 
                                step="1" 
                                @focus="ppEmpty()">(%)
                            <span class="mi">* 必填</span>    
                        </td>
                        <td >
                            端口：
                            <input class="long-input linuxport" type="text" data-toggle="popover" data-placement="top"
                            @blur="chkLinuxport" v-model="linuxport" @focus="isEmpty('.linuxport')">
                            <span class="mi">* 必填</span>
                        </td>
					</tr>
                    <tr>
                        <td >
                            Windows主机比例：<input type="number"  class="windowspp"
                            @blur="chkWindowspp()" v-model="windowspp" max="100" min="0" step="1" @focus="ppEmpty()">(%)
                            <span class="mi">* 必填</span>
                        </td>
                        <td >
                            端口：
                            <input class="long-input windowsport" type="text" data-toggle="popover" data-placement="top"
                            @blur="chkWindowsport" v-model="windowsport" @focus="isEmpty('.windowsport')">
                            <span class="mi">* 必填</span>
                        </td>
					</tr>
                    <tr>
                        <td >
                            Server主机比例：<input type="number" class="serverpp" data-placement="bottom"
                            @blur="chkServerpp()" v-model="serverpp" step="1" @focus="ppEmpty()">(%)
                            <span class="mi">* 必填</span>
                        </td>
                        <td >
                            端口：
                            <input rows="2" class="long-input serverport" type="text" data-toggle="popover" data-placement="top"
                            @blur="chkServerport" v-model="serverport" 
                            @focus="isEmpty('.serverport')">
                            <span class="mi">* 必填</span>
                        </td>
					</tr>
                    <tr>
                        <td >
                            端口响应概率：<input type="number" class="portrespp" data-toggle="popover" data-placement="top"
                            @blur="chkPortpp()" v-model="portrespp" max="100" min="0" step="1" @focus="noEmpty('.portrespp')">(%)
                            <span class="mi">* 必填</span>                            
                        </td>
                        <td ></td>
					</tr>
                    <tr>
                        <td style="padding-left:120px;" colspan="2" >
                            响应mac标识：
                            <input class="long-input portmacmark" data-toggle="popover" data-placement="top"
                            @blur="chkMac" type="text" v-model="portmacmark" @focus="noEmpty('.portmacmark')"
                            @keyup.enter="setVhost()">
                            <span class="mi">* 必填</span>
                        </td>
					</tr>
				</tbody>
			</table>
            <Spin fix v-if="isLoading">
                <Icon type="load-c" size=18 class="spin-icon-load"></Icon>
                <div>正在保存中...</div>
            </Spin>
            <p style="color:#69b6ff ;">注：多个端口或响应mac标识用“,”隔开。三个主机比例必须是整数，相加等于100。</p>
		</div>
	</div>
</template>
<script>
    import NetService from 'services/netService'
    import formatTest from 'libs/formatTest'

	export default {
        mounted() {
           this.getVhost();
        },
        
        data() {
            return {
                isLoading: false,
                linuxpp: "",
                linuxport: "",
                windowspp: "",
                windowsport: "",
                serverpp: "",
                serverport: "",
                portrespp: "",
                portmacmark: "",
                error: "",
                oper: ""
            }
        },

        methods: {
            setVhost() {
                if (this.checkPer() && this.checkPort() && this.checkEachport()) {
                    let params = {
                        17: `${this.linuxpp}|${this.windowspp}|${this.serverpp}`,
                        18: this.portrespp,
                        19: this.linuxport,
                        20: this.windowsport,
                        21: this.serverport,
                        22: this.portmacmark
                    }
                    // this.status = "ing"
                    this.isLoading = true
                    NetService.updateVResRange(params)
                        .then((res) => {
                            if (res.errcode === 0) {
                                NetService.updateVResRangeCmd()
                                    .then((res) => {
                                        if (res.errcode === 0) {
                                            // this.status = "ok"
                                         
                                            this.$Modal.success({
                                                title: '虚假响应配置',
                                                content: '保存成功！',
                                                scrollable: false,
                                                onOk: () => {
                                                    this.getVhost()
                                                }
                                            })
                                        } 
                                    })
                                    .always(() => {
                                        this.isLoading = false
                                    })
                                
                            } else {
                                this.isLoading = false
                            }
                        })
                }
            },
            checkPer() {
                let regNum = /0$|(^[1-9].\d*$)/

                if (!regNum.test(this.linuxpp)) {
                    this.shock(".linuxpp")
                    this.popoverShow('.linuxpp', 'Linux主机比例输入有误')
                    return false
                } else {
                    this.noshock(".linuxpp")
                } 
                if (!regNum.test(this.windowspp)) {
                    this.shock(".windowspp")
                    this.popoverShow('.windowspp', 'Windows主机比例输入有误')
                    return false
                } else {
                    this.noshock(".windowspp")
                }  
                if (!regNum.test(this.serverpp)) {
                    this.shock(".serverpp")
                    this.popoverShow('.serverpp', 'Server主机比例输入有误')
                    return false
                } else {
                    this.noshock(".serverpp")
                }  
                if ((parseFloat(this.linuxpp) + parseFloat(this.windowspp) + parseFloat(this.serverpp)) != 100) {
                    this.shock(".linuxpp")
                    this.shock(".windowspp")
                    this.shock(".serverpp")
                    this.popoverShow('.serverpp', 'Linux主机、Windows主机与Server主机比例不等于100')
                    return false
                } else {
                    this.noshock(".linuxpp")
                    this.noshock(".windowspp")
                    this.noshock(".serverpp")
                }
                if (!regNum.test(this.portrespp)) {
                    this.shock(".portrespp")
                    this.popoverShow('.portrespp', '端口响应比例输入有误')
                    return false
                } else {
                    this.noshock(".portrespp")
                }  
                if (this.portrespp > 100) {
                    this.shock(".portrespp")
                    this.popoverShow('.portrespp', '端口响应概率大于100')
                    return false
                } else {
                    this.noshock(".portrespp")
                } 
                return true
            },
            checkPort() {
                let regMarkinput = /^[0-9a-zA-Z,]+$/
                let regPortinput = /^[0-9,]+$/

                this.portmacmark = this.portmacmark.replace(/，/g,",")
                this.linuxport = this.linuxport.replace(/，/g,",")
                this.windowsport = this.windowsport.replace(/，/g,",")
                this.serverport = this.serverport.replace(/，/g,",")
            
                if (!regMarkinput.test(this.portmacmark)) {
                    this.shock(".portmacmark")
                    return false
                } else {
                    this.noshock(".portmacmark")
                }  
                if (!regPortinput.test(this.linuxport)) {
                    this.shock(".linuxport")
                    return false
                } else {
                    this.noshock(".linuxport")
                }  
                if (!regPortinput.test(this.windowsport)) {
                    this.shock(".windowsport")
                    return false
                } else {
                    this.noshock(".windowsport")
                }  
                if (!regPortinput.test(this.serverport)) {
                    this.shock(".serverport")
                    return false
                } else {
                    this.noshock(".serverport")
                } 
                return true
            },
            checkEachport() {
                let regPort = /^((([1-9]\d{0,3})|([1-5]\d{4})|(6[0-4]\d{3})|(65[0-4]\d{2})|(655[0-2]\d)|(6553[0-5])),){0,19}(([1-9]\d{0,3})|([1-5]\d{4})|(6[0-4]\d{3})|(65[0-4]\d{2})|(655[0-2]\d)|(6553[0-5]))$/;
                let regMac = /^(([0-9A-Fa-f]{6}),){0,9}([0-9A-Fa-f]{6})$/;

                let mac = this.portmacmark.replace(/[，]/g,",").replace(/\s+/, '').split(",")
                let linux = this.linuxport.replace(/[，]/g,",").replace(/\s+/, '').split(",")
                let windows = this.windowsport.replace(/[，]/g,",").replace(/\s+/, '').split(",")
                let server = this.serverport.replace(/[，]/g,",").replace(/\s+/, '').split(",")

                if (linux.length > 20) {
                    this.shock(".linuxport")
                    this.popoverShow('.linuxport', '端口最多20个')
                    return false
                } else {
                    this.noshock(".linuxport")
                }
                for(let i = 0; i < linux.length; i++) {
                    if (!regPort.test(linux[i])) {
                        this.shock(".linuxport")
                        this.popoverShow('.linuxport', "第" + (i+1) +"个端口格式有误")
                        return false
                    } else {
                        this.noshock(".linuxport")
                    }
                }
                
                if (windows.length > 20) {
                    this.shock(".windowsport")
                    this.popoverShow('.windowsport', '端口最多20个')
                    return false
                } else {
                    this.noshock(".windowsport")
                }
                for(let i = 0; i < windows.length; i++) {
                    if (!regPort.test(windows[i])) {
                        this.shock(".windowsport")
                        this.popoverShow('.windowsport', "第" + (i+1) +"个端口格式有误")
                        return false
                    } else {
                        this.noshock(".windowsport")
                    }
                }
                
                if (server.length > 20) {
                    this.shock(".serverport")
                    this.popoverShow('.serverport', '端口最多20个')
                    return false
                } else {
                    this.noshock(".serverport")
                }
                for(let i = 0; i < server.length; i++) {
                    if (!regPort.test(server[i])) {
                        this.shock(".serverport")
                        this.popoverShow('.serverport', "第" + (i+1) +"个端口格式有误")
                        return false
                    } else {
                        this.noshock(".serverport")
                    }
                }

                if (mac.length > 20) {
                    this.shock(".portmacmark")
                    this.popoverShow('.serverport', '响应mac标识最多20个')
                    return false
                } else {
                    this.noshock(".portmacmark")
                } 
                for(let i = 0; i < mac.length; i++) {
                    if (!regMac.test(mac[i])) {
                        this.shock(".portmacmark")
                        this.popoverShow('.portmacmark', "第" + (i+1) +"个端口格式有误")
                        return false
                    } else {
                        this.noshock(".portmacmark")
                    }
                }
                return true
            },
            getVhost() {
                let params ={
                    oper:'load'
                }
				NetService.getVResRange(params)
				    .then((res) => {
                        if (res.errcode === 0) {
                            let hostRatio = res['17'].split('|')
                            this.linuxpp = hostRatio[0]
                            this.windowspp = hostRatio[1]
                            this.serverpp = hostRatio[2]
                            this.portrespp = res['18']
                            this.linuxport = res['19']
                            this.windowsport = res['20']
                            this.serverport = res['21']
                            this.portmacmark = res['22']
                        }
                        
                    })
       		},
            chkLinuxpp() {
                let regNum = /^\d+$/
                if ( !regNum.test(this.linuxpp)) {
                    this.shock(".linuxpp")
                    return false
                } else {
                    this.noshock(".linuxpp")
                } 
            },
            chkWindowspp() {
                let regNum = /^\d+$/
                if ( !regNum.test(this.windowspp)) {
                    this.shock(".windowspp")
                    return false
                } else {
                    this.noshock(".windowspp")
                }  
            },
            chkServerpp() {
                let regNum = /^\d+$/
                if ( !regNum.test(this.serverpp)) {
                    this.shock(".serverpp")
                    return false
                } else {
                    this.noshock(".serverpp")
                    if ((parseFloat(this.linuxpp) + parseFloat(this.windowspp) + parseFloat(this.serverpp)) > 100) {
                        this.shock(".linuxpp")
                        this.shock(".windowspp")
                        this.shock(".serverpp")
                        this.popoverShow('.serverpp', 'Linux主机、Windows主机与Server主机比例不等于100')
                        return false
                    } else {
                        this.noshock(".linuxpp")
                        this.noshock(".windowspp")
                        this.noshock(".serverpp")
                    }
                }    
                
            },
            chkPortpp() {
                let regNum = /^\d+$/
                if ( !regNum.test(this.portrespp)) {
                    this.shock(".portrespp")
                    this.popoverShow('.portrespp', '端口响应比例输入有误')
                    return false
                } else {
                    this.noshock(".portrespp")
                }  
                if ( this.portrespp > 100) {
                    this.shock(".portrespp")
                    this.popoverShow('.portrespp', '端口响应概率大于100')
                    return false
                } else {
                    this.noshock(".portrespp")
                } 
            },
            chkLinuxport() {
                this.linuxport = this.linuxport.replace(/[，]/g,",").replace(/\s+/g, '')
                let regPortinput = /^[0-9,]+$/;
                let regPort = /^((([1-9]\d{0,3})|([1-5]\d{4})|(6[0-4]\d{3})|(65[0-4]\d{2})|(655[0-2]\d)|(6553[0-5])),){0,19}(([1-9]\d{0,3})|([1-5]\d{4})|(6[0-4]\d{3})|(65[0-4]\d{2})|(655[0-2]\d)|(6553[0-5]))$/;
                if ( !regPortinput.test(this.linuxport)) {
                    this.shock(".linuxport")
                    return false
                } else {
                    this.noshock(".linuxport")
                    let linux = this.linuxport.split(",")
                    if ( linux.length > 20) {
                        this.shock(".linuxport")
                        this.popoverShow('.linuxport', '端口最多20个')
                        return false
                    } else {
                        this.noshock(".linuxport")
                    }
                    for( let i=0; i < linux.length; i++) {
                        if ( !regPort.test(linux[i])) {
                            this.shock(".linuxport")
                            this.popoverShow('.linuxport', "第" + (i+1) +"个端口格式有误")
                            return false
                        } else {
                            this.noshock(".linuxport")
                        }
                    }
                }  
            },
            chkWindowsport() {
                this.windowsport = this.windowsport.replace(/，/g,",").replace(/\s+/g, '')
                let regPortinput = /^[0-9,]+$/;
                let regPort = /^((([1-9]\d{0,3})|([1-5]\d{4})|(6[0-4]\d{3})|(65[0-4]\d{2})|(655[0-2]\d)|(6553[0-5])),){0,19}(([1-9]\d{0,3})|([1-5]\d{4})|(6[0-4]\d{3})|(65[0-4]\d{2})|(655[0-2]\d)|(6553[0-5]))$/;
                if ( !regPortinput.test(this.windowsport)) {
                    this.shock(".windowsport")
                    return false
                } else {
                    this.noshock(".windowsport")
                    let windows = this.windowsport.split(",")
                    if ( windows.length > 20) {
                        this.shock(".windowsport")
                        this.popoverShow('.windowsport', '端口最多20个')
                        return false
                    } else {
                        this.noshock(".windowsport")
                    }
                    for( let i=0; i < windows.length; i++) {
                        if ( !regPort.test(windows[i])) {
                            this.shock(".windowsport")
                            this.popoverShow('.windowsport', "第" + (i+1) +"个端口格式有误")
                            return false
                        } else {
                            this.noshock(".windowsport")
                        }
                    }
                }  
            },
            chkServerport() {
                this.serverport = this.serverport.replace(/，/g,",").replace(/\s+/g, '')
                let regPortinput = /^[0-9,]+$/;
                let regPort = /^((([1-9]\d{0,3})|([1-5]\d{4})|(6[0-4]\d{3})|(65[0-4]\d{2})|(655[0-2]\d)|(6553[0-5])),){0,19}(([1-9]\d{0,3})|([1-5]\d{4})|(6[0-4]\d{3})|(65[0-4]\d{2})|(655[0-2]\d)|(6553[0-5]))$/;
                if ( !regPortinput.test(this.serverport)) {
                    this.shock(".serverport")
                    return false
                } else {
                    this.noshock(".serverport")
                    let server = this.serverport.split(",")
                    if ( server.length > 20) {
                        this.shock(".serverport")
                        this.popoverShow('.serverport', '端口最多20个')
                        return false
                    } else {
                        this.noshock(".serverport")
                    }
                    for( let i=0; i < server.length; i++) {
                        if ( !regPort.test(server[i])) {
                            this.shock(".serverport")
                            this.popoverShow('.serverport', "第" + (i+1) +"个端口格式有误")
                            return false
                        } else {
                            this.noshock(".serverport")
                        }
                    }
                } 
            },
            chkMac() {
                this.portmacmark = this.portmacmark.replace(/，/g,",").replace(/\s+/g, '')
                let regMarkinput = /^[0-9a-zA-Z,]+$/;
                let regMac = /^(([0-9A-Fa-f]{6}),){0,9}([0-9A-Fa-f]{6})$/;
                if ( !regMarkinput.test(this.portmacmark)) {
                    this.shock(".portmacmark")
                    return false
                } else {
                    this.noshock(".portmacmark")
                    let mac = this.portmacmark.split(",")
                    if ( mac.length > 20) {
                        this.shock(".portmacmark")
                        this.popoverShow('.serverport', '响应mac标识最多20个')
                        return false
                    } else {
                        this.noshock(".portmacmark")
                    } 
                    for( let i=0; i < mac.length; i++) {
                        if ( !regMac.test(mac[i])) {
                            this.shock(".portmacmark")
                            this.popoverShow('.portmacmark', "第" + (i+1) +"个端口格式有误")
                            return false
                        } else {
                            this.noshock(".portmacmark")
                        }
                    }
                }  
            },
            testVal(ele, reg) {
				let val = $(ele).val()
				let test = new formatTest(ele, reg, false)
				return test.testFormat()
			},
            isEmpty(ele) {
                let test = new formatTest(ele)
			    test.isEmpty()
			},
            noEmpty(ele) {
                let test = new formatTest(ele)
			    test.notEmpty()
			},
            ppEmpty() {
                $(".windowspp").parent().find('.mi').css('color', '#aaa9a9')
		        $(".windowspp").css('border', '1px solid #e8e8e8')
                $(".linuxpp").parent().find('.mi').css('color', '#aaa9a9')
		        $(".linuxpp").css('border', '1px solid #e8e8e8')
                $(".serverpp").parent().find('.mi').css('color', '#aaa9a9')
		        $(".serverpp").css('border', '1px solid #e8e8e8')
            },
            shock(ele) {
                let $ele = $(ele)
                if ($ele.val()=='') {
                    let mi = $ele.parent().find('.mi')
                    let miTextarea = $ele.parent().find('.mi-textarea')
                    mi.length && mi.css('color', '#b63039')
                    miTextarea.length && miTextarea.css('color', '#b63039')
                }
				$ele.css('border', '1px solid #b63039')
				$ele.addClass('animated shake')
				setTimeout(function() {
					$ele.removeClass('animated shake')
				}, 200)
            },
            noshock(ele) {
                $(ele).css('border', '1px solid #e8e8e8')
            },
            popoverShow(ele, content) {
                let $ele = $(ele)
				$ele.attr("data-content", content).popover('show')
				setTimeout(function() {
					$ele.popover('destroy')
				}, 2000)
			}
        }
	}
    
</script>
<style scoped lang="less">
    .spin-icon-load {
        animation: ani-spin 1s linear infinite
    }
    @keyframes ani-spin {
        from {transform: rotate(0deg)}
        50%  {transform: rotate(180deg)}
        to   {transform: rotate(360deg)}
    }
	.wrap {
		margin: 30px 0 0 30px;
		padding-bottom: 10px;
		background: #FFFFFF;
	}
	h3 {
		line-height: 30px;
	}
    .butn {
		display: inline-block;
		float: right;
	}
	.butn li{
		display: inline-block;
		margin: 0px 25px 0px 0px;
		cursor: pointer;		
    }
	.butn img {
        vertical-align: -2px;
        width: 12px;
	}
	.table-wrap{
        position: relative;
		margin: 20px;
	}
    tbody tr {
		height: 60px;
	}
	thead tr th {
        height: 30px;
        text-align: left;
        padding-left: 15px;
        position: relative;
	}
    .colortable tr:hover{
        background: none;
    }
    tbody tr td {
        position: relative;
        label {
            position: relative;
            top: -17px;
            color: #495060;
            font-weight: normal
        }
        textarea {
            position: relative;
            top: 5px;
            resize: none;
            padding-left: 5px;
            border: 1px solid #e6e6e6;
            border-radius: 5px;
            outline: none;
        }
    }
    tbody tr td:nth-child(1) {
        text-align: right;
        padding-right: 45px;
    }
    tbody tr td:last-child{
        text-align: left;
        padding-left: 55px;
    }
    tbody tr:last-child td:nth-child(1) {
        padding-right: 63px;
    }
    tbody tr:nth-child(4) td {
        padding-top: 15px;
    }
    input{
        height: 25px;
        width: 130px;
        border: 1px solid #e6e6e6;
        border-radius: 5px;
        margin-right: 8px;
        padding: 3px;
    }
    .long-input{
        width: 400px;
        background: #ffffff;
    }
    p {
		color: #fb5656;
		margin-top: 20px;
    }
    .mi {
        // color: #d2d2d2;
        color: #aaa9a9;
		margin-left: 10px;
    }
    .mi-textarea {
        position: relative;
        top: -17px;
		margin-left: 10px;
        color: #d2d2d2;
	}
</style>