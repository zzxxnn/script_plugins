<template>
    <div>
        <div class="table_wrap">
            <div class="page-title">
                <h3>{{title}}</h3>
            </div>
            <Tables 
                class="style_c" 
                :title="'内部IP网段配置'"  
                :tableName="'rip'" 
                :btns='btns' 
                :field='field'
                :tableData='ripTableData' 
                :curPage="rip_cur_page" 
                :pageSize="pageSize"
                :perNum='rip_size' 
                :totalNum="rip_total_num"
                :collectField="collect_field"  
                :clearSelectItems="selectedItems" 
                @reset="reset"  
                :rankable="true"
                @rankData="handleRankData"
                @loadData="_getRealIpRange" 
                @sentSelectedItems="getSelectedItems" 
                @sentEditData="getEditData"
                @changePageSize='handleChangePageSize'
                @delEvent="handleDelRip">
            </Tables>
            <Tables 
                class="style_c"  
                :title="'内部IP保留网段配置'" 
                :tableName="'norip'" 
                :btns='btns' 
                :field='field'
                :tableData='noripTableData' 
                :pageSize="pageSize"
                :curPage="norip_cur_page" 
                :perNum='norip_size'
                :totalNum="norip_total_num" 
                :collectField="collect_field" 
                :clearSelectItem1="selectedItem1" 
                @reset="reset"   
                :rankable="true"
                @rankData="handleRankData"
                @loadData="_getRealIpReservedRange" 
                @sentSelectedItem1="getSelectedItem1"
                @sentEditData="getEditData"
                @changePageSize='handleChangePageSize'
                @delEvent="handleDelRip">
            </Tables>
        </div>
        
        <Modals 
            :id="'modal'" 
            :title="add_title" 
            :field='field' 
            :collectField="collect_field"
            :selectItem="select_item" 
            :status="status" 
            :errorMsg="errorMsg" 
            :type="type"
            :selectedItems="table_name === 'rip' ? selectedItems : selectedItem1" 
            :editData="edit_data" 
            @sentErrorMsg="getErrorMsg"
            @addEvent="handleAddRip"
            @editEvent="handleEditRip"
            >
        </Modals>
    </div>
</template>
<script>
import Tables from 'components/common/Tables'
import Modals from 'components/common/Modals'
import NetService from 'services/netService'
import SystemService from 'services/systemService'
let field = [
    {
        type: 'checkbox',
    },
    {
        type: 'rank',
    },
    {
        type: 'text',
        label: '网段',
        name: 'ip',          
        regex: /^((2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)$/,
        required: true, 
        remark: '*必填'
    },
    {
        type: 'text',
        label: '掩码',
        name: 'mask',
        regex:  /^(254|252|248|240|224|192|128|0)\.0\.0\.0$|^(255\.(254|252|248|240|224|192|128|0)\.0\.0)$|^(255\.255\.(254|252|248|240|224|192|128|0)\.0)$|^(255\.255\.255\.(255|254|252|248|240|224|192|128|0))$/ ,
        required: true, 
        remark: '*必填'  
    },
    {
        type: 'text',
        label: 'VLAN',
        name: 'vlan_id',
        regex:  /^\d$|^[1-9]\d{0,2}$|^[1-3]\d{3}$|^40\d[0-4]$/,
        required: true, 
        remark: '*必填(0~4094的整数)',
        style: 'width: 200px'  
    },
    {
        type: 'select',
        label: '物理线路',
        name: 'group_id',
        required: true, 
        remark: '*必选',
        style: 'width: 200px' 
    }
]

export default {
    components: {
        Tables,
        Modals
    },
    data() {
        return {
            title: '网络配置',   
            add_title: '',  
            field: field,
            btns: [
                {
                    type: 'add',
                    name: '添加',
                    event: 'addEvent',
                    icon: `/static/img/add.png`,
                    class: 'add_btn',
                },
                {
                    type: 'del',
                    name: '删除',
                    event: 'delEvent',
                    icon: `/static/img/delete.png`,
                    class: 'del_btn',
                },
                {
                    type: 'edit',
                    name: '编辑',
                    event: 'editEvent',
                    icon: `/static/img/modpic.png`,
                    class: 'edit_btn',
                }
            ],
            pageSize: [10, 20, 40, 80],
            cur_page: 1,             
            status: "",
            errorMsg: '',
            type: '',
            edit_data: {},

            select_item: [],
            collect_field: 'id',
            table_name: '',

            rip_cur_page: 1,
            rip_size: 10,
            rip_total_num: 0,
            ripTableData: [],    
            selectedItems: [],

            norip_cur_page: 1,
            norip_size: 10,
            norip_total_num: 0,
            noripTableData: [],
            selectedItem1: [],
            
            rip_order: 'desc',
            rip_by: '',
            norip_order: 'desc',
            norip_by: ''
        }
    },
    mounted() {
        let params = {
            oper: 'load',
            page:  1
        }
        // this.loadNoripData(params)
        this._getRealIpRange({
            oper: 'load',
            page: this.rip_cur_page,
            size: this.rip_size,
            order: this.rip_order,
            by: this.rip_by
        })
        this._getRealIpReservedRange({
            oper: 'load',
            page: this.norip_cur_page,
            size: this.norip_size,
            order: this.norip_order,
            by: this.norip_by
        })
        this._getLine() 
    },
    methods: {
        handleAddRip(params) {
            let data = Object.assign({}, params)
            if (data.group_id) {
                data.group_id = data.group_id.replace(/[^0-9]/ig,"")
            } else {
                data.group_id = ''
            }
            
            if (this.table_name === 'rip') {
                data.oper = data.oper + "_rip"
                this._createRealIpRange(data)
            } else {
                data.oper = data.oper + "_norip"
                this._createRealIpReservedRange(data)
            }
        },
        handleEditRip(params) {
            let data = Object.assign({}, params)
            data.group_id = data.group_id.replace(/[^0-9]/ig, "")  
            if (this.table_name === 'rip') {
                data.oper = data.oper + "_rip"
                this._updateRealIpRange(data)
            } else {
                data.oper = data.oper + "_norip"
                this._updateRealIpReservedRange(data)
            }
        },
        handleDelRip(params) {
            if (this.table_name === 'rip') {
                params.oper = params.oper + "_rip"
                this._destroyRealIpRange(params)
            } else {
                params.oper = params.oper + "_norip"
                this._destroyRealIpReservedRange(params)
            }
        },
        getErrorMsg(msg) {
            this.errorMsg = msg
        },
        getSelectedItems(selectedItems) {
            this.selectedItems = selectedItems
        },
        getSelectedItem1(selectedItem1) {
            this.selectedItem1 = selectedItem1
        },
        getEditData(editdata) {
            this.edit_data = editdata 
        },
        reset(type, table_name) {
            this.status = ""
            this.errorMsg = ''
            this.type = type
            this.table_name = table_name
            if (table_name === 'norip') {     
                this.add_title = "内部IP保留网段"
            } else {
                this.add_title = "内部IP网段"
            } 
            $('.inputs_wrap .error_foramt').removeClass('error_foramt')
        },
        handleRankData(params, tableName) {
            if (tableName === 'rip') {
                params.page = this.rip_cur_page
                params.size = this.rip_size
                this.rip_order = params.order 
                this.rip_by = params.by
                this._getRealIpRange(params)
            } else {
                params.page = this.norip_cur_page
                params.size = this.norip_size
                this.norip_order = params.order
                this.norip_by = params.by
                this._getRealIpReservedRange(params)
            }
        },
        handleChangePageSize(page, size, tableName) {
            if (tableName === 'rip') {
                this.rip_cur_page = page
                this.rip_size = size
                let params = {
                    page: this.rip_cur_page,
                    size: this.rip_size,
                    order: this.rip_order,
                    by: this.rip_by
                }
                this._getRealIpRange(params)
            } else {
                this.norip_cur_page = page
                this.norip_size = size
                this._getRealIpReservedRange({
                    page: this.norip_cur_page,
                    size: this.norip_size,
                    order: this.norip_order,
                    by: this.norip_by
                })
            }
        }, 
        _getRealIpRange(params) {
            this.status = 'ing'  
            NetService.getRealIpRange(params)
            .then((res) => {
                if (res.errcode === 0) {
                    this.status = 'ok'
                    this.errorMsg = ''
                    let data = res['9'].data     
                    this.rip_total_num = res['9'].count
                    let page = params.page ? params.page : this.rip_cur_page

                    if (!params.oper) {
                        params.oper = 'load'
                    }
                    
                    this.rip_cur_page = page
                    this.ripTableData =  data.map((item)=> { 
                        return {
                            id: item.id,
                            ip: item.ip,
                            mask: item.mask,
                            vlan_id: item.vlan_id,
                            group_id: '线路' + item.group_id
                        }
                    })
                } 
            })
        },
        _createRealIpRange(params) {
            params = {
                9: `${params.ip}|${params.mask}|${params.vlan_id}|${params.group_id}`
            }
            NetService.createRealIpRange(params)
               .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        this.$Modal.success({
                            title: '网络配置',
                            content: '添加成功！',
                            scrollable: false,
                            onOk: () => {
                                this._getRealIpRange({page: 1, size: this.rip_size})
                            }
                        })
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
              })
        },
        _updateRealIpRange(params) {
            params = {
                9: `${params.id}|${params.ip}|${params.mask}|${params.vlan_id}|${params.group_id}`
            }
            NetService.updateRealIpRange(params)
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        this.$Modal.success({
                            title: '网络配置',
                            content: '修改成功！',
                            scrollable: false,
                            onOk: () => {
                                this._getRealIpRange({
                                    oper: 'edit', 
                                    page: this.rip_cur_page,
                                    size: this.rip_size,
                                    order: this.rip_order,
                                    by: this.rip_by
                                })
                            }
                        })
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
                })
        },
        _destroyRealIpRange(params) {
            this.status = 'ing'
            params = {
                9: params.ids
            }
            NetService.destroyRealIpRange(params)
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        setTimeout(() => {
                            this.$Modal.success({
                                title: '网络配置',
                                content: '删除成功！',
                                scrollable: false
                            })
                        }, 250)
                        
                        this.selectedItems = []
                        if (this.ripTableData.length === 1) {
                            this.rip_cur_page = this.rip_cur_page === 1 ? 1 : this.rip_cur_page - 1
                        }
                        this._getRealIpRange({
                            oper: 'del', 
                            page: this.rip_cur_page,
                            size: this.rip_size,
                            order: this.rip_order,
                            by: this.rip_by
                        })
                    }
                })
        },
        _getRealIpReservedRange(params) { 
            this.status ='ing'  
            NetService.getRealIpReservedRange(params)
            .then((res) => {
                if (res.errcode === 0) {
                    this.status = 'ok'
                    this.errorMsg = ''
                    let data = res['10'].data
                    this.norip_total_num = res['10'].count
                    let page = params.page ? params.page : this.norip_cur_page

                    if (!params.oper) {
                        params.oper = 'load'
                    }
                   
                    this.norip_cur_page = page
                    this.noripTableData = data.map((item)=> { 
                        return {
                            id: item.id,
                            ip: item.ip,
                            mask: item.mask,
                            vlan_id: item.vlan_id,
                            group_id: '线路' + item.group_id
                        }
                    })    
                }
            })
        },
        _createRealIpReservedRange(params) {
            params = {
                10: `${params.ip}|${params.mask}|${params.vlan_id}|${params.group_id}`
            }
            NetService.createRealIpReservedRange(params)
               .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        this.$Modal.success({
                            title: '网络配置',
                            content: '添加成功！',
                            scrollable: false,
                            onOk: () => {
                                this._getRealIpReservedRange({page: 1, size: this.norip_size})
                            }
                        })
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
              })
        },
        _updateRealIpReservedRange(params) {
            params = {
                10: `${params.id}|${params.ip}|${params.mask}|${params.vlan_id}|${params.group_id}`
            }
            NetService.updateRealIpReservedRange(params)
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        this.$Modal.success({
                            title: '网络配置',
                            content: '修改成功！',
                            scrollable: false,
                            onOk: () => {
                                 this._getRealIpReservedRange({
                                    oper: 'edit', 
                                    page: this.norip_cur_page,
                                    size: this.norip_size,
                                    order: this.norip_order,
                                    by: this.norip_by
                                })
                            }
                        })
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
                })
        },
        _destroyRealIpReservedRange(params) {
            this.status = 'ing'
            params = {
                10: params.ids
            }
            NetService.destroyRealIpReservedRange(params)
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        setTimeout(() => {
                            this.$Modal.success({
                                title: '网络配置',
                                content: '删除成功！',
                                scrollable: false
                            })
                        }, 250)

                        this.selectedItem1 = []
                        if (this.noripTableData.length === 1) {
                            this.norip_cur_page = this.norip_cur_page === 1 ? 1 : this.norip_cur_page - 1
                        }
                        this._getRealIpReservedRange({
                            oper: 'del', 
                            page: this.norip_cur_page,
                            size: this.norip_size,
                            order: this.norip_order,
                            by: this.norip_by
                        })
                    } 
                })
        },
        _getLine() {
            SystemService.getLine()
                .then((res) => {
                    if (res.errcode === 0) {
                        this.select_item = res.group_id.map((item)=>{
                            return  '线路' + item
                        })
                    }
                })
        },
        popoverShow(ele,content) {//删除弹窗
            $(ele).attr({
                'data-toggle': 'popover',
                'data-placement':"bottom",
                'data-content': content
            }).popover('show')
            setTimeout(function() {
                $(ele).popover('destroy')
            }, 1500)
        },
    }
}
</script>
<style scoped>
	.table_wrap {
		background: #fff;
		margin: 30px 0 30px 30px;
		padding-bottom: 1px;
	}
</style>
