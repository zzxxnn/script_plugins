<template>
	<div class="wrap agreement" @keyup.enter="setPpass()" >
		<div class="page-title">
			<h3>协议透传配置</h3>
		</div>
		<div class="table-wrap">
			<table >
				<thead class="thead-bottom-line">
					<tr>
						<th style="width: 1200px;" colspan="5">选择协议
							<ul class="titile-butn">
								<li v-on:click.stop="setPpass()" >
									<img :src="`/static/${themeColor}-img/bule_sure.png`">
									<span>确定</span>
								</li>
							</ul>
						</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td class="name cu" >STP：</td>
						<td class="option">
							<div class="on_off_but">							
								<button @click.stop = "swichStatus('STPs',1)" :class="[STPs?'btn-active':'']" class="on_but">启用</button>
								<button @click.stop = "swichStatus('STPs',0)" :class="[STPs?'':'btn-active']" class="off_but">禁用</button>
							</div>
						</td>			
						<td >
							<p  style="text-align: center; color:#69b6ff;">注：STP为禁用状态时，同步开关失效。</p>
						</td>			
					</tr>
					<tr>
						<td class="name cu">Communication_Redundancy：</td>
							<td class="option" >
								<div class="on_off_but">							
								<button @click.stop = "swichStatus('CRs',1)" :class="[CRs?'btn-active':'']" class="on_but"> 启用 </button>
								<button @click.stop = "swichStatus('CRs',0)" :class="[CRs?'':'btn-active']" class="off_but"> 禁用 </button>
							</div>
						</td>		
					  <td></td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</template>
<script>
	import NetService from 'services/netService'
	import formatTest from 'libs/formatTest'

	export default {
		mounted() {
			this.getPpass()
		},
		data() {
			return {
				STPs:"",
				CRs:"",
				type:"",
				status:''
			}
		},
		methods: {
			swichStatus(butn_type,on_off) {       		
				if (butn_type=='STPs') {
					this.STPs = on_off
				} else if (butn_type=='CRs') {
					this.CRs = on_off
				}
      },
			getPpass() {
				NetService.getProtocolpass()
				.then((res) => {					
					if (res.errcode === 0) {
						this.STPs = res[26] == 1? true : false
						this.CRs = res[27] == 1 ? true : false	
					}
				})
			},
			setPpass() {			
					let conf={
						stp_switch:this.STPs ? "1" : "0",
						cr_switch:this.CRs ? "1" : "0",
					}
					this.status = 'ing'
					NetService.setProtocolpass(conf)
					.then((res) => {
						if (res.errcode === 0) {
							this.$Modal.success({
								title: '协议透传配置',
								content: '保存成功！',
								scrollable: false,
								onOk: () => {
									this.getPpass()
								}
							})
						} 
					})		
      },
    }
	}
    
</script>