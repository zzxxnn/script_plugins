<template>
    <div class="app">
        <span style="display: none;" class="copyText"></span>
        <navbar></navbar>
            <div class="accredit-warp">
                <router-view v-if='accredit'></router-view>
                <div v-else class="container">
                    <div class="updata">
                        <update></update>
                    </div>
                </div>
            </div>
            <timeout></timeout>
        <footerbar></footerbar>
    </div>
</template>
<script>
import timeout from "./timeout"
import update from 'components/context/systemSet/content/update'
import navbar from 'components/navbar'
import Footerbar from 'components/footer'
export default {
    components: {
        navbar,
        Footerbar,
        timeout,
        update,
    },
    computed:{
        accredit: function() {
            if (this.$store.state.cert.type ==='test') {
                return  this.$store.state.cert.status === 'valid'
            } else {
                if (this.$store.state.cert.type ==='official') {
                    return true
                } else {
                   return false
                }     
            }           
        }
    },
    created() {
        let _this = this
        window.addEventListener('click', function() {
            let time = _this.$store.state.time
            _this.$store.commit('EDIT_WEB', time)
        })

        this.bus.$on('timeout_Event', function() {
            $('.modal').modal("hide")
            $('#timeout').modal("show")
        })
    },
    mounted() {
        $('body').on('copy', function() {
            $('.copyText').html(window.getSelection().toString())
        })
        $('.accredit-warp').height($(window).height() - 70 - 40)
        $(window).on('resize', () => {
            $('.accredit-warp').height($(window).height() - 70 - 40)
        })
    },
}
</script>
<style scoped>
.app{
    height: 100%;
    background: #e5e5e5;
}
.accredit-warp{
    overflow: auto;
    overflow-x: hidden;
    background: #e5e5e5;
}
.updata{
    width: 1270px;
    margin-left: -80px;
}
</style>