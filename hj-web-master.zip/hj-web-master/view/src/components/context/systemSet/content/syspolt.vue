<template>
    <div class="wrap syspolt">
		<div class="page-title"><h3>{{title}}</h3></div>
        <div class="table_wrap">
            <div class="page-title">
                <h3>网管参数</h3>
                <div style="cursor: pointer" @click.stop="setNum()">
                    <img src="/static/img/sure.png">
                    <span>确定</span>
                </div>
            </div>
            <table class="syspolt-table"> 
               <tbody>  
                    <tr>
                        <td >WebUI超时</td>
                        <td >
                            <input v-model="web_ui" type="number"   min="1" max="1440" step="1" @keydown="remove_e($event)" 
                            @focus="focusStyle($event)"  @blur="formatTest($event,'web_ui',1,1440)">
                            <span class="mi">分钟(1-1440)</span>
                        </td>
                        <td >管理员超出登录次数惩罚时间</td>
                        <td >
                            <input v-model="punish" type="number" min="1" @keydown="remove_e($event)"  
                            @focus="focusStyle($event)"  @blur="formatTest($event,'punish',1,10000)" >
                            <span class="mi">分钟(1-10000)</span>
                        </td>
                    </tr>
                    <tr>
                        <td>管理员最大登录次数</td>
                        <td>
                            <input v-model="max_times"  type="number" min="3" max="100" step="1"  @keydown="remove_e($event)" 
                            @focus="focusStyle($event)"  @blur="formatTest($event,'max_times',3,100)" >
                            <span class="mi">(3-100)&nbsp;&nbsp;</span>
                        </td>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </div>    
        <Tables 
            class="style_c" 
            :title="'网管策略'" 
            :btns='btns' 
            :field='field' 
            :tableData='tableData' 
            :pageSize='pageSize' 
            :totalNum="total_num"
            :perNum="size"
            :collectField="collect_field"
            :curPage="cur_page" 
            :clearSelectItems="selectedItems"
            @reset="reset"  
            @loadData="loadNs" 
            @sentSelectedItems="getSelectedItems"
            @sentEditData="getEditData"
            @changePageSize='changePageSize'
            @delEvent='delData'
            >
        </Tables>
		<Modals 
            :id="'modal'" 
            :title="'网管策略'" 
            :field='field' 
            :collectField="collect_field"
            :selectItem="select_item" 
            :status="status" 
            :errorMsg="errorMsg" 
            :type="type"
            :selectedItems="selectedItems" 
            :editData="edit_data"  
            @sentErrorMsg="getErrorMsg"
            @addEvent='addData'
            @editEvent='editData'
            >
        </Modals>
        <!-- <noticeModal :id="'notice_modal'" :title="'提示'" :status="num_status"></noticeModal> -->
    </div>
</template>
<script>
    import Tables from 'components/common/Tables'
	import search from 'components/common/search'
	import Modals from 'components/common/Modals'
    import logManageService from 'services/logManageService' 
    import SystemService from 'services/systemService'
    let field = [
        {
            type:'checkbox', 
        },
        {
            type:'rank',
        },
        {
            type:'text',
            label:'规则名',
            name:'name',
            regex:/^\S+$/,
            required:true, 
            remark:'*必填',
            ellipsis:'width: 300px',
            style:'width: 300px'        
        },
		{
            type:'text',
            label:'允许网管设备的IP',
            name:'ip_mac', 
            regex:/^((2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)$/,
            required:true, 
            remark:'*必填'         
        },
		{
            type:'textarea',
            label:'描述',
            name:'note', 
            regex:/^[\S\s]{0,32}$/,
            required:false,
            ellipsis:'width: 300px',
            style:'width: 300px',
            remark:'选填，长度不能超过32个字符'  
        }
    ]
    export default {
		components:{
		    Tables,
			Modals,
			search
	    },
        data() {
            return{
                title:'系统策略',
                btns:[
                    {
                        type:'add',
                        name:'添加',
                        event:'addEvent',
                        icon:`/static/img/add.png`,
                        class:'add_btn',
                    },
                    {
                        type:'del',
                        name:'删除',
                        event:'delEvent',
                        icon:`/static/img/delete.png`,
                        class:'del_btn',
                    },
                    {
                        type:'edit',
                        name:'编辑',
                        event:'editEvent',
                        icon:`/static/img/modpic.png`,
                        class:'edit_btn',
                    }
                ],
                field:field,
                tableData:[],
                pageSize: [10, 20, 40, 80],
                size: 20,
                total_num:1,
                cur_page:1,
                collect_field:'id',              
                select_item:[],
                status:"",
                errorMsg:'',
                type:'',
                selectedItems:[],
                edit_data:{},

                max_times:0,
                punish:0,
                web_ui:0,
                error_arr:[],
                num_status:'',
            }
        },
        created() {
            this.loadNum()
            this.loadNs()       
        },
        methods:{
			getSelectedItems(selectedItems) {
                this.selectedItems = selectedItems
            },
            getEditData(editdata) {
                this.edit_data = editdata 
            },
            getErrorMsg(msg) {
                this.errorMsg = msg
            },
            reset(type) {
                this.status = ""
                this.errorMsg = ''
                this.type = type
                $('.inputs_wrap .error_foramt').removeClass('error_foramt')
            },
            setNum() {         
                if (this.error_arr==0) {
                    let nmdata ={
                        1:this.web_ui,
                        2:this.punish,
                        3:this.max_times
                    }
                    SystemService.setNetParams(nmdata)
                    .then((res) => {
                        $('#notice_modal').modal('show')
                       
                        if (res.errcode === 0) {
                            $('#notice_modal').modal('hide')
                            this.num_status = 'ok' 
                            setTimeout(() => {
                                this.$Modal.success({
                                    title: '网管参数',
                                    content: '保存成功！',
                                    scrollable: false,
                                    onOk: () => {
                                        this.loadNum()
                                        // this.$store.commit('EDIT_Time', this.web_ui)
                                        // this.$store.commit('EDIT_WEB', this.web_ui)
                                    }
                                })       
                            }, 200)
                                             
                        } else {
                            this.num_status = 'error'
                            this.errorMsg = this.$t('error_code.' + res.errcode)
                        }
                    })
                }      
            }, 
            loadNum() {
                 SystemService.getNetParams()
                .then((res) => {
					if (res.errcode === 0) {      
						this.max_times = res['3']
						this.punish = res['2']
                        this.web_ui = res['1']
                    }
				})
            }, 
            setNs(nsdata) {
                this.status = 'ing'		
                nsdata.oper = nsdata.oper+'_ns'
                SystemService.getSysPolice(nsdata)
                .then((res) => {
					if (res.errcode === 0) {
                        this.status = 'ok'  
                        this.errorMsg = ''
                        this.$Modal.success({
                            title: '提示',
                            content: '操作成功！',
                            scrollable: false,
                            onOk: () => {
                                let loaddata ={
                                    oper:'get_ns',
                                    page:1,
                                }
                                this.loadNs(loaddata)
                            }
                        })            
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
				})
            },
            loadNs() {
                let params = {
                    t: 6,
                    page: this.cur_page,
                    row: this.size
                }
                SystemService.getNetMangage(params)
                .then((res) => {
					if (res.errcode === 0) {     
						this.total_num = res['6'].count
						this.tableData = res['6'].data
                    }
				})
            },
            changePageSize (page, size) {
                this.cur_page = page
                this.size = size
                this.loadNs()
            },
            addData(params) {
                params.note = params.note || ''
                let sendStr = `${params.name}|${params.ip_mac}|${params.note}`
                this.status = 'ing'
                SystemService.addNetMangage({6: sendStr})
                .then((res) => {
                    if (res.errcode === 0) {
                        $('#notice_modal').modal('hide')
                        this.status = 'ok'
                        this.errorMsg = ''
                        setTimeout(() => {
                            this.$Modal.success({
                                title: '网管策略',
                                content: '添加成功！',
                                scrollable: false,
                                onOk: () => {
                                    this.cur_page = 1
                                    this.loadNs()
                                }
                            })     
                        }, 250)
                    } else {
                      this.status = 'error'  
                      this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
                    
                })
            },
            editData(params) {
                params.note = params.note || ''
                let sendStr = `${params.id}|${params.name}|${params.ip_mac}|${params.note}`
                this.status = 'ing'
                SystemService.editNetMangage({6: sendStr})
                .then((res) => {
                    if (res.errcode === 0) {
                        $('#notice_modal').modal('hide')
                        this.status = 'ok'
                        this.errorMsg = ''
                        setTimeout(() => {
                             this.$Modal.success({
                                title: '提示',
                                content: '修改成功！',
                                scrollable: false,
                                onOk: () => {
                                    this.loadNs()
                                }
                            })     
                        }, 250)
                    } else {
                      this.status = 'error'
                      this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
                    
                })
            },
            delData(params) {
                let ids = params.ids
                this.status = 'ing'
                SystemService.delNetMangage({6: ids})
                .then((res) => {
                    if (res.errcode === 0) {
                        $('#notice_modal').modal('hide')
                        this.status = 'ok'
                        this.errorMsg = ''
                        setTimeout(() => {
                            this.$Modal.success({
                                title: '网管策略',
                                content: '删除成功！',
                                scrollable: false
                            })     
                        }, 250)
                        this.loadNs()
                    } else {
                      this.status = 'error'
                      this.errorMsg = this.$t('error_code.' + res.errcode)  
                    }
                })
            },
            remove_e(event) {//input输入不能是.,e
                if (event.keyCode==69||event.keyCode==229||event.keyCode==110||event.keyCode==190) {
                    event.preventDefault()        
                }  
            },
            formatTest(event,type,v1,v2) {
                let ele = $(event.currentTarget)
                if (ele.val()<=v2&&$(ele).val()>=v1) {
                    ele.removeClass("error_foramt")	
                    for(let [k,v] of this.error_arr.entries()) {
                        if (v == type) {
                            this.error_arr.splice(k,1)
                        }
                    }
                    return true		
                } else {	 
                    ele.addClass("error_foramt")
                    this.error_arr = [...this.error_arr,type]
                    return false
                }
            },
            focusStyle(event) {
                $(event.currentTarget).removeClass("error_foramt")
            },
        }
    }
</script>