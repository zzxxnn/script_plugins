<template>
    <table>
        <thead class="thead-bottom-line">
            <tr>
                <th style="width: 1200px;" colspan="4">
                    <span style="margin-left: 5px">Ping</span>
                    <span style="float:right;padding: 0 15px " @click='diagnose()'>
                        <button class="yellow-btn button button--aylen">
                            <img src="../../../../img/diagnose.png" style="margin-right: 5px;margin-bottom:3px;width: 13px" >开始诊断
                        </button>
                    </span>
                </th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="width: 100px; text-align: left;padding-left: 23px;">IP</td>
                <td style="width: 500px;">
                    <input class="pinkip" style="width:180px;margin:4px 0;" @blur="testIp($event)" @keyup.enter="diagnose()">
                    <span class="mi">*必填</span>
                </td>
                <td style="width: 100px;"></td>
                <td style="width: 500px;"></td>
            </tr>
            <tr>
                <td style="width: 100px;">Ping次数</td>
                <td style="width: 500px;"><input type="number" min="1"  max='255' step="1" @keydown="mgnextInput($event)" @focus="empty('.pinktimes')" @keyup.enter="diagnose()" @blur='wordslength(".pinktimes",0,101)' class="pinktimes" v-model=times> <span class="mi">(1-100)</span></td>
                <td style="width: 100px;">报文长度</td>
                <td style="width: 500px;"><input type="number" min="64"  max='8000' step="1" @keydown="mgnextInput($event)"  @focus="empty('.pinklength')" @keyup.enter="diagnose()" @blur='wordslength(".pinklength",63,1501)' class="pinklength" v-model=length> <span class="mi">(64-1500字节)</span></td>
            </tr>
            <tr>					
                <td style="text-align: left;vertical-align: top;line-height:25px;padding-left:23px" colspan="4">
                    测试结果:  
                    <ul id='pinkScroll' style="height:100%;overflow-y:auto;max-height: 500px;min-height: 300px;padding:0 10px 20px;width: 100%;box-sizing: border-box">
                        <li v-for='item in pingResult'>{{item}}
                        </li>
                        <li>
                            <div class="rotate">|</div>
                        </li>
                    </ul>
                </td>
                
            </tr>
        </tbody>
    </table>
</template>
<script>
import ipinput from 'components/libs/ipinput'
import formatTest from 'libs/formatTest'
export default{
    components:{
        ipinput
    },
    props: {
        pingResult:{
            type: Array,
            require: true
        }
    },
    data() {
        return{
            flag:false,
            ip:'',
            times:'5',
            length:'64',
            textlength:true,
            pinktimes:true
        }
    },
    methods:{
        mgnextInput(event) {//input输入不能是.,e
            if (event.keyCode==69||event.keyCode==229||event.keyCode==110||event.keyCode==190) {
                event.preventDefault()        
            }  
        },
        traceRoutePage() {
            let status=false
            this.$emit("traceRoutePage",status)
        },
        diagnose() {
             this.wordslength(".pinktimes",0,101)
             this.wordslength(".pinklength",63,1501)
            //  let pinkip=this.ipVal('.pinkip')
            let pinkip = $('.pinkip').val()
            if (this.testIp() && this.pinktimes && this.textlength) {
                let type={}
                type.status=true
                type.type='ping'
                type.ip=pinkip
                type.times=this.times
                type.length=this.length
                this.$emit("diagnose",type)  
            } else {
                this.isEmpty('.pinktimes')
                this.isEmpty('.pinklength')
                
            }
        },
        ipVal(ele) {
            let ipVal = ($(ele+' .ip_a').val()?$(ele+' .ip_a').val():"")+
                        ($(ele+' .ip_b').val()?'.'+$(ele+' .ip_b').val():"")+
                        ($(ele+' .ip_c').val()?'.'+$(ele+' .ip_c').val():"")+
                        ($(ele+' .ip_d').val()?'.'+$(ele+' .ip_d').val():"")
            return ipVal
		},
        testVal: function(ele, reg) {
            let test = new formatTest(ele, reg, false)
            return test.testFormat()
        },
        testIp(evt) {
            // let ip_a = $(ele).find('.ip_a').val()
            // let ip_b = $(ele).find('.ip_b').val()
            // let ip_c = $(ele).find('.ip_c').val()
            // let ip_d = $(ele).find('.ip_d').val()
            // let val = ip_a+"."+ip_b+"."+ip_c+"."+ip_d
            let $ele = $('.pinkip')
            let val = $ele.val()
            let reg = /^((2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)$/
            if (val=='0.0.0.0') {
               $ele.addClass('error_foramt').addClass('animated shake')
                setTimeout(()=> {
                    $ele.removeClass('animated shake')
                }, 200)
                return false 
            }
            if (reg.test(val)) {
                $ele.removeClass('error_foramt').removeClass('animated shake')
                return true
            } else {
                $ele.addClass('error_foramt').addClass('animated shake')
                setTimeout(()=> {
                    $ele.removeClass('animated shake')
                }, 200)
                return false
            }
		},
		isEmpty: function(ele) {
			let val = $(ele).val()
			if (!val) {
				$(ele).css("border",'1px solid #b63039')
				$(ele).addClass("animated shake")
                $(ele).parent().find('.mi').css('color', '#b63039')
                $(ele).css("outline",'none')
				setTimeout(function() {
					$(ele).removeClass('animated shake')
				}, 200)
			}
		},
        empty: function(ele) {
            $(ele).parent().find('.mi').css('color', '#575757')
            $(ele).css('border', '')
            $(ele).css('outline', '1px solid #96ccff')
        },
        wordslength: function(ele, v1, v2) {
            if ($(ele).val() < v2 && $(ele).val() > v1) {
                if (ele === '.pinklength') {
                    this.textlength = true;
                } else {
                    this.pinktimes = true;
                }
                $(ele).css("border-color",'#d2d2d2')
            } else {
                if (ele === '.pinklength') {
                    this.textlength = false;
                } else {
                    this.pinktimes = false;
                }
                $(ele).css("border",'1px solid #b63039')
                $(ele).addClass("animated shake")
                $(ele).parent().find('.mi').css('color', '#b63039')
                setTimeout(function() {
                    $(ele).removeClass('animated shake')
                }, 200)
            }
                $(ele).css("outline",'none')
        }
    }
}
</script>
<style scoped lang="less">
    .pinkip{
        margin-right: 10px;
    }
    .rotate{
    	width: 18px;
    	display: none;
        animation: rot 1s infinite;
    }
    input{
        padding:3px; 
        border: 1px solid #e6e6e6;
        border-radius:3px;
        height: 25px;
        width: 180px; 
        margin-right: 10px;
        padding-left: 10px;
        background: #FFFFFF;
    }
    thead tr th {
        text-align: left;
        padding-left: 15px;
	}
    td:nth-child(odd) {
		text-align: center;
	}
    td:nth-child(even) {
		text-align: left;
        padding-left: 20px;
	}
	tr {
		height: 30px;
	}
    .mi{
    	color: #aaa9a9;
		line-height: 20px;
        vertical-align: middle;
	}
     @keyframes rot {
        0% {
           opacity: 0
        }
        100%{
            opacity: 1
        }
    }
    @-webkit-keyframes  rot {
        0% {
           opacity: 0
        }
        100%{
            opacity: 1
        }
    }
    @-moz-keyframes rot{
   		 0% {
           opacity: 0
        }
        100%{
            opacity: 1
        }
   }
   @-ms-keyframes rot{
   		 0% {
           opacity: 0
        }
        100%{
            opacity: 1
        }
   }
</style>