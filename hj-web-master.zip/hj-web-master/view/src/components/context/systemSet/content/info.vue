<template>
	<div class="wrap">
		<div class="page-title">
			<h3>系统信息</h3>
		</div>
		<div class="table-wrap">
			<table>
				<thead class="thead-bottom-line">
					<tr>
						<th colspan="4">内容</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="width: 100px;">硬件平台：</td>
						<td style="width: 500px;">{{acrt.model ? acrt.model : '-'}}</td>
						<td style="width: 100px;">系统版本：</td>
						<td style="width: 500px;">{{ sysVerison }}</td>
					</tr>
					<tr>
						<td style="width: 100px;">在线节点：</td>
						<td style="width: 500px;">{{ onlineNode }}</td>
						<td style="width: 100px;">运行时间：</td>
						<td style="width: 500px;">{{ runTime }}</td>
					</tr>
					<tr>					
						<td style="width: 100px;">序 列 号：</td>
						<td style="width: 500px;">{{acrt.device_id ? acrt.device_id : '-'}}</td>
						<td style="width: 100px;">系统时间：</td>
						<td style="width: 500px;">{{ systime }}</td>
					</tr>
				</tbody>
			</table>
		</div>
        <div id="dtBox"></div>
	</div>
</template>
<script>
	import SystemService from 'services/systemService'
	export default {
		created() {
			this.getsysinfo()
			this.intervalid = setInterval(() => this.getsysinfo(), 1000)
		},
        mounted() {
			this.getsysinfo()
        },
        data() {
            return {
                hardware:"",
                sysVerison:"",
                onlineNode:0,
                runTime:"",
                serialNumber:"",
                systime:""
            }
        },
		computed:{
			acrt: function() {
				return this.$store.state.cert
			}
		},
		beforeDestroy() {
			clearInterval(this.intervalid)
		},
        methods: {
			getsysinfo() {
				SystemService.getSysinfo()
				.then((res) => {
					if (res.errcode === 0) {
						this.sysVerison = res['23']
						this.systime = this.dateFormat(new Date(res['24'] * 1000), 'yyyy-MM-dd hh:mm:ss').split(' ')[1]
						this.onlineNode = res['4']
						this.runTime = this.runningTime(res[20])
					}
				})
			},
            runningTime(time) {
				if (time < 60) {
					return time + this.$t('home.seconds')
				}
				if (time >= 60 && time < 3600) {
					return Math.floor(time/60) + this.$t('home.minutes') + (time % 60) + this.$t('home.seconds')
				}
				if (time >= 3600 && time < 24*3600) {
					return Math.floor(time/3600) + this.$t('home.hours') + Math.floor(time%3600/60) + this.$t('home.minutes')
				}
				if (time >= 24*3600) {
					return Math.floor(time/24/3600) + this.$t('home.days') + Math.floor(time%86400/3600) + this.$t('home.hours')
				}
			},
			dateFormat(date, format) {
				let o = {
					'M+': date.getMonth() + 1,
					'd+': date.getDate(),
					'h+': date.getHours(),
					'm+': date.getMinutes(),
					's+': date.getSeconds(),
					'q+': Math.floor((date.getMonth() + 3) / 3),
					'S': date.getMilliseconds()
				}

				if (/(y+)/.test(format)) {
					format = format.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length))
				}

				for (let k in o) {
					if (new RegExp("(" + k + ")").test(format)) {
						format = format.replace(RegExp.$1, (RegExp.$1.length === 1 ? o[k] : (("00" + o[k]).substr(("" + o[k]).length))))
					}
				}

				return format
			}
        }
	}
    
</script>
<style scoped lang='less'>
	.wrap {
		margin: 30px 0 0 30px;
		padding-bottom: 10px;
		background: #FFFFFF;
	}
	.table-wrap{
		margin: 20px;
	}
    thead tr th {
        text-align: left;
        padding-left: 15px;
		height: 30px;
	}
    td:nth-child(odd) {
		text-align: center;
	}
    td:nth-child(even) {
		text-align: left;
        padding-left: 20px;
	}
	tbody tr {
		height: 35px;
	}
</style>