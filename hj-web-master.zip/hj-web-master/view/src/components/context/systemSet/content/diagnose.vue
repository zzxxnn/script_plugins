<template>
	<div class="wrap">
		<div class="page-title">
			<h3> 诊断工具 </h3>
		</div>
		<div class="table-wrap">
			<div class="btns">
					<button class="button button--aylen" :class="type=='ping' ? 'btn-active' : 'btn-unactive'" @click="chageType('ping')">Ping</button>      
					<button class="button button--aylen" :class="type=='trace' ? 'btn-active' : 'btn-unactive'" @click="chageType('trace')">TraceRoute</button>       
			</div>
		  <ping v-if="type=='ping'" v-on:traceRoutePage='traceRoutePage' :pingResult='pingResult' @diagnose='diagnose'></ping>
		  <traceRoute v-else v-on:pinkPage='pinkPage' @diagnose='diagnose' :traResult='traResult'></traceRoute>
	  </div>
	</div>
</template>
<script>
	 import SystemService from 'services/systemService'
	 import ping from './diagnose/ping'
	 import traceRoute from './diagnose/traceRoute'
	 export default{
		components: {
			ping,
			traceRoute
		},
		data() {
			return{
				type:'ping',
				pingResult:[],
				traResult:[],
				result:'',
				interval:'',
				interval2:'',
				errorMessage:''
			}
		},
		methods:{
			getErrorMsg(msg) {
				this.errorMsg = msg
			},
			chageType(type) {
				this.type = type
			},
			pinkPage(msg) {
				this.flag = msg
				this.traResult = []
				this.pingResult = []
				$(".rotate").hide()
				clearTimeout(this.interval)
			},
			traceRoutePage(msg) {
				this.flag = msg
				this.traResult = []
				this.pingResult = []
				$(".rotate").hide()
				clearTimeout(this.interval)
			},
			diagnose(msg) {
				this.result = ''
				let params = {}
				$(".rotate").show()

				if (msg.type === 'ping') {
					params.oper = msg.type
					params.ip = msg.ip
					params.length = msg.length
					params.times = msg.times

					SystemService.getPing(params)
						.then((res) => {
							if (res.errcode === 0) {
								// 获取ping结果
								this.getPingResult()
							} else {
								$(".rotate").hide()
								clearTimeout(this.interval)
							}
						}, () => {
							$(".rotate").hide()
							clearTimeout(this.interval)
						})
				} else {
					params.oper = msg.type
					params.min_ttl = msg.min_ttl
					params.max_ttl = msg.max_ttl
					params.ip = msg.ip

					SystemService.getTraceRoute(params)
						.then((res) => {
							if (res.errcode === 0) {
								// 获取ping结果
								this.getTraceRouteResult()
							} else {
								$(".rotate").hide()
								clearTimeout(this.interval2)
							}
						}, () => {
							$(".rotate").hide()
							clearTimeout(this.interval2)
						})
				}
			},
			getPingResult() {
				SystemService.getPingResult()
					.then((res) => {
						$(".rotate").hide()
						if (res.errcode === 0) {
							this.pingResult = res.ping
							$('#pinkScroll').scrollTop($('#pinkScroll')[0].scrollHeight)
							this.traResult = []
							// 轮询去取结果
							clearTimeout(this.interval)
							this.interval = setTimeout(this.getPingResult, 1000)
						} else {
							clearTimeout(this.interval)
						}
					}, () => {
						$(".rotate").hide()
						clearTimeout(this.interval)
					})
			},
			getTraceRouteResult() {
				SystemService.getTraceRouteResult()
					.then((res) => {
						$(".rotate").hide()
						if (res.errcode === 0) {
							this.traResult = res.traceroute
							$('#tracerouteScroll').scrollTop( $('#tracerouteScroll')[0].scrollHeight )
							this.pingResult = []
							// 轮询去取结果
							clearTimeout(this.interval2)
							this.interval2 = setTimeout(this.getTraceRouteResult, 1000)
						} else {
							clearTimeout(this.interval2)
						}
					}, () => {
						$(".rotate").hide()
						clearTimeout(this.interval2)
					})
			}
		},
		
		beforeDestroy() {
			$(".rotate").hide()
			clearTimeout(this.interval)
			clearTimeout(this.interval2)
		}
	 }
</script>
<style lang="less" scoped>
	.btns{
		margin-bottom: 10px;
	}
	button{
		border-radius: 3px;
		height: 20px;
		padding:0 20px;     
  }
	.wrap {
		margin: 30px 0 0 30px;
		padding-bottom: 10px;
		background: #FFFFFF;
	}
	.table-wrap{
		padding: 20px;
	}
</style>
