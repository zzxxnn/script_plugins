<template>
		<div class="container current-wrap">
	    <div class="row">
	      <leftnavbar :menudata='menudata' class="navBar  col-sm-2 col-md-2 col-lg-2" :screen_with = "screen_with" :class="[screen_with != 'big'?'samll_width':'']" @comeOut="comeOut" @goIn="goIn"></leftnavbar>
	      <div class="view col-sm-10 col-md-10 col-lg-10" :class="[screen_with == 'small'?'small_content':screen_with == 'mid'?'mid_content':'']">
	        <router-view></router-view>
	      </div>
	    </div>
  	</div>
</template>
<script>	
  import leftnavbar from 'src/components/navbar/leftbar.vue'
  export default {
    components: {
      leftnavbar
    },
    data() {
    	return{
    		screen_with:'',
				menudata:[
				{
					name:'系统维护',
					path:'/system',
					img:'/static/img/system.png',
					children:[
						{
							name:'系统升级',
							path:'/system/update'
						},{
							name:'备份/恢复',
							path:'/system/backup'
						},{
							name:'重启/关机',
							path:'/system/boot'
						}
					]
				},
				{
					name:'系统管理员',
					path:'/system/manager',
					img:'/static/img/systemadmin.png'
				},{
					name:'日期/时间',
					path:'/system/time',
					img:'/static/img/datatime.png'
				},{
					name:'系统信息',
					path:'/system/info',
					img:'/static/img/systeminfo.png'
				},{
					name:'系统策略',
					path:'/system/policy',
					img:'/static/img/syspolt.png'
				},{
					name:'集中管理',
					path:'/system/centralize',
					img:'/static/img/sysmanagement.png'
				},{
					name:'诊断工具',
					path:'/system/diagnose',
					img:'/static/img/diagnose.png'
				}
				]
    	}
    },
    created() {
      this.getScreenWidth()
      let _this = this
      $(window).resize(function() {
      	  _this.getScreenWidth()
      })
    },
    methods: {
    	getScreenWidth() {
      	let  screen_with = $(window).width()
      	if (screen_with>1470) {
      		this.screen_with = 'big'
      	} else if (screen_with<=1470&&screen_with>1280) {
      		this.screen_with = 'mid'
      	} else {
      		this.screen_with = 'small'     	
      	}
      },
			comeOut() {
			  $('.samll_width').addClass('out').removeClass('in')
			},
			goIn() {
				$('.samll_width').addClass('in').removeClass("out")
			}
		}
  }
</script>
<style scoped>
.container{
	height: 100%;
}
.un_accredit{
	width: 1240px;
}
.row{
	height: 100%;
}
.current-wrap{
  min-width: 1500px;
}
.view,.navBar{
   display: inline-block;
   vertical-align: top;
}  
.samll_width{
	position: relative; 
	z-index: 10;
	left: -220px;
	transition: 0.5s;
}
.small_content{
	margin-left: -250px;
}
.mid_content{
	margin-left: -200px;
}
.in{
	left:-220px;
}
.out{
	left:-20px;
}
</style>
