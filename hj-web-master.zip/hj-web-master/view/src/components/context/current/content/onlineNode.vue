<template>
    <div class="online-node">
        <Tables
            :title='title'
            :field='field'
            :btns='btns'
            :tableData='tableData'
            :animateShow="animate_show"
            :totalNum="total_num"
            :perNum="size"
            :collectField="collect_field"
            :clearSelectItems="selectedItems"
            :curPage="cur_page"
            :pageSize='pageSize'
            :tableNotice="$t('realTime.tableNotice1')"
            :rankable="true"
            :rankOrderBy="by"
            :rankOrder="order"
            :dbclick="false"
            @reset="reset"
            @rankData="rankData"
            @loadData="getData"
            @sentEditData="getEditData"
            @clearInterval="handleClearInterval"
            @setBlock="setBlockModal"
            @changePageSize='changePageSize'
            @delEvent="delDada"
            :confirmTextKey="'common.delNodeNotice'"
            >
            <div slot="filter">
                <search
                    class="label-width"
                    :searchFiled="searchFiled"
                    @searchEvent="searchData">
                </search>
            </div>
        </Tables>
        <Modals
            :id="'modal'"
            :title="$t('realTime.navBtn4')"
            :status="status"
            :errorMsg="errorMsg"
            :type="'del'"
            >
        </Modals>


    </div>
</template>
<script>
    import Tables from 'components/common/Tables'
    import Modals from 'components/common/Modals'
    import realTimeService from 'services/realTimeService'
	import indexService from 'services/indexService'
    import defendService from 'services/defendService'
	import search from 'components/common/search'
    export default {
		components: {
		    Tables,
            search,
            Modals
	    },
        data() {
            return{
                title: this.$t('realTime.navBtn4'),
                btns: [
                    {
                        type:'del',
                        name:this.$t('common.delBtn'),
                        event:'delEvent',
                        icon:'/static/img/delete.png',
                        class:'del_btn'
                    }
                ],
                field: [
                    {
                        type:'checkbox',
                    },
                    {
                        type:'rank'
                    },
                    {
                        type:'text',
                        label:this.$t('realTime.onlineTabelTh1'),
                        name:'mac',
                        style:'width: 120px'
                    },
                    {
                        type:'none',
                        label:this.$t('realTime.onlineTabelTh2'),
                        name:'desc',
                        editable:true,
                        regex:/^[\S\s]{0,32}$/,
                        ellipsis:'width: 120px'
                    },
                    {
                        type:'text',
                        label:this.$t('realTime.onlineTabelTh3'),
                        name:'rip',
                        style:'width: 100px'
                    },
                    {
                        type:'text',
                        label:this.$t('realTime.onlineTabelTh4'),
                        name:'vip',
                        style:'width: 100px'
                    },
                    {
                        type:'text',
                        label:this.$t('realTime.onlineTabelTh5'),
                        name:'wip',
                        style:'width: 100px'
                    },
                    {
                        type:'text',
                        label:this.$t('realTime.onlineTabelTh6'),
                        name:'name',
                        style:'width: 100px'
                    },
                    {
                        type:'text',
                        label:this.$t('realTime.onlineTabelTh7'),
                        name:'groupid',
                        style:'width: 100px'
                    },
                    {
                        type:'text',
                        label:this.$t('realTime.onlineTabelTh8'),
                        name:'vlanid',
                        style:'width: 80px'
                    },
                    {
                        type:'text',
                        label:this.$t('realTime.onlineTabelTh9'),
                        name:'time',
                        style:'width: 120px'
                    },
                    {
                        type:'opration',
                        label:[this.$t('common.unblockBtn'),this.$t('common.blockBtn')],
                        event:'setBlock',
                        linkname:'is_block',
                        collectname:'mac',
                        style:'width: 80px'
                    }
                ],
				searchFiled:[
                    {
                        type:'text',
                        label:this.$t('realTime.onlineTabelTh1'),
                        name:'mac'
                    },
                    {
                        type:'text',
                        label:this.$t('realTime.onlineTabelTh3'),
                        name:'rip'
                    },
                    {
                        type:'time-rang',
                        label:this.$t('common.searchLabel1'),
                        name:['start_time','end_time']
                    },
                    {
                        type:'text',
                        label:this.$t('realTime.onlineTabelTh4'),
                        name:'vip'
                    },
                    {
                        type:'text',
                        label:this.$t('realTime.onlineTabelTh5'),
                        name:'wip'
                    },
                    {
                        type:'text',
                        label:this.$t('realTime.onlineTabelTh6'),
                        name:'name'
                    }
                ],
                tableData:[],
                total_num:1,
                collect_field:'mac',
                selectedItems:[],
                select_item:[],
                status:"",
                errorMsg:'',
                type:'',
                edit_data:{},
				block:'',
                cur_page:1,
                pageSize:[10, 20, 40, 80],
				finddata:{},
                animate_show:false,
                params:{},
                size:20,
                order: 'desc',
                by:'time'
            }
        },
        created() {
            this.getData()
            // this.intervalid = setInterval(()=>{ this.getData() },1000)
        },
        methods:{
            getSelectedItems(selectedItems) {
                this.selectedItems = selectedItems
            },
            getEditData(editdata) {
                this.edit_data = editdata
                this.edit_data.oper = 'block'
            },
            getErrorMsg(msg) {
                this.errorMsg = msg
            },
            reset(type) {
                // this.status = ""
                // this.errorMsg = ''
                this.type = type
            },
			setBlockModal(block, operid) {
				this.reset()
				this.block = block
				this.edit_data = {
					ipmac: operid,
					oper: block ? 'unblock' : 'block'
                }

                this.intervalid && clearTimeout(this.intervalid)

                this.$Modal.confirm({
                    title: this.block ? this.$t('common.unblockTitle') : this.$t('common.blockTitle'),
                    content: this.block ? this.$t('common.unblockNotice') : this.$t('common.blockNotice'),
                    scrollable: false,
                    onOk: () => {
                        this.setBlock()
                    },
                    onCancel: () => {
                        this.getData()
                    }
                })
			},
			setBlock() {
				indexService.setBlock(this.edit_data)
				.then((res) => {
					if (res.errcode === 0) {
                        // this.status='ok'
                        this.$Modal.remove()
                        setTimeout(() => {
                            this.getData()
                            this.$Modal.success({
                                title: this.block ? this.$t('common.unblockTitle') : this.$t('common.blockTitle'),
                                content: '操作成功！',
                                scrollable: false
                            })
                        }, 500)

					}
				})
			},
            handleClearInterval(val) {
                if (val) {
                    clearTimeout(this.intervalid)
                }
            },
            changePageSize (nowpage, size) {
                this.cur_page = nowpage
                this.size = size
                clearTimeout(this.intervalid)
                this.getData()
            },
            rankData(param){
                this.order = param.order
                this.by =  param.by
                clearTimeout(this.intervalid)
                this.getData()
            },
            searchData(searchData){
                this.animate_show = true
                this.params = searchData
                clearTimeout(this.intervalid)
				this.getData()
            },
            getData(){
                realTimeService.getOnlineNode(this.cur_page, this.size, this.order, this.by, this.params)
                .then((res) => {
                    this.animate_show = false
                    if (res.errcode===0){
                        this.tableData = res['10'].stats.map((item)=>{
                            item.is_drop = item.is_block?true:false
                            item.groupid = this.$t('common.tableRoad') + item.groupid
                            item.time = this.formatDate(item.time)
							return item
                        })
                        this.total_num = res['10'].count
                        this.intervalid && clearTimeout(this.intervalid)
                        this.intervalid = setTimeout(() => {
                            this.getData()
                        }, 5000)
                    } else {
                        this.intervalid && clearTimeout(this.intervalid)
                    }
                })
                .fail((res) => {
                    this.intervalid && clearTimeout(this.intervalid)
                })
            },
            formatDate(timestrap){
                let time  = new Date(timestrap * 1000)
                let year = time.getFullYear()
                let month = time.getMonth()+1
                let date = time.getDate()
                let hour = time.getHours()
                let minutes = time.getMinutes()
                let seconds = time.getSeconds()

                return `${year}-${sigForamt(month)}-${sigForamt(date)} ${sigForamt(hour)}:${sigForamt(minutes)}:${sigForamt(seconds)}`

                function sigForamt(time){
                    return Number(time) > 9 ? time :  '0' + time
                }
            },
            delDada(params){
                this.status = 'ing'
                setTimeout(() => {
                    $("#modal").modal("show")
                }, 400);
                this.intervalid && clearTimeout(this.intervalid)
                realTimeService.delOnlineNode({"10": params.ids})
                    .then((res) => {
                        if (res.errcode === 0){
                            setTimeout(() => {
                                $("#modal").modal("hide")
                                this.status = 'ok'
                                this.errorMsg = ''
                                setTimeout(() => {
                                    this.$Modal.success({
                                        title: '在线节点',
                                        content: '删除成功！',
                                        scrollable: false
                                    })
                                }, 250)
                                this.selectedItems = []
                                this.getData()
                            }, 2000)
                           
                        } else {
                            this.status = 'ok'
                            $("#modal").modal("hide")
                        }
                    })
            }
        },
		beforeDestroy() {
            this.intervalid && clearTimeout(this.intervalid)
		}
    }
</script>
<style scoped>
	.button {
		height: 20px;
		margin-right: 10px;
	}
	.active {
		background: #69b6ff;
		color: #ffffff;
	}
	.unactive{
		background: #e8e8e8;
		color: #444!important;
    }

</style>
