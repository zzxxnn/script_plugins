<template>
    <div>
        <Tables
            :title='title'
            :btns='btns'
            :field='field'
            :tableData='tableData'
            :animateShow="animate_show"
            :perNum='size'
            :totalNum="total_num"
            :collectField="collect_field"
            :dbClickDisabled="true"
            :tableNotice="momal_notice"
            :curPage="cur_page"
            :clearSelectItems="selectedItems"
            :pageSize='pageSize'
            :rankable="true"
            @reset="reset"
            @rankData="rankData"
            @changePageSize='changePageSize'
            @loadData="getData"
            @sentSelectedItems="getSelectedItems"
            @sentEditData="getEditData"
            @delEvent="delDada"
            >
            <div slot="filter">
                <search :searchFiled="searchFiled" @searchEvent ="searchData"></search>
            </div>
        </Tables>

        <Modals
            :id="'modal'"
            :title="$t('realTime.blackModalTitle')"
            :field='field'
            :collectField="collect_field"
            :selectItem="select_item"
            :status="status"
            :errorMsg="errorMsg"
            :type="type"
            :selectedItems="selectedItems"
            :editData="edit_data"
            :momalNotice="momal_notice"
            @sentErrorMsg="getErrorMsg"
            @addEvent="addData"
            >
          </Modals>
    </div>
</template>
<script>
    import Tables from 'components/common/Tables'
    import Modals from 'components/common/Modals'
    import realTimeService from 'services/realTimeService'
    import search from 'components/common/search'
    export default {
		components: {
		    Tables,
            Modals,
			search
	    },
        data() {
            return {
                title: this.$t('realTime.navBtn7'),
                btns: [
                    {
                        type: 'add',
                        name: this.$t('common.addBtn'),
                        event: 'addEvent',
                        icon: '/static/img/add.png',
                        class: 'add_btn'
                    },
                    {
                        type: 'del',
                        name: this.$t('common.delBtn'),
                        event: 'delEvent',
                        icon: '/static/img/delete.png',
                        class: 'del_btn'
                    }
                ],
                field: [
                    {
                        type: 'checkbox',
                    },
                    {
                        type: 'rank'
                    },
                    {
                        type: 'text',
                        label: this.$t('realTime.blackTableTh1'),
                        name: 'mac',
                        regex: /^((2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)$|^[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}$/,
                        required: true,
                        remark: this.$t('realTime.w_bRemark1')
                    },
                    {
                        type: 'none',
                        label: this.$t('realTime.blackTableTh4'),
                        name: 'description',
                        editable: true,
                        ellipsis:'width: 280px',
                        style:'width: 280px'
                    },
                    {
                        type: 'none',
                        label: this.$t('realTime.blackTableTh2'),
                        name: 'timestamp',
                        style:'width: 140px'
                    },
                    {
                        type: 'textarea',
                        label: this.$t('realTime.blackTableTh3'),
                        name: 'note',
                        regex: /^[\S\s]{0,32}$/,
                        required: false,
                        remark: this.$t('realTime.w_bRemark2'),
                        ellipsis:'width: 300px',
                        style:'width: 300px'
                    }
                ],
                searchFiled: [
                    {
                        type: 'text',
                        label: this.$t('realTime.blackTableTh1'),
                        name: 'mac'
                    },
                    {
                        type: 'time-rang',
                        label: this.$t('common.searchLabel1'),
                        name: ['start_time','end_time']
                    }
                ],
                tableData: [],
                total_num: 1,
                cur_page: 1,
                pageSize: [10, 20, 40, 80],
                collect_field: 'id',
                select_item: [],
                status: "",
                errorMsg: '',
                type: '',
                selectedItems: [],
                edit_data: {},
                momal_notice: this.$t('realTime.tableNotice2'),
                finddata: {},
                animate_show: false,
                order: '',
                by: '',
                size: 20,
                params: {}
            }
        },
        created() {
            this.getData()
            this.intervalid = setInterval(() => {this.getData()}, 30000)
        },
        methods:{
            getSelectedItems(selectedItems) {
                this.selectedItems = selectedItems
            },
            getEditData(editdata) {
                this.edit_data = editdata
            },
            getErrorMsg(msg) {
                this.errorMsg = msg
            },
            reset(type) {
                this.status = ""
                this.errorMsg = ''
                this.type = type
                $('.inputs_wrap .error_foramt').removeClass('error_foramt')
            },
            changePageSize (nowpage, size) {
                this.cur_page = nowpage
                this.size = size
                this.getData()
            },
            rankData(param){
                this.order = param.order
                this.by =  param.by
                this.getData()
            },
            searchData(searchData){
                this.animate_show = true
                this.params = searchData
				this.getData()
            },
            getData(){
                realTimeService.getBlackList(this.cur_page, this.size, this.order, this.by, this.params)
                .then((res)=>{
                    this.animate_show = false
                    if(res.errcode === 0){
                        this.tableData = res['4'].data
                        this.total_num = res['4'].count
                    }else{
                        clearInterval(this.intervalid)
                    }
                })
                .fail((res)=>{
                    clearInterval(this.intervalid)
                })
            },
            addData(params){
                let note = params.note?params.note:'-'
                let conf = `${params.mac}|${note}`
                realTimeService.addBlackList(conf)
                .then((res)=>{
                    if(res.errcode === 0){
                        this.status = 'ok'
                        this.errorMsg = ''
                        $('#modal').modal('hide')
                        this.$Modal.success({
                            title: '当前黑名单',
                            content: '添加成功！',
                            scrollable: false,
                            onOk: () => {
                                this.getData()
                            }
                        })
                    }else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
                })
            },
            delDada(params){
                 this.status ='ing'
                 realTimeService.delBlackList(params.ids)
                .then((res)=>{
                    if(res.errcode === 0){
                        this.status = 'ok'
                        this.errorMsg = ''
                        setTimeout(() => {
                            this.$Modal.success({
                                title: '当前黑名单',
                                content: '删除成功！',
                                scrollable: false
                            })
                        }, 250)
                        this.getData()
                        this.selectedItems = []
                    }else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
                })
            }

        },
		beforeDestroy() {
			this.intervalid && clearTimeout(this.intervalid)
		}
    }
</script>
