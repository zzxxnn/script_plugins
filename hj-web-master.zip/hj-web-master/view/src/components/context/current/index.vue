<template>
		<div class="container current-wrap">
	    <div class="row">
	      <leftnavbar :menudata='menudata' class="navBar  col-sm-2 col-md-2 col-lg-2" :screen_with="screen_with" :class="[screen_with !== 'big' ? 'samll_width' : '']" @comeOut="comeOut" @goIn="goIn"></leftnavbar>
	      <div class="view col-sm-10 col-md-10 col-lg-10" :class="[screen_with === 'small'?'small_content':screen_with === 'mid' ? 'mid_content' : '']">
	        <router-view></router-view>
	      </div>
	    </div>
  	</div>
</template>
<script>
  import leftnavbar from 'src/components/navbar/leftbar.vue'
  export default {
    components: {
      leftnavbar
    },
    data() {
    	return{
    		screen_with:'',
				menudata:[
				{
					name:this.$t('realTime.navBtn1'),
					path:'/monitor/resource',
					img:'/static/img/equip.png'
				},
				{
					name:this.$t('realTime.navBtn2'),
					path:'/monitor/interface',
					img:'/static/img/port.png'
				},{
					name:this.$t('realTime.navBtn3'),
					path:'/monitor/user',
					img:'/static/img/userMonitor.png'
				},{
					name:this.$t('realTime.navBtn4'),
					path:'/monitor/online_host',
					img:'/static/img/onlineNode.png'
				},
				{
					name:this.$t('realTime.navBtn5'),
					path:'/monitor/block_list',
					img:'/static/img/black.png'
				},{
					name:this.$t('realTime.navBtn6'),
					path:'/monitor/white_list',
					img:'/static/img/white.png'
				},{
					name:this.$t('realTime.navBtn7'),
					path:'/monitor/black_list',
					img:'/static/img/black.png'
				}
				]
    	}
    },
    created() {
      this.getScreenWidth()
      let _this = this
      $(window).resize(function() {
      	  _this.getScreenWidth()
      })
    },
    methods: {
    	getScreenWidth() {
      	let  screen_with = $(window).width()
      	if (screen_with>1470) {
      		this.screen_with = 'big'
      	} else if (screen_with<=1470&&screen_with>1280) {
      		this.screen_with = 'mid'
      	} else {
      		this.screen_with = 'small'     	
      	}
      },
			comeOut() {
			  $('.samll_width').addClass('out').removeClass('in')
			},
			goIn() {
				$('.samll_width').addClass('in').removeClass("out")
			}
		}
  }
</script>
<style scoped>
.container{
	height: 100%;
}
.un_accredit{
	width: 1240px;
}
.row{
	height: 100%;
}
.current-wrap{
  min-width: 1500px;
}
.view,.navBar{
   display: inline-block;
   vertical-align: top;
} 
.view{
	margin-bottom: 60px;
}
.samll_width{
	position: relative;
	z-index: 10;
	left: -220px;
	transition: 0.5s;
}
.small_content{
	margin-left: -250px;
}
.mid_content{
	margin-left: -200px;
}
.in{
	left:-220px;
}
.out{
	left:-20px;
}
</style>