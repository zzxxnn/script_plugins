<template>
		<div class="container current-wrap">
	    <div class="row">
	      <leftnavbar :menudata='menudata' class="navBar col-sm-2 col-md-2 col-lg-2" :screen_with = "screen_with" :class="[screen_with != 'big'?'samll_width':'']" @comeOut="comeOut" @goIn="goIn" ></leftnavbar>
	      <div class="view col-sm-10 col-md-10 col-lg-10" :class="[screen_with == 'small'?'small_content':screen_with == 'mid'?'mid_content':'']">
	        <router-view></router-view>
	      </div>
	    </div>
	  </div>
</template>
<script>	
  import leftnavbar from 'src/components/navbar/leftbar.vue'
  export default {
    components: {
      leftnavbar
    },
     data() {
    	return{
    		screen_with:'',
				menudata:[
						{
							img:'/static/img/safeplot.png',
							path:'/security/firewall',
							name:this.$t('safeplot.navBtn1')
						},
						{
							img:'/static/img/syspolt.png',
							path:'/security/access_strategy',
							name:this.$t('safeplot.navBtn12')
						},
						{
							img:'/static/img/hostcomputer.png',
							path:'/security/honey',
							name:this.$t('safeplot.navBtn2')
						},
						{
							img:'/static/img/selfset.png',
							path:'/security/host_remark',
							name:this.$t('safeplot.navBtn3'),
							children:[
								{
									path:'/security/host_remark',
									name:this.$t('safeplot.navBtn4'),
								},{
									path:'/security/white_list',
									name:this.$t('safeplot.navBtn5'),
								},{
									path:'/security/black_list',
									name:this.$t('safeplot.navBtn6'),
								},{
									path:'/security/host_admit',
									name:this.$t('safeplot.navBtn7'),
								}
							]
						},{
							img:'/static/img/holomask.png',
							path:'/security/server_pretend',
							name:this.$t('safeplot.navBtn8')	
						},{
							img:'/static/img/trapnode.png',
							path:'/security/ports_unreal_open',
							name:this.$t('safeplot.navBtn9'),
							children:[
								{
									path:'/security/ports_unreal_open',
									name:this.$t('safeplot.navBtn10'),
								},{
									path:'/security/unreal_open_white',
									name:this.$t('safeplot.navBtn11'),
								}
							]
						}
					]
    	}
    },
    created() {
      this.getScreenWidth()
      let _this = this
      $(window).resize(function() {
      	  _this.getScreenWidth()
      })
    },
    methods: {
    	getScreenWidth() {
      	let screen_with = $(window).width()
      	if (screen_with > 1470) {
      		this.screen_with = 'big'
      	} else if (screen_with<=1470&&screen_with > 1280) {
      		this.screen_with = 'mid'
      	} else {
      		this.screen_with = 'small'     	
      	}
      },
			comeOut() {
			  $('.samll_width').addClass('out').removeClass('in')
			},
			goIn() {
				$('.samll_width').addClass('in').removeClass("out")
			}
		}
  }
</script>
<style scoped>
.container{
	height: 100%;
}
.un_accredit{
	width: 1240px;
}
.row{
	height: 100%;
}
.current-wrap{
  min-width: 1500px;
}
.view,.navBar{
   display: inline-block;
   vertical-align: top;
} 
.view{
	margin-bottom: 60px;
}
.samll_width{
	position: relative;
	z-index: 10;
	left: -220px;
	transition: 0.5s;
}
.small_content{
	margin-left: -250px;
}
.mid_content{
	margin-left: -200px;
}
.in{
	left:-220px;
}
.out{
	left:-20px;
}
</style>
