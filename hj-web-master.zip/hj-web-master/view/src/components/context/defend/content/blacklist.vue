<template>
    <div>
        <Tables 
            :title ='title' 
            :btns = 'btns' 
            :field = 'field' 
            :tableData ='tableData' 
            :dbClickDisabled ="true"
            :rankable ="true"
            :pageSize='pageSize'
            :totalNum="total_num" 
            :perNum="size"
            :collectField = "collect_field" 
            :tableNotice="momal_notice"
            :curPage ="cur_page" 
            :clearSelectItems="selectedItems"  
            @reset="reset"  
            @loadData ="setData" 
            @sentSelectedItems="getSelectedItems"
            @sentEditData="getEditData"
            @changePageSize = 'changePageSize'
            @rankData = "rankData"
            @delEvent = 'delData'
            >
        </Tables>

        <Modals 
            :id ="'modal'" 
            :title ='title' 
            :field = 'field' 
            :collectField = "collect_field"
            :selectItem = "select_item" 
            :status = "status" 
            :errorMsg="errorMsg" 
            :type="type"
            :selectedItems="selectedItems" 
            :editData = "edit_data" 
            :momalNotice="momal_notice" 
            @sentErrorMsg = "getErrorMsg"
            @addEvent = 'addData'
            >
        </Modals>
    </div>
</template>
<script>
    import Tables from 'components/common/Tables'
    import Modals from 'components/common/Modals'
    import defendService from 'services/defendService'
    export default {
		components:{
		    Tables,
            Modals        
	    },
        data() {
            return{
                title:this.$t('safeplot.navBtn6'),
                btns:[
                    {
                        type:'add',
                        name:this.$t('common.addBtn'),
                        event:'addEvent',
                        icon:'/static/img/add.png',
                        class:'add_btn',
                    },
                    {
                        type:'del',
                        name:this.$t('common.delBtn'),
                        event:'delEvent',
                        icon:'/static/img/delete.png',
                        class:'del_btn',
                    }
                ],
                field:[
                    {
                        type:'checkbox', 
                    },
                    {
                        type:'rank'
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.blackTableTh1'),
                        name:'mac',
                        regex:/^((2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)$|^[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}$/,
                        required:true, 
                        remark:this.$t('safeplot.bwRemark')
                    },
                    {
                        type:'none',
                        label:this.$t('safeplot.bwTableTh4'),
                        name:'description',
                        editable: true,
                        ellipsis:'width: 300px',
                        style:'width: 300px'
                    },
                    {
                        type:'none',
                        label:this.$t('safeplot.bwTableTh2'),
                        name:'timestamp',
                        style:'width: 150px'
                    },
                    {
                        type:'textarea',
                        label:this.$t('safeplot.bwTableTh3'),
                        name:'note',
                        regex:/^[\S\s]{0,32}$/,
                        required:false, 
                        remark:this.$t('safeplot.remark2'),
                        ellipsis:'width: 200px',
                        style:'width: 200px'    
                    }
                ],
                tableData:[],
                pageSize: [10, 20, 40, 80],
                size:20,
                total_num:1,
                cur_page:1,
                collect_field:'id',              
                select_item:[],
                status:"",
                errorMsg:'',
                type:'',
                selectedItems:[],
                edit_data:{},
                momal_notice:this.$t('safeplot.bwTableNotice')
            }
        },
        created() {
            this.loadData()
        },
        methods:{
            getSelectedItems(selectedItems) {
                this.selectedItems = selectedItems
            },
            getEditData(editdata) {
                this.edit_data = editdata 
            },
            getErrorMsg(msg) {
                this.errorMsg = msg
            },
            reset(type) {
                this.status = ""
                this.errorMsg = ''
                this.type = type
                $('.inputs_wrap .error_foramt').removeClass('error_foramt')
            },  
            loadData() {
				let params = {
                    page: this.cur_page,
                    row: this.size,
                    order: this.order,
                    by: this.by
                }
                defendService.getSafePolt(4, params)
                .then((res) => {
					
					if (res.errcode === 0) {
						this.total_num = res['4'].count
                        this.tableData =  res['4'].data  
                    }
				})
            },
			setData(params) {
				if (params.oper=='page_change') {
					this.loadData(params)
					return 
				}
				this.status ='ing'
				params.black= true
                realTimeService.setBlackList(params)
                .then((res) => {		
					
					if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        if (params.oper=='del') {
                            this.selectedItems = []
                        }
                        let reload = {
                            oper:params.oper,
                            page:params.page
                        }
                        this.loadData(reload)
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)	
                    }
				})
            },
            changePageSize (nowpage, size) {
                this.cur_page = nowpage
                this.size = size
                this.loadData()
            }, 
            rankData (param) {
                this.order = param.order 
                this.by = param.by
                this.loadData()
            },
            addData (data) {
                this.status ='ing'
                let note = data.note || ''
                let sendStr = `${data.mac}|${note}`
                defendService.addSafePolt(4, {4: sendStr})
                .then((res) =>{
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        this.$Modal.success({
                            title: '主机黑名单',
                            content: '添加成功！',
                            scrollable: false,
                            onOk: () => {
                                this.loadData()
                            }
                        })
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)	
                    }
                })
            },
            delData (data) {
                this.status ='ing'
                defendService.delSafePolt(4, {4: data.ids})
                .then((res) =>{
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        setTimeout(() => {
                            this.$Modal.success({
                                title: '主机黑名单',
                                content: '删除成功！',
                                scrollable: false
                            })
                        }, 250)
                        this.loadData()
                        this.selectedItems = []
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)	
                    }
                })
            }
        }
    }
</script>