<template>
    <div>
        <Tables 
            :title ='title' 
            :btns = 'btns' 
            :field = 'field' 
            :tableData ='tableData' 
            :pageSize='pageSize' 
            :totalNum="total_num"
            :perNum="size" 
            :collectField = "collect_field"
            :curPage ="cur_page" 
            :clearSelectItems="selectedItems"
            @reset="reset"  
            @loadData ="loadData" 
            @sentSelectedItems="getSelectedItems"
            @sentEditData="getEditData"
            @changePageSize = 'changePageSize'
            @rankData = "rankData"
            @delEvent = 'delData'
            >
        </Tables>

        <Modals 
            :id ="'modal'" 
            :title ='title' 
            :field = 'field' 
            :collectField = "collect_field"
            :selectItem = "select_item" 
            :status = "status" 
            :errorMsg="errorMsg" 
            :type="type"
            :selectedItems="selectedItems" 
            :editData = "edit_data"  
            @sentErrorMsg = "getErrorMsg"
            @addEvent = 'addData'
            @editEvent = 'editData'
            >
        </Modals>
    </div>
</template>
<script>
    import Tables from 'components/common/Tables'
    import Modals from 'components/common/Modals'
    import defendService from 'services/defendService' 
    export default {
		components:{
		    Tables,
            Modals        
	    },
        data() {
            return {
                title:this.$t('safeplot.navBtn11'),
                btns: [
                    {
                        type:'add',
                        name:this.$t('common.addBtn'),
                        event:'addEvent',
                        icon:'/static/img/add.png',
                        class:'add_btn',
                    },
                    {
                        type:'del',
                        name:this.$t('common.delBtn'),
                        event:'delEvent',
                        icon:'/static/img/delete.png',
                        class:'del_btn',
                    },
                    {
                        type:'edit',
                        name:this.$t('common.editBtn'),
                        event:'editEvent',
                        icon:'/static/img/modpic.png',
                        class:'edit_btn',
                    }
                ],
                field: [
                    {
                        type:'checkbox', 
                    },
                    {
                        type:'rank'
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.fakewTableTh1'),
                        name:'t_ip_mac',
                        regex:/(^[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}$)|(^(!*(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)(\/(3[0-2]|2[0-9]|1[0-9]|[1-9]))*(\-(!*(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?))*(\/(3[0-2]|2[0-9]|1[0-9]|[1-9]))*$)/,
                        required:true, 
                        remark:this.$t('safeplot.fakewRemark1')
                    },
                    {
                        type:'textarea',
                        label:this.$t('safeplot.fakewTableTh2'),
                        name:'t_port',
                        regex:/^((([1-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])))(\,(([1-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5]))){0,9}$/,
                        required:true, 
                        remark:this.$t('safeplot.fakewRemark2'),
                        ellipsis:'width:480px' 
                    },
                ],
                tableData:[],
                pageSize: [10, 20, 40, 80],
                size:20,
                total_num:1,
                cur_page:1,
                collect_field:'id',              
                select_item:[],
                status:"",
                errorMsg:'',
                type:'',
                selectedItems:[],
                edit_data:{},
                order: '',
                by: ''
            }
        },
        created() {
            this.loadData()
        },
        methods:{
            getSelectedItems(selectedItems) {
                this.selectedItems = selectedItems
            },
            getEditData(editdata) {
                this.edit_data = editdata 
            },
            getErrorMsg(msg) {
                this.errorMsg = msg
            },
            reset(type) {
                this.status = ""
                this.errorMsg = ''
                this.type = type
                $('.inputs_wrap .error_foramt').removeClass('error_foramt')
            },  
            loadData() {
                this.status ='ing'
                let params = {
                    page: this.cur_page,
                    row: this.size,
                    order: this.order,
                    by: this.by
                }
                defendService.getSafePolt(9, params)
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        this.total_num = res['9'].count				
                        this.tableData =  res['9'].data
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)	
                    }
                })
            },
            changePageSize (nowpage, size) {
                this.cur_page = nowpage
                this.size = size
                this.loadData()
            },
            rankData (param) {
                this.order = param.order
                this.by = param.by
                this.loadData()
            },
            addData(params) {
                this.status ='ing'
                let sendStr = `${params.t_ip_mac}|${params.t_port}`
                defendService.addSafePolt(9, {9: sendStr})
                .then((res) => {	
                    if (res.errcode === 0) {
                        this.status ='ok'
                        this.errorMsg = ''
                        this.$Modal.success({
                            title: '虚开白名单',
                            content: '添加成功！',
                            scrollable: false,
                            onOk: () => {
                                this.loadData()
                            }
                        })
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
				})
            },
            delData(params) {
                this.status ='ing'
                defendService.delSafePolt(9, {9: params.ids})
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        setTimeout(() => {
                            this.$Modal.success({
                                title: '虚开白名单',
                                content: '删除成功！',
                                scrollable: false
                            })
                        }, 250)
                        this.selectedItems = []
                        this.loadData()
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
				})
            },
            editData (params) {
                let sendStr = `${params.id}|${params.t_ip_mac}|${params.t_port}`
                this.status ='ing'
                defendService.editSafePolt(9, {9: sendStr})
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        this.$Modal.success({
                            title: '虚开白名单',
                            content: '修改成功！',
                            scrollable: false,
                            onOk: () => {
                                this.selectedItems = []
                                this.loadData()
                            }
                        })
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
                })
            },
        }
    }
</script>