<template>
  <div class="modal addModal-modal-lg safe-modal add-modal as-modal" 
      id='modal'  
      @keyup.enter="beforeSendData()"  
      tabindex="-1" 
      role="dialog" 
      aria-labelledby="myModalLabel" 
      aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">    
          <h3 class="modal-title" id="myModalLabel">
            <template v-if ="oper=='add'">新增应用访问策略 </template>        
            <template v-else-if="oper=='edit'">编辑应用访问策略</template>
            <template v-else-if="oper=='del'">删除应用访问策略</template> 
          </h3>
          <span class="close" data-dismiss="modal" aria-hidden="true">&times;</span>
        </div>
        <div class="modal-body">
          <!-- 正在请求 -->
          <div class="result" v-show="result=='ing'">
            <img src="../../../../img/loading.gif" />
            <p style="font-size: 12px;line-height: 20px;">正在提交数据...</p>
          </div>
          <!-- 成功 -->
          <!-- <div class="result" v-show="result=='ok'" style="line-height:350px">
            <img src="../../../../img/success.png" />
            <span>{{$t('common.successNotice')}}</span>
          </div> -->
          <!-- table -->
          <!-- <div v-show="oper=='del'&&result!='ok' && result!='ing'">
            <p style="line-height: 320px;text-align: center;font-size: 18px;color: #666">
              {{$t('common.delNotice')}}
            </p>
          </div> -->
          <div class="tbody" v-show="oper!='del'&&result!='ok' && result!='ing'">
            <!-- 策略名称 -->
            <div class="line">
              <div class="tr">
                <label>策略名</label>
                <input class="as-name" style="margin-left: 5px;" size="32" v-model="name" @blur="checkName('.as-name')">
                <span style="color: #495060;margin-left: 10px;">(*必填，长度不能超过32个字符)</span>
              </div>
            </div>
            <!-- 协议类型 -->
            <div class="line">
              <div class="tr">
                <label>{{$t('safeplot.plotTableTh2')}}</label>
                <select class="protocol" v-model="protocol_id">
                  <option :value="item.value" v-for='item in protocal_ar' :key="item.value">{{item.text}}</option>
                </select>
                <span style="color: #495060;margin-left: 10px;">{{$t('safeplot.plotRemark1')}}</span>
              </div>
            </div>
            <!-- 端口设置 -->
            <div class="line port" style="position: relative;">
                <div class="tr">
                    <label>{{$t('safeplot.plotTableTh5')}}</label>
                    <Select v-model="s_port.type" :transfer='transfer' size="small">
                        <Option value="1" :key="0">ANY</Option>
                        <Option value="2" :key="1">{{$t('safeplot.sPort')}}</Option>
                    </Select>
                    <input 
                      v-if='s_port.type == "2"' 
                      v-model='s_port.val' 
                      class="srcprot" 
                      type="text" 
                      placeholder="8080，2000"
                      @blur="checkPort('.srcprot','protRang')" 
                      style="margin-left: 5px;">
                </div>
                <div class="tr">
                    <label>{{$t('safeplot.plotTableTh6')}}</label>
                    <Select v-model="d_port.type" :transfer='transfer' size="small">
                        <Option value="1" :key="0">ANY</Option>
                        <Option value="2" :key="1">{{$t('safeplot.sPort')}}</Option>
                    </Select>
                    <input 
                      v-if='d_port.type == "2"' 
                      v-model='d_port.val' 
                      class="desprot" 
                      type="text"
                      placeholder="8080，2000" 
                      @blur="checkPort('.desprot','protRang')"
                      style="margin-left: 5px;">
                </div>
                <p style="padding-left:102px;color: #495060;text-align:left">(*端口形式：80，可配置多个，用逗号隔开，最多可配置10个)</p>
            </div>

            <!-- 生效时间 -->
            <div class="line">
              <div class="tr">
                <label>生效时间</label>
                <Row>
                  <TimePicker 
                    class="start-time" 
                    format="HH:mm" 
                    placeholder="开始时间" 
                    placement="bottom-start" 
                    :editable="false" 
                    :value="start_time"
                    @on-change="handleStartTime"
                    @on-clear="handleClearStartTime"
                    >
                  </TimePicker>
                  <TimePicker 
                    class="end-time" 
                    format="HH:mm" 
                    placeholder="结束时间" 
                    placement="bottom-start" 
                    :editable="false" 
                    :value ="end_time"
                    @on-change="handleEndTime"
                    @on-clear="handleClearEndTime"
                    >
                  </TimePicker>
                <!-- <span style="color: #495060;margin-left: 10px;"></span> -->
                </Row>
              </div>
            </div>

          </div>
        </div>
        <div class="modal-footer">
          <div style="text-align:left;color:#ff3300;">{{error_msg ? '* ' + error_msg : ''}}</div>
          <button class="button sure-btn button--aylen" data-dismiss="modal">{{$t('common.cancelBtn')}}</button>
          <button class="button sure-btn button--aylen" @click='beforeSendData()'>{{$t('common.sureBtn')}}</button>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import formatTest from 'libs/formatTest'
  export default {
    components:{
    },
    props: {
      result: {
        type: String,
        // required: true
      },
      errorMsg: {
        type: String,
        // required: true
      },
      oper: {
        type: String
      },
      selectedItems: {},
      editData: {}
    },
    data() {
      return {
        name: '',
        protocol_id: '6',
        protocal_ar: [
          {text: 'TCP', value: '6'},
          {text: 'UDP', value: '17'}
        ],
        transfer: true,//下拉列表position
        start_time: '',
        end_time: '',
				d_port: {type: "1", val: ''},
        s_port: {type: "1", val: ''},
        listener: 1,
        error_msg: ''
      }
    },
    mounted () {
      $('.safe-modal').on('hide.bs.modal', ()=> {
          this.name = ''
          this.protocol_id = '6'
          this.d_port = {type:"1", val:''}
        	this.s_port = {type:"1", val:''}
          this.start_time = ''
          this.end_time = ''
          this.$store.state.modalFormVisible = false
      })
      $('.safe-modal').on('show.bs.modal', () => {
          this.$store.state.modalFormVisible = true
      })
    },
    beforeUpdate() {
      this.error_msg = this.errorMsg
    },
    watch: {
      result: function() {
        if (this.result == 'ok') {
          $('.addModal-modal-lg').modal('hide')
        } else if (this.result == 'error') {
          $('.error-notice').show()
        }
      },
      editData: function() {
        this.listener++
        this.protocol_id = '6'
        this.description = ''
        this.name = this.editData.name
        if (this.editData.protocol_id) {
          this.protocol_id = this.editData.protocol_id == 'TCP' ? '6' : '17'
					if (this.editData.d_port) {
							this.d_port.type ='2'
					} else {
							this.d_port.type ='1'
					}
					if (this.editData.s_port) {
							this.s_port.type ='2'
					} else {
							this.s_port.type ='1'
					}
					this.d_port.val = this.editData.d_port
          this.s_port.val = this.editData.s_port
          if (this.editData.effect_time) {
            let time = this.editData.effect_time.split('-')
            this.start_time = time[0]
            this.end_time = time[1]
          } else {
            this.start_time = ''
            this.end_time = ''
          }
          
        }
      }
    },
    methods: {
      addErrorCls(ele) {
        $(ele).css('border', '1px solid #b63039')
        $(ele).addClass('animated shake')
        setTimeout(function() {
          $(ele).removeClass('animated shake')
        }, 200)
      },
      checkName(ele) {
        if (this.name == null || String(this.name).length == 0 || String(this.name).length > 32) {
          this.addErrorCls(ele)
          return false
        } else {
          $(ele).css('border', '1px solid #e8e8e8')
          return true
        }
      },
      checkTime() {
        let ele = '.ivu-date-picker input'
        let startEle = '.start-time input'
        let endEle = '.end-time input'
        if (!this.start_time && !this.end_time) {
          $(ele).css('border', '1px solid #e8e8e8')
          return true
        }

        if (!this.start_time) {
           this.addErrorCls(startEle)
        } else {
          $(startEle).css('border', '1px solid #e8e8e8')
        }

        if (!this.end_time) {
          this.addErrorCls(endEle)
        } else {
          $(endEle).css('border', '1px solid #e8e8e8')
        }

        if (!this.start_time || !this.end_time) {
          return false
        } else {
          return true
        }
      },
      handleStartTime(val) {
        this.start_time = val
      },
      handleEndTime(val) {
        this.end_time = val
      },
      handleClearStartTime(val) {
        this.start_time = ''
      },
      handleClearEndTime(val) {
        this.end_time = ''
      },
      beforeSendData() {
        this.sendData()
      },
      sendData() {
        let nameValid = this.checkName('.as-name')

        let sportValid = false
        let dportValid = false

        if (this.protocol_id === '6' || this.protocol_id === '17') {
            if (this.s_port.type === '1') {
                sportValid = true
            } else {
                sportValid = this.checkPort('.srcprot', 'protRang')
            }
            if (this.d_port.type === '1') {
                dportValid = true
            } else {
                dportValid = this.checkPort('.desprot', 'protRang')
            }
        } else {
            sportValid = true
            dportValid = true
        }

        let timeValid = this.checkTime()
        if (!nameValid || !sportValid || !dportValid || !timeValid) {
          return
        }

        let effect_time = !this.start_time || !this.end_time ? '' : [this.start_time, this.end_time].join('-')
        let s_port = this.s_port.type === '1' ? '' : this.s_port.val
        let d_port = this.d_port.type === '1' ? '' : this.d_port.val
        let sendStr = ''
        switch (this.oper) {
          case 'edit':
              sendStr = `${this.editData.id}|${this.name}|${this.protocol_id}|${s_port}|${d_port}|${effect_time}`
              this.$emit('editEvent', {'10': sendStr})
            break
          default:
            sendStr = `${this.name}|${this.protocol_id}|${s_port}|${d_port}|${effect_time}`
              this.$emit('addEvent', {'10': sendStr})
            break
        }
        // if (this.oper === 'del') {
        //   this.$emit('delEvent',{'1': this.selectedItems.join(',')})
        //   return
        // }

      },
      TextLength(desc) {
        if (desc && desc.length > 10) {
          $('.length-notice').show()
          return false
        } else {
          $('.length-notice').hide()
          return true
        }
			},
		
      checkPort: function(ele, reg) {
        if (ele == ".srcprot" || ele == ".desprot") {
          let protRangReg =/^([1-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])(,([1-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])){0,9}$/
          if (!protRangReg.test($(ele).val())) {
            this.addErrorCls(ele)
            return false            
          } else {
            $(ele).css('border', '1px solid #e8e8e8')
            return true
          }
        }
      }
    },
    beforeDestroy() {
      $('.safe-modal').off('show.bs.modal').off('hide.bs.modal')
    }
  }
</script>

<style lang="less" scoped>
.notice{
  display: none;
  margin-left: 10px;
  text-align: left;
  color: #ff3300;  
}

</style>
<style lang="less">

.as-modal {
  .ivu-input-icon {
    line-height: 27px;
  }
  .ivu-select-dropdown {
    position: absolute !important;
    .ivu-time-picker-cells-list {
      max-height: 100px;
      ul {
        padding-bottom: 0px;
      }
    }
  }
}
</style>