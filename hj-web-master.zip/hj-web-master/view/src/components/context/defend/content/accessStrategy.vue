<template>
    <div class="access-strategy">
        <Tables 
            :title='title' 
            :btns='btns' 
            :field='field' 
            :tableData='tableData' 
            :pageSize='pageSize' 
            :perNum='size'
            :totalNum="total_num"
            :collectName="collect_name" 
            :rankable="true"
            :curPage="cur_page" 
            :collectField='"id"'
            :clearSelectItems="selectedItems" 
            :tdWidth="'max-width:250px'"
            @reset="reset"  
            @loadData="loadData" 
            @sentSelectedItems="getSelectedItems"
            @sentEditData="getEditData"
            @rankData="setData"
            @changePageSize='changePageSize'
            @delEvent='delData'
            @clearCountEvent='clearCount'
            >
    </Tables>
        <asModal 
            @addEvent='addData'
            @editEvent='editData'
            :result='status' 
            :editData='edit_data' 
            :oper='type' 
            :errorMsg='errorMsg' 
            :selectedItems='selectedItems'
            >
        </asModal>
    </div>
</template>
<script>
  import Tables from 'components/common/Tables'
  import defendService from 'services/defendService'
  import netService from 'services/netService'
  import asModal from './safeplot/asModal'
  export default {
    components: {
        Tables,
        asModal
      },
    data() {
      return {
          title: '应用访问策略',
          btns: [
              {
                  type:'add',
                  name:this.$t('common.addBtn'),
                  event:'addEvent',
                  icon:'/static/img/add.png',
                  class:'add_btn',
              },
              {
                  type:'del',
                  name:this.$t('common.delBtn'),
                  event:'delEvent',
                  icon:'/static/img/delete.png',
                  class:'del_btn',
              },
              {
                  type:'edit',
                  name:this.$t('common.editBtn'),
                  event:'editEvent',
                  icon:'/static/img/modpic.png',
                  class:'edit_btn',
              }
          ],
          field: [
              {
                  type:'checkbox',
              },
              {
                  type:'rank',
              },
              {
                  label:'策略名',
                  name:'name',
                  ellipsis: 'width:200px',
                  style:'width: 200px'
              },
              {
                  label:'协议类型',
                  name:'protocol_id',
                  style:'width: 80px'
              },
              {
                  label:'源端口',
                  name:'s_port',
                  ellipsis: 'width:180px',
                  style:'width: 180px'
              },
              {
                  label:'目的端口',
                  name:'d_port',
                  ellipsis: 'width:180px',
                  style:'width: 180px'
              },
              {
                  label:'生效时间',
                  name:'effect_time',
                  style:'width: 150px'
              },
              {
                  label:'匹配计数',
                  name:'matching_counts',
                  ellipsis:'width: 80px',
                  style:'width: 80px'  
              },
              {
                  type: 'clearCount',
                  label:'操作',
                  name:'operator',
                  collectname: 'id',
                  event: 'clearCountEvent'
              },
          ],
          tableData: [],
          pageSize: [10, 20, 40, 80],
          total_num: 1,
          cur_page: 1,
          collect_field: 'id',              
          size: 20,
          collect_name: 'id',              
          select_item: [],
          status: "",
          errorMsg: '',
          type: '',
          selectedItems: [],
          edit_data: {},
          momal_notice: '',
          oper: '',
          order: '',
          by: ''
        }
    },
    created() {
      this.loadData()
    },
    methods: {
      clearCount (_, id) {
        let params = {
          ids: id
        }
        defendService.clearCount(params)
        .then((res) => {
            if (res.errcode === 0) {
                this.loadData()
                setTimeout(() => {
                    this.$Modal.success({
                        title: this.title,
                        content: '匹配计数清零成功',
                        scrollable: false
                    })
                }, 250)
            }
        })  
      },
      getSelectedItems(selectedItems) {
        this.selectedItems = selectedItems
      },
      getEditData(editdata) {
        this.edit_data = editdata 
      },
      getErrorMsg(msg) {
        this.errorMsg = msg
      },
      reset(type) {
        this.status = ""
        this.errorMsg = ''
        this.type = type
        $('.safe-modal input').css('border', '1px solid rgb(232, 232, 232)')  
        $('.inputs_wrap .error_foramt').removeClass('error_foramt')
      }, 
      changePageSize (nowpage, size) {
        this.cur_page = nowpage
        this.size = size
        this.loadData()
      }, 
      loadData() {
        let params = {
            page: this.cur_page,
            row: this.size,
            order: this.order,
            by: this.by
        }
        this.status = "ing"
        defendService.getAccessStrategy(params)
          .then((res) => {
            if (res.errcode === 0) {               
                this.status = "ok"
                this.errorMsg = ''
                this.tableData = res['10'].data.map((item) => {
                    item.protocol_id = item.protocol_id == '6' ? 'TCP' : 'UDP'
                    return item
                })
                this.total_num = res['10'].count
            } else {
                this.status = 'error'
                this.errorMsg = this.$t('error_code.' + res.errcode)  
            }
          })
      },
      setData(param) {
        this.order = param.order
        this.by = param.by
        this.loadData()
      },
      addData (data) {
        if (this.status == 'ing') {
            return
        }
        this.status = 'ing'
        defendService.addAccessStrategy(data)
          .then((res) => {
            if (res.errcode === 0) {
                $('.addModal-modal-lg').modal('hide')
                this.status = 'ok'
                setTimeout(() => {
                    this.$Modal.success({
                        title: this.title,
                        content: this.$t('common.addSuccessNotice'),
                        scrollable: false,
                        onOk: () => {
                            this.loadData()
                        }
                    })
                }, 250)
            } else {
                this.status = 'error'
                this.errorMsg = this.$t('error_code.' + res.errcode)
            }
        })
      },
      editData (data) {
        if (this.status == 'ing') {
          return
        }
        this.status = 'ing'
        defendService.updateAccessStrategy(data)
          .then((res) => {
              if (res.errcode === 0) {
                  $('.addModal-modal-lg').modal('hide')
                  this.status = 'ok'
                  this.selectedItems = []
                  this.loadData()
                  setTimeout(() => {
                      this.$Modal.success({
                          title: this.title,
                          content: this.$t('common.editSuccessNotice'),
                          scrollable: false
                      })
                  }, 250)
              } else {
                  this.status = 'error'
                  this.errorMsg = this.$t('error_code.' + res.errcode)
              }
          })
      },
      delData (data) {
        defendService.deleteAccessStrategy(data)
          .then((res) => {
              if (res.errcode === 0) {
                  this.selectedItems = []
                  this.loadData()
                  setTimeout(() => {
                      this.$Modal.success({
                          title: this.title,
                          content: this.$t('common.delSuccessNotice'),
                          scrollable: false
                      })
                  }, 250)
              }
          })  
        }
      }
    }
</script>
<style lang="less">
  .access-strategy table {
    table-layout: fixed;
  }
</style>