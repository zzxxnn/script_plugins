<template>
    <div>
        <Tables 
            :title='title' 
            :btns='btns' 
            :field='field' 
            :tableData='tableData' 
            :pageSize='pageSize' 
            :perNum='size'
            :totalNum="total_num" 
            :collectField="collect_field" 
            :dbClickDisabled="true"
            :rankable="true"
            :curPage="cur_page" 
            :clearSelectItems="selectedItems" 
            @reset="reset" 
            @loadData="loadData" 
            @sentSelectedItems="getSelectedItems"
            @sentEditData="getEditData"
            @changePageSize='changePageSize'
            @rankData="rankData"
            @delEvent='delData'
            >
        </Tables>

        <Modals 
            :id="'modal'" 
            :title='title' 
            :field='field' 
            :collectField="collect_field"
            :selectItem="select_item" 
            :status="status" 
            :errorMsg="errorMsg" 
            :type="type"
            :selectedItems="selectedItems" 
            :editData="edit_data" 
            :momalNotice="momal_notice"
            @sentErrorMsg="getErrorMsg" 
            @addEvent='addData'
            >
        </Modals>
    </div>
</template>
<script>
    import Tables from 'components/common/Tables'
    import Modals from 'components/common/Modals'
    import defendService from 'services/defendService'
	import netService from 'services/netService'
    export default {
		components:{
		    Tables,
            Modals        
	    },
        data() {
            return{
                title:this.$t('safeplot.navBtn2'),
                btns: [
                    {
                        type:'add',
                        name:this.$t('common.addBtn'),
                        event:'addEvent',
                        icon:'/static/img/add.png',
                        class:'add_btn',
                    },
                    {
                        type:'del',
                        name:this.$t('common.delBtn'),
                        event:'delEvent',
                        icon:'/static/img/delete.png',
                        class:'del_btn',
                    }
                ],
                field: [
                    {
                        type:'checkbox', 
                    },
                    {
                        type:'rank'
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.hostTableTh1'),
                        name:'v_port',
                        regex:/^([1-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/,
                        required:true, 
                        remark:this.$t('safeplot.remark1')
                    },
                    {
                        type:'select',
                        label:this.$t('safeplot.hostTableTh2'),
                        name:'h_ip',
                        regex:/^((2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)$/,
                        required:true, 
                        remark:this.$t('safeplot.remark1'),
                        style:'width: 300px'
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.hostTableTh3'),
                        name:'h_port',
                        regex:/^([1-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/,
                        required:true, 
                        remark:this.$t('safeplot.remark1'),
                        style:'width: 300px'  
                    }
                ],
                tableData: [],
                pageSize: [10, 20, 40, 80],
                size: 20,
                total_num: 1,
                cur_page: 1,
                collect_field: 'id',              
                select_item: [],
                status: "",
                errorMsg: '',
                type: '',
                selectedItems: [],
                edit_data: {},
				momal_notice: ''
            }
        },
        created() {
            this.loadData()
			this.getIPaddress()
        },
        methods:{
            getSelectedItems(selectedItems) {
                this.selectedItems = selectedItems
            },
            getEditData(editdata) {
                this.edit_data = editdata 
            },
             getErrorMsg(msg) {
                this.errorMsg = msg
            },
            reset(type) {
                this.status = ""
                this.errorMsg = ''
                this.type = type
                $('.inputs_wrap .error_foramt').removeClass('error_foramt')
            },  
            loadData(order = '', by = '') {
				let params = {
                    page: this.cur_page,
                    row: this.size,
                    order: order,
                    by: by
                }
				this.status = "ing"
                defendService.getSafePolt(2, params)
                .then((res) => {
					if (res.errcode === 0) {
                        this.status = "ok"
                        this.errorMsg = ''
                        this.tableData =  res['2'].data
                        this.total_num = res['2'].count
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)	
                    }
				})
            },
			getIPaddress() {
                netService.getBindIp(1, 1000)
                .then((res)=>{
                    if(res.errcode === 0){
                        if (res['23'].count > 0) {
							this.select_item = 	res['23'].data.map((item)=>{
								return item.ip
							})
							this.momal_notice = this.$t('safeplot.hostModalNotice1')	
						} else {
							this.select_item = [this.$t('safeplot.noSelectItem')]
							this.momal_notice = this.$t('safeplot.hostModalNotice2')
						}
                    }
                })
            },
            changePageSize (nowpage, size) {
                this.cur_page = nowpage
                this.size = size
                this.loadData()
            }, 
            rankData (param) {
                this.loadData(param.order, param.by)
            },
            addData (data) {
                let sendStr = `${data.v_port}|${data.h_ip}|${data.h_port}`
                defendService.addSafePolt(2, {2: sendStr})
                .then((res) =>{
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''

                        this.$Modal.success({
                            title: '蜜罐主机',
                            content: '添加成功！',
                            scrollable: false,
                            onOk: () => {
                               this.loadData()
                            }
                        })
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
                })
            },
            delData (data) {
                defendService.delSafePolt(2, {2: data.ids})
                .then((res) =>{
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
               
                        setTimeout(() => {
                            this.$Modal.success({
                                title: '蜜罐主机',
                                content: '删除成功！',
                                scrollable: false
                            })
                        }, 250)
                        this.loadData()
                        this.selectedItems = []
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
                })
            }
        }
    }
</script>