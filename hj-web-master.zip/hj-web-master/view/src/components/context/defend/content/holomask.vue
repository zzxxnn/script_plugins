<template>
    <div class="holomask">
        <Tables 
            :title='title' 
            :btns='btns' 
            :field='field' 
            :tableData='tableData' 
            :pageSize='pageSize'  
            :totalNum="total_num" 
            :perNum="size"
            :collectField="collect_field"
            :curPage="cur_page" 
            :clearSelectItems="selectedItems"
            :rankable="true"
            @reset="reset"  
            @loadData="loadData" 
            @sentSelectedItems="getSelectedItems"
            @sentEditData="getEditData"
            @changePageSize='changePageSize'
            @rankData="rankData"
            @delEvent='delData'
            >
        </Tables>
        <Modals 
            :id="'modal'" 
            :title='title' 
            :field='field' 
            :collectField="collect_field"
            :selectItem="select_item" 
            :status="status" 
            :errorMsg="errorMsg" 
            :type="type"
            :selectedItems="selectedItems" 
            :editData="edit_data"  
            @sentErrorMsg="getErrorMsg"
            @addEvent='addData'
            @editEvent='editData'
            >
        </Modals>
    </div>
</template>
<style>
.holomask td {
    vertical-align: top
}
</style>
<script>
    import Tables from 'components/common/Tables'
    import Modals from 'components/common/Modals'
    import defendService from 'services/defendService' 
    import SystemService from 'services/systemService'
    export default {
		components:{
		    Tables,
            Modals
	    },
        data() {
            return{
                title:this.$t('safeplot.navBtn8'),
                btns:[
                    {
                        type:'add',
                        name:this.$t('common.addBtn'),
                        event:'addEvent',
                        icon:'/static/img/add.png',
                        class:'add_btn',
                    },
                    {
                        type:'del',
                        name:this.$t('common.delBtn'),
                        event:'delEvent',
                        icon:'/static/img/delete.png',
                        class:'del_btn',
                    },
                    {
                        type:'edit',
                        name:this.$t('common.editBtn'),
                        event:'editEvent',
                        icon:'/static/img/modpic.png',
                        class:'edit_btn',
                    }
                ],
                field: [
                    {
                        type:'checkbox',
                    },
                    {
                        type:'rank',
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.maskTableTh1'),
                        name:'name',          
                        regex:/^[\S\s]{1,32}$/,
                        required:true, 
                        remark:this.$t('safeplot.remark1') + '，长度不能超过32个字符',
                        ellipsis:'width:200px'
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.maskTableTh2'),
                        name:'r_ip',
                        regex:/^((2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)$/,
                        required:true, 
                        remark:this.$t('safeplot.remark1'),
                        style:'width: 230px'  
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.maskTableTh3'),
                        name:'v_ip',
                        regex:/^(!*(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)(\/(3[0-2]|2[0-9]|1[0-9]|[1-9]))*(\-(!*(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?))*(\/(3[0-2]|2[0-9]|1[0-9]|[1-9]))*$/,
                        required:true, 
                        remark:this.$t('safeplot.maskRemark1'),
                        style:'width: 230px'  
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.maskTableTh4'),
                        name:'vlan_id',
                        regex:/^\d$|^[1-9]\d{0,2}$|^[1-3]\d{3}$|^40\d[0-4]$/,
                        required:true, 
                        remark:this.$t('safeplot.maskRemark2'),
                        style:'width: 150px' 
                    },
                    {
                        type:'select',
                        label:this.$t('safeplot.maskTableTh5'),
                        name:'group_id',
                        emums:null,//下拉选项
                        regex:/\S+/,
                        required:true, 
                        remark:this.$t('safeplot.remark1'),
                        style:'width: 150px' 
                    }
                ],
                tableData:[],
                pageSize: [10, 20, 40, 80],
                size:20,
                total_num:1,
                cur_page:1,
                collect_field:'id',
                select_item:[],
                status:"",
                errorMsg:'',
                type:'',
                selectedItems:[],
                edit_data:{},
            }
        },
        created() {
            this.loadData()
            this.getLine()
        },
        methods:{
            getSelectedItems(selectedItems) {
                this.selectedItems = selectedItems
            },
             getErrorMsg(msg) {
                this.errorMsg = msg
            },
            getEditData(editdata) {
                this.edit_data = editdata 
            },
            reset(type) {
                this.status = ""
                this.errorMsg = ''
                this.type = type
                $('.inputs_wrap .error_foramt').removeClass('error_foramt')
            },  
            loadData(order = '', by = '') {
                let params = {
                    page: this.cur_page,
                    row: this.size,
                    order: order,
                    by: by
                }
                this.status = "ing"
                defendService.getSafePolt(7, params)
                .then((res) => {
					if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        this.tableData =  res['7'].data.map((item)=>{
                             item.group_id = this.$t('common.tableRoad') + item.group_id
                             return item
                        })
                        this.total_num = res['7'].count
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)	
                    }
				})
            },
            getLine() {
                SystemService.getLine()
                .then((res) => {
                    if (res.errcode === 0) {
                        this.select_item = res.group_id.map((item)=>{
                            return  this.$t('common.tableRoad') + item
                        })
                        this.edit_data.group_id = this.select_item[0]
                    }
                })
            },
            changePageSize (nowpage, size) {
                this.cur_page = nowpage
                this.size = size
                this.loadData()
            }, 
            rankData (param) {
                this.loadData(param.order, param.by)
            },
            addData (data) {
                if (!data.group_id) {
                    data.group_id = this.select_item[0]
                }
                let sendStr = `${data.name}|${data.r_ip}|${data.v_ip}|${data.vlan_id}|${data.group_id.substr(2)}`
                this.status = "ing"
                defendService.addSafePolt(7, {7: sendStr})
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = "ok"
                        this.errorMsg = ''
            
                        this.$Modal.success({
                            title: '全息伪装',
                            content: '添加成功！',
                            scrollable: false,
                            onOk: () => {
                                this.loadData()
                            }
                        })
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
                    
                })
            },
            editData (data) {
                let sendStr = `${data.id}|${data.name}|${data.r_ip}|${data.v_ip}|${data.vlan_id}|${data.group_id.substr(2)}`
                this.status = "ing"
                defendService.editSafePolt(7, {7: sendStr})
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = "ok"
                        this.errorMsg = ''
                        this.$Modal.success({
                            title: '全息伪装',
                            content: '修改成功！',
                            scrollable: false,
                            onOk: () => {
                                this.selectedItems = []
                                this.loadData()
                            }
                        })
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
                })
            },
            delData (data) {
                this.status = "ing"
                defendService.delSafePolt(7, {7: data.ids})
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        setTimeout(() => {
                            this.$Modal.success({
                                title: '全息伪装',
                                content: '删除成功！',
                                scrollable: false
                            })
                        }, 250)
                        this.loadData()
                        this.selectedItems = []
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
                })
            }
        }
    }
</script>