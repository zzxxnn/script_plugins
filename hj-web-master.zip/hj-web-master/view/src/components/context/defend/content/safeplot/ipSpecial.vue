<template>
    <div class="inputDev">
        <Select v-model="ipType" :transfer='transfer' size="small" @on-change='changeSelect($event)'>
            <Option value="0" :key="0">ANY</Option>
            <Option value="1" :key="1">{{$t('safeplot.sIp')}}</Option>
            <Option value="2" :key="2">{{$t('safeplot.sIp')}}/{{$t('safeplot.sMask')}}</Option>
            <Option value="3" :key="3">{{$t('safeplot.sIpRang')}}</Option>
        </Select>
        <template v-if='ipType=="1"'>
            <input type="text" class="ip_a" v-model='iptable_a.f' :class="cls" @blur='test($event)' @focus="focusStyle($event)">
            <!-- <span class="warning">{{ipMsg1}}</span> -->
        </template>
        <template v-if='ipType=="2"'>
            <input type="text" v-model='iptable_b.f' class="ip_b" :class="cls" @blur='test($event)' @focus="focusStyle($event)">
            /
            <input type="text" v-model='iptable_b.s' class="ip_c" :class="cls" @blur='test($event)' @focus="focusStyle($event)">
            <!-- <span class="warning">{{ipMsg2}}</span> -->
        </template>    
        <template v-if='ipType=="3"'>
            <input type="text" v-model="iptable_c.f" class="ip_d" :class="cls" @blur='test($event)' @focus="focusStyle($event)">
            -
            <input type="text" v-model='iptable_c.s' class="ip_e" :class="cls"  @blur='test($event)' @focus="focusStyle($event)">
            <!-- <span class="warning">{{ipMsg3}}</span> -->
        </template>   
        					
    </div>
</template>
<script>
    import formatTest from 'libs/formatTest'
    export default {
        props: {
            special: {
                
            },
            listener: {

            },
            cls: {
                type: String
            }
        },   
        data() {
            return {
                transfer: true,
                ipType: '0',
                ipVal: this.special,
                iptable_a: {f: ''},
                iptable_b: {f: '', s: ''},
                iptable_c: {f: '', s: ''},
                ipMsg1: '',
                ipMsg2: '',
                ipMsg3: '',
                valid: false,
                timer: null
            }
        },
        watch: {
            listener:function() {
                this.iptable_a={f:''}
                this.iptable_b={f:'',s:''}
                this.iptable_c={f:'',s:''}
                if (this.special==undefined||this.special=='') {
                    this.ipType='0'
                    return 
                }
                if (this.special.indexOf('/')>0) {
                    this.iptable_b.f = this.special.split('/')[0]
                    this.iptable_b.s = this.special.split('/')[1]
                    this.ipType='2'
                    return 
                }
                if (this.special.indexOf('-')>0) {
                    this.iptable_c.f = this.special.split('-')[0]
                    this.iptable_c.s = this.special.split('-')[1]
                    this.ipType='3'
                    return 
                }
                this.iptable_a.f = this.special
                this.ipType='1'
                return
            }, 
        },
        mounted() {
            this.bus.$on('test', () => {
                this.test()
            })
        },
        methods: {
            emitUnvalidStatus(evt, cls) {
                let sendip = {
                    ip: '',
                    status: false,
                    cls: cls
                }
                if (evt) {
                    let $ele = $(evt.target)
                    if ($ele.hasClass(cls.replace(/\./, ' '))) {
                        $ele.css('border', '1px solid #b63039')
                        $ele.addClass('animated shake')
                        setTimeout(function() {
                            $ele.removeClass('animated shake')
                        }, 200)
                    }
                }
                							
                this.$emit('sendip', sendip)
                
            },
            emitValidStatus(evt, cls) {
                if (evt) {
                    let $ele = $(evt.target)
                    if ($ele.hasClass(cls.replace(/\./, ' '))) {
                        $ele.css('border', '1px solid #e6e6e6')
                        $ele.removeClass('animated shake')
                    }
                }
            },
            test(evt) {
                    $('.error_notice').hide()
                    let $ele = null
                    if (evt) {
                        $ele = $(evt.target)
                    }
                    let IPReg = /^((2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)$/
                    if (this.ipType == '0') {
                        let sendip = {
                            ip: '',
                            status: true
                        }
                        this.$emit('sendip', sendip)
                        return
                    }
                    if (this.ipType == '1') {
                        let ip = this.iptable_a.f
                        if (!String(ip)) {
                            this.ipMsg1 = this.$t('safeplot.inputBlank')
                            this.emitUnvalidStatus(evt, 'ip_a.' + this.cls)
                        } else {
                            if (ip === '0.0.0.0') {
                                this.ipMsg1 = this.$t('safeplot.inputNotice1') 
                                this.emitUnvalidStatus(evt, 'ip_a.' + this.cls)
                                return false
                            }
                            if (!IPReg.test(ip) || ip === '0.0.0.0') {
                                this.ipMsg1 = this.$t('safeplot.inputNotice1') 
                                this.emitUnvalidStatus(evt, 'ip_a.' + this.cls)
                            } else {
                                this.emitValidStatus(evt, 'ip_a.' + this.cls)
                                this.ipMsg1 = ''
                                let sendip = {
                                    ip: ip,
                                    status: true
                                }
                                this.$emit('sendip', sendip)
                            }
                        }
                    }
                    if (this.ipType == '2') {
                        let ip = String(this.iptable_b.f)
                        // 掩码
                        let mask = String(this.iptable_b.s)

                        let ipValid = false 
                        let maskValid = false

                        // if (!ip && !mask) {
                        //     this.ipMsg2 = this.$t('safeplot.inputBlank')
                        //     this.emitUnvalidStatus(evt)
                        //     return
                        // }
                        if ($ele && $ele.hasClass('ip_b ' + this.cls)) {
                            if (ip) {
                                if (!IPReg.test(ip)) {
                                    this.ipMsg2 = this.$t('safeplot.inputNotice1') 
                                    this.emitUnvalidStatus(evt, 'ip_b.' + this.cls)
                                    return
                                } else if (ip === '0.0.0.0') {
                                    this.ipMsg2 = this.$t('safeplot.inputNotice1') 
                                    this.emitUnvalidStatus(evt, 'ip_b.' + this.cls)
                                    return
                                } else {
                                    this.emitValidStatus(evt, 'ip_b.' + this.cls)
                                    ipValid = true
                                    return
                                }
                            } else {
                                this.ipMsg2 = this.$t('safeplot.ipBlank') 
                                this.emitUnvalidStatus(evt, 'ip_b.' + this.cls)
                                return
                            }
                        } else {
                            if (IPReg.test(ip) && ip != '0.0.0.0') {
                                $('.ip_b').css('border', '1px solid #e6e6e6').removeClass('animated shake')
                                this.emitValidStatus(evt, 'ip_b.' + this.cls)
                                ipValid = true
                            } 
                        }
                        
                        if ($ele && $ele.hasClass('ip_c ' + this.cls)) {
                            if (!mask) {
                                this.ipMsg2 = this.$t('safeplot.inputNotice2')
                                this.emitUnvalidStatus(evt, 'ip_c.' + this.cls)
                                return
                            } else {
                                // 1-32
                                if (!(mask > 0 && mask < 33)) {
                                    this.ipMsg2 = this.$t('safeplot.inputNotice3')
                                    this.emitUnvalidStatus(evt, 'ip_c.' + this.cls)
                                    return
                                } else {
                                    this.emitValidStatus(evt, 'ip_c.' + this.cls)
                                    maskValid = true
                                    return
                                }
                            }
                        } else {
                            if (mask && mask > 0 && mask < 33) {
                                $('.ip_c').css('border', '1px solid #e6e6e6').removeClass('animated shake')
                                this.emitValidStatus(evt, 'ip_c.' + this.cls)
                                maskValid = true
                            }
                        }
                        
                        if (!ipValid) {
                            this.emitUnvalidStatus(evt, 'ip_b.' + this.cls)
                            return
                        }

                        if (!maskValid) {
                            this.emitUnvalidStatus(evt, 'ip_c.' + this.cls)
                            return
                        }
                        this.emitValidStatus(evt, 'ip_b.' + this.cls)
                        this.emitValidStatus(evt, 'ip_c.' + this.cls)
                        this.ipMsg2 = ''
                        let ipMask = ip + '/' + mask
                        let sendip = {
                            ip: ipMask,
                            status: true
                        }
                        this.$emit('sendip', sendip)
                        return
                    }
                    if (this.ipType == '3') {
                        let ip1 = String(this.iptable_c.f)
                
                        let ip2 = String(this.iptable_c.s)

                        let ip1Num = Number(ip1.replace(/\./g, ''))
                        let ip2Num = Number(ip2.replace(/\./g, ''))


                        let ip1Valid = false 
                        let ip2Valid = false

                        if (ip1 === '0.0.0.0' || ip2 === '0.0.0.0') {
                            this.ipMsg3 = this.$t('safeplot.inputNotice1')
                            if (ip1 === '0.0.0.0') {
                                this.emitUnvalidStatus(evt, 'ip_d.' + this.cls)
                            }
                            if (ip2 === '0.0.0.0') {
                                this.emitUnvalidStatus(evt, 'ip_e.' + this.cls)
                            }
                            return
                        }
                    
                        if ($ele && $ele.hasClass('ip_d ' + this.cls)) {
                            if (ip1) {
                                if (!IPReg.test(ip1)) {
                                    this.ipMsg3 = this.$t('safeplot.inputNotice1') 
                                    this.emitUnvalidStatus(evt, 'ip_d.' + this.cls)
                                    return
                                } else {
                                    this.emitValidStatus(evt, 'ip_d')
                                    ip1Valid = true
                                }
                            } else {
                                this.ipMsg3 = this.$t('safeplot.ipBlank') 
                                this.emitUnvalidStatus(evt, 'ip_d.' + this.cls)
                                return
                            }
                        } else {
                            if (IPReg.test(ip1)) {
                                this.emitValidStatus(evt, 'ip_d')
                                ip1Valid = true
                            }
                        }
                        
                        if ($ele && $ele.hasClass('ip_e ' + this.cls)) {
                            if (ip2) {
                                if (!IPReg.test(ip2)) {
                                    this.ipMsg3 = this.$t('safeplot.inputNotice1') 
                                    this.emitUnvalidStatus(evt, 'ip_e.' + this.cls)
                                    return
                                } else {
                                    this.emitValidStatus(evt, 'ip_e')
                                    ip2Valid = true
                                }
                            } else {
                                this.ipMsg3 = this.$t('safeplot.ipBlank') 
                                this.emitUnvalidStatus(evt, 'ip_e.' + this.cls)
                                return
                            }
                        } else {
                            if (IPReg.test(ip2)) {
                                this.emitValidStatus(evt, 'ip_e')
                                ip2Valid = true
                            }
                        }
                        
                        if (!ip1Valid) {
                            this.emitUnvalidStatus(evt, 'ip_d.' + this.cls)
                            return
                        }

                        if (!ip2Valid) {
                            this.emitUnvalidStatus(evt, 'ip_e.' + this.cls)
                            return
                        }
                        

                    let ipRangeValid = true
                    // 可能还有备注中包含-, 这里只能是IP范围这种情况
                    if (!Number.isNaN(ip1Num) && !Number.isNaN(ip2Num)) {
                        let ip1Nums = ip1.split('.')
                        let ip11 = Number(ip1Nums[0])
                        let ip12 = Number(ip1Nums[1])
                        let ip13 = Number(ip1Nums[2])
                        let ip14 = Number(ip1Nums[3])

                        let ip2Nums = ip2.split('.')
                        let ip21 = Number(ip2Nums[0])
                        let ip22 = Number(ip2Nums[1])
                        let ip23 = Number(ip2Nums[2])
                        let ip24 = Number(ip2Nums[3])

                        if (!((ip11 < ip21) || 
                            (ip11 == ip21 && ip11 < ip22) ||
                            (ip11 == ip21 && ip12 == ip22 && ip13 < ip23) ||
                            (ip11 == ip21 && ip12 == ip22 && ip13 == ip23 && ip14 < ip24))
                        ) {
                            ipRangeValid = false
                        }
                    }

                    if (!ipRangeValid && ip1Valid && ip2Valid) {
                        this.ipMsg3 = 'IP范围不正确'
                        // this.emitUnvalidStatus(evt, 'ip_d')
                        this.emitUnvalidStatus(evt, 'ip_e.' + this.cls)
                        return
                    }

                    this.emitValidStatus(evt, 'ip_d')
                    this.emitValidStatus(evt, 'ip_e')
                    this.ipMsg3 = ''
                    let ip = ip1 + '-' + ip2
                    let sendip = {
                        ip: ip,
                        status: true
                    }
                    this.$emit('sendip', sendip)
                    return
                }
                
            },
            focusStyle(evt) {
                let $ele = $(evt.target)
                $ele.css("border", '1px solid #e6e6e6')
            },
            changeSelect() {
                $('input.' + this.cls).css('border', '1px solid #e6e6e6')
                this.test()
            }
        }
    }
</script>
<style scoped>
.warning {
    display: inline-block
}
.inputDev{
    display: inline-block
}
</style>