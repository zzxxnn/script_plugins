<template>
    <div class="trapnode">
        <Tables 
            :title='title' 
            :btns='btns' 
            :field='field' 
            :tableData='tableData' 
            :pageSize='pageSize'
            :totalNum="total_num" 
            :perNum="size"
            :rankable="true"
            :collectField="collect_field" 
            :curPage="cur_page" 
            :clearSelectItems="selectedItems"
            :editModal="'modal2'"
            @reset="reset"  
            @loadData="loadData" 
            @sentSelectedItems="getSelectedItems"
            @sentEditData="getEditData"
            @changePageSize='changePageSize'
            @rankData="rankData"
            @delEvent='delData'
            >
        </Tables>

        <trapModals :id="'modal'" :title="title" @sentSetType="getSetType"></trapModals>
        
        <Modals 
            :id="'modal2'" 
            :title='title' 
            :field='field2' 
            :collectField="collect_field" 
            :selectItem="select_item" 
            :status="status"
            :errorMsg="errorMsg2" 
            :type="type" 
            :selectedItems="selectedItems" 
            :editData="edit_data"
            @modalEvent="loadData"
            @sentErrorMsg="getErrorMsg"
            @addEvent='addData'
            @editEvent='editData'
            >
        </Modals>

        <stepModal 
            :id="'quick_set'" 
            :title="title" 
            :errorMsg="errorMsg" 
            :field="field2"
            :selectItem="select_item" 
            :addStep="add_step"  
            :status="status" 
            @addSubmit="addData" 
            @sentStep="getStep"
            >
        </stepModal>
    </div>
</template>
<style>
.trapnode td {
    vertical-align: top;
}
</style>
<script>
    import Tables from 'components/common/Tables'
    import Modals from 'components/common/Modals'
    import trapModals from './solts/trapModals'
    import stepModal from './solts/stepModal'
    import defendService from 'services/defendService' 
    import SystemService from 'services/systemService'
    const PORTREG = /^([1-9][0-9]*?)([,:][1-9]([0-9])*?)?((,)?([1-9][0-9]*?)([,:][1-9]([0-9])*?)?)*?$/
    export default {
        components:{
            Tables,
            Modals,
            trapModals,
            stepModal
        },
        data() {
            return {
                title: this.$t('safeplot.navBtn9'),
                btns: [
                    {
                        type:'add',
                        name:this.$t('common.addBtn'),
                        event:'addEvent',
                        icon:'/static/img/add.png',
                        class:'add_btn',
                    },
                    {
                        type:'del',
                        name:this.$t('common.delBtn'),
                        event:'delEvent',
                        icon:'/static/img/delete.png',
                        class:'del_btn',
                    },
                    {
                        type:'edit',
                        name:this.$t('common.editBtn'),
                        event:'editEvent',
                        icon:'/static/img/modpic.png',
                        class:'edit_btn',
                        modal:'modal2'
                    }
                ],
                field: [
                    {
                        type:'checkbox',
                    },
                    {
                        type:'rank',
                        style:'width: 50px' 
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.fakecTableTh1'),
                        name:'name',          
                        regex:/^[\S\s]{1,32}$/,
                        required:true, 
                        remark:this.$t('safeplot.remark1') + '，长度不能超过32个字符',
                        ellipsis:'width:100px;',
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.fakecTableTh2'),
                        name:'mac',
                        regex:/(^[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}$)|(^(!*(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)(\/(3[0-2]|2[0-9]|1[0-9]|[1-9]))*(\-(!*(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?))*(\/(3[0-2]|2[0-9]|1[0-9]|[1-9]))*$)/,
                        required:true, 
                        remark:this.$t('safeplot.fakewRemark1'),
                        ellipsis:'max-width:120px;',
                        style:'width: 130px' 
                    },

                     {
                        type:'text',
                        label:this.$t('safeplot.plotTableTh8'),
                        name:'description',
                        regex:/(^[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}$)|(^(!*(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)(\/(3[0-2]|2[0-9]|1[0-9]|[1-9]))*(\-(!*(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?))*(\/(3[0-2]|2[0-9]|1[0-9]|[1-9]))*$)/,
                        required:true,
                        editable: true,
                        remark:this.$t('safeplot.fakewRemark1'),
                        ellipsis:'max-width:120px;',
                        style:'width: 130px' 
                    },

                    {
                        type:'checkinput',
                        label:this.$t('safeplot.fakecTableTh3'),
                        name:'t_ip_type',
                        regex:/\S/,
                        required:true, 
                        remark:this.$t('safeplot.fakecRemark1') ,
                        emums:[
                            {
                                label:this.$t('safeplot.Vip'),
                                value:'1'
                            },
                            {
                                label:this.$t('safeplot.Wip'),
                                value:'2'
                            }
                        ],
                        disabled:false,
                        style:'width: 100px' 
                    },
                    {
                        type:'textarea',
                        label:this.$t('safeplot.fakecTableTh4'),
                        name:'t_port',
                        regex: PORTREG,
                        required:true, 
                        remark:this.$t('safeplot.plotRemark2'),
                        ellipsis:'max-width:100px;',
                        ellipsis:'width: 100px'      
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.fakecTableTh5'),
                        name:'s_ip',
                        regex:/^((2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)$/,
                        required:false, 
                        remark:this.$t('safeplot.fakecRemark2'),
                        style:'width: 150px'   
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.fakecTableTh6'),
                        name:'s_port',
                        regex:/^([1-9]|[1-9]\d{1,3}|[1-5]\d{4}|6[0-5]{2}[0-3][0-5])$/,
                        required:false, 
                        remark:this.$t('safeplot.fakecRemark3'),
                        ellipsis:'width: 80px'   
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.fakecTableTh7'),
                        name:'vlan_id',
                        regex:/(^\d$)|(^[1-9]\d{0,2}$)|(^[1-3]\d{3}$)|(^40\d[0-4]$)/,
                        required:true, 
                        remark:this.$t('safeplot.maskRemark2'),
                        style:'width: 60px' 
                    },
                    {
                        type:'select',
                        label:this.$t('safeplot.fakecTableTh8'),
                        name:'group_id',
                        emums:null,//下拉选项
                        regex:/\S+/,
                        required:true, 
                        remark:this.$t('safeplot.remark1'),
                        style:'width: 80px'  
                    }
                ],
                field2: [
                    {
                        type:'checkbox',
                    },
                    {
                        type:'rank',
                        style:'width: 50px' 
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.fakecTableTh1'),
                        name:'name',          
                        regex:/^[\S\s]{1,32}$/,
                        required:true, 
                        remark:this.$t('safeplot.remark1') + '，长度不能超过32个字符',
                        ellipsis:'max-width:130px;',
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.fakecTableTh2'),
                        name:'mac',
                        regex:/(^[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}$)|(^(!*(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)(\/(3[0-2]|2[0-9]|1[0-9]|[1-9]))*(\-(!*(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?))*(\/(3[0-2]|2[0-9]|1[0-9]|[1-9]))*$)/,
                        required:true, 
                        remark:this.$t('safeplot.fakewRemark1'),
                        ellipsis:'max-width:120px;',
                        style:'width: 130px' 
                    },
                    {
                        type:'checkinput',
                        label:this.$t('safeplot.fakecTableTh3'),
                        name:'t_ip_type',
                        regex:/\S/,
                        required:true, 
                        remark:this.$t('safeplot.fakecRemark1') ,
                        emums:[
                            {
                                label:this.$t('safeplot.Vip'),
                                value:'1'
                            },
                            {
                                label:this.$t('safeplot.Wip'),
                                value:'2'
                            }
                        ],
                        disabled:false,
                        style:'width: 100px' 
                    },
                    {
                        type:'textarea',
                        label:this.$t('safeplot.fakecTableTh4'),
                        name:'t_port',
                        regex:PORTREG,
                        required:true, 
                        remark:this.$t('safeplot.plotRemark2'),
                        ellipsis:'max-width:100px;',
                        ellipsis:'width: 100px'      
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.fakecTableTh5'),
                        name:'s_ip',
                        regex:/^((2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)$/,
                        required:false, 
                        remark:this.$t('safeplot.fakecRemark2'),
                        style:'width: 150px'   
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.fakecTableTh6'),
                        name:'s_port',
                        regex:/^([1-9]|[1-9]\d{1,3}|[1-5]\d{4}|6[0-5]{2}[0-3][0-5])$/,
                        required:false, 
                        remark:this.$t('safeplot.fakecRemark3'),
                        ellipsis:'width: 80px'   
                    },
                    {
                        type:'text',
                        label:this.$t('safeplot.fakecTableTh7'),
                        name:'vlan_id',
                        regex:/(^\d$)|(^[1-9]\d{0,2}$)|(^[1-3]\d{3}$)|(^40\d[0-4]$)/,
                        required:true, 
                        remark:this.$t('safeplot.maskRemark2'),
                        style:'width: 60px' 
                    },
                    {
                        type:'select',
                        label:this.$t('safeplot.fakecTableTh8'),
                        name:'group_id',
                        emums:null,//下拉选项
                        regex:/\S+/,
                        required:true, 
                        remark:this.$t('safeplot.remark1'),
                        style:'width: 80px'  
                    }
                ],
                tableData: [],
                pageSize:  [10, 20, 40, 80],
                size: 20,
                total_num: 1,
                cur_page: 1,
                collect_field: 'id',
                select_item: [],
                status: "",
                errorMsg: '',
                errorMsg2: '',
                type: '',
                selectedItems: [],
                edit_data: {},
                add_step: 0,
                order:  '',
                by:  ''
            }
        },
        created() {
            this.loadData()
            this.getLine()
        },
        methods: {
            getSetType(type) {  
                $('#' + type).modal('show')      
            },
            getErrorMsg(msg) {
                this.errorMsg2 = msg
            },
            getStep(step) {
                this.add_step = step
            },
            getSelectedItems(selectedItems) {
                this.selectedItems = selectedItems
            },
            getEditData(editdata) {
                if (editdata.hasOwnProperty('t_ip_type')) {
                    switch (editdata.t_ip_type) {
                        case this.$t('safeplot.Vip'):
                            editdata.t_ip_type = 1
                            break;
                        case this.$t('safeplot.Wip'):
                            editdata.t_ip_type = 2
                            break;
                        case `${this.$t('safeplot.Vip')},${this.$t('safeplot.Wip')}`:
                        case `${this.$t('safeplot.Wip')},${this.$t('safeplot.Vip')}`:
                        case (editdata.t_ip_type.indexOf('1') !== -1 && editdata.t_ip_type.indexOf('2') !== -1):
                            editdata.t_ip_type = '1,2'
                            break;
                        default:
                            editdata.t_ip_type = 0
                    }
                } 
                this.edit_data = editdata 
            },
            reset(type) {
                this.status = ""
                this.errorMsg = ''
                this.errorMsg2 = ''
                this.type = type
                this.add_step = 0
                this.add_data = {}
                $('.inputs_wrap .error_foramt').removeClass('error_foramt')
                if (type === 'add') {
                    $('#modal').modal('hide')
                    $('#trap_modal').modal('show')
                }
            },  
            getLine() {
                SystemService.getLine()
                .then((res) => {
                    if (res.errcode === 0) {
                        this.select_item = res.group_id.map((item) => {
                            return this.$t('common.tableRoad') + item
                        })
                    }
                })
            },
            changePageSize (nowpage, size) {
                this.cur_page = nowpage
                this.size = size
                this.loadData()
            },
            rankData (param) {
                this.order = param.order
                this.by = param.by
                this.loadData()
            },
            loadData() {
                let params = {
                    page: this.cur_page,
                    row: this.size,
                    order: this.order,
                    by: this.by
                }
                defendService.getSafePolt(8, params)
                .then((res) => {                    
                    if (res.errcode === 0) {
                        this.total_num = res['8'].count            
                        this.tableData =  res['8'].data.map((item)=>{
                            item.group_id = this.$t('common.tableRoad') + item.group_id
                            item.vlan_id = String(item.vlan_id)
                            item.mac = item.t_ip_mac
                            switch (item.t_ip_type) {
                                case 0:
                                    item.t_ip_type = "-"
                                    break;
                                case 1:
                                    item.t_ip_type = this.$t('safeplot.Vip')
                                    break;
                                case 2:
                                    item.t_ip_type = this.$t('safeplot.Wip')
                                    break;
                                case 3:
                                    item.t_ip_type = `${this.$t('safeplot.Vip')},${this.$t('safeplot.Wip')}`
                                    break;
                                default:
                                    break;
                            }
                            return item
                        })   
                    } 
                })
            },    

            paramsFormat(params){//参数处理
                let data = {...params}
                data.group_id = data.group_id ? data.group_id.replace(/[^0-9]/ig,"") : ''//取线路数字
                if (data.t_ip_type) {
                    if (data.t_ip_type === '1,0' || data.t_ip_type === '0,1') {
                        data.t_ip_type = 1
                    }
                    if (data.t_ip_type === '2,0' || data.t_ip_type === '0,2') {
                        data.t_ip_type = 2
                    }
                    if (data.t_ip_type === '2,1' || data.t_ip_type === '1,2') {
                        data.t_ip_type = 3
                    }
                } else {
                    data.t_ip_type = 0
                }
                data.s_port = data.s_port ? data.s_port : ''
                data.s_ip = data.s_ip ? data.s_ip : ''
                data.description = data.description ? data.description : ''

                return data
            },
            addData(params) {
                this.status ='ing'
                let f_params =  this.paramsFormat(params)

                if (f_params.t_ip_mac) {
                    f_params.mac = f_params.t_ip_mac
                }

                if (String(f_params.t_ip_type).indexOf('1') !== -1 && String(f_params.t_ip_type).indexOf('2') !== -1) {
                    f_params.t_ip_type = '3'
                }

                let sendStr = `${f_params.name}|${f_params.mac}|${f_params.t_ip_type}|${f_params.t_port}|${f_params.s_ip}|${f_params.s_port}|${f_params.vlan_id}|${f_params.group_id}`
                
                defendService.addSafePolt(8, {8: sendStr})
                .then((res) => {                    
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        this.errorMsg2 = ''
                        this.$Modal.success({
                            title: '端口虚开',
                            content: '添加成功！',
                            scrollable: false,
                            onOk: () => {
                                this.loadData()
                            }
                        })
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.errorMsg2 = this.$t('error_code.' + res.errcode)
                    }
                })
            },
            delData(params) {
                this.status ='ing'
                defendService.delSafePolt(8, {8: params.ids})
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        setTimeout(() => {
                            this.$Modal.success({
                                title: '端口虚开',
                                content: '删除成功！',
                                scrollable: false
                            })
                        }, 250)
                        this.selectedItems = []
                        this.loadData()
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
                })
            },
            editData (params) {
                this.status ='ing'
                let f_params =  this.paramsFormat(params)

                if (f_params.t_ip_type === '1,2' || (String(f_params.t_ip_type).indexOf('1') !== -1 && String(f_params.t_ip_type).indexOf('2') !== -1))  {
                    f_params.t_ip_type = 3
                }

                let sendStr = `${f_params.id}|${f_params.name}|${f_params.mac}|${f_params.t_ip_type}|${f_params.t_port}|${f_params.s_ip}|${f_params.s_port}|${f_params.vlan_id}|${f_params.group_id}`
                
                defendService.editSafePolt(8, {8: sendStr})
                .then((res) => {                    
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        this.$Modal.success({
                            title: '端口虚开',
                            content: '修改成功！',
                            scrollable: false,
                            onOk: () => {
                                this.loadData()
                                this.selectedItems = []
                            }
                        })      
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.errorMsg2 = this.$t('error_code.' + res.errcode)
                    }
                })
            },

        }
    }
</script>