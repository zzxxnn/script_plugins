<template>
    <div>
        <Tables 
            :title ='title' 
            :field = "field" 
            :tableData ='tableData' 
            :btns ="btns" 
            :animateShow = "animate_show"
            :pageSize='pageSize' 
            :totalNum="total_num"
            :perNum="size"
            :curPage ="cur_page" 
            @loadData ="loadData" 
            @reset = "reset"
            @xmlEvent="exportFile('xml')" 
            @htmlEvent="exportFile('html')" 
            @clearEvent="clearModal" 
            :dbClickDisabled = "true"
            :rankable ="true"
            @changePageSize='changePageSize'
            @rankData = "rankData"
            >
           <div slot="filter">
                <search :searchFiled="searchFiled" @searchEvent = "searchEvent"></search>
            </div>
        </Tables>
        <Modals 
            :id ="'clear'" 
            :title ="'提示'"
            :type="'clear'"
            :status = "status" 
            :errorMsg="errorMsg" 
            @sentErrorMsg = "getErrorMsg" 
            >
          </Modals>
    </div>
</template>
<script>
    import Tables from 'components/common/Tables'
    import search from 'components/common/search'
    import Modals from 'components/common/Modals'
    import logManageService from 'services/logManageService' 
    let btns = [
         {
            type:'other',
            name:'导出XML',
            event:'xmlEvent',
            icon:'/static/img/exportxml.png'
        },
         {
            type:'other',
            name:'导出HTML',
            event:'htmlEvent',
            icon:'/static/img/exporthtml.png'
        },
        {
            type:'clear',
            name:'清空',
            event:'clearEvent',
            icon:'/static/img/w_clear.png'
        }
    ]
    let field = [
        {
            type:'rank',
        },
        {
            type:'text',
            label:'等级',
            name:'level',
            style:'width: 100px'           
        },
         {
            type:'text',
            label:'事件类型',
            name:'type', 
            style:'width: 200px'           
        },
        {
            type:'text',
            label:'事件内容',
            name:'content',
            ellipsis:'max-width:250px;',        
        },
        {
            type:'text',
            label:'时间',
            name:'time',         
        }   
    ]
    let searchFiled =[
         {
            type:'select_link',
            label:['等级','事件类型'],
            name:['level','type'],
            meuns:[
                {val:'',label:'全部'},
                {val:'1',label:'普通'},
                {val:'2',label:'警告'},
                {val:'3',label:'严重'}
            ]
        },
        {
            type:'time-rang',
            label:'时间范围',
            name:['start_time','end_time'],
        }
    ]
    export default {
        components:{
            Tables,
            Modals,
            search
        },
        data() {
            return{
                title:'事件日志',
                field:field,
                btns:btns,
                tableData:[],
                pageSize: [10, 20, 40, 80],
                size: 20,
                total_num:1,
                cur_page:1,
                type:'block',
                searchFiled:searchFiled,
                animate_show:false,
                export_data:{},
                status:'',
                errorMsg:'',
                finddata:{},
                orderby: '',
                order: '',
                filter: {
                    level: '',
                    type: '',
                    start_time: '',
                    end_time: ''
                }
            }
        },
        created() {
            this.loadData()
        },
        methods:{
            formatContent(val) {
                let index = val.content.indexOf('|')
                if (index !== -1) {
                    let content = val.content.split('|')
                    return `用户名：${content[0]}，IP：${content[1]} `
                } else {
                    return val.content
                }
            },
            getErrorMsg(msg) {
                this.errorMsg = msg
            },
            reset(type) {
                this.status = ""
                this.errorMsg = ''
            },  
            exportFile(filetype) {                                
                let params = this.filter
                params.type = params.type?params.type:''
                params.level = params.level?params.level:''
                params.start_time = params.start_time?params.start_time:''
                params.end_time = params.end_time?params.end_time:''
                let fileName = '事件日志'+new Date().toLocaleString()
                let setUrl =`/logs/get?t=10&export=${filetype}&type=${params.type}&level=${params.level}` +
                            `&start_time=${params.start_time}&end_time=${params.end_time}`
                window.open(setUrl);
            },
            clearModal() {
                setTimeout(() => {
                    this.status = 'ing'
                    $('#clear').modal('show')
                    this.clearAll()
                }, 300)
            },
            clearAll() {
                logManageService.clearEventLog()
                .then((res) => {
                    
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''

                        setTimeout(() => {
                            this.$Modal.success({
                                title: this.title,
                                content: '清空成功！',
                                scrollable: false
                            })
                        }, 400)

                        let params ={
                            page:1,
                        }
                        this.loadData(params)
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
                })
            },
            loadData() {        
                let params = {
                    t: 10,
                    orderby: this.orderby,
                    order: this.order,
                    page: this.cur_page,
                    row: this.size,
                    level: this.filter.level,
                    type: this.filter.type,
                    start_time: this.filter.start_time,
                    end_time: this.filter.end_time,     
                }
                logManageService.getEventLog(params)
                .then((res) => {
                    if (res.errcode === 0) {
                        this.animate_show = false       
                        this.total_num = res['10'].count
                        this.tableData = res['10'].logs.map((item)=>{
                            item.type = this.$t(`logmanage.logType${item.type}`)
                            item.level = this.$t(`logmanage.logLevel${item.level}`)
                            item.content = this.formatContent(item)
                            return item
                        })
                    }
                })
            },
            changePageSize (page, size) {
                this.cur_page = page
                this.size = size
                this.loadData()
            },
            rankData (param) {
                this.order = param.order
                this.orderby = param.by
                this.loadData()
            },
            searchEvent (params) {
                this.filter.level = params.level ? params.level : ''
                this.filter.type = params.type ? params.type : ''
                this.filter.start_time = params.start_time ? params.start_time : ''
                this.filter.end_time = params.end_time ? params.end_time : ''
                this.cur_page = 1
                this.loadData()
            }   
        }
    }
</script>