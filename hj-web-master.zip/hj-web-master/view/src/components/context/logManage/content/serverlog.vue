<template>
  <div class="wrap">
    <div class="page-title Menu">
      <h3>日志服务器</h3>
      <div class="addbtn" @click="toAdd()">
        <img src="../../../img/add.png" />
        <span>添加服务器</span>
      </div>
    </div>
    <!--加载数据-->
    <loading v-show="!show"></loading>

    <transition name="fade">
      <div v-if="show" class="content">
      <!-- 默认日志服务器 -->
        <div class="server-wrap" v-if="curpage==1">
          <div class="gradient-head">
            <h3>默认日志服务器</h3>      
          </div>
          <div class="content">
            <ul class="sever-btn" style="height: 55px;">
              <li>
                <label class="labels">服务器开关:</label>    
                <span>{{defaultServer.switch ? '启用' : '禁用'}}</span>   
              </li>            
              <li>
                <label class="labels">服务器地址：</label><span>{{defaultServer.ip}}(本机)</span>        
              </li>
              <li>
                <label class="labels">服务器端口：</label><span>{{defaultServer.port}}</span>
              </li>                                    
            </ul>
            <div class="logtype">
              <inputs :type="'logs'" :disabled="true" :required="true" :name="defaultServer.types" :val="'1,4,5,6,7,8,9'"></inputs>
            </div>
          </div>
        </div>
        <ul class="servers">
          <li class="serve" v-for='(item, index) in tableData' :key="index">
            <div class="server-wrap">
              <div class="gradient-head">
                <h3>日志服务器 {{ curpage + '-' + (index + 1) }}</h3>      
                <ul class="titile-butn">
                  <li @click.stop="editData(item)">
                    <img :src="`/static/${themeColor}-img/bule_sure.png`">                              
                    <span>确定</span>
                  </li>
                  <li @click.stop="delModal(item)">
                    <img :src="`/static/${themeColor}-img/bule_delet.png`"/>
                    <span>删除</span>
                  </li>
                </ul>
              </div>
              <loading v-if="status=='ing' && edit_id==item.id"></loading>          
              <div class="content" v-else>
                <ul class="sever-btn">
                  <!--启用禁用 -->
                  <li>
                    <label class="labels">服务器开关:</label>                
                    <div class="on_off_but">              
                      <button @click.stop="swichStatus(item,1)" :class="[item.switch>0?'btn-active':'btn-unactive']" class="on_but">启用</button>
                      <button @click.stop="swichStatus(item,0)" :class="[item.switch>0?'btn-unactive':'btn-active']" class="off_but">禁用</button>
                    </div>
                  </li>            
                  <!--input-->
                  <li>
                    <label class="labels">服务器地址：</label>
                    <inputs 
                      :type="'text'" 
                      :name="'ip'" 
                      :val="item.ip" 
                      :id="item.id"
                      :required="true"
                      :regex="/^((2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)$/" 
                      @getVal="getEditVal" >
                    </inputs>
                    <span class="mi">* 必填</span>        
                  </li>
                  <li>
                    <label class="labels">服务器端口：</label>
                    <inputs 
                      :type="'text'" 
                      :name="'port'" 
                      :val="item.port" 
                      :required="true"
                      :regex="/^([1-9]|[1-9]\d{1,3}|[1-5]\d{4}|6[0-5]{2}[0-3][0-5])$/" 
                      :id="item.id" 
                      @getVal="getEditVal">
                    </inputs>
                    <span class="mi">* 必填</span>    
                  </li>                                    
                </ul>
                <div class="logtype">
                  <inputs :type="'logs'" :required="true" :name="'types'" :val="item.types" :id = "item.id" :index="index"
                  @getVal="getEditVal"></inputs>
                </div>
              </div>            
            </div>
          </li>
        </ul>
          
      </div>  
    </transition>
    <pagination 
			v-show="show"
			:totalNum="count" 
			:nowpage="curpage" 
			:perNum="perNum" 
			:pageSize="pageSize" 
			@curPage="curPageEvent" 
			@changePageSize="changePageSize">
    </pagination>          

    <addServerLogModal :status="status" :errorMsg="errorMsg" @addLogServerEvent="addData"></addServerLogModal>
  </div>
</template>
<script>
import loading from 'components/common/loading'  
import Modals from 'components/common/Modals'  
import inputs from 'components/common/inputs'
import pagination from 'components/common/pagination'
import logManageService from 'services/logManageService'
import addServerLogModal from './addServerLogModal'
let field = []

export default {
  components: {
    inputs,
    Modals,
    loading,
    pagination,
    addServerLogModal
  },
  data() {
    return {
      field:field,
      tableData: [],
      oper: '',
      status: '',
      modok: '',
      operID: '',
      errorMsg: '',
      switch: '',
      show:false,
      defaultServer:{},
      adddata:{
        switch:0,
        ip:'',
        port:'',
        types:''
      },
      add_format_error:[],
      add_error_notice:"",
      deldata:{},
      selected_id:[],
      editdata:{},
      edit_id:'',
      edit_format_obj:{},
      count:1,
      curpage:1,
      perNum:2,
      pageSize:[2, 3, 5]
    }
  },
  mounted() {
    this.getData()      
  },
  watch:{
    tableData:function(){
      // edit_format_obj = {0:[],2:[]}
      // editdata_item = {0:{},2:{}}
      for(let [k,v] of this.tableData.entries()){
        let err_arr_item = {[v.id]:[]}
        Object.assign(  this.edit_format_obj,err_arr_item)
        let editdata_item =  {
          [v.id]:{
              id:v.id,
              switch:v.switch,
              ip:v.ip,
              port:v.port,
              types:v.types
          }
        }
        Object.assign(this.editdata, editdata_item)
      }
    }
  },
  methods: {
    getErrorMsg(msg) {
      this.errorMsg = msg
    },
    changePageSize (pageSize) {
      this.perNum = pageSize
      let totalPage = Math.floor((this.count - 1) / pageSize) + 1
      if (totalPage < this.curpage){
        if (totalPage === 0) {
          this.curPage = 1
        } else {
          this.curpage = totalPage
        }
      }
      this.getData()
    },
    curPageEvent(cur_page){
      this.curpage = cur_page
      this.getData()
    },
    getData() {
      this.show = false
      logManageService.getServer(this.curpage,this.perNum)
      .then((res) => {        
        this.show = true
        if (res.errcode === 0) {
          this.status = 'ok'
          this.errorMsg = ''
          if(this.curpage===1){//默认服务器
            this.defaultServer = res['7'].data.splice(0,1)[0]
          }            
          this.tableData = res['7'].data
          this.count = res['7'].count
        } else {
          this.status = 'error'
          this.errorMsg = this.$t('error_code.' + res.errcode)
        }
      })  
    },
    toAdd() {
      this.oper = 'add'        
      this.reset()
      $("#add-serverlog-modal").modal("show")
    },
    getAddVal(name, val, format_test, id) {//接收inputs发送回来的值  
      this.adddata[name] = val  
      if (format_test) { 
        this.error_notice = false
        for (let [index, ele] of this.add_format_error.entries()) {
          if (ele == name) {
            this.add_format_error.splice(index,1)
          }
        }
      } else {
        let format_error_arr = new Set([...this.add_format_error,name])
        this.add_format_error = [...format_error_arr]
      } 
    }, 
    addData(params) {  
      params.switch = 1
      let data = `${params.ip}|${params.port}|${params.switch}|${params.logs}`
      this.status = 'ing'
      logManageService.addServer(data)
      .then((res) => {        
        if (res.errcode === 0) {
          this.status = 'ok'
          this.errorMsg = ''
          this.$Modal.success({
              title: '日志服务器',
              content: '添加成功！',
              scrollable: false,
              onOk: () => {
                this.getData()
              }
          })
        } else {
          this.status = 'error'
          this.errorMsg = this.$t('error_code.' + res.errcode)
        }
      })  
    },
  
    delModal(item) {
      this.oper = "del"
      this.selected_id = [item.id]
      this.reset()
      this.$Modal.confirm({
				title: '日志服务器',
				content: '确定删除当前配置？',
				scrollable: false,
				"mask-closable": true,
				onOk: () => {
					this.delData(item)
				}
			})
    },
    delData(item){
      this.status = 'ing'
      logManageService.delServer(item.id)
      .then((res) => {        
        if (res.errcode === 0) {
          this.status = 'ok'
          this.errorMsg = ''
          setTimeout(() => {
              this.$Modal.success({
                  title: '日志服务器',
                  content: '删除成功！',
                  scrollable: false
              })
          }, 250)
          this.count--
          // 最后一页，只有一条记录时，删除后，要设置当前为上一页
          if (this.count === 0) {
            this.curpage = 1
          } else {
            let totalPage = (this.count - 1) / this.perNum + 1
            if (this.curpage >= totalPage) {
              if (this.curpage !== 1) {
                this.curpage--
              }
            }       
          }
          this.getData()
        } else {
          this.status = 'error'
          this.errorMsg = this.$t('error_code.' + res.errcode)
        }
      })  
    },
    getEditVal(name,val,format_test,id) {//接收inputs发送回来的值  
      this.editdata[id][name] = val

      if (format_test) { 
          this.error_notice = false
          for(let [index,ele] of this.edit_format_obj[id].entries()) {
              if (ele == name) {
                  this.edit_format_obj[id].splice(index,1)
              }
          }
      } else {
          let edit_format_obj = new Set([...this.edit_format_obj[id],name])
          this.edit_format_obj[id] = [...edit_format_obj]
      }     
    },
    editData(item){
      this.edit_id = item.id
      let test = true
      if(this.edit_format_obj[item.id]){
        test =   this.edit_format_obj[item.id].length===0?true:false
      }    
      if(!test){
        this.$Modal.error({
            title: '提示',
            content: '请检查输入格式',
            scrollable: false,
        })
        return
      }
      let params = this.editdata[item.id]
      let conf = `${params.id}|${params.ip}|${params.port}|${params.switch}|${params.types}`
      this.status = 'ing'
      logManageService.editServer(conf)
      .then((res) => {        
        if (res.errcode === 0) {
          this.status = 'ok'
          this.errorMsg = ''
          this.$Modal.success({
              title: '日志服务器',
              content: '修改成功！',
              scrollable: false,
              onOk: () => {
                this.getData()
              }
          })
        } else {
          this.status = 'error'
          this.errorMsg = this.$t('error_code.' + res.errcode)
        }
      })  
    },
    swichStatus(item, on_off) {
      this.edit_id = item.id  
      if (item.switch!=on_off) {
        this.editdata[this.edit_id] = {
          id:item.id,
          switch:on_off,
          ip:item.ip,
          port:item.port,
          types:item.types
        }  
        let params = {
          id:item.id,
          switch:on_off,
          ip:item.ip,
          port:item.port,
          types:item.types
        }      
        this.editData(params)
      }
    },
    reset() {
      this.status = ''
      this.errorMsg = ''
      this.adddata = {
        switch:0,
        ip:'',
        port:'',
        types:''
      },
      this.add_error_msg = ''
      this.add_error_notice = false
    }
  }
}
</script>
<style scoped lang="less">
  .wrap {
    margin: 30px 0 0 30px;
    background: #ffffff;
    padding-bottom: 10px;
  }
  .addbtn {
    float: right;
    cursor: pointer;
  }
  .sever-btn{
    display: flex;
    justify-content: space-between;
    li{
      width: 168px;
      margin-top: 15px;
      margin-bottom: 15px;
      
    }
    li:nth-child(2){
      width: 340px;
    }
    li:nth-child(3){
      width: 320px;
    }
  }
  .add_servers{
    text-align: left;
    border: 1px solid #E0E0E0;
  }
  .server-wrap{
    margin: 20px 0;
    border: 1px solid #E0E0E0;
  }
  p {
    text-align: center;
    line-height: 500px;
    font-size: 16px;
  }
  .content{
    padding: 0 20px;
  }
  .fade-enter-active, 
  .fade-leave-active {
    transition: opacity .5s;
  }
  .fade-enter,
  .fade-leave-to {
    opacity: 0;
  }
</style>