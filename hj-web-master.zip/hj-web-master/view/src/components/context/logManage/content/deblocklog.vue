<template>
    <div>
        <Tables 
            :title='title' 
            :field="type=='1'?field:field1" 
            :btns="btns" 
            :tableData='tableData' 
            :animateShow="animate_show"
            :dbClickDisabled="true"
            :perNum='size' 
            :totalNum="total_num"  
            :curPage="cur_page"
            :pageSize='pageSize' 
            :rankable="true"
            @rankData="rankData"
            @changePageSize='changePageSize'
            @loadData="getData"  
            @clearEvent="clearModal"
            :clearTip="clearTip"
            >
            <div slot="filter">
                <search :searchFiled="searchFiled" @searchEvent="searchData"></search>
                <div style="margin: 10px 0 0 20px;">
                    <button :class="[type=='1' ? 'btn-active' : 'btn-unactive']" class="button button--aylen" @click="changeType('1')">封堵日志</button>
                    <button :class="[type=='0' ? 'btn-active' : 'btn-unactive']" class="button button--aylen" @click="changeType('0')">解封日志</button>
                </div>
            </div>
        </Tables>
        <Modals 
            :id="'clear'" 
            :title="'提示'"
            :type="'clear'"
            :status="status" 
            :errorMsg="errorMsg" 
            @sentErrorMsg="getErrorMsg" 
            >
        </Modals>
    </div>
</template>
<script>
    import Tables from 'components/common/Tables'
    import search from 'components/common/search'
    import Modals from 'components/common/Modals'
    import logManageService from 'services/logManageService' 
    let btns = [
        {
            type:'clear',
            name:'清空',
            event:'clearEvent',
            icon:'/static/img/w_clear.png'
        }
    ]
    let field = [
        {
            type:'rank'
        },
        {
            type:'text',
            label:'MAC地址/IP地址',
            name:'mac',
            style:'width: 260px'    
        },
        {
            type:'text',
            label:'备注',
            name:'description', 
            editable:true,
            regex:/^[\S\s]{0,32}$/,
            style:'width: 260px'         
        },
        {
            type:'text',
            label:'管理员',
            name:'username',
            style:'width: 260px'        
        },
        {
            type:'text',
            label:'封堵时间',
            name:'time',
            style:'width: 260px'          
        }   
    ]
    let field1 = [
        {
            type:'rank',
        },
        {
            type:'text',
            label:'MAC地址/IP地址',
            name:'mac',
            style:'width: 260px'       
        },
        {
            type:'text',
            label:'备注',
            name:'description', 
            editable:true,
            regex:/^[\S\s]{0,32}$/,
            style:'width: 260px'          
        },
        {
            type:'text',
            label:'管理员',
            name:'username',
            style:'width: 260px'       
        },
        {
            type:'text',
            label:'解封时间',
            name:'time',
            style:'width: 260px'            
        }   
    ]
    let searchFiled = [
         {
            type:'text',
            label:'IP|MAC',
            name:'source'
        },
        {
            type:'time-rang',
            label:'时间范围',
            name:['start_time','end_time']
        }
    ]
    export default {
        components: {
            Tables,
            Modals,
            search
        },
        data() {
            return {
                title: '封堵&解封',
                type: '1',
                field: field,
                field1: field1,
                btns: btns,
                tableData: [],
                total_num: 1,
                cur_page: 1,
                pageSize: [10, 20, 40, 80],       
                searchFiled: searchFiled,
                animate_show: false,
                finddata: {},
                errorMsg: '',
                status: "",
                size: 20,
                order: '',
                by: '',
                params: {}
            }
        },
        computed: {
            clearTip: function(val) {
                return this.type == '1' ? '封堵日志' : '解封日志'
            }
        },
        created() {
            this.getData()
        },
        methods:{
            getErrorMsg(msg) {
                this.errorMsg = msg
            },
            clearModal() {
                setTimeout(() => {
                    this.status = 'ing'
                    this.errorMsg = ''
                    $('#clear').modal('show')
                    this.clearAll()
                }, 300)
            },
            clearAll() {
                logManageService.clearUnblockLog(this.type)
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''
                        this.cur_page = 1

                        setTimeout(() => {
                            this.$Modal.success({
                                title: this.title,
                                content: '清空成功！',
                                scrollable: false
                            })
                        }, 400)
                        
                        this.getData()
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
                })
            },
            loadBolck(status) {
                this.type = status
                this.cur_page = 1
                this.getData()
            },
            changePageSize (nowpage, size) {
                this.cur_page = nowpage
                this.size = size
                this.getData()
            }, 
            rankData(param){
                this.order = param.order
                this.by =  param.by
                this.getData()
            },
            searchData(searchData){
                this.animate_show = true
                this.params = searchData
                this.getData()
            },
            changeType(type){
                this.type = type
                this.order = ''
                this.by = ''
                this.cur_page = 1
                this.params = {}
                this.getData()
            },
            getData() {        
                this.order = this.order === 'mac' ? 'source': this.order

                logManageService.getUnblockLog(this.order, this.by, this.cur_page, this.size, this.type, this.params)
                    .then((res) => {                
                        if (res.errcode === 0) {
                            this.animate_show = false
                            this.tableData = res['8'].logs.map((item)=>{
                                item.mac = item.source
                                return item
                            })
                            this.total_num = res['8'].count
                        }
                    })
                }
        }
    }
</script>
<style scoped>
    .button {
        height: 20px;
        margin-right: 10px;
    }
</style>