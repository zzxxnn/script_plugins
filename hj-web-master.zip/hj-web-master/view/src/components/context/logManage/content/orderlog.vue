<template>
    <div>
        <Tables 
            :title='title' 
            :field="field" 
            :tableData='tableData' 
            :btns="btns" 
            :animateShow="animate_show"
            :pageSize='pageSize' 
            :totalNum="total_num"  
            :perNum="size"
            :curPage="cur_page" 
            @loadData="loadData" 
            @reset="reset"
            @xmlEvent="exportFile('xml')" 
            @htmlEvent="exportFile('html')" 
            @clearEvent="clearModal" 
            :dbClickDisabled="true"
            :rankable="true"
            @changePageSize='changePageSize'
            @rankData="rankData"
            >
           <div slot="filter">
                <search class="label-width" :searchFiled="searchFiled" @searchEvent="searchData"></search>
            </div>
        </Tables>
        <Modals 
            :id="'clear'" 
            :title="'提示'"
            :type="'clear'"
            :status="status" 
            :errorMsg="errorMsg" 
            @sentErrorMsg="getErrorMsg" 
            >
        </Modals>
    </div>
</template>
<script>
    import Tables from 'components/common/Tables'
    import search from 'components/common/search'
    import Modals from 'components/common/Modals'
    import logManageService from 'services/logManageService' 
    let btns = [
         {
            type:'other',
            name:'导出XML',
            event:'xmlEvent',
            icon:'/static/img/exportxml.png'
        },
         {
            type:'other',
            name:'导出HTML',
            event:'htmlEvent',
            icon:'/static/img/exporthtml.png'
        },
        {
            type:'clear',
            name:'清空',
            event:'clearEvent',
            icon:'/static/img/w_clear.png'
        }
    ]
    let field = [
        {
            type:'rank',
        },
        {
            type:'text',
            label:'管理员',
            name:'username',
            style:'width: 150px'           
        },
        {
            type:'text',
            label:'IP地址',
            name:'clientip',          
        },
        {
            type:'text',
            label:'内容',
            name:'content',
            ellipsis:'max-width:300px;',
        },
        {
            type:'text',
            label:'时间',
            name:'time',          
        }   
    ]
    let searchFiled = [
        {
            type:'text',
            label:'IP地址',
            name:'clientip'
        },
        {
            type:'text',
            label:'管理员',
            name:'username',
            regex:null,
        },
        {
            type:'time-rang',
            label:'时间范围',
            name:['start_time','end_time'],
        }

    ]
    export default {
        components: {
            Tables,
            Modals,
            search
        },
        data() {
            return {
                title: '操作日志',
                field: field,
                btns: btns,
                tableData: [],
                pageSize: [10, 20, 40, 80],
                size: 20,
                total_num: 1,
                cur_page: 1,
                type: 'block',
                searchFiled: searchFiled,
                animate_show: false,
                export_data: {},
                status: '',
                errorMsg: '',
                finddata: {},
                orderby:  '',
                order: '',
                filter: {
                    username: '',
                    mac: '',
                    clientip: '',
                    start_time: '',
                    end_time: '',
                    content: ''
                }
            }
        },
        created() {
            this.loadData()
        },
        methods: {
            getErrorMsg(msg) {
                this.errorMsg = msg
            },
            reset(type) {
                this.status = ""
                this.errorMsg = ''
            },  
            exportFile(filetype) {                                
                let params = this.filter
                params.mac = params.mac ? params.mac : ""
                params.clientip = params.clientip ? params.clientip : ''
                params.username = params.username ? params.username : ''
                params.content = params.content ? params.content : ""
                params.start_time = params.start_time ? params.start_time : ''
                params.end_time = params.end_time ? params.end_time : ''
                let fileName = '操作日志' + new Date().toLocaleString()
                let setUrl =`/logs/get?t=9&export=${filetype}&mac=${params.mac}&clientip=${params.clientip}`             
                +`&username=${params.username}&content=${params.content}&start_time=${params.start_time}&end_time=${params.end_time}`
                window.open(setUrl);
            },
            clearModal() {
                setTimeout(() => {
                    this.status = 'ing'
                    $('#clear').modal('show')
                    this.clearAll()
                }, 300)
            },
            clearAll() {
                logManageService.clearOrderLog()
                .then((res) => {
                    if (res.errcode === 0) {
                        this.status = 'ok'
                        this.errorMsg = ''

                        setTimeout(() => {
                            this.$Modal.success({
                                title: this.title,
                                content: '清空成功！',
                                scrollable: false
                            })
                        }, 400)

                        let params = {
                            page: 1,
                        }
                        this.loadData(params)
                    } else {
                        this.status = 'error'
                        this.errorMsg = this.$t('error_code.' + res.errcode)
                    }
                })
            },
            loadData() {                    
                let params = {
                    t: 9,
                    orderby: this.orderby,
                    order: this.order,
                    page: this.cur_page,
                    row: this.size,
                    username: this.filter.username,
                    content: this.filter.content,
                    mac: this.filter.mac,
                    clientip: this.filter.clientip,
                    start_time: this.filter.start_time,
                    end_time: this.filter.end_time,     
                }
                logManageService.getOrderLog(params)
                .then((res) => {
                    if (res.errcode === 0) {
                        this.animate_show = false       
                        this.total_num = res['9'].count
                        this.tableData = res['9'].logs
                    }
                })
            },
            changePageSize (page, size) {
                this.cur_page = page
                this.size = size
                this.loadData()
            },
            rankData (param) {
                this.order = param.order
                this.orderby = param.by
                this.loadData()
            },
            searchData (params) {
                this.filter.username = params.username ? params.username : ''
                this.filter.mac = params.mac ? params.mac : ''
                this.filter.content = params.content ? params.content : ''
                this.filter.clientip = params.clientip ? params.clientip : ''
                this.filter.start_time = params.start_time ? params.start_time : ''
                this.filter.end_time = params.end_time ? params.end_time : ''
                this.cur_page = 1
                this.loadData()
            }
        }
    }
</script>