<template>
  <div class="modal" id='add-serverlog-modal'  @keyup.enter="sendData"  tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-700">
      <div class="modal-content" style="width:840px;">
        <div class="modal-header">    
          <h3 class="modal-title" id="myModalLabel">
            添加日志服务器
          </h3>
          <span class="close" data-dismiss="modal" aria-hidden="true">&times;</span>
        </div>
        <div class="modal-body">
          <div class="servers add_servers">
            <ul style="
              display: flex;
              align-items: center;
              justify-content: space-between;
              margin-bottom: -1px;
              padding: 40px 20px;
              border: 1px solid #e0e0e0">        
              <li>
                <label class="labels">服务器地址：</label>
                <input 
                  type="text"
                  :class="['input-item', ipErrorCls]"
                  v-model="formData.ip" 
                  @blur="checkValid('ip', 'ipErrorCls', 'ipReg')"
                  >
                <span class="mi">* 必填</span>        
              </li>
              <li>
                <label class="labels">服务器端口：</label>
                <input
                  type="text"
                  :class="['input-item', portErrorCls]"
                  v-model="formData.port"
                  @blur="checkValid('port', 'portErrorCls', 'portReg')"
                  >
                <span class="mi">* 必填</span>    
              </li>                                    
            </ul>
            <div :class="logErrorCls" style="padding: 20px;border: 1px solid #e0e0e0;">
              <div>
                <ul class="logLabel">
                    <li style="text-align:left">
                        <label class="labels">日志类型：</label>									
                        <span class="line"></span>									
                        <input :disabled="disabled" style="margin-left: 10px;" type="checkbox" :checked="checkAllStatus"  @click='checkedAll($event)' />
                        <label style=" font-weight: 500; margin-left: 3px;">全选</label>
                        <span class="mi">（* 不能少于一种）</span>	
                    </li>													
                </ul>
                <ul class="logs">
                    <li>
                        <input type="checkbox" :checked="String(this.formData.logs).indexOf(1)>=0" @change="logsVal('1',$event)"/>
                        <label >渗透日志</label>
                    </li>
                    <li>
                        <input type="checkbox" :checked="String(this.formData.logs).indexOf(4)>=0"  @change="logsVal('4',$event)"/>
                        <label >主机下线日志</label>
                    </li>
                    <li>
                        <input type="checkbox" :checked="String(this.formData.logs).indexOf(5)>=0"  @change="logsVal('5',$event)"/>
                        <label>封堵日志</label>
                    </li>
                    <li>
                        <input type="checkbox" :checked="String(this.formData.logs).indexOf(6)>=0"  @change="logsVal('6',$event)"/>								
                        <label >解封日志</label>
                    </li>							
                    <br/>							
                    <li>
                        <input type="checkbox" :checked="String(this.formData.logs).indexOf(8)>=0" @change="logsVal('8',$event)"/>
                        <label >命令日志</label>
                    </li>
                    <li>
                        <input type="checkbox" :checked="String(this.formData.logs).indexOf(7)>=0" @change="logsVal('7',$event)"/>								
                        <label >主机变换日志</label>
                    </li>								
                    <li>
                        <input type="checkbox" :checked="String(this.formData.logs).indexOf(9)>=0" @change="logsVal('9',$event)"/>					
                        <label >事件日志</label>
                    </li>
                </ul>		
              </div>      
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <div style="text-align:left;color:#ff3300;">{{errorMsg ? '* ' + errorMsg : ''}}</div>
          <button class="button sure-btn button--aylen" data-dismiss="modal">{{$t('common.cancelBtn')}}</button>
          <Button class="button sure-btn button--aylen" :loading="false" @click='sendData'>{{$t('common.sureBtn')}}</Button>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import ProtocolData from 'libs/ProtocolData'
  import formatTest from 'libs/formatTest'
  export default {
    props: {
      status: {
        type: String,
        // required: true
      },
      errorMsg: {
        type: String,
        // required: true
      },
      oper: {
        type: String
      },
      selectedItems: {},
      editData: {}
    },
    data() {
      return {
        formData: {
          ip: '',
          port: '',
          logs: []
        },
        disabled: false,
        ipErrorCls: '',
        portErrorCls: '',
        logErrorCls: '',
        ipReg: /^((2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)\.){3}(2[0-4]\d?|25[0-5]|[1-9][0-9]|[0-9]|[1]\d\d?)$/,
        portReg: /^([1-9]|[1-9]\d{1,3}|[1-5]\d{4}|6[0-5]{2}[0-3][0-5])$/,
        errors: {}
      }
    },
    mounted () {
      $('#add-serverlog-modal').on('hide.bs.modal', () => {
          this.error_msg = ''
          this.ipErrorCls = ''
          this.portErrorCls = ''
          this.logErrorCls = ''
          this.formData = {
            ip: '',
            port: '',
            logs: []
          }
          this.errors = {}
          this.$store.state.modalFormVisible = false
      })
      $('#add-serverlog-modal').on('show.bs.modal', () => {
          this.$store.state.modalFormVisible = true
      })
    },
    computed:{
      checkAllStatus() {  
        return this.formData.logs.length >= 7
      }
    },
    beforeUpdate() {
      this.error_msg = this.errorMsg
    },
    watch: {
      status: function() {
        if (this.status == 'ok') {
          $('#add-serverlog-modal').modal('hide')
        } 
      }
    },
    methods: {
      addErrorCls(name, cls) {
        this[cls] = 'normal error_foramt animated shake'
            setTimeout(() => {
                this[cls] = 'normal error_foramt'
            }, 200)
        this.errors[name] = false
        return false
      },
      checkValid(name, cls, reg) {
        if (name == 'ip') {
          if (this.formData.ip == '0.0.0.0') {
            return this.addErrorCls(name, cls)
          }
        }

        if (name == 'log') {
          if (this.formData.logs.length == 0) {
            return this.addErrorCls(name, cls)
          }
        }

        if (this[reg] && !this[reg].test(this.formData[name])) {
          return this.addErrorCls(name, cls)
        } else {
          this[cls] = 'normal'
        }

        this.errors[name] = true
      },
      checkAllValid() {
        this.checkValid('ip', 'ipErrorCls', 'ipReg')
        this.checkValid('port', 'portErrorCls', 'portReg')
        this.checkValid('log', 'logErrorCls')

        return !Object.values(this.errors).includes(false)
      },
      
      logsVal(val, event) {
        let index = this.formData.logs.findIndex((item) => {
          return val == item
        })
        if (index == -1) {       
          this.formData.logs.push(val)
        } else {
          this.formData.logs.splice(index, 1)
        }
      },
      checkedAll(event) {
        if (this.formData.logs.length < 7) {
          this.formData.logs = ['1', '4', '5', '6', '7', '8', '9']
        } else {
          this.formData.logs = []
        }   
      },
      sendData() {
        // console.log(this.checkAllValid())
        if (!this.checkAllValid()) {
          return
        }
        this.$emit('addLogServerEvent', this.formData)
      },
    },
    beforeDestroy() {
      $('.safe-modal').off('show.bs.modal').off('hide.bs.modal')
    }
  }
</script>

<style lang="less" scoped>
.notice{
  display: none;
  margin-left: 10px;
  text-align: left;
  color: #ff3300;  
}
// .servers {
//   // border: 1px solid #e0e0e0;
// }
.input-item {
  width: 180px;
  height: 25px;
  border-radius: 3px;
  padding: 0 10px;
  border: 1px solid #e8e8e8;
}
/*日志类型*/
.line {
    border-left: 1px solid#E0E0E0;
    height: 15px;
    vertical-align: middle;
}
.logs {
    display: flex;
    vertical-align: top;
    margin-left: 70px;
    margin-top: 10px;
    width: 600px;
    flex-wrap: wrap;
}
.logs label {		
    font-weight: 500;
    margin-left: 3px;	
}
.logs li {
    display: flex;
    align-items: center;
    border: 1px solid#E2E2E2;
    border-radius: 3px;
    padding: 4px 10px;
    margin: 0 40px 20px 0;
}
</style>
