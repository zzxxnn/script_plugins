<template>
	<div class="content-wrap statistic">
		<div class="title Menu">
			<h3>渗透统计</h3>
		</div>
		<div class="content">
			<rank></rank>
			<record></record>
		</div>
	</div>
</template>
<script>
	import rank from './slots/rank.vue'
	import record from './slots/record.vue'
	export default {
		components: {
			rank,
			record
		}
	}
</script>