import common from './common'
import login from './login'
import nav from './nav'
import home from './home'
import realTime from './realTime'
import safeplot from './safeplot'
import sysconf from './sysconf'
import netmanage from './netmanage'
import logmanage from './logmanage'
import errcode from './errcode'
export default{
  common: common,
  login: login,
  nav: nav,
  home: home,
  realTime: realTime,
  safeplot: safeplot,
  sysconf: sysconf,
  netmanage: netmanage,
  logmanage: logmanage,
  error_code: errcode
}