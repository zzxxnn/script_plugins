export default{
  logo:'Magic',
  zhlogo:'Environment',
  enlogo:"Intranet Dynamic Defense System",
  navBtn1:'Home page',
  navBtn2:'Realtime monitor',
  navBtn3:'Security policy',
  navBtn4:'system config',
  navBtn5:"Network manage",
  navBtn6:"Log manage",
  freshBtn:"Fresh",
  saveBtn:'Save config',
  exitBtn:'logout'
}