export default{
  logo:'Magic',
  zhlogo:'Environment',
  enlogo:"Intranet Dynamic Defense System",
  themeLabel:'Theme switch',
  red:'Red theme',
  blue:'Blue theme',
  loginLabel:'USER LOGIN',
  userNameLabel:"User name",
  passWroldLabel:"Pass word",
  loginButton:"LOGIN",
  DkeyLogin:'use Dkey to login',
  activex:'Install the activex control'
}
