export default {
  logType1: '网口接入',
  logType2: '网口断开',
  logType3: '登录成功',
  logType4: '用户注销',
  logType5: '系统初始化',
  logType6: '系统启动',
  logType7: '中心连接',
  logType8: '登录失败',
  logType9: '中心断开',
  logType10: '登录超限制',
  logLevel1: '普通',
  logLevel2: '警告',
  logLevel3: '严重'
}