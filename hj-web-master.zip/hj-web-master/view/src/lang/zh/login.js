export default{
    logo:'幻境',
    zhlogo:'内网动态防御系统',
    enlogo:"Intranet Dynamic Defense System",
    themeLabel:'主题切换',
    red:'红色',
    blue:'蓝色',
    loginLabel:'用户登录',
    userNameLabel:"用户名",
    passWroldLabel:"密 码",
    loginButton:"登 录",
    DkeyLogin:'使用Dkey登录',
    activex:'安装activex控件'
}