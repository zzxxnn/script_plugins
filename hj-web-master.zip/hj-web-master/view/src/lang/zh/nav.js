export default{
  logo:'幻境',
  zhlogo:'内网动态防御系统',
  enlogo:"Intranet Dynamic Defense System",
  navBtn1:'首页',
  navBtn2:'实时监控',
  navBtn3:'安全策略',
  navBtn4:'系统配置',
  navBtn5:"网络管理",
  navBtn6:"日志管理",
  freshBtn:"刷新",
  saveBtn:'保存配置',
  exitBtn:'注销'
}