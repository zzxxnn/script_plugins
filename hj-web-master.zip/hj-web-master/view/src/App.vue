<template>
    <div id="app" :class="`theme-${themeColor}`">
      <router-view></router-view> 
    </div>
</template>
<script>
import navbar from './components/navbar'
import Footerbar from './components/footer'
import UserService from 'services/userService'
import SystemService from 'services/systemService'

export default {
  name: 'app',
  components: {
    navbar,
    Footerbar
  },
  // computed: {
  //   login: function() {
  //     return this.$store.state.login.is_login
  //   }
  // },
  // watch: {
  //   login: function() {
  //     if (!this.login) {
  //       this.$router.push("/login")
  //     } else {
  //       this.$router.push("/")
  //     }
  //   }
  // },
  mounted() {
    SystemService.getLicense()
      .then((res) => {
        if (res.errcode === 0) {
          this.$store.state.cert = res.cert
        } else {
          this.$router.push('/errorpage')
        }
      })
    
    UserService.getLoginInfo()
     .then((res) => {
        if (res.errcode === 0) {
          this.$store.commit('EDIT_Access', res.access)
          this.$store.commit('EDIT_LOGIN', res)

          if (res.access) {
            if (window.location.href.indexOf('errorpage') != -1) {
              this.$router.push('/')
            }
          }
       }
    })
  }
}
</script>
