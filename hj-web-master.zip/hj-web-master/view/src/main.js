// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import 'babel-polyfill'
import Vue from 'vue'
import VueRouter from 'vue-router'
import App from './App'
import routes from './routes/'
import store from 'src/vuex/store'
import iView from 'iview'
import 'iview/dist/styles/iview.css'
import 'src/theme/theme-red/index.less'
import 'src/theme/theme-blue/index.less'
import enMessages from 'src/lang/en/index.js'
import zhMessages from 'src/lang/zh/index.js'
import UserService from 'services/userService'

Vue.use(VueRouter)
Vue.use(iView)
Vue.prototype.bus = new Vue()

window.code_version = __COMMIT__

// 主题
Vue.prototype.themeColor = __THEME__ || 'red'
let themeColor = window.localStorage.getItem('themeColor')
if (themeColor) {
  Vue.prototype.themeColor = themeColor
}

// 中英文切换
const messages = {
  en: enMessages,
  zh: zhMessages
}

if (window.localStorage.getItem('lang')) {
  store.state.lang = window.localStorage.getItem('lang')
}

Vue.prototype.$t = function (key) {
  let lang = store.state.lang
  let ret = messages[lang]
  key.split('.').forEach((k) => {
    ret = ret && ret[k]
    if (ret && typeof ret[k] === 'object') {
      ret = ret[k]
    }
  })
  return ret
}

const router = new VueRouter({
  mode: 'history',
  routes
})

router.beforeEach((to, from, next) => {
  Vue.prototype.$Modal.remove()
  let isLogin = store.state.login.is_login

  if (!isLogin) {
    UserService.getLoginInfo()
      .then((res) => {
        if (res.errcode === 0) {
          store.commit('EDIT_Access', res.access)
          store.commit('EDIT_LOGIN', res)

          if (!res.is_login) {
            if (to.path !== "/login") {
              next("/login")
            } else {
              next()
            }
          } else {
            if ((to.path === "/login" || to.path === "/error")) { // 如果已经登录，却尝试访问登录页面或者错误页面，将继续保持原本的页面
              next(from.path)
            } else {
              next()
            }
          }
        }
      })
  } else {
    if ((to.path === '/login' || to.path === '/error')) { // 如果已经登录，却尝试访问登录页面或者错误页面，将继续保持原本的页面
      next(from.path)
    } else {
      next()
    }
  }
    // if (!is_login && to.path !== "/login") {//如果有网站访问权限，但没有登录，跳转到登录页面
    //   next("/login")
    // } else {
    //   if ((to.path === "/login" || to.path === "/error") && is_login) {//如果已经登录，却尝试访问登录页面或者错误页面，将继续保持原本的页面
    //     next(from.path)
    //   } else {
    //     next()
    //   }
    // }
})

/* eslint-disable no-new */
new Vue({
  el: '#app',
  template: '<App/>',
  components: { App },
  router,
  store
})

