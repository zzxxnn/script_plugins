const routes = [
	{
		path: '/',
		component: resolve => require(['components/context/'], resolve),
		children:[
			{
				path: '/',
				component:resolve => require(['components/context/homePage/'], resolve)
			},
			{
				path: 'home',
				component:resolve => require(['components/context/homePage/'], resolve)
			},
			{
				path: 'monitor',
				component: resolve => require(['components/context/current/'], resolve),
				children:[
					{
						path: '/',
						component: resolve => require(['components/context/current/content/equipment'], resolve)
					},
					{
						path: 'resource',
						component:resolve => require(['components/context/current/content/equipment'], resolve)
					},
					{
						path: 'interface',
						component:resolve => require(['components/context/current/content/port'], resolve)
					},
					{
						path: 'user',
						component:resolve => require(['components/context/current/content/userMonitor'], resolve)
					},
					{
						path: 'online_host',
						component:resolve => require(['components/context/current/content/onlineNode'], resolve)	
					},					
					{
						path: 'block_list',
						component:resolve => require(['components/context/current/content/blockPage'], resolve)	
					},
					{
						path: 'white_list',
						component:resolve => require(['components/context/current/content/whiteList'], resolve)	
					},
					{
						path: 'black_list',
						component:resolve => require(['components/context/current/content/blacklist'], resolve)	
					}
				]
			},
			{
				path: 'system',
				component: resolve => require(['components/context/systemSet/'], resolve),
				children:[
					{
						path: '/',
						component:resolve => require(['components/context/systemSet/content/update'], resolve)
					},		
					{
						path: 'update',
						component:resolve => require(['components/context/systemSet/content/update'], resolve)
					},
					{
						path: 'backup',
						component:resolve => require(['components/context/systemSet/content/backups'], resolve)
					},
					{
						path: 'boot',
						component:resolve => require(['components/context/systemSet/content/shutdown'], resolve)
					},
					{
            path: 'policy',
						component:resolve => require(['components/context/systemSet/content/syspolt'], resolve)
					},
					{
            path: 'diagnose',
						component:resolve => require(['components/context/systemSet/content/diagnose'], resolve)
					},
					{
            path: 'centralize',
						component:resolve => require(['components/context/systemSet/content/sysmanagement'], resolve)
					},
					{
						path: 'manager',
						component:resolve => require(['components/context/systemSet/content/admin'], resolve)	
					},
					{
						path: 'time',
						component:resolve => require(['components/context/systemSet/content/datatime'], resolve)	
					},
					{
						path: 'info',
						component:resolve => require(['components/context/systemSet/content/info'], resolve)	
					}
				]
			},
			{
				path: 'network',
				component: resolve => require(['components/context/netManage/'], resolve),
				children: [
					{
						path: '/',
						component:resolve => require(['components/context/netManage/content/globalconf'], resolve)
					},		
					{
						path: 'global',
						component:resolve => require(['components/context/netManage/content/globalconf'], resolve)
					},
					{
						path: 'rip',
						component:resolve => require(['components/context/netManage/content/ripconf'], resolve)
					},
					{
						path: 'vip',
						component:resolve => require(['components/context/netManage/content/vipconf'], resolve)	
					},
					{
						path: 'wip',
						component:resolve => require(['components/context/netManage/content/wipconf'], resolve)	
					},
					{
						path: 'vnetwork',
						component:resolve => require(['components/context/netManage/content/vnetconf'], resolve)	
					},
					{
						path: 'virtual_response',
						component:resolve => require(['components/context/netManage/content/vresconf'], resolve)	
					},
					{
						path: 'static_wip',
						component:resolve => require(['components/context/netManage/content/staticaddr'], resolve)
					},
					{
						path: 'static_route',
						component:resolve => require(['components/context/netManage/content/staticroute'], resolve)	
					},
					{
						path: 'host_passthrough',
						component:resolve => require(['components/context/netManage/content/trunk'], resolve)	
					},
					{
						path: 'proto_passthrough',
						component:resolve => require(['components/context/netManage/content/agreement'], resolve)	
					},
					{
						path: 'bypass',
						component:resolve => require(['components/context/netManage/content/softbypass'], resolve)	
					},
					{
						path: 'ha',
						component:resolve => require(['components/context/netManage/content/ha'], resolve)	
					}
				]
			},
			{
				path: 'security',
				component: resolve => require(['components/context/defend/'], resolve),
				children: [
					{
						path: '/',
						component:resolve => require(['components/context/defend/content/safeplot'], resolve)
					},
					{
						path: 'firewall',
						component:resolve => require(['components/context/defend/content/safeplot'], resolve)
					},		
					{
						path: 'access_strategy',
						component:resolve => require(['components/context/defend/content/accessStrategy'], resolve)
					},
					{
						path: 'black_list',
						component:resolve => require(['components/context/defend/content/blacklist'], resolve)
					},
					{
						path: 'honey',
						component:resolve => require(['components/context/defend/content/hostcomputer'], resolve)
					},
					{
						path: 'host_remark',
						component:resolve => require(['components/context/defend/content/selfset'], resolve)
					},
					{
						path: 'host_admit',
						component:resolve => require(['components/context/defend/content/Hostap'], resolve)
					},
					{
						path: 'white_list',
						component:resolve => require(['components/context/defend/content/whitelist'], resolve)	
					},
					{
						path: 'server_pretend',
						component:resolve => require(['components/context/defend/content/holomask'], resolve)	
					},
					{
						path: 'ports_unreal_open',
						component:resolve => require(['components/context/defend/content/trapnode'], resolve)	
					},
					{
						path: 'unreal_open_white',
						component:resolve => require(['components/context/defend/content/trapwlist'], resolve)	
					}
				]
			},
			{
				path: 'log',
				component: resolve => require(['components/context/logManage/'], resolve),
				children: [
					{
						path: '/',
						component:resolve => require(['components/context/logManage/content/permeatelog'], resolve)
					},
					{
						path: 'attack_log',
						component:resolve => require(['components/context/logManage/content/permeatelog'], resolve)
					},		
					{
						path: 'attack_statistics',
						component:resolve => require(['components/context/logManage/content/statistic'], resolve)
					},
					{
						path: 'host_log',
						component:resolve => require(['components/context/logManage/content/terminallog'], resolve)
					},
					{
						path: 'block_log',
						component:resolve => require(['components/context/logManage/content/deblocklog'], resolve)
					},
					{
						path: 'event_log',
						component:resolve => require(['components/context/logManage/content/eventlog'], resolve)	
					},
					{
						path: 'operation_log',
						component:resolve => require(['components/context/logManage/content/orderlog'], resolve)	
					},
					{
						path: 'log_server',
						component:resolve => require(['components/context/logManage/content/serverlog'], resolve)	
					}
				]
			}
		]
	},
	{
		path: '/login',
		component: resolve => require(['components/login/'],resolve)
	},
	{
		path: '/errorpage',
		component: resolve => require(['components/error/'],resolve)
	},
	{
		path: '*',
		component: resolve => require(['components/error/404'],resolve)
	}
]


export default routes