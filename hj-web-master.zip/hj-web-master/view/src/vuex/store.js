import Vue from 'vue'
import Vuex from 'vuex'
import createPersistedState from 'vuex-persistedstate'
Vue.use(Vuex)

const state = {
  access: false,
  cert: {},
  login: {},
  web_ui: false,
  time: '',
  lang: 'zh',
  modalFormVisible: false
}
const mutations = {
  EDIT_LOGIN (state, payload) {
    state.login = payload
  },
  EDIT_WEB (state, payload) {
    state.web_ui = payload
  },
  EDIT_Access (state, payload) {
    state.access = payload
  },
  EDIT_Time (state, payload) {
    state.time = payload
  }
}
const store = new Vuex.Store({
  state,
  mutations,
  plugins: [createPersistedState({ storage: window.sessionStorage })]
})

export default store
