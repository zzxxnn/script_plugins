// see http://vuejs-templates.github.io/webpack for documentation.
const path = require('path')
const host = 'https://192.168.2.11'

module.exports = {
  build: {
    env: require('./prod.env'),
    index: path.resolve(__dirname, '../../api/application/index/view/index/index.html'),
    assetsRoot: path.resolve(__dirname, '../../api/public/'),
    assetsSubDirectory: 'static',
    assetsPublicPath: '/',
    productionSourceMap: true,
    // Gzip off by default as many popular static hosts such as
    // Surge or Netlify already gzip all static assets for you.
    // Before setting to `true`, make sure to:
    // npm install --save-dev compression-webpack-plugin
    productionGzip: false,
    productionGzipExtensions: ['js', 'css']
  },
  dev: {
    env: require('./dev.env'),
    port: 8086,
    assetsSubDirectory: 'static',
    assetsPublicPath: '/',
    proxyTable: {
      '/logs': {
        target: host,
        secure: false,
        changeOrigin: true
      },
      '/stats': {
        target: host,
        secure: false,
        changeOrigin: true
      },
      '/utils': {
        target: host,
        secure: false,
        changeOrigin: true
      },
      '/netmgmt': {
        target: host,
        secure: false,
        changeOrigin: true
      },
      '/license': {
        target: host,
        secure: false,
        changeOrigin: true
      },
      '/services': {
        target: host,
        secure: false,
        changeOrigin: true
      },
      '/session': {
        target: host,
        secure: false,
        changeOrigin: true
      },
      '/safe/*': {
        target: host,
        secure: false,
        changeOrigin: true
      },
      '/stats/': {
        target: host,
        secure: false,
        changeOrigin: true
      },
      '/sysconf': {
        target: host,
        secure: false,
        changeOrigin: true
      },
      '/sys-conf': {
        target: host,
        secure: false,
        changeOrigin: true
      },
      '/usermgmt': {
        target: host,
        secure: false,
        changeOrigin: true
      },
      '/network-mode': {
        target: host,
        secure: false,
        changeOrigin: true
      }
    },
    // CSS Sourcemaps off by default because relative paths are "buggy"
    // with this option, according to the CSS-Loader README
    // (https://github.com/webpack/css-loader#sourcemaps)
    // In our experience, they generally work as expected,
    // just be aware of this issue when enabling this option.
    cssSourceMap: false
  },
  test: {
    env: require('./test.env')
  }
}
