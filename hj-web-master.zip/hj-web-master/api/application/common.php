<?php 

use think\Db;

//--------------------------
// 算法加密工具
//--------------------------
//令牌加密
function TokenHash($token) {
    $token = base64_encode(hash("sha1", $token));
    return $token;
}
// 登陆信息散列
function AuthSign($data) {
    if(!is_array($data)){
        $data = (array)$data;
    }
    ksort($data);//对数组进行降序排列
    $code = http_build_query($data);//将数组处理为url-encoded 请求字符串
    $sign = sha1($code);//进行散列算法
    return $sign;
}
//随机生成6个字母
function RandChars(){
    $chars = '';
    for($i=1;$i<=4;$i++){
        $chars .= chr(rand(97,122));
    }
    return $chars;
}

//--------------------------
// 网络地址处理工具
//--------------------------
//获取客户端IP
function GetClientIp(){
    if(getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
        $onlineip = getenv('REMOTE_ADDR');
    } elseif(isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
        $onlineip = $_SERVER['REMOTE_ADDR'];
    } elseif(getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
        $onlineip = getenv('HTTP_CLIENT_IP');
    } elseif(getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
        $onlineip = getenv('HTTP_X_FORWARDED_FOR');
    }
    return $onlineip;
}
// 获取服务器IP
function GetServerIP(){
    return isset($_SERVER['HTTP_X_FORWARDED_HOST']) ? $_SERVER['HTTP_X_FORWARDED_HOST'] : (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');
}
//验证Mac
function CheckMac($mac){
    return filter_var($mac, FILTER_VALIDATE_MAC) === false ? false : true;
}
//验证Ip
function CheckIp($ip){
    return !empty(ip2long($ip));
}
// 验证IP/MASK
function CheckIpMask($ip){
    $ip_mask = explode('/', $ip);
    return count($ip_mask)==2 && ip2long($ip_mask[0]) && is_numeric($ip_mask[1]) && is_int((int)$ip_mask[1]) && $ip_mask[1] >= 1 && $ip_mask[1] <= 32;
}
// 验证IP范围
function CheckIpRange($ip){
    $ip_arr = explode('-', $ip);
    if(count($ip_arr) !== 2){
        return false;
    }
    if(ip2long($ip_arr[0]) >= ip2long($ip_arr[1])){
        return false;
    }
    return count($ip_arr)==2 && ip2long($ip_arr[0]) && ip2long($ip_arr[1]) ;
}
/**
 * 解析如 24 => 255.255.255.0
 * @param  Int    $mask_len  
 * @return String    $mask
 */
function ParseMask($mask_len){
    $mask = 0xFFFFFFFF << (32 - $mask_len) & 0xFFFFFFFF;
    return long2ip($mask);
}

//--------------------------
// 前置方法校验工具
//--------------------------
// （前置方法中）用与是否登录
function IsLogin(){
    $user = session('user_auth');
    if(empty($user)){
        return 0;
    }else{
        return session('user_auth_sign') == AuthSign($user) ? $user['username'] : 0;
    }
}
//（前置方法中）是否存在网管限制
function CheckAccess(){
    $count = Db::table('user_pass')->count();
    if($count === 0){
        return true;
    }

    $client_ip = $_SERVER['REMOTE_ADDR'];
    $result = db('user_pass')->where('ip_mac', $client_ip)->select();
    if(empty($result)){
        return false;
    }
    return true;
}
//（前置方法中）登陆或token验证
function CheckLoginToken(){
    $user_auth = session('user_auth');
    $user_token = input('get.token');
    if(!is_null($user_auth) && (session('user_auth_sign') == AuthSign($user_auth)) ){ //登录状态中
        return true;
    }
    if(empty($user_token) && $user_token !== '0'){ // 无token
        return false;
    }

    $result = Db::table('user')->where('token', $user_token)->select();
    return empty($result) ? false : true;
}
//（前置方法中）证书合格验证
function CheckValid(){ 
    $licenceInfo = \app\index\repository\LicenseRepository::getLicenceInfo();
    if($licenceInfo["type"] === "official"){
        return '0';
    }
    
    if($licenceInfo["status"] != "valid") {
        return "12020";
    }else{
        return '0';
    }
}

//--------------------------
// 返回状态码工具
//--------------------------
/**
 * 接口返回成功方法
 * @param  String|Array    $data  返回数据 (参数不传或传null或为空数组，不显示返回值，若为数组则键值为key，其他数据类型默认key为data)
 * @param  String    $code  状态码默认0为请求成功
 * @return String    json
 */
function Finalsuccess($data=NULL, $code="0"){
    $jsonData = ['errcode' => intval($code), 'errmsg' => 'ok'];
    if(is_null($data)){
    }else if(is_array($data) && empty($data)){
        $jsonData = ['errcode' => 0, 'errmsg' => 'ok'];
    }else if(is_array($data)){
        foreach ($data as $name => $value) {
            $jsonData[$name] = $value;
        }
    }else{
        $jsonData = ['errcode' => 0, 'errmsg' => 'ok', 'data' => $data];
    }
    config('return_info', $jsonData);
    return json($jsonData);    
}
/**
 * 接口返回失败方法
 * @param  String    $code  状态码 （若为10001|miss，则解析为状态码+错误信息）
 * @param  String    $errorMessage  错误信息
 * @param  Array     $additionResults  追加data数据 
 * @return Object    json对象
 */
function Finalfail($code, $errorMessage='', array $additionResults=[]){
    $tmp = explode("|", $code);
    if(count($tmp) == 2){
        $code = $tmp[0];
        $errorMessage = $tmp[1];
    }
    
    $jsonData = ['errcode' => intval($code), 'errmsg'=>$errorMessage];
    if(!empty($additionResults)){
        foreach ($additionResults as $name => $value) {
            $jsonData[$name] = $value;
        }
    }
    return json($jsonData);
}
/**
 * 接口失败
 * @param  String    $code  状态码 （若为10001|miss，则解析为状态码+错误信息）
 * @param  String    $errorMessage  错误信息
 * @param  Array     $additionResults  追加data数据 
 * @return String    json字符串
 */
function Error($code, $errorMessage='', array $additionResults=[]){
    $tmp = explode("|", $code);
    if(count($tmp) == 2){
        $code = $tmp[0];
        $errorMessage = $tmp[1];
    }

    $jsonData = ['errcode' => intval($code), 'errmsg'=>$errorMessage];
    if(!empty($additionResults)){
        foreach ($additionResults as $name => $value) {
            $jsonData[$name] = $value;
        }
    }

    header("Content-Type: application/json");
    die(json_encode($jsonData));
}

//--------------------------
// 底层交互工具
//--------------------------
// 执行exec
function ExcuteExec($order){
    $output=[];
    $status=[];
    exec($order,$output,$status);
    if($status!=0){
        Error('20002','error: '.$order);
    }
}
/**
 * 将配置信息写入共享内存
 * @param String $config
 * @return Boolean
 */
function WriteInShm($config){
    exec("fpcmd clear_mimic_shm");

    $shm_key = ftok("/web", "2");
    $shm_id = shmop_open($shm_key, 'c', 0644, 16*1024*1024);
    if (!$shm_id) {
        return false;
    }

    $shm_bytes_written = shmop_write($shm_id, $config, 0);
    if (!$shm_bytes_written) {
        return false;
    }

    shmop_close($shm_id);
    return true;
}

//--------------------------
// 数组处理工具
//--------------------------
// 数组按键排序
function ArrKeySort($arr, $rules = []) {
    if (empty($rules)) {
        array_multisort($arr);
        return $arr;
    }
    if (empty($arr)) {
        return [];
    }
    foreach ($arr as $k => $a) {
        foreach ($rules as $rk => $rule) {
            $orderby[$rk][$k] = $a[$rule['orderby']];
            $order[$rk] = $rule['order'] == 'desc' ? SORT_DESC : SORT_ASC;
            $order_flag[$rk] = isset($rule['order_flag']) ? $rule['order_flag'] : SORT_REGULAR;
        }
    }
    foreach ($rules as $rk => $rule) {
        $params[] = $orderby[$rk];
        $params[] = $order[$rk];
        $params[] = $order_flag[$rk];
    }
    $params[] = &$arr;
    array_multisort(...$params);
    return $arr;
}
// 数组分页
function ArrPage($arr, $page, $row) {
    $arr = array_slice($arr, ($page - 1) * $row, $row);
    return $arr;
}
// 数组关键字查找
function ArrKeyFilter($arr, $filter = []) {
    if (empty($filter)) {
        return $arr;
    }
    $arr = array_filter($arr, function ($item) use ($filter) {
        foreach ($item as $k => $v) {
            if (isset($filter[$k])) {
                switch ($filter[$k]['type']) {
                    case 'str':
                        if (!strstr($v, $filter[$k]['value'])) {
                            return false;
                        }
                        break;
                    case 'int':
                        if ($v != $filter[$k]['value']) {
                            return false;
                        }
                        break;
                    case 'time':
                        if (isset($filter[$k]['start']) && $filter[$k]['start'] > $v) {
                            return false;
                        }
                        if (isset($filter[$k]['end']) && $filter[$k]['end'] < $v) {
                            return false;
                        }
                        break;
                }
            }
        }
        return true;
    });
    return $arr;
}
function MultisortArr($arr){
	$sort = array(  
        'direction' => 'SORT_ASC',
        'field'     => 'groupid',
	);  
	$arrSort = array();  
	foreach($arr AS $uniqid => $row){  
		foreach($row AS $key=>$value){  
			$arrSort[$key][$uniqid] = $value;  
		}  
	}  
	if($sort['direction']){  
		array_multisort($arrSort[$sort['field']], constant($sort['direction']), $arr);  
	}  
	  
	return $arr;  
}

//--------------------------
// 公共方法
//--------------------------
// 主机备注列表（所有）
function MacInfo() {
    $mac_info = Db::table('mac_info')->field('mac,description')->select();
    $macinfo_map = [];
    foreach ($mac_info as $val) {
        $macinfo_map[FormatMac($val['mac'])] = $val['description'];
    }
    return $macinfo_map;
}

// 封堵列表（所有）
function BlockInfo() {
    exec("fpcmd block_list -s", $block_str);
    if (empty($block_str[0])) {
        return [];
    }
    $block_str = trim($block_str[0], "|\n");
    $blockstat = explode('|', $block_str);
    $blockstat = array_map(function ($info) {
        $info = explode(' ', $info);
        return [
            'source' => $info[0],
            'timestamp' => $info[1]
        ];
    }, $blockstat);
    return $blockstat;
}
// 获取网口信息
function GetEthChart() {
	$chart = [];
	$chart_mgt = [];
	$chart_lan = [];
	$chart_wan = [];
	
	exec('fpcmd set_eth_info -s',$config);
	$config = trim($config[0],"|");
	foreach(explode('|',$config) as $record) {                                                                                                                                                                                                                                        
		$params = explode(' ',$record);
		switch(substr($params[2],0,3)) {
			case "MGT":
				$chart_mgt[] = ['eth'=>$params[0],'groupid'=>$params[1],'desc'=>$params[2]];
				break;
			case "LAN":
				$chart_lan[] = ['eth'=>$params[0],'groupid'=>$params[1],'desc'=>$params[2]];
				break;
			case "WAN":
				$chart_wan[] = ['eth'=>$params[0],'groupid'=>$params[1],'desc'=>$params[2]];
				break;
		}
	}
	foreach($chart_mgt as $mgt) {
		$chart[] = $mgt;
	}
	$chart_lan = MultisortArr($chart_lan);
    $chart_wan = MultisortArr($chart_wan);
	
	for($i = 0; $i < max(count($chart_lan),count($chart_wan)); $i++) {
		if(isset($chart_lan[$i])) {
			$chart[] = $chart_lan[$i];
		}
		if(isset($chart_wan[$i])) {
			$chart[] = $chart_wan[$i];
		}
	}
	return $chart;
}

//--------------------------
// 日志解析
//--------------------------
// 解析操作日志
function TranslateLog($log) {
    $log_ch_map = [
        'type' => [
            '11' => '防火墙规则',
            '12' => '蜜罐主机',
            '13' => '主机备注',
            '14' => '黑名单',
            '15' => '白名单',
            '16' => '准入主机',
            '17' => '全息伪装策略',
            '18' => '端口虚开策略',
            '19' => '端口虚开白名单',
            '110'=> '应用访问策略',
            '21' => 'WEBUI超时时间',
            '22' => '登录惩罚时间',
            '23' => '最大错误登录次数',
            '24' => '集中管理配置',
            '25' => '系统时间',
            '26' => '网管策略',
            '27' => '日志服务器',
            '28' => '关机',
            '29' => '重启',
            '210'=> '系统配置',
            '211'=> '恢复出厂配置',
            '212'=> '系统版本',
            '30' => '全局配置',
            '31' => 'DHCP开关',
            '32' => 'DNS服务器',
            '33' => 'DHCP租期',
            '34' => '主机信息表有效时间',
            '35' => '真实IP访问开关',
            '36' => '主机自动封堵开关',
            '37' => '虚拟变换间隔时间',
            '38' => '管理口IP',
            '39' => '真实IP网段',
            '310' => '真实IP保留网段',
            '311' => '虚拟IP网段',
            '312' => '虚拟IP保留网段',
            '313' => '外网IP网段',
            '314' => '外网IP保留网段',
            '315' => '虚拟网络网段',
            '316' => '虚拟网络保留网段',
            '317' => '虚假响应OS比例',
            '318' => '虚假响应端口概率',
            '319' => '虚假响应Linux端口',
            '320' => '虚假响应Windows端口',
            '321' => '虚假响应Server端口',
            '322' => '虚假响应MAC标识',
            '323' => '静态地址',
            '324' => '静态路由',
            '325' => '主机透传',
            '328' => '主机准入开关',
            '329' => '软件bypass',
            '330' => '高可靠性',
            '331' => '虚假响应配置',
            '41'  => '用户',
            '42'  => '密码',
            '51'  => '授权文件'
        ],
        'subtype' => [
            '1' => '添加',
            '2' => '删除',
            '3' => '更新',
            '4' => '导出',
            '5' => '导入',
            '6' => '执行',
            '7' => '升级'
        ],
    ];

    // 对日志内容进行转化
    if (isset($log_ch_map['subtype'][$log['subtype']], $log_ch_map['type'][$log['type']])) {
        $log['content'] = $log_ch_map['subtype'][$log['subtype']].'【'.$log_ch_map['type'][$log['type']].'】';
    }

    return $log;
}
// 解析事件日志
function TranslateEventLog($log_arr) {
    $log_type = [
        '1' => '网口接入',
        '2' => '网口断开',
        '3' => '登录成功',
        '4' => '用户注销',
        '5' => '系统初始化',
        '6' => '系统启动',
        '7' => '中心连接',
        '8' => '登陆失败',
        '9' => '中心断开',
        '10'=> '登录超限',
    ];
    foreach($log_arr as &$log){
        switch($log['type']){
            case 1:
            case 2:
                $log['content'] = $log['content'].$log_type[$log['type']];  
            break;

            case 3:
            case 4:
            case 8:
                $log['content'] = '用户名：'.explode("|", $log['content'])[0]."，IP：".explode("|", $log['content'])[1];
            break;

            default:
                $log['content'] = $log_type[$log['type']];
            break;
        }
    }
    return $log_arr;
}

//--------------------------
// 其他方法
//--------------------------
/**
 * trim配置参数中的空格等
 * @param  String    $param  "0|80|100|210|1,2"
 * @return Array    
 */
function TrimParams(String $param){
    $conf_arr = array_map(function($item){
        return trim($item);
    },explode("|", $param));
    return $conf_arr;
}
// 上传excel文件
function UploadExcel(){
    $public_path = ROOT_PATH . 'public' . DS . 'uploads';

    $file = request()->file('file');
    if(is_null($file))
        Error('10020', 'file null');

    $info = $file->validate(['ext'=>'xls,xlsx'])->move($public_path);
    if(!$info){
        Error('12023');
    }
    return $info->getPathName();
}
// 记录操作日志
function RecordOperLog($log_type, $log_subtype, $log_content=""){
    $log = [
        "uid"    =>  session('user_auth.u_id'),
        "type"   =>  $log_type,
        "subtype"=>  $log_subtype,
        "clientip"=> GetClientIp(),
        "content" => $log_content,
        "result" => 1,
        "time"   =>  date('Y-m-d H:i:s', time())
    ];
    $redis = new \Redis();
    $redis->pconnect('127.0.0.1');
    $redis->rPush('oper_log_list', json_encode($log));
}

/**
 * post方法发送https请求
 * @param  string $url 请求url
 * @param  string $data
 * @return array     返回结果数组
 */
function PostContent($url, $data)
{
    $context_options = [
        "ssl"  => [
            "verify_peer"      => false,
            "verify_peer_name" => false,
        ],
        'http' => [
            'method'  => 'POST', // post
            'header'  => "Content-type: application/json\r\n" //json
                . "Content-Length: " . strlen($data) . "\r\n",
            'content' => $data
        ]
    ];

    try {
        $result = file_get_contents($url, false, stream_context_create($context_options));
    } catch (Exception $e) {
        return false;
    }
    if (!$result) {
        return false;
    }
    $data_arr = json_decode($result, true);

    return $data_arr;
}

// 配置更新同步更新时间戳
function SyncTimestampUpdate()
{
    file_put_contents("/hard_disk/ha/message.json", json_encode(["synTimestamp" => strtotime('now')]));
}

function FormatMac($string)
{
    return filter_var($string, FILTER_VALIDATE_MAC) ? strtolower($string) : $string;
}

if (!function_exists('decrypt')) {
    /**
     * 解密幻势集中管理平台传递的加密参数
     *
     * @param $data
     * @return string
     * @throws \app\common\exception\DecryptException
     */
    function decrypt($data)
    {
        return (new \app\index\tools\HSEncrypt())->decrypt($data);
    }
}

/**
 * 二维数组按指定列去重，排序靠后的替换排序靠前的
 * @param   array $array 第一维为索引数组
 * @param   string $col
 * @return  array   返回结果数组
 */
function ArrayDistinctByKey($array, $col)
{
    $tmpArr = [];
    foreach ($array as $arr) {
        $tmpArr[$arr[$col]] = $arr;
    }

    return array_values($tmpArr);

}

if (!function_exists('array_get')) {
    /**
     * @param array $array
     * @param $key
     * @param null $default
     * @return array|mixed|null
     */
    function array_get($array = [], $key, $default = null)
    {
        $keys = explode('.', $key);

        foreach ($keys as $key) {
            if (array_key_exists($key, $array)) {
                $array = $array[$key];
            } else {
                return $default;
            }
        }

        return $array;
    }
}

if (!function_exists('sendMetricLog')) {
    /**
     * 发送Metric 日志
     * @param $log
     * @param $type
     */
    function sendMetricLog($log, $type)
    {
        $redis = new Redis();
        $redis->pconnect('127.0.0.1');
        $redis->rPush($type, json_encode($log));
    }

}
