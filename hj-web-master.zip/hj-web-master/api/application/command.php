<?php

return [
    'app\index\command\Metrics',
    'app\index\command\Reload'
];
