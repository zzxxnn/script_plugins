<?php

use think\Route;

// 所有路由绑定到index控制器
Route::bind('index');

// 暴漏给幻势集中管理平台的API
Route::group('api', function () {
    // 对主机进行封堵
    Route::post('host/block', 'Api/hostBlock');
    // 对主机进行解封
    Route::post('host/unblock', 'Api/hostUnBlock');
    // 获取设备授权信息
    Route::post('get-license', 'Api/getLicence');
    // 设备重启
    Route::post('reboot', 'Api/reboot');
    // 设备关机
    Route::post('poweroff', 'Api/powerOff');
    // 封堵列表
    Route::post('block-list', 'Api/hostBlockList');
    // 设备状态
    Route::post('status', 'Api/status');
});

// SSO
Route::group('sso', function () {
    Route::get('hs', 'SSO/hs');
});

// 引入Sys Conf路由
require APP_PATH . 'index/route/sys-conf.php';

// 前端页面路由
return [
    //控制器路由别名
    '__alias__' => [
        'session'  => 'index/Login',
        'license'  => 'index/License',
        'stats'    => 'index/Stats',
        'logs'     => 'index/Logs',
        'sysconf'  => 'index/Sysconf',
        'netmgmt'  => 'index/Netmgmt',
        'usermgmt' => 'index/Usermgmt',
        'safe'     => 'index/Safepolicy',
        'utils'    => 'index/Utils',
        'sync'     => 'index/Sync'
    ],
    '__miss__'  => 'index/Index/index'
];
