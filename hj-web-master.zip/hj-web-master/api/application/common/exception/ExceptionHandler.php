<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/7/31
 * Time: 10:44
 */

namespace app\common\exception;


use app\index\tools\CustomerLogger;
use Exception;
use think\exception\Handle;

class ExceptionHandler extends Handle
{

    public function render(Exception $e)
    {
        //TODO::开发者对异常的操作

        // 错误日志记录
        $this->errorHandle($e);

        //可以在此交由系统处理
        return parent::render($e);
    }

    private function errorHandle(\Exception $e)
    {
        $log = ['file' => $e->getFile(), 'code' => $e->getCode(), 'msg' => $e->getMessage(), 'line' => $e->getLine()];
        (new CustomerLogger())->log($log);
    }

}