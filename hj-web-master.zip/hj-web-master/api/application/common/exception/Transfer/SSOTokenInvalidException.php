<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/6/14
 * Time: 11:26
 */

class SSOTokenInvalidException extends \Exception
{
    protected $code = 403;

    protected $message = 'SSO token invalid.';
}