<?php namespace app\common\exception;
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/6/8
 * Time: 14:31
 */

class DecryptException extends \Exception
{

}