<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/6/8
 * Time: 16:15
 */

namespace app\common\exception;


class PermissionDenyException extends \Exception
{
    protected $code = 403;

    protected $message = 'Permission Deny!';
}