<?php
namespace app\index\stats;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;
use think\Db;

class Network extends Controller {
    protected $redis;
    protected $time_now;

    public function _initialize(){
        $this->redis = new \Redis();
        $this->redis->pconnect('127.0.0.1');
        $this->time_now = time();
    }
    //【方法】获取实时主机数
    public function RealHostCount() {
        $stats = $this->redis->hGet('dev_stat', 'host_count');
        return $stats;
    }
    //【方法】获取实时总连接数
    public function RealHostConnects() {
        $stats = $this->redis->hGet('dev_stat', 'total_connects');
        return $stats;
    }
    //【方法】获取虚拟主机个数（安全域）
    public function VirtualHosts() {
        exec('fpcmd get_virtual_hosts -s', $vhosts);
        $vhosts = trim($vhosts[0],"|\n");
        $vhosts = explode('|', $vhosts);
        $stats = [];
        foreach ($vhosts as $h) {
            $h = explode(' ', $h);
            $stats[$h[0]] = $h[1];
        }
        return $stats;
    }
    //【方法】获取实时主机状态
    public function RealHostStats($orderby, $order, $page, $row, $search = []) {
        $stats = $this->redis->get('hosts_stat_col');
        $stats = json_decode($stats, true);
        if (empty($stats)) {
            return ['count'=>0, 'stats'=>[]];
        }
        $stats = array_values($stats);
        $stats = array_map(function($stat) {
            $stat['speed'] = $stat['up_speed'] + $stat['down_speed'];
            return $stat;
        }, $stats);
        $mac_info = MacInfo();
        $block_info = BlockInfo();
        $block_info = array_map(function ($block) {
            return $block['source'];
        }, $block_info);
        $stats = array_map(function ($stat) use ($mac_info,$block_info) {
            $stat['desc'] = isset($mac_info[$stat['mac']]) ? $mac_info[$stat['mac']] : '';
            $stat['is_block'] = in_array($stat['mac'], $block_info) ? 1 : 0;
            return $stat;
        }, $stats);
        if (empty($orderby)) {
            $orderby = 'connects';
        }
        if (empty($order)) {
            $order = 'desc';
        }
        if (empty($page)) {
            $page = 1;
        }
        if (empty($row)) {
            $row = 1;
        }
        $filter = [];
        if (isset($search['mac']) && !empty($search['mac'])) {
            $filter['mac'] = ['type'=>'str','value'=>$search['mac']];
        }
        if (isset($search['desc']) && !empty($search['desc'])) {
            $filter['desc'] = ['type'=>'str','value'=>$search['desc']];
        }
        if (isset($search['rip']) && !empty($search['rip'])) {
            $filter['rip'] = ['type'=>'str','value'=>$search['rip']];
        }
        if (isset($search['vip']) && !empty($search['vip'])) {
            $filter['vip'] = ['type'=>'str','value'=>$search['vip']];
        }
        if (isset($search['wip']) && !empty($search['wip'])) {
            $filter['wip'] = ['type'=>'str','value'=>$search['wip']];
        }
        if (isset($search['name']) && !empty($search['name'])) {
            $filter['name'] = ['type'=>'str','value'=>$search['name']];
        }
        if (isset($search['groupid']) && !empty($search['groupid'])) {
            $filter['groupid'] = ['type'=>'int','value'=>$search['groupid']];
        }
        if (isset($search['vlanid']) && !empty($search['vlanid'])) {
            $filter['vlanid'] = ['type'=>'int','value'=>$search['vlanid']];
        }
        if (isset($search['is_block']) && !empty($search['is_block'])) {
            $filter['is_block'] = ['type'=>'int','value'=>$search['is_block']];
        }
        if (isset($search['start_time']) && !empty($search['start_time'])) {
            $filter['time']['type'] = 'time';
            $filter['time']['start'] = $search['start_time'];
        }
        if (isset($search['end_time']) && !empty($search['end_time'])) {
            $filter['time']['type'] = 'time';
            $filter['time']['end'] = $search['end_time'];
        }
        $stats = ArrKeySort($stats, [['orderby'=>$orderby, 'order'=>$order]]);
        $stats = ArrKeyFilter($stats, $filter);
        $count = count($stats);
        $stats = ArrPage($stats, $page, $row);
        return ['count'=>$count, 'stats'=>$stats];
    }
    // 【方法】获取封堵列表
    public function BlockList($orderby, $order, $page, $row, $search = []) {
        if (empty($orderby)) {
            $orderby = 'timestamp';
        }
        if (empty($order)) {
            $order = 'desc';
        }
        if (empty($page)) {
            $page = 1;
        }
        if (empty($row)) {
            $row = 1;
        }
        $filter = [];
        if (isset($search['source']) && !empty($search['source'])) {
            $filter['source'] = ['type'=>'str','value'=>$search['source']];
        }
        if (isset($search['desc']) && !empty($search['desc'])) {
            $filter['desc'] = ['type'=>'str','value'=>$search['desc']];
        }
        if (isset($search['start_time']) && !empty($search['start_time'])) {
            $filter['timestamp']['type'] = 'time';
            $filter['timestamp']['start'] = $search['start_time'];
        }
        if (isset($search['end_time']) && !empty($search['end_time'])) {
            $filter['timestamp']['type'] = 'time';
            $filter['timestamp']['end'] = $search['end_time'];
        }
        $mac_info = MacInfo();
        $blockstat = BlockInfo();
        $blockstat = array_map(function ($stat) use ($mac_info) {
            return [
                'source' => $stat['source'],
                'desc' => isset($mac_info[$stat['source']]) ? $mac_info[$stat['source']] : '',
                'timestamp' => $stat['timestamp']
            ];
        }, $blockstat);
        $count = count($blockstat);
        $blockstat = ArrKeySort($blockstat, [['orderby'=>$orderby, 'order'=>$order]]);
        $blockstat = ArrKeyFilter($blockstat, $filter);
        $blockstat = ArrPage($blockstat, $page, $row);
        return ['count'=>$count,'stats'=>$blockstat];
    }
    // 【方法】获取最近15分钟主机数
    public function RecentHostCount() {
        $time_range = $this->RecentTimeRange();
        $recentHostcountStats = Db::table('hostcount_10')->where(['time'=>['IN',$time_range]])->select();
        $recentHostcountStats = array_map(function($log) {
            return [
                'value' => ['count'=>$log['count']],
                'timestamp' => strtotime($log["time"])
            ];
        }, $recentHostcountStats);
        return $recentHostcountStats;
    }
    // 【方法】攻击状态
    public function AttackStats() {
        $attack_count = Db::table('attack_log_stat')->sum('count');
        $attack_time = Db::table('attack_log_stat')->order('end_time desc')->find();
        if (!empty($attack_time)) {
            $attack_time = strtotime($attack_time['end_time']);
        } else {
            $attack_time = 0;
        }
        $u_id = session('user_auth.u_id');
        if (empty($u_id)) {
            $check_time = 0;
        } else {
            $check_time = Db::table('attack_log_check')->where(['u_id'=>$u_id])->find();
            $check_time = !empty($check_time) ? strtotime($check_time['check_time']) : 0;
        }
        return ['attack_count'=>$attack_count,'attack_time'=>$attack_time,'check_time'=>$check_time];
    }
    // 【方法】最近攻击记录
    public function RecentAttackLogs($recent) {
        if (!empty($recent)) {
            $recent = intval($recent);
        } else {
            $recent = 10;
        }
        $subsql = Db::table('attack_log_stat')
            ->field('attack_source,max(end_time) as end_time')
            ->group('attack_source')
            ->buildSql();
        $blockstat = BlockInfo();
        $blockstat = array_map(function($item) {
            return "'".$item['source']."'";
        }, $blockstat);
        $blockstat = empty($blockstat) ? ["'"."'"] : $blockstat;
        $blockstat = '('.implode(',', $blockstat).')';
        $logs = Db::table('attack_log_stat')
            ->alias('a')
            ->join([$subsql => 'b'], 'a.attack_source=b.attack_source and a.end_time=b.end_time', 'RIGHT')
            ->join('mac_info m', 'a.attack_source=m.mac', 'LEFT')
            ->field('a.attack_source,m.description,a.attack_type,a.count,a.groupid,a.start_time,CASE WHEN a.attack_source IN '.$blockstat.' THEN 1 ELSE 0 END as is_block,a.end_time')
            ->group('a.attack_source')
            ->order('a.end_time desc,a.attack_source')
            ->limit($recent)
            ->select();
            
        $logs = array_map(function ($item) {
            $item['attack_source'] = FormatMac($item['attack_source']);
            return $item;
        }, $logs);
        return $logs;
    }
    // 【方法】最近15分钟时间段计算
    public function RecentTimeRange() {
        $time_end = floor($this->time_now / 10) * 10;
        $time_start = $cursor = $time_end - 15 * 60;

        $time_range = [];
        while ($cursor <= $time_end) {
            $time_range[] = date('Y-m-d H:i:s', $cursor);
            $cursor += 10;
        }

        return $time_range;
    }
    // 【方法】删除在线节点记录
    public function delHostStats(){
        $macs = input('post.10', null);
        if(is_null($macs)){
            return ;
        }

        $macs_arr = explode(",", $macs);
        $macs_arr = array_filter($macs_arr, function($item){
            return CheckMac($item);
        });

        if(empty($macs_arr)){
            return ;
        }

        $stamp = 80;
        $macs_arr_page = ceil(count($macs_arr)/$stamp);
        for($i = 0; $i < $macs_arr_page; $i++){
            $start=($i-1)*$stamp;
            $items = array_slice($macs_arr, $start, $stamp);
            ExcuteExec("uroot fpcmd host_status -d ".implode(" ", $items));
        }

    }
}