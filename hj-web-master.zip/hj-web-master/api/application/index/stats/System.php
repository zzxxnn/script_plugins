<?php
namespace app\index\stats;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;
use think\Db;

class System extends Controller {
    protected $redis;
    protected $time_now;

    public function _initialize(){
        $this->redis = new \Redis();
        $this->redis->pconnect('127.0.0.1');
        $this->time_now = time();
    }
    //【方法】获取系统版本信息
    public function SysVersion() {
        exec('cat /etc/version', $sysinfo);
        $sysinfo = trim($sysinfo[0]);
        $sysinfo = preg_split("/\s+/", $sysinfo);
        return "ME_".$sysinfo[0].".".$sysinfo[3].".".explode('_', str_replace('-','',$sysinfo[1]))[0].".".substr($sysinfo[2], 0, 4);
    }
    //【方法】获取开机运行时间
    public function UpTime() {
        $stats = $this->redis->info();
        return $stats['uptime_in_seconds'];
    }
    //【方法】获取cpu实时状态
    public function RealCPUStats(){
        $stats = $this->redis->hGet('dev_stat', 'cpu');
        $stats = json_decode($stats, true);
        return $stats;
    }
    //【方法】获取内存状态
    public function RealRAMStats() {
        $stats = $this->redis->hGet('dev_stat', 'memory');
        $stats = json_decode($stats, true);
        return $stats;
    }
    //【方法】获取硬盘状态
    public function RealHDStats(){
        $stats = $this->redis->hGet('dev_stat', 'disk');
        $stats = json_decode($stats, true);
        return $stats;
    }
    //【方法】最近事件日志
    public function RecentEventLogs($recent) {
        if (!empty($recent)) {
            $recent = intval($recent);
        } else {
            $recent = 8;
        }
        $logs = Db::table('event_log')
            ->field('CASE type WHEN 10 THEN 3 WHEN 8 or 9 THEN 2 ELSE 1 END as level,type,content,time')
            ->order('time desc')
            ->limit($recent)
            ->select();
            
        $logs = TranslateEventLog($logs);
        return $logs;
    }
    //【方法】获取cpu最近15分钟状态
    public function RecentCPUStats(){
        $time_range = $this->RecentTimeRange();
        $recentCpuStats = Db::table('cpu_10')->where(['time'=>['IN',$time_range]])->select();
        $recentCpuStats = array_map(function($log) {
            return [
                'value' => ['user'=>$log['user'],'system'=>$log['system'],'idle'=>$log['idle']],
                'timestamp' => strtotime($log["time"])
            ];
        }, $recentCpuStats);
        return $recentCpuStats;
    }
    //【方法】获取最近15分钟内存状态
    public function RecentRAMStats() {
        $time_range = $this->RecentTimeRange();
        $recentRAMStats = Db::table('memory_10')->where(['time'=>['IN',$time_range]])->select();
        $recentRAMStats = array_map(function($log) {
            return [
                'value' => ['total'=>$log['total'],'used'=>$log['used']],
                'timestamp' => strtotime($log["time"])
            ];
        }, $recentRAMStats);
        return  $recentRAMStats;
    }
    //【方法】获取最近15分钟硬盘状态
    public function RecentHDStats(){
        $time_range = $this->RecentTimeRange();
        $recentHDStats = Db::table('disk_10')->where(['time'=>['IN',$time_range]])->select();
        $recentHDStats = array_map(function($log) {
            return [
                'value' => ['total'=>$log['total'],'used'=>$log['used']],
                'timestamp' => strtotime($log["time"])
            ];
        }, $recentHDStats);
        return  $recentHDStats;
    }
    //【方法】网卡信息
    public function EthStats($orderby, $order) {
        if (empty($orderby)) {
            $orderby = 'desc_no';
        }
        if (empty($order)) {
            $order = 'asc';
        }
        $stats = $this->redis->hGetAll('interface_stat');
        $stats = array_values($stats);
        $stats = array_map(function($stat) {
            $stat = json_decode($stat, true);
            return [
                'desc'=>$stat['desc'],
                'desc_no'=>$stat['desc_no'],
                'up'=>$stat['up'],
                'name'=>$stat['name'],
                'macaddr'=>FormatMac($stat['macaddr']),
                'in_bytes'=>$stat['in']['bytes'],
                'in_dropped'=>$stat['in']['dropped'],
                'in_errors'=>$stat['in']['errors'],
                'in_packets'=>$stat['in']['packets'],
                'in_Bps'=>$stat['in']['Bps'],
                'out_bytes'=>$stat['out']['bytes'],
                'out_dropped'=>$stat['out']['dropped'],
                'out_errors'=>$stat['out']['errors'],
                'out_packets'=>$stat['out']['packets'],
                'out_Bps'=>$stat['out']['Bps'],
                'timestamp'=>$stat['time']
            ];
        }, $stats);
        $stats = ArrKeySort($stats, [['orderby'=>$orderby, 'order'=>$order]]);
        return $stats;
    }
    // 【方法】最近15分钟时间段计算
    public function RecentTimeRange() {
        $time_end = floor($this->time_now / 10) * 10;
        $time_start = $cursor = $time_end - 15 * 60;

        $time_range = [];
        while ($cursor <= $time_end) {
            $time_range[] = date('Y-m-d H:i:s', $cursor);
            $cursor += 10;
        }

        return $time_range;
    }
}