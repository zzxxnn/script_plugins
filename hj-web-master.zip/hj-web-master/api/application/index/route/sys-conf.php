<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/7/31
 * Time: 14:19
 */

use think\Route;

Route::group('sys-conf', function () {
    Route::get('sntp-conf', 'index/Sysconf/getSntpConf');
    Route::post('sntp-conf', 'index/Sysconf/updateSntpConf');
});