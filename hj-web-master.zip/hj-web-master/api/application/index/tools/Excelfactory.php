<?php
namespace app\index\tools;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;

/**
 * 构建excel下载、解析excel数据
 */
class Excelfactory extends Controller {

    public function _initialize(){
        vendor("phpoffice.phpexcel.Classes.PHPExcel");
    }

    /**
     * 解析导入excel
     * @param $path   上传的excel文件路径
     */
    public function praseExcel($path){
        $excelType = \PHPExcel_IOFactory::identify($path);
        $objReader = \PHPExcel_IOFactory::createReader($excelType);
        $objReader->setReadDataOnly(true);
        $objPHPExcel = $objReader->load($path);

        $activeSheet = $objPHPExcel->getActiveSheet(0);
        $highestColumn = $activeSheet->getHighestColumn();
        $highestRow = $activeSheet->getHighestRow();
        $highestColumnIndex = \PHPExcel_Cell::columnIndexFromString($highestColumn);

        $datas = [];
        for($row = 1; $row <= $highestRow; $row++){
            for($col = 0; $col < $highestColumnIndex; $col++){
                $datas[$row][] = $activeSheet->getCellByColumnAndRow($col, $row)->getValue();
            }
        }
        return $datas;
    }

    /**
     * 导出excel
     * @param $report_type 导出表类型
     * @param $content 日志数据
     */
    public function exportExcel($report_type, $content){
        switch($report_type){
            case 'bind_ip':
                $sheet_title = "静态地址";
                $filename = "静态地址配置".date("Y_m_d H_i_s", strtotime('now'));
                break;
            case 'mac_through':
                $sheet_title = "主机透传";
                $filename = "主机透传配置".date("Y_m_d H_i_s", strtotime('now'));
                break;
            case 'mac_info':
                $sheet_title = "主机备注";
                $filename = "主机备注配置".date("Y_m_d H_i_s", strtotime('now'));
                break;
            case 'mac_allow':
                $sheet_title = "主机准入";
                $filename = "主机准入配置".date("Y_m_d H_i_s", strtotime('now'));
                break;
            default:
                $sheet_title = "VEDA";
                $filename = date("Y_m_d H_i_s", strtotime('now'));
                break;
        }

        $objPHPExcel = $this->_loadPhpExcel();
        $this->_setExcelProperty($objPHPExcel);
        $this->_writeInExcel($objPHPExcel, $report_type, $content, $sheet=0, $sheet_title);
        $this->_saveExcel($objPHPExcel, $filename);
    }
    
    // 引入phpexcel类
    private function _loadPhpExcel(){
        $objPHPExcel = new \PHPExcel();
        return $objPHPExcel;
    }

    // 设置excel属性
    private function _setExcelProperty($objPHPExcel){
        // 创建人
        $objPHPExcel->getProperties()->setCreator("vedasec");
        // 最后修改人
        $objPHPExcel->getProperties()->setLastModifiedBy("vedasec");
    }

    // 写入内容
    private function _writeInExcel($objPHPExcel, $report_type, $content, $sheet, $sheet_title){
        // 设置当前的sheet
        $objPHPExcel->setActiveSheetIndex($sheet);
        // 设置sheet的name
        $objPHPExcel->getActiveSheet()->setTitle($sheet_title);
        // 设置单元格的值
        switch($report_type){
            case 'bind_ip':
                $this->_structBindIp($objPHPExcel, $content);
                break;
            case 'mac_through':
                $this->_structMacThrough($objPHPExcel, $content);
                break;
            case 'mac_info':
                $this->_structMacInfo($objPHPExcel, $content);
                break;
            case 'mac_allow':
                $this->_structMacAccess($objPHPExcel, $content);
                break;
            default:
                #...
                break;
        }
    }

    // 保存文件
    private function _saveExcel($objPHPExcel, $filename){
        // 清除缓冲区,避免乱码
        ob_end_clean(); 

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="'.$filename.'.xlsx"');
        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');
        // If you're serving to IE over SSL, then the following may be needed
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Last-Modified: ' . gmdate('D, d M Y H_i_s') . ' GMT'); // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0

        //设置保存版本格式
        $objWriter = new \PHPExcel_Writer_Excel2007($objPHPExcel);// xlsx
        $objWriter->save('php://output');
        exit; //必须 终止
    }

    
    // 静态地址格式解析
    private function _structBindIp($objPHPExcel, $datas){
        // 取可用sheet
        $activeSheet = $objPHPExcel->getActiveSheet();
        // 确定列数
        $columns = ["A","B"];
        // 所有单元格默认高度
        $activeSheet->getDefaultRowDimension()->setRowHeight(15);
        // 内容样式
        foreach(["A","B"] as $b){
            $activeSheet->getColumnDimension($b)->setWidth(20); // 设置宽width
            $activeSheet->getStyle($b)->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            $activeSheet->getStyle($b)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        }
        foreach($datas as $num => $h){
            $activeSheet->setCellValue("A".($num+1), $h['ip']);
            $activeSheet->setCellValue("B".($num+1), $h['mac']);
        }
    }

    // 主机透传格式解析
    private function _structMacThrough($objPHPExcel, $datas){
        // 取可用sheet
        $activeSheet = $objPHPExcel->getActiveSheet();
        // 确定列数
        $columns = ["A","B","C","D"];
        // 所有单元格默认高度
        $activeSheet->getDefaultRowDimension()->setRowHeight(15);
        // 内容样式
        foreach(["A","B","C","D"] as $b){
            $activeSheet->getColumnDimension($b)->setWidth(20); // 设置宽width
            $activeSheet->getStyle($b)->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            $activeSheet->getStyle($b)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        }
        foreach($datas as $num => $h){
            $activeSheet->setCellValue("A".($num+1), $h['mac']);
            $activeSheet->setCellValue("B".($num+1), $h['ip']);
            $activeSheet->setCellValue("C".($num+1), $h['vlan_id']);
            $activeSheet->setCellValue("D".($num+1), $h['group_id']);
        }
    }

    // 主机备注格式解析
    private function _structMacInfo($objPHPExcel, $datas){
        // 取可用sheet
        $activeSheet = $objPHPExcel->getActiveSheet();
        // 确定列数
        $columns = ["A","B","C"];
        // 所有单元格默认高度
        $activeSheet->getDefaultRowDimension()->setRowHeight(15);
        // 设置宽width
        $activeSheet->getColumnDimension("A")->setWidth(5); 
        $activeSheet->getColumnDimension("B")->setWidth(20); 
        $activeSheet->getColumnDimension("C")->setWidth(25); 
        // 内容样式
        foreach(["A","B","C"] as $b){
            $activeSheet->getStyle($b)->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            $activeSheet->getStyle($b)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        }
        foreach($datas as $num => $h){
            $activeSheet->setCellValue("A".($num+1), $h['gid']);
            $activeSheet->setCellValue("B".($num+1), $h['mac']);
            $activeSheet->setCellValue("C".($num+1), $h['description']);
        }
    }

    // 主机准入格式解析
    private function _structMacAccess($objPHPExcel, $datas){
        // 取可用sheet
        $activeSheet = $objPHPExcel->getActiveSheet();
        // 确定列数
        $columns = ["A","B"];
        // 所有单元格默认高度
        $activeSheet->getDefaultRowDimension()->setRowHeight(15);
        // 设置宽width
        $activeSheet->getColumnDimension("A")->setWidth(20); 
        $activeSheet->getColumnDimension("B")->setWidth(25); 
        // 内容样式
        foreach(["A","B"] as $b){
            $activeSheet->getStyle($b)->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            $activeSheet->getStyle($b)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        }
        foreach($datas as $num => $h){
            $activeSheet->setCellValue("A".($num+1), $h['mac']);
            $activeSheet->setCellValue("B".($num+1), $h['description']);
        }
    }

}