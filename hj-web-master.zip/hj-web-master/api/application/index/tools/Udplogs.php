<?php
namespace  app\index\tools;
use think\Db;

class Udplogs
{
    protected static $udpInstance = null;

    // 日志服务器IP
    protected static $remoteIp = "192.168.2.15";

    // 日志服务器端口
    protected static $remotePort = 8080;

    // 设备标识编号
    protected static $serialNum = "10000000000001";

    /**
     * 获取UDP套接字实例
     * @return Socket
     */
    protected static function udpInstance()
    {
        if (!self::$udpInstance) {
            $remote = Db::table('sys_config')->where(['conf_type'=>'remote'])->find();
            $remote = explode("|", $remote['conf_value']);
            self::$remoteIp = $remote[0] ?? self::$remoteIp;
            self::$remotePort = $remote[1] ?? self::$remotePort;
            self::$serialNum = $remote[2] ?? self::$serialNum;
            self::$udpInstance = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
        }

        return self::$udpInstance;
    }

    public function send($logs = "", $log_type = 'test')
    {
        if (empty($logs)) {
            return;
        }

        $len = strlen($logs);
        try{
            socket_sendto(self::udpInstance(), $logs, $len, 0, self::$remoteIp, self::$remotePort);
        }catch(\Exception $e){
            file_put_contents("/tmp/metrics_error.log", "[".date("Y-m-d H:i:s", time())."]".__LINE__." Error: centralized management host name lookup failure ;\n");
        }
    }

    public function sendArrLogs($logs = [], $log_type = 'test', $mtu = 10)
    {
        if (!is_array($logs) || empty($logs)) {
            return;
        }
        $count = count($logs);

        // 每$mtu条日志作为一包数据发送
        do {
            $len = $count < $mtu ? $count : $mtu;
            $logs_json = json_encode([
                "serial_num" => self::$serialNum,
                "log_type" => $log_type,
                "data" => array_slice($logs, 0, $len)
            ]);

            try{
                socket_sendto(self::udpInstance(), $logs_json, strlen($logs_json), 0, self::$remoteIp, self::$remotePort);
            }catch(\Exception $e){
                file_put_contents("/tmp/metrics_error.log", "[".date("Y-m-d H:i:s", time())."]".__LINE__." Error: centralized management host name lookup failure ;\n");
            }
            
            $count = $count - $mtu;
            $logs = array_slice($logs, $len);
        } while ($count > 0);
    }
}