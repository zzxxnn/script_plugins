<?php

namespace app\index\tools;

use app\index\model\NetConfig;
use app\index\model\NetRip;
use app\index\model\NetVip;
use app\index\model\NetWip;
use app\index\model\NetVnet;
use app\index\model\MacBlackWhiteList;
use app\index\model\InnerfirewallPol;
use app\index\model\HoneyPot;
use app\index\model\LogServer;
use app\index\model\NetMacThrough;
use app\index\model\NetBindIp;
use app\index\model\MacAllow;
use app\index\model\ServerTrap;
use app\index\model\ServerMask;
use app\index\model\NetBindRouter;
use app\index\model\ServerTrapWhiteList;
use app\index\model\AccessSt;
use app\index\repository\SysConfRepository;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;

/**
 * 获取所有配置并构建json
 */
class Makeconfjson extends Controller
{

    public function make()
    {
        $json_arr = [];
        $json_arr = array_merge(
            $this->_netConf(),
            $this->_ripConf(),
            $this->_vipConf(),
            $this->_vnetConf(),
            $this->_wipConf(),
            $this->_fireWall(),
            $this->_hostBwList(),
            $this->_honeyPot(),
            $this->_logServer(),
            $this->_macThrough(),
            $this->_bindIp(),
            $this->_macFilter(),
            $this->_unrealPort(),
            $this->_unrealPortWlist(),
            $this->_serverMask(),
            $this->_bindRouter(),
            $this->_accessSt(),
            $this->_sntpConf()
        );

        return json_encode($json_arr, 192);
    }

    private function _accessSt()
    { // 应用访问策略
        $conf_arr = [];
        $M_acs_st = new AccessSt;
        $data = $M_acs_st->selectAllAccessSt();
        if (empty($data)) {
            return [];
        }
        foreach ($data as $tmp) {
            $conf_arr['access_strategy'][] = [
                "id"          => $tmp['id'],
                "name"        => $tmp['name'],
                "proto"       => $tmp['protocol_id'],
                "sport"       => empty($tmp['s_port']) && $tmp['s_port'] !== '0' ? '0' : $tmp['s_port'],
                "dport"       => empty($tmp['d_port']) && $tmp['d_port'] !== '0' ? '0' : $tmp['d_port'],
                "effect_time" => empty($tmp['effect_time']) && $tmp['effect_time'] !== '0' ? '0' : $tmp['effect_time']
            ];
        }

        return $conf_arr;
    }

    private function _bindRouter()
    {
        $conf_arr = [];
        $M_net_bind_router = new NetBindRouter;
        $data = $M_net_bind_router->selectAllBindRouter();
        if (empty($data)) {
            return [];
        }
        foreach ($data as $tmp) {
            $conf_arr['static_route'][] = [
                "gateway"     => $tmp['gateway'],
                "net_segment" => $tmp['ip']
            ];
        }

        return $conf_arr;
    }

    private function _serverMask()
    {
        $conf_arr = [];
        $M_server_mask = new ServerMask;
        $data = $M_server_mask->selectAllServerMask();
        if (empty($data)) {
            return [];
        }
        foreach ($data as $tmp) {
            $conf_arr['server_pretend'][] = [
                "name"           => $tmp['name'],
                "real_server"    => $tmp['r_ip'],
                "virtual_server" => $tmp['v_ip'],
                "vlanid"         => $tmp['vlan_id'],
                "groupid"        => $tmp['group_id']
            ];
        }

        return $conf_arr;
    }

    private function _unrealPortWlist()
    {
        $conf_arr = [];
        $M_server_trap_wlist = new ServerTrapWhiteList;
        $data = $M_server_trap_wlist->selectAllServerTrapWlist();
        if (empty($data)) {
            return [];
        }
        foreach ($data as $tmp) {
            $conf_arr['unreal_open_white'][] = [
                "target"      => $tmp['t_ip_mac'],
                "target_port" => $tmp['t_port']
            ];
        }

        return $conf_arr;
    }

    private function _unrealPort()
    { // 端口虚开
        $conf_arr = [];
        $M_server_trap = new ServerTrap;
        $data = $M_server_trap->selectAllServerTrap();
        if (empty($data)) {
            return [];
        }
        foreach ($data as $tmp) {
            $conf_arr['ports_unreal_open'][] = [
                "name"        => $tmp['name'],
                "source_ip"   => empty($tmp['s_ip']) && $tmp['s_ip'] !== '0' ? '0' : $tmp['s_ip'],
                "source_port" => empty($tmp['s_port']) ? 0 : $tmp['s_port'],
                "target"      => $tmp['t_ip_mac'],
                "target_port" => $tmp['t_port'],
                "type"        => $tmp['t_ip_type'],
                "vlanid"      => $tmp['vlan_id'],
                "groupid"     => $tmp['group_id']
            ];
        }

        return $conf_arr;
    }

    private function _macFilter()
    {
        $conf_arr = [];
        $M_mac_allow = new MacAllow;
        $data = $M_mac_allow->selectAllMacAllow();
        if (empty($data)) {
            return [];
        }
        foreach ($data as $tmp) {
            $conf_arr['mac_filter_config'][] = [
                "mac" => $tmp['mac'],
            ];
        }

        return $conf_arr;
    }

    private function _bindIp()
    {
        $conf_arr = [];
        $M_net_bind_ip = new NetBindIp;
        $data = $M_net_bind_ip->selectAllBindIp();
        if (empty($data)) {
            return [];
        }
        foreach ($data as $tmp) {
            $conf_arr['mac_bind_wip'][] = [
                "mac" => $tmp['mac'],
                "wip" => $tmp['ip']
            ];
        }

        return $conf_arr;
    }

    private function _macThrough()
    {
        $conf_arr = [];
        $M_net_mac_through = new NetMacThrough;
        $data = $M_net_mac_through->selectAllMacThrough();
        if (empty($data)) {
            return [];
        }
        foreach ($data as $tmp) {
            $conf_arr['mac_bind_passthrough'][] = [
                "groupid" => $tmp['group_id'],
                "mac"     => $tmp['mac'],
                "vlanid"  => $tmp['vlan_id'],
                "wip"     => $tmp['ip']
            ];
        }

        return $conf_arr;
    }

    private function _logServer()
    {
        $conf_arr = [];
        $M_log_server = new LogServer;
        $data = $M_log_server->selectAllLogServer();
        $conf_arr = [];
        foreach ($data as $tmp) {
            $conf_arr['log_server'][] = [
                "host"   => $tmp['ip'],
                "port"   => $tmp['port'],
                "switch" => $tmp['switch'],
                "type"   => $tmp['types']
            ];
        }

        return $conf_arr;
    }

    private function _honeyPot()
    {
        $conf_arr = [];
        $M_honey_pot = new HoneyPot;
        $data = $M_honey_pot->selectAllHoneyPot();
        if (empty($data)) {
            return [];
        }
        foreach ($data as $tmp) {
            $conf_arr['honey_pot'][] = [
                "honey_ip"   => $tmp['h_ip'],
                "honey_port" => $tmp['h_port'],
                "vport"      => $tmp['v_port']
            ];
        }

        return $conf_arr;
    }

    private function _fireWall()
    { // 内网防火墙
        $conf_arr = [];
        $M_fw_pol = new InnerfirewallPol;
        $data = $M_fw_pol->selectAllFwPol();
        if (empty($data)) {
            return [];
        }
        foreach ($data as $tmp) {
            $conf_arr['firewall'][] = [
                "dip"   => empty($tmp['dst_ip']) && $tmp['dst_ip'] !== '0' ? '0' : $tmp['dst_ip'],
                "dport" => empty($tmp['d_port']) && $tmp['d_port'] !== '0' ? '0' : $tmp['d_port'],
                "proto" => $tmp['protocol_id'],
                "sip"   => empty($tmp['src_ip']) && $tmp['src_ip'] !== '0' ? '0' : $tmp['src_ip'],
                "sport" => empty($tmp['s_port']) && $tmp['s_port'] !== '0' ? '0' : $tmp['s_port'],
                "type"  => $tmp['action']
            ];
        }

        return $conf_arr;
    }

    private function _hostBwList()
    {
        $conf_arr = [];
        $M_mac_bwlist = new MacBlackWhiteList;
        $data = $M_mac_bwlist->selectAllMacBwlist();
        if (empty($data)) {
            return [];
        }
        foreach ($data as $tmp) {
            if ($tmp['type']) { // 黑名单
                if ($this->_cheakMac($tmp['mac'])) {
                    $conf_arr["black_mac"][] = ['mac' => $tmp['mac']];
                } elseif ($this->_cheakIp($tmp['mac'])) {
                    $conf_arr["black_ip"][] = ['ip' => $tmp['mac']];
                }
            } else { // 白名单
                if ($this->_cheakMac($tmp['mac'])) {
                    $conf_arr["white_mac"][] = ['mac' => $tmp['mac']];
                } elseif ($this->_cheakIp($tmp['mac'])) {
                    $conf_arr["white_ip"][] = ['ip' => $tmp['mac']];
                }
            }
        }

        return $conf_arr;
    }

    private function _wipConf()
    {
        $conf_arr = [];
        $M_net_wip = new NetWip;
        $data = $M_net_wip->selectAllWip();
        if (empty($data)) {
            return [];
        }
        foreach ($data as $tmp) {
            $conf = [];
            if ($tmp['exclude'] == 1) {
                $conf = [
                    'exclude_wip' => $tmp['ip'],
                    'mask'        => $tmp['mask'],
                    'gateway'     => $tmp['gateway'],
                    'vlanid'      => $tmp['vlan_id'],
                    'groupid'     => $tmp['group_id'],
                ];
                $conf_arr["exclude_wip_mask"][] = $conf;
            } else {
                $conf = [
                    'wip'     => $tmp['ip'],
                    'mask'    => $tmp['mask'],
                    'gateway' => $tmp['gateway'],
                    'vlanid'  => $tmp['vlan_id'],
                    'groupid' => $tmp['group_id'],
                ];
                $conf_arr["wip_mask"][] = $conf;
            }
        }

        return $conf_arr;
    }

    private function _vnetConf()
    {
        $conf_arr = [];
        $M_net_vnet = new NetVnet;
        $data = $M_net_vnet->selectAllVnet();
        if (empty($data)) {
            return [];
        }
        foreach ($data as $tmp) {
            $conf = [];
            if ($tmp['exclude'] == 1) {
                $conf = [
                    'exclude_vnetwork' => $tmp['ip'],
                    'mask'             => $tmp['mask'],
                    'vlanid'           => $tmp['vlan_id'],
                    'groupid'          => $tmp['group_id'],
                ];
                $conf_arr["exclude_vnetwork_mask"][] = $conf;
            } else {
                $conf = [
                    'vnetwork' => $tmp['ip'],
                    'mask'     => $tmp['mask'],
                    'vlanid'   => $tmp['vlan_id'],
                    'groupid'  => $tmp['group_id'],
                ];
                $conf_arr["vnetwork_mask"][] = $conf;
            }
        }

        return $conf_arr;
    }

    private function _vipConf()
    {
        $conf_arr = [];
        $M_net_vip = new NetVip;
        $data = $M_net_vip->selectAllVip();
        if (empty($data)) {
            return [];
        }
        foreach ($data as $tmp) {
            $conf = [];
            if ($tmp['exclude'] == 1) {
                $conf = [
                    'exclude_vip' => $tmp['ip'],
                    'mask'        => $tmp['mask'],
                    'vlanid'      => $tmp['vlan_id'],
                    'groupid'     => $tmp['group_id'],
                ];
                $conf_arr["exclude_vip_mask"][] = $conf;
            } else {
                $conf = [
                    'vip'     => $tmp['ip'],
                    'mask'    => $tmp['mask'],
                    'vlanid'  => $tmp['vlan_id'],
                    'groupid' => $tmp['group_id'],
                ];
                $conf_arr["vip_mask"][] = $conf;
            }
        }

        return $conf_arr;
    }

    private function _ripConf()
    {
        $conf_arr = [];
        $M_net_rip = new NetRip;
        $data = $M_net_rip->selectAllRip();
        if (empty($data)) {
            return [];
        }
        foreach ($data as $tmp) {
            $conf = [];
            if ($tmp['exclude'] == 1) {
                $conf = [
                    'exclude_rip' => $tmp['ip'],
                    'mask'        => $tmp['mask'],
                    'vlanid'      => $tmp['vlan_id'],
                    'groupid'     => $tmp['group_id'],
                ];
                $conf_arr["exclude_rip_mask"][] = $conf;
            } else {
                $conf = [
                    'rip'     => $tmp['ip'],
                    'mask'    => $tmp['mask'],
                    'vlanid'  => $tmp['vlan_id'],
                    'groupid' => $tmp['group_id'],
                ];
                $conf_arr["rip_mask"][] = $conf;
            }
        }

        return $conf_arr;
    }

    private function _netConf()
    {
        $conf_arr = [];
        $M_net_config = new NetConfig;
        $data = $M_net_config->selectAllConfValue();
        if (empty($data)) {
            return [];
        }
        foreach ($data as $tmp) {
            switch ($tmp['conf_type']) {
                case 1:
                    $conf_arr['dhcp_switch'] = (int)$tmp['conf_value'];
                    break;
                case 2:
                    $conf_arr['dhcp_dns'] = str_replace("|", ",", $tmp['conf_value']);
                    break;
                case 3:
                    $conf_arr['dhcp_time'] = (int)$tmp['conf_value'];
                    break;
                case 4:
                    $conf_arr['host_status_ttl'] = (int)$tmp['conf_value'];
                    break;
                case 5:
                    $conf_arr['rip_access_switch'] = (int)$tmp['conf_value'];
                    break;
                case 6:
                    $conf_arr['host_status_switch'] = (int)$tmp['conf_value'];
                    break;
                case 7:
                    $tmp_arr = explode("|", $tmp['conf_value']);
                    $conf_arr['vip_alter_time'] = (int)$tmp_arr[0] * 60;
                    $conf_arr['vname_alter_time'] = (int)$tmp_arr[1] * 60;
                    $conf_arr['vnetwork_alter_time'] = (int)$tmp_arr[2] * 60;
                    break;
                case 8:
                    $tmp_arr = explode("|", $tmp['conf_value']);
                    $conf_arr['mgt1_ip'] = $tmp_arr[0];
                    $conf_arr['mgt2_ip'] = $tmp_arr[1];
                    break;
                case 17:
                    $tmp_arr = explode("|", $tmp['conf_value']);
                    $conf_arr['linux_per'] = (int)$tmp_arr[0];
                    $conf_arr['windows_per'] = (int)$tmp_arr[1];
                    $conf_arr['server_per'] = (int)$tmp_arr[2];
                    break;
                case 18:
                    $conf_arr['virtual_port_percent'] = (int)$tmp['conf_value'];
                    break;
                case 19:
                    $conf_arr['linux_port'] = $tmp['conf_value'];
                    break;
                case 20:
                    $conf_arr['windows_port'] = $tmp['conf_value'];
                    break;
                case 21:
                    $conf_arr['server_port'] = $tmp['conf_value'];
                    break;
                case 22:
                    $conf_arr['company_mac'] = $tmp['conf_value'];
                    break;
                // case 26:
                //     $conf_arr['stp_swtich'] = (int)$tmp['conf_value'];
                // break;
                case 28:
                    $conf_arr['mac_filter_switch'] = (int)$tmp['conf_value'];
                    break;
                case 29:
                    if (!empty($tmp['conf_value'])) {
                        $conf_arr['bypass_groupids'] = $tmp['conf_value'];
                    }
                    break;
                case 30:
                    $conf_arr['host_block_config'] = str_replace("|", ",", $tmp['conf_value']);
                    break;
                default:

                    break;
            }
        }

        return $conf_arr;
    }

    private function _cheakMac($mac)
    {
        return !empty(filter_var($mac, FILTER_VALIDATE_MAC));
    }

    private function _cheakIp($ip)
    {
        return !(ip2long($ip) === false);
    }


    private function _sntpConf()
    {
        $conf = (new SysConfRepository())->getSntpConf();

        return [
            'ntp_enable' => (int)$conf['sntp_enable'],
            'ntp_server' => $conf['sntp_host'],
            'ntp_period' => (int)$conf['sntp_sync_interval']
        ];
    }
}