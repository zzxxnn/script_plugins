<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/7/31
 * Time: 11:04
 */

namespace app\index\tools;


use think\Log;

class CustomerLogger
{

    public function log($msg = null, $lvl = 'error', $path = null)
    {
        try {
            empty($path) && $path = RUNTIME_PATH . 'error-log';

            $logFile = $path . DS . date('Ymd') . '.log';

            // 检查日志目录是否存在
            if (!is_dir(dirname($logFile))) {
                mkdir(dirname($logFile), 0755, true);
            }

            $url = request()->method() . " " . request()->url();
            $content = sprintf('[' . date('Y-m-d H:i:s') . ']' . '[%s] [%s]:' . PHP_EOL, strtoupper($lvl), $url);
            $content .= 'AUTH_INFO: ' . var_export(session('user_auth'), true) . PHP_EOL;
            $content .= 'REQUEST: ' . var_export($this->getLogRequest(), true) . PHP_EOL;
            $content .= 'ERROR_MSG: ' . var_export($msg, true) . PHP_EOL;
            $content .= '---------------------------------------------------------------' . PHP_EOL;

            file_put_contents($logFile, $content, FILE_APPEND);
        } catch (\Exception $e) {
            Log::error($e->getMessage());
        }
    }


    private function getLogRequest()
    {
        return ['URL' => request()->url(), 'HEADER' => request()->header(), 'PARAM' => request()->param()];
    }

}