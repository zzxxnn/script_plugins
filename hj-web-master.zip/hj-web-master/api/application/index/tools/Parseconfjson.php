<?php
namespace app\index\tools;
use app\index\model\NetConfig;
use app\index\model\NetRip;
use app\index\model\NetVip;
use app\index\model\NetWip;
use app\index\model\NetVnet;
use app\index\model\MacBlackWhiteList;
use app\index\model\InnerfirewallPol;
use app\index\model\HoneyPot;
use app\index\model\LogServer;
use app\index\model\NetMacThrough;
use app\index\model\NetBindIp;
use app\index\model\MacAllow;
use app\index\model\ServerTrap;
use app\index\model\ServerMask;
use app\index\model\NetBindRouter;
use app\index\model\ServerTrapWhiteList;
use app\index\model\AccessSt;
use app\index\repository\SysConfRepository;
use app\index\validate\Sysconf;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;

/**
 * 解析所有配置json
 */
class Parseconfjson extends Controller {

    protected $V_parse; 
    protected $check_default_log_server;
    
    public function _initialize(){
        $this->V_parse = Loader::validate('Parsejson');
        $this->check_default_log_server = false;
    }

    public function parse($json_content){
        $conf_arr = json_decode($json_content, TRUE);
        if(empty($conf_arr)){
            return ;
        }
        $this->_checkJsonFormat($conf_arr);// 检查格式
        
        $is_mgt_ip_changed = $this->_netConf($conf_arr, false);
        $this->_ripConf($conf_arr);
        $this->_vipConf($conf_arr);
        $this->_vnetConf($conf_arr);
        $this->_wipConf($conf_arr);
        $this->_hostBwList($conf_arr);
        $this->_fireWall($conf_arr);
        $this->_honeyPot($conf_arr);
        $this->_logServer($conf_arr);
        $this->_macThrough($conf_arr);
        $this->_bindIp($conf_arr);
        $this->_macFilter($conf_arr);
        $this->_unrealPort($conf_arr);
        $this->_unrealPortWlist($conf_arr);
        $this->_serverMask($conf_arr);
        $this->_bindRouter($conf_arr);
        $this->_accessSt($conf_arr);
        $this->_sntpConf($conf_arr);
        
        if($is_mgt_ip_changed !== FALSE){ // 是否改变管理口ip
            header("Content-Type: application/json");
            echo json_encode(['errcode' => 0, 'errmsg' => 'mgt changed!', 'change_mgt' => $is_mgt_ip_changed]);
            // 刷新buffer
            ob_flush();
            flush();
            fastcgi_finish_request();
        }

        if($this->check_default_log_server === false){ // 下发配置时需要配置默认数据库配置
            $conf_arr['log_server'][]=[
                "host"    =>  "127.0.0.1",
                "port"    =>  30000,
                "switch"  =>  1,
                "type"    =>  "1,4,5,6,7,8,9"
            ];
        }

        $result = WriteInShm(json_encode($conf_arr));
        if($result){
            exec("fpcmd load_sys_config");
            exec("nohup fpcmd alter_vnetwork >/dev/null 2>&1 &"); // 虚拟网络变换
        }else{
            Error('20003');
        }
    }

    public function syncparse($json_content){
        $conf_arr = json_decode($json_content, TRUE);
        
        $this->_netConf($conf_arr, true);
        $this->_ripConf($conf_arr);
        $this->_vipConf($conf_arr);
        $this->_vnetConf($conf_arr);
        $this->_wipConf($conf_arr);
        $this->_hostBwList($conf_arr);
        $this->_fireWall($conf_arr);
        $this->_honeyPot($conf_arr);
        $this->_logServer($conf_arr);
        $this->_macThrough($conf_arr);
        $this->_bindIp($conf_arr);
        $this->_macFilter($conf_arr);
        $this->_unrealPort($conf_arr);
        $this->_unrealPortWlist($conf_arr);
        $this->_serverMask($conf_arr);
        $this->_accessSt($conf_arr);
        $this->_sntpConf($conf_arr);

        if(isset($conf_arr['log_server'])){
            foreach($conf_arr['log_server'] as $tmp){
                foreach($conf_arr['log_server'] as $tmp){
                    if(($tmp['host'] == '127.0.0.1') && ($tmp['port'] == 30000)){
                        $this->check_default_log_server = true; // 查看是否有默认数据库配置
                    }
                }
            }
        }

        if($this->check_default_log_server === false){ // 下发配置时需要配置默认数据库配置
            $conf_arr['log_server'][]=[
                "ip"      =>  1,
                "host"    =>  "127.0.0.1",
                "port"    =>  30000,
                "switch"  =>  1,
                "type"    =>  "1,4,5,6,7,8,9"
            ];
        }

        $result = WriteInShm(json_encode($conf_arr));
        if($result){
            exec("fpcmd load_sys_config");
            exec("nohup fpcmd alter_vnetwork >/dev/null 2>&1 &"); // 虚拟网络变换
        }else{
            Error('20003');
        }
    }

    private function _accessSt($conf_arr){ // 应用访问策略
        $M_acs_st = new AccessSt;
        $M_acs_st->deleteAll();
        $conf = [];
        if(isset($conf_arr['access_strategy'])){
            foreach($conf_arr['access_strategy'] as $tmp){
                $conf[]=[
                    "id"    =>    $tmp['id'],
                    "name"  =>    $tmp['name'],
                    "protocol_id"=>  $tmp['proto'],
                    "s_port"     =>  $tmp['sport'] === '0' ? '' : $tmp['sport'],
                    "d_port"     =>  $tmp['dport'] === '0' ? '' : $tmp['dport'],
                    "effect_time"=>  $tmp['effect_time'] === '0' ? '' : $tmp['effect_time']
                ]; 
            }
            if(!empty($conf)){
                $M_acs_st->insertAllConf($conf);
            }
        }
    }

    private function _bindRouter($conf_arr){
        $M_net_bind_router = new NetBindRouter;
        $M_net_bind_router->deleteAll();
        $conf = [];
        if(isset($conf_arr['static_route'])){
            foreach($conf_arr['static_route'] as $tmp){
                $conf[]=[
                    "gateway"   =>  $tmp['gateway'],
                    "ip"        =>  $tmp['net_segment']
                ]; 
            }
            if(!empty($conf)){
                $M_net_bind_router->saveAll($conf);
            }
        }
    }

    private function _serverMask($conf_arr){
        $M_server_mask = new ServerMask;
        $M_server_mask->deleteAll();
        $conf = [];
        if(isset($conf_arr['server_pretend'])){
            foreach($conf_arr['server_pretend'] as $tmp){
                $conf[]=[
                    "name"      =>  $tmp['name'],
                    "r_ip"      =>  $tmp['real_server'],
                    "v_ip"      =>  $tmp['virtual_server'],
                    "vlan_id"   =>  $tmp['vlanid'],
                    "group_id"  =>  $tmp['groupid']
                ]; 
            }
            if(!empty($conf)){
                $M_server_mask->saveAll($conf);
            }
        }
    }

    private function _unrealPortWlist($conf_arr){
        $M_server_trap_wlist = new ServerTrapWhiteList;
        $M_server_trap_wlist->deleteAll();
        $conf = [];
        if(isset($conf_arr['unreal_open_white'])){
            foreach($conf_arr['unreal_open_white'] as $tmp){
                $conf[]=[
                    "t_ip_mac" =>  FormatMac($tmp['target']),
                    "t_port"   =>  $tmp['target_port']
                ]; 
            }
            if(!empty($conf)){
                $M_server_trap_wlist->saveAll($conf);
            }
        }
    }

    private function _unrealPort($conf_arr){ // 端口虚开
        $M_server_trap = new ServerTrap;
        $M_server_trap->deleteAll();
        $conf = [];
        if(isset($conf_arr['ports_unreal_open'])){
            foreach($conf_arr['ports_unreal_open'] as $tmp){
                $conf[]=[
                    "name"      =>  $tmp['name'],
                    "t_ip_mac"  =>  FormatMac($tmp['target']),
                    "t_ip_type" =>  $tmp['type'],
                    "t_port"    =>  $tmp['target_port'],
                    "s_ip"      =>  $tmp['source_ip'] === '0' ? '' : $tmp['source_ip'],
                    "s_port"    =>  $tmp['source_port'] === 0 ? '' : $tmp['source_port'],
                    "vlan_id"   =>  $tmp['vlanid'],
                    "group_id"  =>  $tmp['groupid']
                ]; 
            }
            if(!empty($conf)){
                $M_server_trap->saveAll($conf);
            }
        }
    }

    private function _macFilter($conf_arr){
        $M_mac_allow = new MacAllow;
        $M_mac_allow->deleteAll();
        $conf = [];
        if(isset($conf_arr['mac_filter_config'])){
            foreach($conf_arr['mac_filter_config'] as $tmp){
                $conf[]=[
                    "mac"  =>  FormatMac($tmp['mac']),
                ]; 
            }
            if(!empty($conf)){
                $M_mac_allow->saveAll($conf);
            }
        }
    }

    private function _bindIp($conf_arr){
        $M_net_bind_ip = new NetBindIp;
        $M_net_bind_ip->deleteAll();
        $conf = [];
        if(isset($conf_arr['mac_bind_wip'])){
            foreach($conf_arr['mac_bind_wip'] as $tmp){
                $conf[]=[
                    "mac"  =>  FormatMac($tmp['mac']),
                    "ip"   =>  $tmp['wip']
                ]; 
            }
            if(!empty($conf)){
                $M_net_bind_ip->saveAll($conf);
            }
        }
    }

    private function _macThrough($conf_arr){
        $M_net_mac_through = new NetMacThrough;
        $M_net_mac_through->deleteAll();
        $conf = [];
        if(isset($conf_arr['mac_bind_passthrough'])){
            foreach($conf_arr['mac_bind_passthrough'] as $tmp){
                $conf[]=[
                    "mac"      =>  FormatMac($tmp['mac']),
                    "ip"       =>  $tmp['wip'],
                    "vlan_id"  =>  $tmp['groupid'] == 0 ? 0 : $tmp['vlanid'],
                    "group_id" =>  $tmp['groupid']
                ]; 
            }
            if(!empty($conf)){
                $M_net_mac_through->saveAll($conf);
            }
        }
    }

    private function _logServer($conf_arr){
        $M_log_server = new LogServer;
        $M_log_server->where('id', '<>', 1)->delete(); // 不会删除默认配置
        $conf = [];
        if(isset($conf_arr['log_server'])){
            $default_server_flag = false;
            foreach($conf_arr['log_server'] as $tmp){
                if(($tmp['host'] == '127.0.0.1') && ($tmp['port'] == 30000)){ // 不需要写入数据库默认配置
                    continue;
                }
                $conf[]=[
                    "ip"      =>  $tmp['host'],
                    "port"    =>  $tmp['port'],
                    "switch"  =>  $tmp['switch'],
                    "types"   =>  $tmp['type']
                ]; 
            }
            if(!empty($conf)){
                $M_log_server->saveAll($conf);
            }
        }
    }

    private function _honeyPot($conf_arr){
        $M_honey_pot = new HoneyPot;
        $M_honey_pot->deleteAll();
        $conf = [];
        if(isset($conf_arr['honey_pot'])){
            foreach($conf_arr['honey_pot'] as $tmp){
                $conf[]=[
                    "h_ip"  =>  $tmp['honey_ip'],
                    "h_port"=>  $tmp['honey_port'],
                    "v_port"=>  $tmp['vport']
                ]; 
            }
            if(!empty($conf)){
                $M_honey_pot->saveAll($conf);
            }
        }
    }

    private function _fireWall($conf_arr){ // 内网防火墙
        $M_fw_pol = new InnerfirewallPol;
        $M_fw_pol->deleteAll();
        $conf = [];
        if(isset($conf_arr['firewall'])){
            foreach($conf_arr['firewall'] as $tmp){
                $conf[]=[
                    "protocol_id"=>  $tmp['proto'],
                    "dst_ip"   =>  $tmp['dip'] === '0' ? '' : $tmp['dip'],
                    "d_port"   =>  $tmp['dport'] === '0' ? '' : $tmp['dport'],
                    "src_ip"   =>  $tmp['sip'] === '0' ? '' : $tmp['sip'],
                    "s_port"   =>  $tmp['sport'] === '0' ? '' : $tmp['sport'],
                    "action"   =>  $tmp['type']
                ]; 
            }
            if(!empty($conf)){
                $M_fw_pol->saveAll($conf);
            }
        }
    }

    private function _hostBwList($conf_arr){
        $M_mac_bwlist = new MacBlackWhiteList;
        $M_mac_bwlist->where('type', '=', 0)->delete();
        $M_mac_bwlist->where('type', '=', 1)->delete();
        $conf = [];
        if(isset($conf_arr['white_ip'])){
            foreach($conf_arr['white_ip'] as $tmp){
                $conf[] = [
                    'type'  => 0,
                    'mac'   => $tmp['ip']
                ];
            }
        }
        if(isset($conf_arr['white_mac'])){
            foreach($conf_arr['white_mac'] as $tmp){
                $conf[] = [
                    'type'  => 0,
                    'mac'   => FormatMac($tmp['mac'])
                ];
            }
        }
        if(isset($conf_arr['black_ip'])){
            foreach($conf_arr['black_ip'] as $tmp){
                $conf[] = [
                    'type'  => 1,
                    'mac'   => $tmp['ip']
                ];
            }
        }
        if(isset($conf_arr['black_mac'])){
            foreach($conf_arr['black_mac'] as $tmp){
                $conf[] = [
                    'type'  => 1,
                    'mac'   => FormatMac($tmp['mac'])
                ];
            }   
        }
        if(!empty($conf)){
            $M_mac_bwlist->saveAll($conf);
        }
    }

    private function _wipConf($conf_arr){
        $M_net_wip = new NetWip;
        $M_net_wip->where('exclude', '=', 0)->delete();
        if(isset($conf_arr['wip_mask'])){
            $conf = [];
            foreach($conf_arr['wip_mask'] as $tmp){
                $conf[] = [
                    'exclude'   => 0,
                    'ip'        => $tmp['wip'],
                    'mask'      => $tmp['mask'],
                    'gateway'   => $tmp['gateway'],
                    'vlan_id'   => $tmp['vlanid'],
                    'group_id'  => $tmp['groupid']
                ];
            }
            if(!empty($conf_arr['wip_mask'])){
                $M_net_wip->saveAll($conf);
            }
        }
        $M_net_wip->where('exclude', '=', 1)->delete();
        if(isset($conf_arr['exclude_wip_mask'])){
            $conf = [];
            foreach($conf_arr['exclude_wip_mask'] as $tmp){
                $conf[] = [
                    'exclude'   => 1,
                    'ip'        => $tmp['exclude_wip'],
                    'mask'      => $tmp['mask'],
                    'vlan_id'   => $tmp['vlanid'],
                    'group_id'  => $tmp['groupid']
                ];
            }
            if(!empty($conf_arr['exclude_wip_mask'])){
                $M_net_wip->saveAll($conf);
            }
        }
    }

    private function _vnetConf($conf_arr){
        $M_net_vnet = new NetVnet;
        $M_net_vnet->where('exclude', '=', 0)->delete();
        if(isset($conf_arr['vnetwork_mask'])){
            $conf = [];
            foreach($conf_arr['vnetwork_mask'] as $tmp){
                $conf[] = [
                    'exclude'   => 0,
                    'ip'        => $tmp['vnetwork'],
                    'mask'      => $tmp['mask'],
                    'vlan_id'   => $tmp['vlanid'],
                    'group_id'  => $tmp['groupid']
                ];
            }
            if(!empty($conf_arr['vnetwork_mask'])){
                $M_net_vnet->saveAll($conf);
            }
        }
        $M_net_vnet->where('exclude', '=', 1)->delete();
        if(isset($conf_arr['exclude_vnetwork_mask'])){
            $conf = [];
            foreach($conf_arr['exclude_vnetwork_mask'] as $tmp){
                $conf[] = [
                    'exclude'   => 1,
                    'ip'        => $tmp['exclude_vnetwork'],
                    'mask'      => $tmp['mask'],
                    'vlan_id'   => $tmp['vlanid'],
                    'group_id'  => $tmp['groupid']
                ];
            }
            if(!empty($conf_arr['exclude_vnetwork_mask'])){
                $M_net_vnet->saveAll($conf);
            }
        }
    }

    private function _vipConf($conf_arr){
        $M_net_vip = new NetVip;
        $M_net_vip->where('exclude', '=', 0)->delete();
        if(isset($conf_arr['vip_mask'])){
            $conf = [];
            foreach($conf_arr['vip_mask'] as $tmp){
                $conf[] = [
                    'exclude'   => 0,
                    'ip'        => $tmp['vip'],
                    'mask'      => $tmp['mask'],
                    'vlan_id'   => $tmp['vlanid'],
                    'group_id'  => $tmp['groupid']
                ];
            }
            if(!empty($conf_arr['vip_mask'])){
                $M_net_vip->saveAll($conf);
            }
        }

        $M_net_vip->where('exclude', '=', 1)->delete();
        if(isset($conf_arr['exclude_vip_mask'])){            
            $conf = [];
            foreach($conf_arr['exclude_vip_mask'] as $tmp){
                $conf[] = [
                    'exclude'   => 1,
                    'ip'        => $tmp['exclude_vip'],
                    'mask'      => $tmp['mask'],
                    'vlan_id'   => $tmp['vlanid'],
                    'group_id'  => $tmp['groupid']
                ];
            }
            if(!empty($conf_arr['exclude_vip_mask'])){
                $M_net_vip->saveAll($conf);
            }
        }
    }

    private function _ripConf($conf_arr){
        $M_net_rip = new NetRip;
        $M_net_rip->where('exclude', '=', 0)->delete();
        if(isset($conf_arr['rip_mask'])){
            $conf = [];
            foreach($conf_arr['rip_mask'] as $tmp){
                $conf[] = [
                    'exclude'   => 0,
                    'ip'        => $tmp['rip'],
                    'mask'      => $tmp['mask'],
                    'vlan_id'   => $tmp['vlanid'],
                    'group_id'  => $tmp['groupid']
                ];
            }
            if(!empty($conf_arr['rip_mask'])){
                $M_net_rip->saveAll($conf);
            }
        }

        $M_net_rip->where('exclude', '=', 1)->delete();
        if(isset($conf_arr['exclude_rip_mask'])){
            $conf = [];            
            foreach($conf_arr['exclude_rip_mask'] as $tmp){
                $conf[] = [
                    'exclude'   => 1,
                    'ip'        => $tmp['exclude_rip'],
                    'mask'      => $tmp['mask'],
                    'vlan_id'   => $tmp['vlanid'],
                    'group_id'  => $tmp['groupid']
                ];
            }
            if(!empty($conf_arr['exclude_rip_mask'])){
                $M_net_rip->saveAll($conf);
            }
        }
    }

    private function _netConf($conf_arr, $sync=false){ // $sync 标志如果是同步则不改变管理口
        $is_mgt_ip_change = FALSE; // 标志管理口ip是否改变
        $M_net_config = new NetConfig;
        if(isset($conf_arr['dhcp_switch'])){
            if(!$this->V_parse->scene('switchtype')->check(['switch' => $conf_arr['dhcp_switch']]))
                Error('12025', 'dhcp_switch parameters error');
            $M_net_config->updateValueByConfType(1, $conf_arr['dhcp_switch']);
        }
        if(isset($conf_arr['dhcp_dns'])){
            if(!$this->V_parse->scene('dhcp_dns')->check(['double_dns' => str_replace(",", "|", $conf_arr['dhcp_dns'])]))
                Error('12025', 'dhcp_dns parameters error');
            $M_net_config->updateValueByConfType(2, str_replace(",", "|", $conf_arr['dhcp_dns']));
        }
        if(isset($conf_arr['dhcp_time'])){
            if(!$this->V_parse->scene('dhcp_time')->check(['sec_time' => $conf_arr['dhcp_time']]))
                Error('12025', 'dhcp_time parameters error');
            $M_net_config->updateValueByConfType(3, $conf_arr['dhcp_time']);
        }
        if(isset($conf_arr['host_status_ttl'])){
            if(!$this->V_parse->scene('host_status_ttl')->check(['sec_time' => $conf_arr['host_status_ttl']]))
                Error('12025', 'host_status_ttl parameters error');
            $M_net_config->updateValueByConfType(4, $conf_arr['host_status_ttl']);
        }
        if(isset($conf_arr['rip_access_switch'])){
            if(!$this->V_parse->scene('switchtype')->check(['switch' => $conf_arr['rip_access_switch']]))
                Error('12025', 'rip_access_switch parameters error');
            $M_net_config->updateValueByConfType(5, $conf_arr['rip_access_switch']);
        }
        if(isset($conf_arr['host_status_switch'])){
            if(!$this->V_parse->scene('switchtype')->check(['switch' => $conf_arr['dhcp_switch']]))
                Error('12025', 'host_status_switch parameters error');
            $M_net_config->updateValueByConfType(6, $conf_arr['host_status_switch']);
        }
        if(isset($conf_arr['vip_alter_time']) && isset($conf_arr['vname_alter_time']) && isset($conf_arr['vnetwork_alter_time'])){
            if(!$this->V_parse->scene('alter_time')->check(['trible_sec_times' => ($conf_arr['vip_alter_time']/60)."|".($conf_arr['vname_alter_time']/60)."|".($conf_arr['vnetwork_alter_time']/60)]))
                Error('12025', 'vip_alter_time,vname_alter_time,vnetwork_alter_time parameters error');
            $M_net_config->updateValueByConfType(7, ($conf_arr['vip_alter_time']/60)."|".($conf_arr['vname_alter_time']/60)."|".($conf_arr['vnetwork_alter_time']/60));
        }
        if(!$sync && isset($conf_arr['mgt1_ip']) && isset($conf_arr['mgt2_ip'])){
            if(!$this->V_parse->scene('mgt_ip')->check(['double_ipmask' => $conf_arr['mgt1_ip']."|".$conf_arr['mgt2_ip']]))
                Error('12025', 'mgt1_ip,mgt2_ip parameters error');

            // 检测当前使用的管理口
            $used_ip = GetServerIP();
            $data = $M_net_config->selectValueByConfType(8);
            $used_mgt = "";
            foreach(explode("|", $data[0]["conf_value"]) as $k => $ip_range){
                $ip = explode("/", $ip_range)[0];
                if($ip == $used_ip){
                    $used_mgt = "mgt".($k+1)."_ip";
                    $used_ip = $ip_range;
                    break;
                }
            }
            if($conf_arr[$used_mgt] != $used_ip){
                $is_mgt_ip_change = explode("/", $conf_arr[$used_mgt])[0];
            }   
            $M_net_config->updateValueByConfType(8, $conf_arr['mgt1_ip']."|".$conf_arr['mgt2_ip']);
        }
        if(isset($conf_arr['linux_per']) && isset($conf_arr['windows_per']) && isset($conf_arr['server_per'])){
            if(!$this->V_parse->scene('per')->check(['trible_per' => $conf_arr['linux_per']."|".$conf_arr['windows_per']."|".$conf_arr['server_per']]))
                Error('12025', 'linux_per,windows_per,server_per parameters error');
            $M_net_config->updateValueByConfType(17, $conf_arr['linux_per']."|".$conf_arr['windows_per']."|".$conf_arr['server_per']);
        }
        if(isset($conf_arr['virtual_port_percent'])){
            if(!$this->V_parse->scene('virtual_port_percent')->check(['percent' => $conf_arr['virtual_port_percent']]))
                Error('12025', 'virtual_port_percent parameters error');
            $M_net_config->updateValueByConfType(18, $conf_arr['virtual_port_percent']);
        }
        if(isset($conf_arr['linux_port'])){
            if(!$this->V_parse->scene('ports')->check(['multi_ports' => $conf_arr['linux_port']]))
                Error('12025', 'linux_port parameters error');
            $M_net_config->updateValueByConfType(19, $conf_arr['linux_port']);
        }
        if(isset($conf_arr['windows_port'])){
            if(!$this->V_parse->scene('ports')->check(['multi_ports' => $conf_arr['windows_port']]))
                Error('12025', 'windows_port parameters error');
            $M_net_config->updateValueByConfType(20, $conf_arr['windows_port']);
        }
        if(isset($conf_arr['server_port'])){
            if(!$this->V_parse->scene('ports')->check(['multi_ports' => $conf_arr['server_port']]))
                Error('12025', 'server_port parameters error');
            $M_net_config->updateValueByConfType(21, $conf_arr['server_port']);
        }
        if(isset($conf_arr['company_mac'])){
            if(!$this->V_parse->scene('company_mac')->check(['multi_mac_ids' => $conf_arr['company_mac']]))
                Error('12025', 'company_mac parameters error');
            $M_net_config->updateValueByConfType(22, $conf_arr['company_mac']);
        }
        // if(isset($conf_arr['stp_swtich'])){
        //     if(!$this->V_parse->scene('switchtype')->check(['switch' => $conf_arr['stp_swtich']]))
        //         Error('12025', 'stp_swtich parameters error');
        //     $M_net_config->updateValueByConfType(26, $conf_arr['stp_swtich']);
        // }
        if(isset($conf_arr['mac_filter_switch'])){
            if(!$this->V_parse->scene('switchtype')->check(['switch' => $conf_arr['mac_filter_switch']]))
                Error('12025', 'mac_filter_switch parameters error');
            $M_net_config->updateValueByConfType(28, $conf_arr['mac_filter_switch']);
        }
        if(isset($conf_arr['host_block_config'])){
            if(!$this->V_parse->scene('host_block_config')->check(['multi_integer' => $conf_arr['host_block_config']]))
                Error('12025', 'host_block_config parameters error');
            $M_net_config->updateValueByConfType(30, str_replace(",", "|", $conf_arr['host_block_config']));
        }
        if((!isset($conf_arr['bypass_groupids'])) || empty($conf_arr['bypass_groupids'])){
            $M_net_config->updateValueByConfType(29, null); // bypass 如果是空或者0则配置空
        }else{
            if(!$this->V_parse->scene('bypass_groupids')->check(['groupids' => $conf_arr['bypass_groupids']]))
                Error('12025', 'bypass_groupids parameters error');
            $M_net_config->updateValueByConfType(29, $conf_arr['bypass_groupids']);
        }
        return $is_mgt_ip_change;
    }

    private function _cheakMac($mac){
        return !empty(filter_var($mac, FILTER_VALIDATE_MAC));
    }
    private function _cheakIp($ip){
        return !empty(ip2long($ip));
    }

    /**
     * 检查json配置文件格式
     * @param   Json    $json_content
     */
    private function _checkJsonFormat($conf_arr){
        if(isset($conf_arr['rip_mask'])){
            foreach($conf_arr['rip_mask'] as $tmp){
                if(!(isset($tmp['rip']) && isset($tmp['mask']) && isset($tmp['vlanid']) && isset($tmp['groupid'])))
                    Error('12025', 'rip_mask parameters error');
                if(!$this->V_parse->scene('rip')->check(['r_v_v' => $tmp['rip']."|".$tmp['mask']."|".$tmp['vlanid']."|".$tmp['groupid']]))
                    Error('12025', 'rip_mask parameters error');
            }
        }
        if(isset($conf_arr['exclude_rip_mask'])){
            foreach($conf_arr['exclude_rip_mask'] as $tmp){
                if(!(isset($tmp['exclude_rip']) && isset($tmp['mask']) && isset($tmp['vlanid']) && isset($tmp['groupid'])))
                    Error('12025', 'exclude_rip_mask parameters error');
                if(!$this->V_parse->scene('rip')->check(['r_v_v' => $tmp['exclude_rip']."|".$tmp['mask']."|".$tmp['vlanid']."|".$tmp['groupid']]))
                    Error('12025', 'exclude_rip_mask parameters error');
            }
        }
        if(isset($conf_arr['vip_mask'])){
            foreach($conf_arr['vip_mask'] as $tmp){
                if(!(isset($tmp['vip']) && isset($tmp['mask']) && isset($tmp['vlanid']) && isset($tmp['groupid'])))
                    Error('12025', 'vip_mask parameters error');
                if(!$this->V_parse->scene('vip')->check(['r_v_v' => $tmp['vip']."|".$tmp['mask']."|".$tmp['vlanid']."|".$tmp['groupid']]))
                    Error('12025', 'vip_mask parameters error');
            }
        }
        if(isset($conf_arr['exclude_vip_mask'])){            
            foreach($conf_arr['exclude_vip_mask'] as $tmp){
                if(!(isset($tmp['exclude_vip']) && isset($tmp['mask']) && isset($tmp['vlanid']) && isset($tmp['groupid'])))
                    Error('12025', 'exclude_vip_mask parameters error');
                if(!$this->V_parse->scene('vip')->check(['r_v_v' => $tmp['exclude_vip']."|".$tmp['mask']."|".$tmp['vlanid']."|".$tmp['groupid']]))
                    Error('12025', 'exclude_vip_mask parameters error');
            }
        }
        if(isset($conf_arr['vnetwork_mask'])){
            foreach($conf_arr['vnetwork_mask'] as $tmp){
                if(!(isset($tmp['vnetwork']) && isset($tmp['mask']) && isset($tmp['vlanid']) && isset($tmp['groupid'])))
                    Error('12025', 'vnetwork_mask parameters error');
                if(!$this->V_parse->scene('vnet')->check(['r_v_v' => $tmp['vnetwork']."|".$tmp['mask']."|".$tmp['vlanid']."|".$tmp['groupid']]))
                    Error('12025', 'vnetwork_mask parameters error');
            }
        }
        if(isset($conf_arr['exclude_vnetwork_mask'])){
            foreach($conf_arr['exclude_vnetwork_mask'] as $tmp){
                if(!(isset($tmp['exclude_vnetwork']) && isset($tmp['mask']) && isset($tmp['vlanid']) && isset($tmp['groupid'])))
                    Error('12025', 'exclude_vnetwork_mask parameters error');
                if(!$this->V_parse->scene('vnet')->check(['r_v_v' => $tmp['exclude_vnetwork']."|".$tmp['mask']."|".$tmp['vlanid']."|".$tmp['groupid']]))
                    Error('12025', 'exclude_vnetwork_mask parameters error');
            }
        }
        if(isset($conf_arr['wip_mask'])){
            foreach($conf_arr['wip_mask'] as $tmp){
                if(!(isset($tmp['wip']) && isset($tmp['mask']) && isset($tmp['gateway']) && isset($tmp['vlanid']) && isset($tmp['groupid'])))
                    Error('12025', 'wip_mask parameters error');
                if(!$this->V_parse->scene('wip')->check(['w_ip' => $tmp['wip']."|".$tmp['mask']."|".$tmp['gateway']."|".$tmp['vlanid']."|".$tmp['groupid']]))
                    Error('12025', 'wip_mask parameters error');
            }
        }
        if(isset($conf_arr['exclude_wip_mask'])){
            foreach($conf_arr['exclude_wip_mask'] as $tmp){
                if(!(isset($tmp['exclude_wip']) && isset($tmp['mask']) && isset($tmp['vlanid']) && isset($tmp['groupid'])))
                    Error('12025', 'exclude_wip_mask parameters error');
                if(!$this->V_parse->scene('weip')->check(['w_e_ip' => $tmp['exclude_wip']."|".$tmp['mask']."|".$tmp['vlanid']."|".$tmp['groupid']]))
                    Error('12025', 'exclude_wip_mask parameters error');
            }
        }
        if(isset($conf_arr['white_ip'])){
            foreach($conf_arr['white_ip'] as $tmp){
                if(!isset($tmp['ip']))
                    Error('12025', 'white_ip parameters error');
                if(!$this->V_parse->scene('ips')->check(['ip' =>  $tmp['ip']]))
                    Error('12025', 'white_ip parameters error');
            }
        }
        if(isset($conf_arr['white_mac'])){
            foreach($conf_arr['white_mac'] as $tmp){
                if(!isset($tmp['mac']))
                    Error('12025', 'white_mac parameters error');
                if(!$this->V_parse->scene('macs')->check(['mac' =>  $tmp['mac']]))
                    Error('12025', 'white_mac parameters error');
            }
        }
        if(isset($conf_arr['black_ip'])){
            foreach($conf_arr['black_ip'] as $tmp){
                if(!isset($tmp['ip']))
                    Error('12025', 'black_ip parameters error');
                if(!$this->V_parse->scene('ips')->check(['ip' => $tmp['ip']]))
                    Error('12025', 'black_ip parameters error');
            }
        }
        if(isset($conf_arr['black_mac'])){
            foreach($conf_arr['black_mac'] as $tmp){
                if(!isset($tmp['mac']))
                    Error('12025', 'black_mac parameters error');
                if(!$this->V_parse->scene('macs')->check(['mac' => $tmp['mac']]))
                    Error('12025', 'black_mac parameters error');
            }   
        }
        if(isset($conf_arr['firewall'])){
            foreach($conf_arr['firewall'] as $tmp){
                if(!(isset($tmp['proto']) && isset($tmp['dip']) && isset($tmp['dport']) && isset($tmp['sip']) && isset($tmp['sport']) && isset($tmp['type'])))
                    Error('12025', 'firewall parameters error');

                if(!$this->V_parse->scene('firewall')->check(['f_w_pol' => $tmp['proto']."|".($tmp['dip'] === '0' ? '' : $tmp['dip'])
                ."|".($tmp['dport'] === '0' ? '' : $tmp['dport'])."|".($tmp['sip'] === '0' ? '' : $tmp['sip'])."|".($tmp['sport'] === '0' ? '' : $tmp['sport'])."|".$tmp['type']]))
                    Error('12025', 'firewall parameters error');
            }
        }
        if(isset($conf_arr['access_strategy'])){
            foreach($conf_arr['access_strategy'] as $tmp){
                if(!(isset($tmp['id']) && isset($tmp['name']) && isset($tmp['proto']) && isset($tmp['sport']) && isset($tmp['dport']) && isset($tmp['effect_time'])))
                    Error('12025', 'access_strategy parameters error');
                    
                if(!$this->V_parse->scene('access_strategy')->check(['acs_st' => $tmp['id']."|".$tmp['name']."|".$tmp['proto']
                ."|".($tmp['sport'] === '0' ? '' : $tmp['sport'])."|".($tmp['dport'] === '0' ? '' : $tmp['dport'])."|".$tmp['effect_time']]))
                    Error('12025', 'access_strategy parameters error');
            }
        }
        if(isset($conf_arr['honey_pot'])){
            foreach($conf_arr['honey_pot'] as $tmp){
                if(!(isset($tmp['honey_ip']) && isset($tmp['honey_port']) && isset($tmp['vport'])))
                    Error('12025', 'honey_pot parameters error');
                if(!$this->V_parse->scene('honey_pot')->check(['h_pot' => $tmp['honey_ip']."|".$tmp['honey_port']."|".$tmp['vport']]))
                    Error('12025', 'honey_pot parameters error');
            }
        }
        if(isset($conf_arr['log_server'])){
            foreach($conf_arr['log_server'] as $tmp){
                if(!(isset($tmp['host']) && isset($tmp['port']) && isset($tmp['switch']) && isset($tmp['type'])))
                    Error('12025', 'log_server parameters error');
                if(!$this->V_parse->scene('log_server')->check(['l_ser' => $tmp['host']."|".$tmp['port']."|".$tmp['switch']."|".$tmp['type']]))
                    Error('12025', 'log_server parameters error');

                foreach($conf_arr['log_server'] as $tmp){
                    if(($tmp['host'] == '127.0.0.1') && ($tmp['port'] == 30000)){
                        $this->check_default_log_server = true; // 查看是否有默认数据库配置
                    }
                }
            }
        }
        if(isset($conf_arr['mac_bind_passthrough'])){
            foreach($conf_arr['mac_bind_passthrough'] as $tmp){
                if(!(isset($tmp['mac']) && isset($tmp['wip']) && isset($tmp['vlanid']) && isset($tmp['groupid'])))
                    Error('12025', 'mac_bind_passthrough parameters error');
                if(!$this->V_parse->scene('mac_bind_passthrough')->check(['mac_through' => $tmp['mac']."|".$tmp['wip']."|".$tmp['vlanid']."|".$tmp['groupid']]))
                    Error('12025', 'mac_bind_passthrough parameters error');
            }
        }
        if(isset($conf_arr['mac_bind_wip'])){
            foreach($conf_arr['mac_bind_wip'] as $tmp){
                if(!(isset($tmp['mac']) && isset($tmp['wip'])))
                    Error('12025', 'mac_bind_wip parameters error');
                if(!$this->V_parse->scene('mac_bind_wip')->check(['mac_b_ip' => $tmp['mac']."|".$tmp['wip']]))
                    Error('12025', 'mac_bind_wip parameters error');
            }
        }
        if(isset($conf_arr['mac_filter_config'])){
            foreach($conf_arr['mac_filter_config'] as $tmp){
                if(!isset($tmp['mac']))
                    Error('12025', 'mac_filter_config parameters error');
                if(!$this->V_parse->scene('macs')->check(['mac' => $tmp['mac']]))
                    Error('12025', 'mac_filter_config parameters error');
            }
        }
        if(isset($conf_arr['ports_unreal_open'])){
            foreach($conf_arr['ports_unreal_open'] as $tmp){
                if(!(isset($tmp['name']) && isset($tmp['target']) && isset($tmp['type']) && isset($tmp['target_port']) 
                && isset($tmp['source_ip']) && isset($tmp['source_port']) && isset($tmp['vlanid']) && isset($tmp['groupid'])))
                    Error('12025', 'ports_unreal_open parameters error');
                if(!$this->V_parse->scene('ports_unreal_open')->check(['ports_u_o' => $tmp['name']."|".$tmp['target']."|".$tmp['type']."|".$tmp['target_port']."|".
                ($tmp['source_ip'] === '0' ? '' : $tmp['source_ip'])."|".($tmp['source_port'] === 0 ? '' : $tmp['source_port'])."|".$tmp['vlanid']."|".$tmp['groupid']]))
                    Error('12025', 'ports_unreal_open parameters error');
            }
        }
        if(isset($conf_arr['unreal_open_white'])){
            foreach($conf_arr['unreal_open_white'] as $tmp){
                if(!(isset($tmp['target']) && isset($tmp['target_port'])))
                    Error('12025', 'unreal_open_white parameters error');
                if(!$this->V_parse->scene('unreal_open_white')->check(['ports_u_o_wlist' => $tmp['target']."|".$tmp['target_port']]))
                    Error('12025', 'unreal_open_white parameters error');
            }
        }
        if(isset($conf_arr['server_pretend'])){
            foreach($conf_arr['server_pretend'] as $tmp){
                if(!(isset($tmp['name']) && isset($tmp['real_server']) && isset($tmp['virtual_server']) && isset($tmp['vlanid']) && isset($tmp['groupid'])))
                    Error('12025', 'server_pretend parameters error');
                if(!$this->V_parse->scene('server_pretend')->check(['s_pre' => $tmp['name']."|".$tmp['real_server']."|".$tmp['virtual_server']."|".$tmp['vlanid']."|".$tmp['groupid']]))
                    Error('12025', 'server_pretend parameters error');
            }
        }
        if(isset($conf_arr['static_route'])){
            foreach($conf_arr['static_route'] as $tmp){
                if(!(isset($tmp['net_segment']) && isset($tmp['gateway'])))
                    Error('12025', 'static_route parameters error');
                if(!$this->V_parse->scene('static_route')->check(['s_route' => $tmp['net_segment']."|".$tmp['gateway']]))
                    Error('12025', 'static_route parameters error');
            }
        }
    }

    // 设置SNTP服务
    private function _sntpConf($conf_arr)
    {
        $ntp_enable = (int)$conf_arr['ntp_enable'] ?? 0;
        $ntp_server = (int)$conf_arr['ntp_server'] ?? '';
        $ntp_period = (int)$conf_arr['ntp_period'] ?? 0;

        // 参数校验
        $validator = new Sysconf();
        if (!$validator->scene('import_sntp')->check(compact('ntp_enable', 'ntp_period', 'ntp_server'))) {
            \Error(12025, $validator->getError());
        }

        $updateRslt = (new SysConfRepository())->updateSntpConf($ntp_enable, $ntp_server, $ntp_period);
        if ($updateRslt === false) {
            \Error(12025, 'SNTP服务配置失败！');
        }
    }

}