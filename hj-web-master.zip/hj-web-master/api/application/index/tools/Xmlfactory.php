<?php
namespace app\index\tools;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;

/**
 * 构建xml
 */
class Xmlfactory extends Controller {

    public function mwxmlDumpDoc($doc, $rootobj, $rootattrs) {
        $xmlconfig = "<?xml version=\"1.0\"?" . ">\n";
        $xmlconfig .= "<$rootobj $rootattrs>\n";
        $xmlconfig .= $this->mwxmlDumpDocSub($doc, 1);
        $xmlconfig .= "</$rootobj>\n";

        return $xmlconfig;
    }

    public function mwxmlDumpDocSub($arr, $indent) {
        $xmlconfig = "";

        $arr = $this->removeEmptyElements($arr);
        foreach ($arr as $ent => $val) {
            if (is_array($val)) {
                /* is it just a list of multiple values? */
                if (isset($val[0])) {
                    foreach ($val as $cval) {
                        if (is_array($cval)) {
                            $xmlconfig .= str_repeat("\t", $indent);
                            $xmlconfig .= "<$ent>\n";
                            $xmlconfig .= $this->mwxmlDumpDocSub($cval, $indent + 1);
                            $xmlconfig .= str_repeat("\t", $indent);
                            $xmlconfig .= "</$ent>\n";
                        } else {
                            $xmlconfig .= str_repeat("\t", $indent);
                            if ((is_bool($cval)&&($cval == true))||($cval === ""))
                                $xmlconfig .= "<$ent/>\n";
                            else if (isset($cval) && !is_bool($cval))
                                $xmlconfig .= "<$ent>" . htmlspecialchars($cval) . "</$ent>\n";
                        }
                    }
                } else if (count($val)){
                    /* it's a list */
                    $xmlconfig .= str_repeat("\t", $indent);
                    $xmlconfig .= "<$ent>\n";
                    $xmlconfig .= $this->mwxmlDumpDocSub($val, $indent + 1);
                    $xmlconfig .= str_repeat("\t", $indent);
                    $xmlconfig .= "</$ent>\n";
                }
            } else {
                if ((is_bool($val) && ($val == true)) || ($val === "")) {
                    $xmlconfig .= str_repeat("\t", $indent);
                    $xmlconfig .= "<$ent/>\n";
                } else if (isset($val) && !is_bool($val)) {
                    $xmlconfig .= str_repeat("\t", $indent);
                    $xmlconfig .= "<$ent>" . htmlspecialchars($val) . "</$ent>\n";
                }
            }
        }

        return $xmlconfig;
    }

    public function removeEmptyElements($arr){
        foreach ($arr as $idx => $val) {
            if (is_array($val)) {
                if (count($val)) {
                    $arr[$idx] = $this->removeEmptyElements($arr[$idx]);
                } else {
                    unset($arr[$idx]);
                }
            } else if ((is_bool($val) && ($val == false)) ||
                    (!is_bool($val) && !isset($val))) {
                unset($arr[$idx]);
            }
        }
        if (count($arr) == 0) {
            return NULL;//unset($arr);
        }

        return $arr;
    }

}