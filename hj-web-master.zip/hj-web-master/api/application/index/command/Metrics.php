<?php
namespace app\index\command;

use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\console\Input\Option;
use think\Db;
use app\index\tools\Udplogs;

class Metrics extends Command
{
    protected $sysflux_stat;
    protected $ipflux_stat;
    protected $last_flux_update;
    protected $redis;
    protected $udpLogs;

    protected function configure()
    {
        $this->addOption('restart', null, Option::VALUE_NONE);
        $this->setName('metrics')->setDescription('collect metrics ... ');
    }

    protected function execute(Input $input, Output $output)
    {       
        $restart = $input->getOption('restart');
        $this->udpLogs = new Udplogs();
        $pid = pcntl_fork();
        if (!$pid) {
            $p_name = 'PHP Metrics: metrics';
            $p_pid = exec("ps -ef |grep '".$p_name."' |grep -v grep | awk '{print $2}'");
            if(!empty($p_pid)){
                if ($restart) {
                    exec("kill -9 $p_pid");
                } else {
                    exit;
                }
            }
            cli_set_process_title($p_name);
            $output->writeln('Metrics process started on pid ' . posix_getpid());
            $this->metrics();
            exit;
        }

        $pid = pcntl_fork();
        if (!$pid) {
            $p_name = 'PHP Logs: collecting';
            $p_pid = exec("ps -ef |grep '".$p_name."' |grep -v grep | awk '{print $2}'");
            if(!empty($p_pid)){
                if ($restart) {
                    exec("kill -9 $p_pid");
                } else {
                    exit;
                }
            }
            cli_set_process_title($p_name);
            $output->writeln('Logs collecting process started on pid ' . posix_getpid());
            $this->logsPusher();
            exit;
        }

        $pid = pcntl_fork();
        if (!$pid) {
            $p_name = 'PHP Logs: handle';
            $p_pid = exec("ps -ef |grep '".$p_name."' |grep -v grep | awk '{print $2}'");
            if(!empty($p_pid)){
                if ($restart) {
                    exec("kill -9 $p_pid");
                } else {
                    exit;
                }
            }
            cli_set_process_title($p_name);
            $output->writeln('Logs handle process started on pid ' . posix_getpid());
            $this->logsHandle();
            exit;
        }

        $pid = pcntl_fork();
        if (!$pid) {
            $p_name = 'PHP Logs: writer';
            $p_pid = exec("ps -ef |grep '".$p_name."' |grep -v grep | awk '{print $2}'");
            if(!empty($p_pid)){
                if ($restart) {
                    exec("kill -9 $p_pid");
                } else {
                    exit;
                }
            }
            if (!$restart) {
                $this->sysinit();
            }
            cli_set_process_title($p_name);
            $output->writeln('Logs writer process started on pid ' . posix_getpid());
            $this->logsWriter();
            exit;
        }
    }

    protected function metrics() {
        $this->redis = new \Redis();
        $this->redis->pconnect('127.0.0.1');

        exec("fpcmd set_eth_info -s", $eth_config);
        $eth_config = trim($eth_config[0],"|");
        $chart_eth = [];
        foreach (explode('|', $eth_config) as $record) {
            $params = explode(' ',$record);
            $chart_eth[$params[0]] = [$params[1], $params[2]];
        }

        $this->redis->delete(array('cpu_list','memory_list','disk_list', 'interface_list', 'hoststat_list'));
        while (true) {
            $metric = $this->redis->blPop(array('cpu_list','memory_list','disk_list','interface_list','hoststat_list'), 10);
            if (!empty($metric)) {
                // CPU数据处理
                if ($metric[0] == 'cpu_list') {
                    $cpu_info = json_decode($metric[1], true);
                    $cpu_info['@timestamp'] = strtotime($cpu_info['@timestamp']);
                    $cpu_stat = [
                        'user' => $cpu_info['cmd']['cpuusage']['pct'],
                        'system' => 0,
                        'idle' => 100 - $cpu_info['cmd']['cpuusage']['pct'],
                        'time' => date('Y-m-d H:i:s', $cpu_info['@timestamp'])
                    ];
                    if (isset($last_cpu_update) && (floor($cpu_info['@timestamp'] / 10) - floor($last_cpu_update / 10) == 1)) {
                        $time_10 = floor($cpu_info['@timestamp'] / 10) * 10;
                        $cpu_stat['time'] = date('Y-m-d H:i:s', $time_10);
                        db('cpu_10')->insert($cpu_stat);
                        // 当前状态发给幻势
                        $cpu_stat['user'] = $cpu_stat['user'] + 0;
                        $this->udpLogs->sendArrLogs([$cpu_stat], "cpu_log", 5);
                    }
                    $last_cpu_update = $cpu_info['@timestamp'];
                    $res = $this->redis->hSet('dev_stat', 'cpu', json_encode($cpu_stat));
                    if($res < 0){
                        file_put_contents("/tmp/metrics_error.log", "[".date("Y-m-d H:i:s", time())."]".__LINE__." Error: metrics redis hset fail; ", FILE_APPEND);
                    }
                }
                // 内存数据处理
                if ($metric[0] == 'memory_list') {
                    $memory_info = json_decode($metric[1], true);
                    $memory_info['@timestamp'] = strtotime($memory_info['@timestamp']);
                    $memory_stat = [
                        'used' => $memory_info['system']['memory']['used']['bytes'],
                        'total' => $memory_info['system']['memory']['total'],
                        'time' => date('Y-m-d H:i:s', $memory_info['@timestamp'])
                    ];
                    if ($memory_info['@timestamp'] % 10 == 0) {
                        db('memory_10')->insert($memory_stat);
                        // 当前状态发给幻势
                        $this->udpLogs->sendArrLogs([$memory_stat], "memory_log", 5);
                    }
                    $res = $this->redis->hSet('dev_stat', 'memory', json_encode($memory_stat));
                    if($res < 0){
                        file_put_contents("/tmp/metrics_error.log", "[".date("Y-m-d H:i:s", time())."]".__LINE__." Error: metrics redis hset fail; ", FILE_APPEND);
                    }
                }
                // 硬盘数据处理
                if ($metric[0] == 'disk_list') {
                    $disk_info = json_decode($metric[1], true);
                    $disk_info['@timestamp'] = strtotime($disk_info['@timestamp']);
                    $disk_stat = [
                        'used' => $disk_info['system']['fsstat']['total_size']['used'],
                        'total' => $disk_info['system']['fsstat']['total_size']['total'],
                        'time' => date('Y-m-d H:i:s', $disk_info['@timestamp'])
                    ];
                    if ($disk_info['@timestamp'] % 10 == 0) {
                        db('disk_10')->insert($disk_stat);
                        // 当前状态发给幻势
                        $this->udpLogs->sendArrLogs([$disk_stat], "disk_log", 5);
                    }
                    $res = $this->redis->hSet('dev_stat', 'disk', json_encode($disk_stat));
                    if($res < 0){
                        file_put_contents("/tmp/metrics_error.log", "[".date("Y-m-d H:i:s", time())."]".__LINE__." Error: metrics redis hset fail; ", FILE_APPEND);
                    }
                }
                // 网卡信息
                if ($metric[0] == 'interface_list') {
                    $interface_info = json_decode($metric[1], true);
                    $interface_info['@timestamp'] = strtotime($interface_info['@timestamp']);
                    $interface_stat = [
                        'in' => $interface_info['system']['network']['in'],
                        'out' => $interface_info['system']['network']['out'],
                        'time' => $interface_info['@timestamp']
                    ];
                    $ifname = $interface_info['system']['network']['name'];
                    if (isset($chart_eth[$ifname]) && isset($interface_info_last) && isset($interface_info_last[$ifname])) {
                        exec("ifconfig $ifname", $ifinfo);
                        $ifinfo = @preg_split("/\s+/", $ifinfo[0]);
                        exec("cat /sys/class/net/$ifname/carrier 2>&1",$is_connect);
                        $interface_stat['name'] = $ifname;
                        $interface_stat['desc'] = $chart_eth[$ifname][1];
                        $interface_stat['desc_no'] = $chart_eth[$ifname][0];
                        $interface_stat['up'] = isset($is_connect[0]) ? $is_connect[0] : 0;;
                        // 网口插拔日志
                        $interface_info['up'] = isset($is_connect[0]) ? $is_connect[0] : 0;;
                        if (isset($interface_info_last[$ifname]['up']) && $interface_stat['up'] != $interface_info_last[$ifname]['up']) {
                            $res = $this->redis->rPush('event_log_list',json_encode([
                                'type' => $interface_stat['up'] == 1 ? 1 : 2,
                                'content' => $interface_stat['desc'],
                                'time' => date('Y-m-d H:i:s', time())
                            ]));
                            if($res < 0){
                                file_put_contents("/tmp/metrics_error.log", "[".date("Y-m-d H:i:s", time())."]".__LINE__." Error: metrics redis rpush fail; ", FILE_APPEND);
                            }
                        }
                        $interface_stat['macaddr'] = $ifinfo[4];
                        $interface_stat['in']['Bps'] = $interface_stat['in']['bytes'] - $interface_info_last[$ifname]['system']['network']['in']['bytes'];
                        $interface_stat['out']['Bps'] = $interface_stat['out']['bytes'] - $interface_info_last[$ifname]['system']['network']['out']['bytes'];
                        $res = $this->redis->hSet('interface_stat', $interface_stat['desc'], json_encode($interface_stat));
                        if($res < 0){
                            file_put_contents("/tmp/metrics_error.log", "[".date("Y-m-d H:i:s", time())."]".__LINE__." Error: metrics redis hset fail; ", FILE_APPEND);
                        }
                        $interface_info_last[$ifname]['up'] = isset($is_connect[0]) ? $is_connect[0] : 0;;
                        $ifinfo = [];
                        $is_connect = [];
                    }
                    $interface_info_last[$interface_info['system']['network']['name']] = $interface_info;
                }
                // 主机信息
                if ($metric[0] == 'hoststat_list') {
                    $hoststat_info = json_decode($metric[1], true);
                    $hoststat_info['@timestamp'] = strtotime($hoststat_info['@timestamp']);
                    $hosts = trim($hoststat_info['cmd']['hosts']['hoststat'], "|\n");
                    $hoststat = [];
                    if (!empty($hosts)) {
                        $hosts = explode('|', $hosts);
                        // $this->redis->delete('hosts_stat');
                        foreach ($hosts as $host) {
                            $params = explode(' ', $host);
                            $hoststat_row = [
                                'inner_port' => $params[0],
                                'outer_port' => $params[1],
                                'rip' => $params[2],
                                'vip' => $params[3],
                                'wip' => $params[4],
                                'name' => $params[5],
                                'vlanid' => $params[6],
                                'groupid' => $params[7],
                                'time' => $params[8],
                                'ttl' => $params[9],
                                'gateway_ip' => $params[10],
                                'dhcp_server_ip' => $params[11],
                                'mac' => $params[12],
                                'eth_mac' => $params[13],
                                'gateway_mac' => $params[14],
                                'up_speed' => $params[15],
                                'down_speed' => $params[16],
                                'connects' => $params[17],
                                'total_bytes' => $params[18],
                                'sentinel'  => $params[19],
                                'timestamp' => $hoststat_info['@timestamp']
                            ];
                            // $res = $this->redis->hSet('hosts_stat', $hoststat_row['mac'], json_encode($hoststat_row));
                            // if($res < 0){
                            //     file_put_contents("/tmp/metrics_error.log", "[".date("Y-m-d H:i:s", time())."]".__LINE__." Error: metrics redis hset fail; ", FILE_APPEND);
                            // }
                            $hoststat[] = $hoststat_row;
                        }
                    } else {
                        // $this->redis->delete('hosts_stat');
                    }

                    $res = $this->redis->set('hosts_stat_col', json_encode($hoststat));
                    if($res < 0){
                        file_put_contents("/tmp/metrics_error.log", "[".date("Y-m-d H:i:s", time())."]".__LINE__." Error: metrics redis hset fail; ", FILE_APPEND);
                    }
                    $host_count = count($hoststat);
                    $total_connects = array_sum(array_column($hoststat, 'connects'));
                    $this->redis->hSet('dev_stat', 'host_count', $host_count);
                    $this->redis->hSet('dev_stat', 'total_connects', $total_connects);
                    if ($hoststat_info['@timestamp'] % 10 == 0) {
                        db('hostcount_10')->insert([
                            'count' => $host_count,
                            'time' => date('Y-m-d H:i:s', $hoststat_info['@timestamp'])
                        ]);
                        // 发送主机信息表至日志服务器
                        if ($hoststat_info['@timestamp'] % 30 == 0)
                        {
                            $this->udpLogs->sendArrLogs($hoststat, "host_info", 2);
                        }
                    }
                }
            }
        }

    }

    protected function logsPusher() {
        $this->redis = new \Redis();
        $this->redis->pconnect('127.0.0.1');

        if(!($sock = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP))) {
            $errorcode = socket_last_error();
            $errormsg = socket_strerror($errorcode);
            die("Couldn't create socket: [$errorcode] $errormsg \n");
        }

        if( !socket_bind($sock, '0.0.0.0' , 30000) ) {
            $errorcode = socket_last_error();
            $errormsg = socket_strerror($errorcode);
            die("Could not bind socket : [$errorcode] $errormsg \n");
        }

        socket_set_option($sock, SOL_SOCKET, SO_RCVTIMEO, ['sec'=>10, 'usec'=>0]);

        while (true) {
            $content = NULL;
            $content = socket_read($sock,1024);
            $log_tag = substr($content,0,5);
            if($log_tag === "<174>"){
                $content = substr($content,5);
            } else {
                continue;
            }
            // 日志解析
            if (!empty($content)) {
                $log = json_decode($content, true);
                if ($log['log_type'] == 1) {
                    if ($log['groupid'] == -1 || $log['groupid'] == 0) {
                        $log['attack_source'] = $log['attack_ip'];
                    } else {
                        $log['attack_source'] = $log['attack_mac'];
                    }
                    $log_hash = $log['sub_type'].'_'.$log['attack_source'].'_'.$log['groupid'].'_'.(floor($log['time']/3600) * 3600);
                    if ($this->redis->hExists('attack_log_stat', $log_hash)) {
                        $attack_stat = $this->redis->hGet('attack_log_stat', $log_hash);
                        $attack_stat = json_decode($attack_stat, true);
                        $attack_stat['end_time'] = $log['time'];
                        $attack_stat['count'] += 1; 
                        $res = $this->redis->hSet('attack_log_stat', $log_hash, json_encode($attack_stat));
                        if($res < 0){
                            file_put_contents("/tmp/metrics_error.log", "[".date("Y-m-d H:i:s", time())."]".__LINE__." Error: metrics redis hset fail; ", FILE_APPEND);
                        }
                    } else {
                        $attack_stat['start_time'] = $log['time'];
                        $attack_stat['end_time'] = $log['time'];
                        $attack_stat['count'] = 1;
                        $res = $this->redis->hSet('attack_log_stat', $log_hash, json_encode($attack_stat));
                        if($res < 0){
                            file_put_contents("/tmp/metrics_error.log", "[".date("Y-m-d H:i:s", time())."]".__LINE__." Error: metrics redis hset fail; ", FILE_APPEND);
                        }
                    }
                    $res = $this->redis->rPush('attack_log_list', json_encode($log));
                    if($res < 0){
                        file_put_contents("/tmp/metrics_error.log", "[".date("Y-m-d H:i:s", time())."]".__LINE__." Error: metrics redis rpush fail; ", FILE_APPEND);
                    }
                } elseif ($log['log_type'] == 4) {
                    $res = $this->redis->rPush('offline_log_list', json_encode($log));
                    if($res < 0){
                        file_put_contents("/tmp/metrics_error.log", "[".date("Y-m-d H:i:s", time())."]".__LINE__." Error: metrics redis hset fail; ", FILE_APPEND);
                    }
                } elseif ($log['log_type'] == 5) {
                    $res = $this->redis->rPush('block_log_list', json_encode($log));
                    if($res < 0){
                        file_put_contents("/tmp/metrics_error.log", "[".date("Y-m-d H:i:s", time())."]".__LINE__." Error: metrics redis hset fail; ", FILE_APPEND);
                    }
                } elseif ($log['log_type'] == 7) {
                    $res = $this->redis->rPush('ipvary_log_list', json_encode($log));
                    if($res < 0){
                        file_put_contents("/tmp/metrics_error.log", "[".date("Y-m-d H:i:s", time())."]".__LINE__." Error: metrics redis hset fail; ", FILE_APPEND);
                    }
                } else {
                }
            }
        }
    }

    protected function logsHandle() {
        $this->redis = new \Redis();
        $this->redis->pconnect('127.0.0.1');
        $this->redis->delete(array('attack_log_list','attack_log_stat'));
        $attack_logs = [];
        $start_time = time();
        while (true) {
            $log = $this->redis->blPop(
                array('attack_log_list', 'offline_log_list', 'block_log_list', 'ipvary_log_list', 's_list', 'event_log_list', 'user_info', 'oper_log_list'),
                5
            );
            if (!empty($log)) {
                if ($log[0] == 'attack_log_list') {
                    $log = json_decode($log[1], true);
                    $attack_logs[] = [
                        'attack_source' => $log['attack_source'],
                        'attack_type'  =>  $log['sub_type'],
                        'attack_ip' =>  $log['attack_ip'],
                        'target_ip'   =>  $log['response_ip'],
                        'target_port'   =>  $log['response_port'],
                        'groupid'   =>  $log['groupid'],
                        'attack_time'   =>  date('Y-m-d H:i:s', $log['time'])
                    ];
                } elseif ($log[0] == 'offline_log_list') {
                    $log = json_decode($log[1], true);
                    $log = [
                        'groupid'   =>  $log['groupid'],
                        'mac'   =>  $log['mac'],
                        'rip'   =>  $log['rip'],
                        'wip'   =>  $log['wip'],
                        'online_time'   =>  date('Y-m-d H:i:s', $log['online_time']),
                        'offline_time'  =>  date('Y-m-d H:i:s', $log['time'])
                    ];
                    Db::table('offline_log')->insert($log);
                    // 发送日志
                    $this->udpLogs->sendArrLogs([$log], 'offline_log', 5);
                } elseif ($log[0] == 'block_log_list') {
                    $_log = json_decode($log[1], true);
                    $log = [
                        'source'   =>  $_log['attack_source'],
                        'type'   =>  isset($_log['type']) ? $_log['type'] : 1,
                        'uid'   =>  isset($_log['uid']) ? $_log['uid'] : 0,
                        'time'  =>  date('Y-m-d H:i:s', $_log['time'])
                    ];
                    Db::table('block_log')->insert($log);

                    $this->udpLogs->sendArrLogs([$log], 'block_log');

                    // 为log增加hash_id、start_time等标记字段，封解记录成对
                    if ($log['type'] == 0) {
                        $block_item = Db::table('block_log')
                            ->where(['source'=>$log['source'], 'type'=>1])
                            ->order('time desc')
                            ->find();
                        $log['log_id'] = $log['source'] . '_' . $block_item['time'];
                        $log['start_time'] = $block_item['time'];
                        $log['end_time'] = $log['time'];
                        $log['duration'] = strtotime($log['time']) - strtotime($block_item['time']);
                    } else {
                        $log['log_id'] = $log['source'] . '_' . $log['time'];
                        $log['start_time'] = $log['time'];
                        $log['end_time'] = $log['time'];
                        $log['duration'] = 0;
                    }
                    // 发送日志
                    $this->udpLogs->sendArrLogs([$log], 'block_stat', 5);
                } elseif ($log[0] == 'ipvary_log_list') {
                    $log = json_decode($log[1], true);
                    $log = [
                        'mac'   =>  $log['mac'],
                        'groupid'   =>  $log['groupid'],
                        'rip'   =>  $log['rip'],
                        'vip'   =>  $log['vip'],
                        'wip'   =>  $log['wip'],
                        'online_time'   =>  date('Y-m-d H:i:s', $log['online_time']),
                        'vary_time' =>  date('Y-m-d H:i:s', $log['time'])
                    ];
                    Db::table('ipvary_log')->insert($log);
                } elseif ($log[0] == 'oper_log_list') { // 操作日志
                    $log = json_decode($log[1], true);
                    $data = [
                        'uid'      => $log['uid'],
                        'type'     => $log['type'],
                        'subtype'  => $log['subtype'],
                        'clientip' => $log['clientip'],
                        'content'  => $log['content'],
                        'result'   => $log['result'],
                        'time'     => $log['time']
                    ];
                    Db::table('oper_log')->insert($data);

                    $this->udpLogs->sendArrLogs([$log], 'action_log', 5);
                } elseif ($log[0] == 'event_log_list') {
                    $log = json_decode($log[1], true);
                    Db::table('event_log')->insert($log);

                    $this->udpLogs->sendArrLogs([$log], 'event_log', 5);
                } elseif ($log[0] == 'user_info') {
                    $log = json_decode($log[1], true);

                    $this->udpLogs->sendArrLogs([$log], 'user_info', 5);
                }
            }
            $end_time = time();
            if ((count($attack_logs) >= 2500) || (count($attack_logs) && ($end_time - $start_time >= 5))) {
                $this->saveAttackLogs($attack_logs);
                $this->udpLogs->sendArrLogs($attack_logs, 'attack_log', 6);
                $attack_logs = [];
                $start_time = $end_time;
            }
        }
    }

    protected function logsWriter() {
        $this->redis = new \Redis();
        $this->redis->pconnect('127.0.0.1');
        $counter = 0;
        // 每两秒更新状态数据到mysql
        while (true) {
            try {
                $attack_stat = $this->redis->hGetAll('attack_log_stat');
                $hour_time_now = floor(time()/3600) * 3600;
                foreach ($attack_stat as $key => $stat) {
                    $hash_key = $key;
                    $key = explode('_', $key);
                    $hour_time = $key[3];
                    $stat = json_decode($stat, true);
                    $key = [
                        'attack_type'   =>  $key[0],
                        'attack_source' =>  $key[1],
                        'groupid'   =>  $key[2],
                        'count'    =>   $stat['count'],
                        'start_time'    =>  date('Y-m-d H:i:s', $stat['start_time']),
                        'end_time'  =>  date('Y-m-d H:i:s', $stat['end_time'])
                    ];
                    $stat = Db::table('attack_log_stat')->where([
                        'attack_type'   =>  $key['attack_type'],
                        'attack_source' =>  $key['attack_source'],
                        'groupid'   =>  $key['groupid'],
                        'start_time'    =>  $key['start_time']
                    ])->find();
                    if (!empty($stat)) {
                        if ($stat['count'] != $key['count']) {
                            $key['id'] = $stat['id'];
                            Db::table('attack_log_stat')->update($key);
                            $this->udpLogs->sendArrLogs([array_merge(['log_id'=>$hash_key], $key)], 'attack_log_stat', 5);
                        }
                    } else {
                        Db::table('attack_log_stat')->insert($key);
                        $this->udpLogs->sendArrLogs([array_merge(['log_id'=>$hash_key], $key)], 'attack_log_stat', 5);
                    }
                    if ($hour_time_now > $hour_time) {
                        $this->redis->hDel('attack_log_stat', $hash_key);
                    }
                }
            } catch (\Error $e) {
                print_r($e);
            }
            if ($counter == 15) {
                $counter = 0;
                $this->sendLocalConf();
            }
            sleep(2);
            $counter++;
        }
    }

    protected function sysinit() {
        Db::table('event_log')->insert([
            'type' => 6,
            'content' => 'boot',
            'time' => date('Y-m-d H:i:s', time())
        ]);
        $is_init = Db::table('event_log')->where(['type'=>5])->find();
        if (empty($is_init)) {
            Db::table('event_log')->insert([
                'type' => 5,
                'content' => 'init',
                'time' => date('Y-m-d H:i:s', time())
            ]);
        }
    }

    protected function saveAttackLogs($attack_logs = []) {
        $insert_start_str = "INSERT INTO SwitchDB.attack_log (attack_source,attack_type,attack_ip,target_ip,target_port,groupid,attack_time) VALUES ";
        $insert_str = "";
        foreach ($attack_logs as $a) {
            if (empty($insert_str)) {
                $insert_str .= $insert_start_str."('".$a['attack_source']."','".$a['attack_type']."','".$a['attack_ip']."','".$a['target_ip']."','".$a['target_port']."','".$a['groupid']."','".$a['attack_time']."')";
            } else {
                $insert_str .= ",('".$a['attack_source']."','".$a['attack_type']."','".$a['attack_ip']."','".$a['target_ip']."','".$a['target_port']."','".$a['groupid']."','".$a['attack_time']."')";
            }
        }
        if (!empty($insert_str)) {
            list($t1, $t2) = explode(' ', microtime());
            $millisecond = (float)sprintf('%.0f',(floatval($t1)+floatval($t2))*1000);
            $file_name = "/var/tmp/attack_logs_sql_" . $millisecond;
            $insert_file = fopen($file_name,"w");
            fwrite($insert_file, $insert_str);
            fclose($insert_file);
            exec("nohup mysql -uroot -pveda --default-character-set=UTF8 SwitchDB < $file_name && rm -rf $file_name > /dev/null 2>&1 &");
        }
    }

    protected function sendLocalConf() {
        $mac_info = Db::table('mac_info')->select();
        $passthrough = Db::table('net_mac_through')->select();
        $user_info = Db::table('user')->column('u_id,user_id,user_group,real_name,department,email,reg_time');

        $uptime = $this->redis->info();
        $uptime = $uptime['uptime_in_seconds'];

        exec("fpcmd get_trap_nodes -s", $trap);
        $trap = explode(" ", $trap[0]);
        $server_mask = intval($trap[0]);
        $server_trap = intval($trap[1]);

        $net_change_rate = Db::table('net_config')->where(['conf_type' => 7])->find();
        $net_change_rate = $net_change_rate['conf_value'];

        $sysstat = ['uptime'=>$uptime, 'server_mask'=>$server_mask, 'server_trap'=>$server_trap, 'netvary_rate'=>$net_change_rate];

        $this->udpLogs->sendArrLogs($mac_info, 'mac_info');
        $this->udpLogs->sendArrLogs($passthrough, 'passthrough');
        $this->udpLogs->sendArrLogs([$sysstat], 'sys_stat');
        $this->udpLogs->sendArrLogs($user_info, 'user_info');
    }

}