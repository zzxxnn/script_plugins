<?php
namespace app\index\command;

use app\index\tools\Makeconfjson;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\DB;

class Reload extends Command
{
    protected function configure()
    {
        $this->setName('reload')->setDescription('reload the config write in shared memory. ');
    }

    protected function execute(Input $input, Output $output)
    {

        $output->writeln('Reload ... ');
        $result = $this->buildConfig();
        $result ? $output->writeln('Reload success!') : $output->writeln('Reload fail!');
    }

    /**
     * 调用builder构建所有配置写入共享内存
     * @access protected
     * @param void
     * @return void
     */
    protected function buildConfig(){
        $C_maker = new Makeconfjson;
        $json_content = $C_maker->make();
        $result = WriteInShm($json_content);
        if($result){
            exec("fpcmd load_sys_config");
            exec("nohup fpcmd alter_vnetwork >/dev/null 2>&1 &"); // 虚拟网络变换
            return true;
        }else{
            return false;
        }
    }

}

    