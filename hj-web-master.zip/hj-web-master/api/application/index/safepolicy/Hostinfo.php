<?php
namespace app\index\safepolicy;
use app\index\model\MacInfo;
use app\index\model\MacAllow;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;
use think\Validate;

/**
 * 主机备注 分层控制器
 */
class Hostinfo extends Controller {

    protected $V_safepolicy; 
    protected $M_mac_info; 
    
    public function _initialize(){
        $this->V_safepolicy = Loader::validate('Safepolicy');
        $this->M_mac_info = new MacInfo;
    }

    //【接口】获取查询
    public function get(){
        if(!$this->V_safepolicy->scene('get_mac_info')->check(input()))
            Error($this->V_safepolicy->getError());

        $page = empty(input('get.page')) ? 1 : input('get.page');
        $row = empty(input('get.row')) ? 10 : input('get.row');
        $by = empty(input('get.by')) ? 'id' : input('get.by');
        $order = empty(input('get.order')) ? 'desc' : input('get.order');
        $gid = input('get.gid')=="" || is_null(input('get.gid')) ? null : input('get.gid');
        $mac = input('get.mac')=="" || is_null(input('get.mac')) ? null : input('get.mac');
        $desc = input('get.description')=="" || is_null(input('get.description')) ? null : input('get.description');
        $counts = NULL;$datas = [];

        $counts = $this->M_mac_info->countMacInfo($gid, $mac, $desc);
        $datas = $counts == 0 ? [] : $this->M_mac_info->selectMacInfoPages($page, $row, $by, $order, $gid, $mac, $desc);
        if(empty($datas))
            return ["data" => $datas, "count" => $counts];

        $mac_allow_arr = $this->_getMacAllow(); // 匹配主机准入
        foreach($datas as &$tmp){
            $tmp['filter'] = in_array(FormatMac($tmp['mac']), $mac_allow_arr) ? 1 : 0;
        }
        return ["data" => $datas, "count" => $counts];
        
    }

    //【接口】添加操作
    public function add(){
        if(!$this->V_safepolicy->scene('add_mac_info')->check(['add_m_i' => input("post.3")]))
            Error($this->V_safepolicy->getError());

        $tmp_arr = explode("|",input("post.3"));
        $conf_map = [
            "gid"       =>  $tmp_arr[0],
            "mac"       =>  FormatMac($tmp_arr[1]),
            "description" =>  $tmp_arr[2]
        ];
        
        $result = $this->M_mac_info->where(["mac" => $tmp_arr[1]])->select(); // 验证记录是否存在相同配置
        if(count($result) > 0)
            Error("14002");

        $this->M_mac_info->data($conf_map);
        $result = $this->M_mac_info->save();
        if($result <= 0){
            Error("20001");
        }
    }

    //【接口】更新操作
    public function update(){
        if(!$this->V_safepolicy->scene('update_mac_info')->check(['update_m_i' => input("post.3")]))
            Error($this->V_safepolicy->getError());

        $tmp_arr = explode("|", input("post.3"));
        $conf_id = $tmp_arr[0];
        $conf_map = [
            "gid"       =>  $tmp_arr[1],
            "description" =>  $tmp_arr[2]
        ];

        $result = $this->M_mac_info->get($conf_id); // 验证记录是否存在
        if(is_null($result))
            Error("14001");

        $result = $this->M_mac_info->save($conf_map, ['id' => $conf_id]);
        if($result < 0){
            Error("20001");
        }
    }

    //【接口】删除操作
    public function del(){
        if(!$this->V_safepolicy->scene('del_mac_info')->check(['ids' => input("post.3")]))
            Error($this->V_safepolicy->getError());

        $ids_arr = explode(",", input("post.3"));
        $result = $this->M_mac_info->destroy($ids_arr);
        if($result < 0){
            Error("20001");
        }
    }

    //【接口】导入excel
    public function upload(){
        $path = UploadExcel();
        $excel_fac = controller('Excelfactory', 'tools');
        $datas = $excel_fac->praseExcel($path);

        if(input('get.rewrite' == 'true')){
            $conf_map = $this->_praseHostInfo($datas, true);
            $this->M_mac_info->deleteAllMacInfo(); 
        }else{
            $conf_map = $this->_praseHostInfo($datas, false);
        }
        exec("rm -rf ".$path);

        $result = $this->M_mac_info->saveAll($conf_map);
        if($result < 0){
            Error("20001");
        }
    }

    //【接口】导出Excel
    public function export(){
        RecordOperLog(13, 4); // 记录操作日志

        $data = $this->M_mac_info->selectAllMacInfo();
        $excel_fac = controller('Excelfactory', 'tools');
        $excel_fac->exportExcel('mac_info', $data);
    }

    //【接口】快捷修改注解备注
    public function quickSet(){
        if(!$this->V_safepolicy->scene('quick_edit_mac_info')->check(['edit_m_i' => input("post.3")]))
            Error($this->V_safepolicy->getError());

        $param_arr = explode("|", input('post.3'));
        $mac = $param_arr[0];
        $note = $param_arr[1];
        $result = $this->M_mac_info->get(['mac' => $mac]);
        if(is_null($result)){ //添加
            if($note == ''){
                return ;
            }
            $this->M_mac_info->data([
                "gid"  =>  0,
                "mac"  =>  FormatMac($mac),
                "description"  =>  $note
            ]);
            $res = $this->M_mac_info->save();
        }elseif($note == ''){ // 备注为空则删除主机备注
            $id = $result->id;
            $res = $this->M_mac_info->destroy($id);
        }else{ // 修改
            $id = $result->id;
            $res = $this->M_mac_info->save(["description" => $note], ['id' => $id]);
        }

        if($res <= 0)
            Error('20001');
    }

    //【方法】获取准入主机
    private function _getMacAllow(){
        $M_mac_allow = new MacAllow;
        $tmp_data = $M_mac_allow->selectAllMacAllow();
        $mac_allow = array_map(function($tmp){
            return $tmp['mac'];
        },$tmp_data);
        return $mac_allow;
    }

    // 将解析excel出的数据进行结构整理与筛选
    private function _praseHostInfo($datas, $rewrite){
        if(!$rewrite){
            $data = $this->M_mac_info->selectAllMacInfo();
            $already_mac = array_map(function ($tmp) {
                return $tmp['mac'];
            },$data);
        }else{
            $already_mac = [];
        }

        $conf_map = [];
        foreach($datas as $tmp){
            if(is_null($tmp[1]) || is_null($tmp[2])){
                Error('12024');
            }

            $conf = [];
            foreach($tmp as $k => $t){
                if($k == 0 && !is_null($t) && !(Validate::is($t, "integer") && Validate::egt($t, 0, null)) ){
                    Error('12024');
                }
                if($k == 1 && !CheckMac($t)){
                    Error('12006');
                }
                if($k == 2 && !(Validate::is($t, "chsDash") && strlen($t)<=32 )){
                    Error('12014');
                }
            }
            $conf = [
                'gid' => is_null($tmp[0]) ? 0 : $tmp[0],
                'mac' => FormatMac($tmp[1]),
                'description' => $tmp[2]
            ];

            $exist_flag = false;
            foreach($already_mac as $mac){
                if($conf['mac'] == $mac){
                    $exist_flag = true;
                    break;
                }
                continue;
            }

            if(!$exist_flag){
                $conf_map[] = $conf;
                $already_mac[] = $conf['mac'];
            }
        }
        return $conf_map;
    }

}