<?php
namespace app\index\safepolicy;
use app\index\model\ServerMask;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;

/**
 * 全息伪装 分层控制器
 */
class Holomask extends Controller {

    protected $V_safepolicy; 
    protected $M_server_mask; 
    
    public function _initialize(){
        $this->V_safepolicy = Loader::validate('Safepolicy');
        $this->M_server_mask = new ServerMask;
    }

    //【接口】获取查询
    public function get(){
        if(!$this->V_safepolicy->scene('get_holo_mask')->check(input()))
            Error($this->V_safepolicy->getError());

        $page = empty(input('get.page')) ? 1 : input('get.page');
        $row = empty(input('get.row')) ? 10 : input('get.row');
        $by = empty(input('get.by')) ? 'id' : input('get.by');
        $order = empty(input('get.order')) ? 'desc' : input('get.order');
        $counts = NULL;$datas = [];

        $counts = $this->M_server_mask->countServerMask();
        $datas = $counts == 0 ? [] : $this->M_server_mask->selectServerMaskPages($page, $row, $by, $order);
        
        return ["data" => $datas, "count" => $counts];
    }

    //【接口】添加操作
    public function add(){
        if(!$this->V_safepolicy->scene('add_holo_mask')->check(['add_h_m' => input("post.7")]))
            Error($this->V_safepolicy->getError());

        $tmp_arr = explode("|",input("post.7"));
        $conf_map = [
            "r_ip"      =>  $tmp_arr[1],
            "v_ip"      =>  $tmp_arr[2],
            "vlan_id"   =>  $tmp_arr[3],
            "group_id"  =>  $tmp_arr[4]
        ];

        $result = $this->M_server_mask->where($conf_map)->select(); // 验证记录是否存在相同配置
        if(count($result) > 0)
            Error("14002");

        $conf_map["name"] = $tmp_arr[0];
        $this->M_server_mask->data($conf_map);
        $result = $this->M_server_mask->save();
        if($result <= 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】更新操作
    public function update(){
        if(!$this->V_safepolicy->scene('update_holo_mask')->check(['update_h_m' => input("post.7")]))
            Error($this->V_safepolicy->getError());

        $tmp_arr = explode("|", input("post.7"));
        $conf_id = $tmp_arr[0];
        $conf_map = [
            "r_ip"      =>  $tmp_arr[2],
            "v_ip"      =>  $tmp_arr[3],
            "vlan_id"   =>  $tmp_arr[4],
            "group_id"  =>  $tmp_arr[5]
        ];

        $result = $this->M_server_mask->get($conf_id); // 验证记录是否存在
        if(is_null($result))
            Error("14001");

        $result = $this->M_server_mask->selectSameRowNoThisId($conf_id, $conf_map); // 验证记录是否重复
        if(!is_null($result))
            Error("14002");

        $conf_map["name"] = $tmp_arr[1];
        $result = $this->M_server_mask->save($conf_map, ['id' => $conf_id]);
        if($result < 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】删除操作
    public function del(){
        if(!$this->V_safepolicy->scene('del_holo_mask')->check(['ids' => input("post.7")]))
            Error($this->V_safepolicy->getError());

        $ids_arr = explode(",", input("post.7"));
        $result = $this->M_server_mask->destroy($ids_arr);
        if($result < 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    // 构建cli命令
    private function _toCli(){
        ExcuteExec("fpcmd server_pretend -f"); // 清空之前所有配置

        $data = $this->M_server_mask->selectAllServerMask();
        if(empty($data)){
            SyncTimestampUpdate(); // 更新配置同步时间戳            
            return ;
        }
        foreach($data as $tmp){
            ExcuteExec("fpcmd server_pretend -i -r ".$tmp['r_ip']." -g ".$tmp['group_id']." -v ".$tmp['vlan_id']." -vs ".$tmp['v_ip']);
        }
        
        SyncTimestampUpdate(); // 更新配置同步时间戳
        
    }

}