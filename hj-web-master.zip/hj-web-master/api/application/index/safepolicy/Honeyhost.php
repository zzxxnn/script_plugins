<?php
namespace app\index\safepolicy;
use app\index\model\HoneyPot;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;

/**
 * 蜜罐主机 分层控制器
 */
class Honeyhost extends Controller {

    protected $V_safepolicy; 
    protected $M_honey_pot; 
    
    public function _initialize(){
        $this->V_safepolicy = Loader::validate('Safepolicy');
        $this->M_honey_pot = new HoneyPot;
    }

    //【接口】获取查询
    public function get(){
        if(!$this->V_safepolicy->scene('get_honey_pot')->check(input()))
            Error($this->V_safepolicy->getError());

        $page = empty(input('get.page')) ? 1 : input('get.page');
        $row = empty(input('get.row')) ? 10 : input('get.row');
        $by = empty(input('get.by')) ? 'id' : input('get.by');
        $order = empty(input('get.order')) ? 'desc' : input('get.order');
        $counts = NULL;$datas = [];

        $counts = $this->M_honey_pot->countHoneyPot();
        $datas = $counts == 0 ? [] : $this->M_honey_pot->selectHoneyPotPages($page, $row, $by, $order);

        return ["data" => $datas, "count" => $counts];
    }

    //【接口】添加操作
    public function add(){
        if(!$this->V_safepolicy->scene('add_honey_pot')->check(['add_h_pot' => input("post.2")]))
            Error($this->V_safepolicy->getError());

        $tmp_arr = explode("|",input("post.2"));
        $conf_map = [
            "v_port"    =>  $tmp_arr[0],
            "h_ip"      =>  $tmp_arr[1],
            "h_port"    =>  $tmp_arr[2],
        ];

        $result = $this->M_honey_pot->where($conf_map)->select(); // 验证记录是否存在相同配置
        if(count($result) > 0)
            Error("14002");

        $this->M_honey_pot->data($conf_map);
        $result = $this->M_honey_pot->save();
        if($result <= 0){
            Error("20001");
        }

        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】删除操作
    public function del(){
        if(!$this->V_safepolicy->scene('del_honey_pot')->check(['ids' => input("post.2")]))
            Error($this->V_safepolicy->getError());

        $ids_arr = explode(",", input("post.2"));
        $result = $this->M_honey_pot->destroy($ids_arr);
        if($result < 0){
            Error("20001");
        }

        if($result > 0){
            $this->_toCli();
        }
    }

    // 构建cli命令
    private function _toCli(){
        ExcuteExec("fpcmd honey_pot -f"); // 清空之前所有配置

        $data = $this->M_honey_pot->selectAllHoneyPot();
        if(empty($data)){
            SyncTimestampUpdate(); // 更新配置同步时间戳            
            return ;
        }
        foreach($data as $tmp){
            ExcuteExec("fpcmd honey_pot -i -vp ".$tmp['v_port']." -hi ".$tmp['h_ip']." -hp ".$tmp['h_port']);
        }
        
        SyncTimestampUpdate(); // 更新配置同步时间戳
    }

}