<?php
namespace app\index\safepolicy;
use app\index\model\AccessSt as AccessStrategy;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;

/**
 * 应用访问策略 分层控制器
 */
class Accessst extends Controller {

    protected $V_safepolicy; 
    protected $M_access_st; 
    
    public function _initialize(){
        $this->V_safepolicy = Loader::validate('Safepolicy');
        $this->M_access_st = new AccessStrategy;
    }

    //【接口】获取查询
    public function get(){
        if(!$this->V_safepolicy->scene('get_access_st')->check(input()))
            Error($this->V_safepolicy->getError());

        $page = empty(input('get.page')) ? 1 : input('get.page');
        $row = empty(input('get.row')) ? 10 : input('get.row');
        $by = empty(input('get.by')) ? 'id' : input('get.by');
        $order = empty(input('get.order')) ? 'desc' : input('get.order');
        $counts = NULL;$datas = [];

        $counts = $this->M_access_st->countAccessSt();
        $datas = $counts == 0 ? [] : $this->M_access_st->selectAccessStPages($page, $row, $by, $order);

        exec("fpcmd access_strategy -s", $result, $status);
        if($status !== 0){
            Error("20002", "error: fpcmd access_strategy -s");
        }
        if(!empty($result)){
            $matching_counts = explode("|", trim($result[0], "|"));
            $counts_arr = [];
            foreach($matching_counts as $tmp){
                $tmp_arr = explode(" ", $tmp);
                $counts_arr[$tmp_arr[0]] = $tmp_arr[1];
            }
        }

        foreach($datas as &$tmp){
            $tmp['matching_counts'] = isset($counts_arr[$tmp['id']]) ? (int)$counts_arr[$tmp['id']] : 0; //取得统计次数
        }
        return ["data" => $datas, "count" => $counts];
    }

    //【接口】添加操作
    public function add(){
        if(!$this->V_safepolicy->scene('add_access_st')->check(['add_acs_st' => input("post.10")]))
            Error($this->V_safepolicy->getError());

        $tmp_arr = explode("|",input("post.10"));
        $conf_map = [
            "protocol_id" =>  $tmp_arr[1],
            "s_port"      =>  $tmp_arr[2],
            "d_port"      =>  $tmp_arr[3],
            "effect_time" =>  $tmp_arr[4]
        ];
        $result = $this->M_access_st->where($conf_map)->select(); // 验证记录是否存在相同配置
        if(count($result) > 0)
            Error("14002");

        $conf_map["name"] = $tmp_arr[0];
        $this->M_access_st->data($conf_map);
        $result = $this->M_access_st->save();
        if($result <= 0)
            Error("20001");

        if($result > 0){
            $conf_map["id"] = $this->M_access_st->id;
            $this->_toCli("add", $conf_map);
        }
    }

    //【接口】更新操作
    public function update(){
        if(!$this->V_safepolicy->scene('update_access_st')->check(['update_acs_st' => input("post.10")]))
            Error($this->V_safepolicy->getError());

        $tmp_arr = explode("|", input("post.10"));
        $conf_id = $tmp_arr[0];
        $conf_map = [
            "protocol_id" =>  $tmp_arr[2],
            "s_port"      =>  $tmp_arr[3],
            "d_port"      =>  $tmp_arr[4],
            "effect_time" =>  $tmp_arr[5]
        ];

        $result = $this->M_access_st->get($conf_id); // 验证记录是否存在
        if(is_null($result))
            Error("14001");

        $conf_has = [
            "protocol_id" =>  $result->protocol_id,
            "s_port"      =>  $result->s_port,
            "d_port"      =>  $result->d_port,
            "effect_time" =>  $result->effect_time
        ];
        if(empty(array_diff($conf_map,$conf_has))){ //无配置改变不操作
            return ;
        }

        $result = $this->M_access_st->selectSameRowNoThisId($conf_id, $conf_map); // 验证记录是否重复
        if(!is_null($result))
            Error("14002");

        $conf_map["name"] = $tmp_arr[1];
        $result = $this->M_access_st->save($conf_map, ['id' => $conf_id]);
        if($result < 0)
            Error("20001");

        if($result > 0){
            $conf_map["id"] = $conf_id;
            $this->_toCli("update", $conf_map);
        }
    }

    //【接口】删除操作
    public function del(){
        if(!$this->V_safepolicy->scene('del_access_st')->check(['ids' => input("post.ids")]))
            Error($this->V_safepolicy->getError());

        $ids_arr = explode(",", input("post.ids"));
        $result = $this->M_access_st->destroy($ids_arr);
        if($result < 0)
            Error("20001");

        if($result > 0){
            $this->_toCli("del", $ids_arr);
        }
    }

    //【接口】清空匹配计数
    public function clearing(){
        if(!$this->V_safepolicy->scene('del_access_st')->check(['ids' => input("post.ids")]))
            Error($this->V_safepolicy->getError());

        $ids_arr = explode(",", input("post.ids"));
        foreach($ids_arr as $id){
            ExcuteExec("fpcmd access_strategy -r ".$id);
        }
    }

    // 构建cli命令
    private function _toCli($oper, $conf){
        if($oper == "del"){
            foreach($conf as $id){
                ExcuteExec("fpcmd access_strategy -d ".$id);
            }
            SyncTimestampUpdate(); // 更新配置同步时间戳
            return ;
        }

        if($oper == "update"){
            ExcuteExec("fpcmd access_strategy -d ".$conf['id']);
        }

        if(empty($conf['s_port']) && $conf['s_port'] !== '0'){
            $conf['s_port'] = "0";
        }
        if(empty($conf['d_port']) && $conf['d_port'] !== '0'){
            $conf['d_port'] = "0";
        }
        if(empty($conf['effect_time']) && $conf['effect_time'] !== '0') {
            $conf['effect_time'] = "0";
        }
        ExcuteExec("fpcmd access_strategy -i -n ".$conf['id']." -p ".$conf['protocol_id']." -sp ".$conf['s_port']." -dp ".$conf['d_port']." -t ".$conf['effect_time']);
        
        SyncTimestampUpdate(); // 更新配置同步时间戳
    }

}