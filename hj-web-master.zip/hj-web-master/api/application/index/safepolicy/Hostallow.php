<?php
namespace app\index\safepolicy;
use app\index\model\MacAllow;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;
use think\Validate;

/**
 * 主机准入 分层控制器
 */
class Hostallow extends Controller {

    protected $V_safepolicy; 
    protected $M_mac_allow; 
    
    public function _initialize(){
        $this->V_safepolicy = Loader::validate('Safepolicy');
        $this->M_mac_allow = new MacAllow;
    }

    //【接口】获取查询
    public function get(){
        if(!$this->V_safepolicy->scene('get_mac_allow')->check(input()))
            Error($this->V_safepolicy->getError());

        $page = empty(input('get.page')) ? 1 : input('get.page');
        $row = empty(input('get.row')) ? 10 : input('get.row');
        $by = empty(input('get.by')) ? 'id' : input('get.by');
        $order = empty(input('get.order')) ? 'desc' : input('get.order');
        $mac = input('get.mac')=="" || is_null(input('get.mac')) ? null : input('get.mac');
        $desc = input('get.description')=="" || is_null(input('get.description')) ? null : input('get.description');
        $counts = NULL;$datas = [];

        $counts = $this->M_mac_allow->countMacAllow($mac, $desc);
        $datas = $counts == 0 ? [] : $this->M_mac_allow->selectMacAllowPages($page, $row, $by, $order, $mac, $desc);

        return ["data" => $datas, "count" => $counts];
    }

    //【接口】添加操作
    public function add(){
        if(!$this->V_safepolicy->scene('add_mac_allow')->check(['add_m_a' => input("post.6")]))
            Error($this->V_safepolicy->getError());

        $mac_arr = explode(",", input("post.6"));
        $result = $this->M_mac_allow->where("mac", "IN", $mac_arr)->select(); // 验证记录是否存在相同配置
        if(count($result) > 0)
            Error("14002");

        $conf_map = array_map(function($mac){
            return ["mac" => FormatMac($mac)];
        },$mac_arr);

        
        $result = $this->M_mac_allow->saveAll($conf_map);
        if(count($result) <= 0){
            Error("20001");
        }
        if(count($result) > 0){
            $this->_toCli();
        }
    }

    //【接口】删除操作
    public function del(){
        if(!$this->V_safepolicy->scene('del_mac_allow')->check(['ids' => input("post.6")]))
            Error($this->V_safepolicy->getError());

        $ids_arr = explode(",", input("post.6"));
        $result = $this->M_mac_allow->destroy($ids_arr);
        if($result < 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】导入excel
    public function upload(){
        $path = UploadExcel();
        $excel_fac = controller('Excelfactory', 'tools');
        $datas = $excel_fac->praseExcel($path);
        $conf_map = $this->_praseHostAllow($datas);
        exec("rm -rf ".$path);

        $result = $this->M_mac_allow->saveAll($conf_map);
        if($result < 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】导出Excel
    public function export(){
        RecordOperLog(16, 4); // 记录操作日志

        $data = $this->M_mac_allow->selectAllMacAllowWithNote();
        $excel_fac = controller('Excelfactory', 'tools');
        $excel_fac->exportExcel('mac_allow', $data);
    }

    // 构建cli命令
    private function _toCli(){
        ExcuteExec("fpcmd mac_filter_config -f"); // 清空之前所有配置

        $data = $this->M_mac_allow->selectAllMacAllow();
        if(empty($data)){
            SyncTimestampUpdate(); // 更新配置同步时间戳            
            return ;
        }
        foreach($data as $tmp){
            ExcuteExec("fpcmd mac_filter_config -i ".$tmp['mac']);
        }

        SyncTimestampUpdate(); // 更新配置同步时间戳
    }

    // 将解析excel出的数据进行结构整理与筛选
    private function _praseHostAllow($datas){
        $data = $this->M_mac_allow->selectAllMacAllow();
        $already_mac = array_map(function ($tmp) {
            return $tmp['mac'];
        },$data);

        $conf_map = [];
        foreach($datas as $tmp){
            if(is_null($tmp[0])){
                Error('12024');
            }

            $conf = [];
            foreach($tmp as $k => $t){
                if($k == 0 && !CheckMac($t)){
                    Error('12024');
                }
            }
            $conf = [
                'mac' => $tmp[0]
            ];

            $exist_flag = false;
            foreach($already_mac as $mac){
                if($conf['mac'] == $mac){
                    $exist_flag = true;
                    break;
                }
                continue;
            }

            if(!$exist_flag){
                $conf_map[] = $conf;
                $already_mac[] = $conf['mac'];
            }
        }
        return $conf_map;
    }

}