<?php
namespace app\index\safepolicy;
use app\index\model\MacBlackWhiteList;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;

/**
 * 主机黑白名单 分层控制器
 */
class Hostbwlist extends Controller {

    protected $V_safepolicy; 
    protected $M_mac_bwlist; 
    
    public function _initialize(){
        $this->V_safepolicy = Loader::validate('Safepolicy');
        $this->M_mac_bwlist = new MacBlackWhiteList;
    }

    //【接口】获取查询
    public function get($mark){
        if(!$this->V_safepolicy->scene('get_mac_bwlist')->check(input()))
            Error($this->V_safepolicy->getError());

        $page = empty(input('get.page')) ? 1 : input('get.page');
        $row = empty(input('get.row')) ? 10 : input('get.row');
        $by = empty(input('get.by')) ? 'id' : input('get.by');
        $order = empty(input('get.order')) ? 'desc' : input('get.order');
        $ip_mac = input('get.ip_mac')=="" || is_null(input('get.ip_mac')) ? null : input('get.ip_mac');
        $start_time = input('get.start_time')=="" || is_null(input('get.start_time')) ? null : date('Y-m-d H:i:s', input('get.start_time'));
        $end_time = input('get.end_time')=="" || is_null(input('get.end_time')) ? null : date('Y-m-d H:i:s', input('get.end_time'));
        $counts = NULL;$datas = [];

        $counts = $this->M_mac_bwlist->countMacBwlist($ip_mac, $start_time, $end_time, $mark);
        $datas = $counts == 0 ? [] : $this->M_mac_bwlist->selectMacBwlist($ip_mac, $start_time, $end_time, $mark, $page, $row, $by, $order);
        return ["data" => $datas, "count" => $counts];
    }

    //【接口】添加操作
    public function add($mark){
        $param = $mark ? ['add_m_bw' => input("post.4")] : ['add_m_bw' => input("post.5")];
        if(!$this->V_safepolicy->scene('add_mac_bwlist')->check($param))
            Error($this->V_safepolicy->getError());

        $tmp_arr = explode("|",$param['add_m_bw']);
        $conf_map = [
            "mac"       =>  FormatMac($tmp_arr[0]),
            "note"      =>  $tmp_arr[1],
            "type"      =>  $mark
        ];
        
        $result = $this->M_mac_bwlist->where(["mac" => $tmp_arr[0]])->select(); // 验证记录是否存在相同配置
        if(count($result) > 0)
            Error("10016");

        $this->M_mac_bwlist->data($conf_map);
        $result = $this->M_mac_bwlist->save();
        if($result <= 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】删除操作
    public function del($mark){
        $param = $mark ? ['ids' => input("post.4")] : ['ids' => input("post.5")];
        if(!$this->V_safepolicy->scene('del_mac_bwlist')->check($param))
            Error($this->V_safepolicy->getError());

        $ids_arr = explode(",", $param['ids']);
        $result = $this->M_mac_bwlist->destroy($ids_arr);
        if($result < 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    // 构建cli命令
    private function _toCli(){
        ExcuteExec("fpcmd white_list -f"); // 清空之前所有配置
        ExcuteExec("fpcmd black_list -f"); // 清空之前所有配置

        $data = $this->M_mac_bwlist->selectAllMacBwlist();
        if(empty($data)){
            SyncTimestampUpdate(); // 更新配置同步时间戳            
            return ;
        }

        foreach($data as $tmp){
            if($tmp['type'] == 0){
                ExcuteExec("fpcmd white_list -i ".$tmp['mac']);
            }else{
                ExcuteExec("fpcmd black_list -i ".$tmp['mac']);
            }
        }

        SyncTimestampUpdate(); // 更新配置同步时间戳
    }

}