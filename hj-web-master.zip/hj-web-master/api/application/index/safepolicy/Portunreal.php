<?php
namespace app\index\safepolicy;
use app\index\model\ServerTrap;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;

/**
 * 端口虚开 分层控制器
 */
class Portunreal extends Controller {

    protected $V_safepolicy; 
    protected $M_server_trap; 
    
    public function _initialize(){
        $this->V_safepolicy = Loader::validate('Safepolicy');
        $this->M_server_trap = new ServerTrap;
    }

    //【接口】获取查询
    public function get(){
        if(!$this->V_safepolicy->scene('get_server_trap')->check(input()))
            Error($this->V_safepolicy->getError());

        $page = empty(input('get.page')) ? 1 : input('get.page');
        $row = empty(input('get.row')) ? 10 : input('get.row');
        $by = empty(input('get.by')) ? 'id' : input('get.by');
        $order = empty(input('get.order')) ? 'desc' : input('get.order');
        $counts = NULL;$datas = [];

        $counts = $this->M_server_trap->countServerTrap();
        $datas = $counts == 0 ? [] : $this->M_server_trap->selectServerTrapPages($page, $row, $by, $order);
        $mac_info = MacInfo();
        foreach($datas as &$tmp){
            $tmp['s_port'] = $tmp['s_port'] === 0 ? '' : $tmp['s_port'];
            $tmp['description'] = isset($mac_info[FormatMac($tmp['t_ip_mac'])]) ? $mac_info[FormatMac($tmp['t_ip_mac'])] : "";
        }
        return ["data" => $datas, "count" => $counts];
    }

    //【接口】添加操作
    public function add(){
        if(!$this->V_safepolicy->scene('add_server_trap')->check(['add_s_t' => input("post.8")]))
            Error($this->V_safepolicy->getError());

        $tmp_arr = explode("|",input("post.8"));
        $conf_map = [];
        foreach(explode(",", $tmp_arr[1]) as $tmp){
            $conf_map[] = [
                "name"      =>  $tmp_arr[0],
                "t_ip_mac"  =>  FormatMac($tmp),
                "t_ip_type" =>  $tmp_arr[2],
                "t_port"    =>  $tmp_arr[3],
                "s_ip"      =>  $tmp_arr[4],
                "s_port"    =>  $tmp_arr[5],
                "vlan_id"   =>  $tmp_arr[6],
                "group_id"  =>  $tmp_arr[7]
            ];
        }

        $result = $this->M_server_trap->saveAll($conf_map);
        if($result <= 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】更新操作
    public function update(){
        if(!$this->V_safepolicy->scene('update_server_trap')->check(['update_s_t' => input("post.8")]))
            Error($this->V_safepolicy->getError());

        $tmp_arr = explode("|", input("post.8"));
        $conf_id = $tmp_arr[0];
        $conf_map = [
            "t_ip_mac"  =>  FormatMac($tmp_arr[2]),
            "t_ip_type" =>  $tmp_arr[3],
            "t_port"    =>  $tmp_arr[4],
            "s_ip"      =>  $tmp_arr[5],
            "s_port"    =>  $tmp_arr[6],
            "vlan_id"   =>  $tmp_arr[7],
            "group_id"  =>  $tmp_arr[8]
        ];

        $result = $this->M_server_trap->get($conf_id); // 验证记录是否存在
        if(is_null($result))
            Error("14001");

        $result = $this->M_server_trap->selectSameRowNoThisId($conf_id, $conf_map); // 验证记录是否重复
        if(!is_null($result))
            Error("14002");

        $conf_map["name"] = $tmp_arr[1];
        $result = $this->M_server_trap->save($conf_map, ['id' => $conf_id]);
        if($result < 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】删除操作
    public function del(){
        if(!$this->V_safepolicy->scene('del_server_trap')->check(['ids' => input("post.8")]))
            Error($this->V_safepolicy->getError());

        $ids_arr = explode(",", input("post.8"));
        $result = $this->M_server_trap->destroy($ids_arr);
        if($result < 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    // 构建cli命令
    private function _toCli(){
        ExcuteExec("fpcmd ports_unreal_open -f"); // 清空之前所有配置
        $data = $this->M_server_trap->selectAllServerTrap();
        if(empty($data)){
            SyncTimestampUpdate(); // 更新配置同步时间戳            
            return ;
        }
        foreach($data as &$item){
            if(empty($item['s_ip']) && $item['s_ip'] !== '0'){
                $item['s_ip'] = 0;
            }
            if(empty($item['s_port']) && $item['s_port'] !== '0'){
                $item['s_port'] = 0;
            }
        }
        foreach($data as $tmp){
            ExcuteExec("fpcmd ports_unreal_open -i -s ".$tmp['s_ip']." -p ".$tmp['s_port']." -g ".$tmp['group_id']." -v ".$tmp['vlan_id']." -t ".$tmp['t_ip_mac']." -ty ".$tmp['t_ip_type']." -tp ".$tmp['t_port']);
        }

        SyncTimestampUpdate(); // 更新配置同步时间戳
    }

}