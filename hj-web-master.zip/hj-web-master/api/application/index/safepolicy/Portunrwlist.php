<?php
namespace app\index\safepolicy;
use app\index\model\ServerTrapWhiteList;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;

/**
 * 虚开白名单 分层控制器
 */
class Portunrwlist extends Controller {

    protected $V_safepolicy; 
    protected $M_server_trap_wlist; 
    
    public function _initialize(){
        $this->V_safepolicy = Loader::validate('Safepolicy');
        $this->M_server_trap_wlist = new ServerTrapWhiteList;
    }

    //【接口】获取查询
    public function get(){
        if(!$this->V_safepolicy->scene('get_port_unr_wlist')->check(input()))
            Error($this->V_safepolicy->getError());

        $page = empty(input('get.page')) ? 1 : input('get.page');
        $row = empty(input('get.row')) ? 10 : input('get.row');
        $by = empty(input('get.by')) ? 'id' : input('get.by');
        $order = empty(input('get.order')) ? 'desc' : input('get.order');
        $counts = NULL;$datas = [];

        $counts = $this->M_server_trap_wlist->countServerTrapWlist();
        $datas = $counts == 0 ? [] : $this->M_server_trap_wlist->selectServerTrapWlistPages($page, $row, $by, $order);

        return ["data" => $datas, "count" => $counts];
    }

    //【接口】添加操作
    public function add(){
        if(!$this->V_safepolicy->scene('add_port_unr_wlist')->check(['add_p_u_w' => input("post.9")]))
            Error($this->V_safepolicy->getError());

        $tmp_arr = explode("|",input("post.9"));
        $conf_map = [
            "t_ip_mac"    =>  $tmp_arr[0],
            "t_port"      =>  $tmp_arr[1]
        ];

        $result = $this->M_server_trap_wlist->where($conf_map)->select(); // 验证记录是否存在相同配置
        if(count($result) > 0)
            Error("14002");

        $this->M_server_trap_wlist->data($conf_map);
        $result = $this->M_server_trap_wlist->save();
        if($result <= 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】更新操作
    public function update(){
        if(!$this->V_safepolicy->scene('update_port_unr_wlist')->check(['update_p_u_w' => input("post.9")]))
            Error($this->V_safepolicy->getError());

        $tmp_arr = explode("|", input("post.9"));
        $conf_id = $tmp_arr[0];
        $conf_map = [
            "t_ip_mac"    =>  $tmp_arr[1],
            "t_port"      =>  $tmp_arr[2]
        ];

        $result = $this->M_server_trap_wlist->get($conf_id); // 验证记录是否存在
        if(is_null($result))
            Error("14001");

        $result = $this->M_server_trap_wlist->selectSameRowNoThisId($conf_id, $conf_map); // 验证记录是否重复
        if(!is_null($result))
            Error("14002");

        $result = $this->M_server_trap_wlist->save($conf_map, ['id' => $conf_id]);
        if($result < 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】删除操作
    public function del(){
        if(!$this->V_safepolicy->scene('del_port_unr_wlist')->check(['ids' => input("post.9")]))
            Error($this->V_safepolicy->getError());

        $ids_arr = explode(",", input("post.9"));
        $result = $this->M_server_trap_wlist->destroy($ids_arr);
        if($result < 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    // 构建cli命令
    private function _toCli(){
        ExcuteExec("fpcmd unreal_open_white -f"); // 清空之前所有配置
        $data = $this->M_server_trap_wlist->selectAllServerTrapWlist();
        if(empty($data)){
            SyncTimestampUpdate(); // 更新配置同步时间戳            
            return ;
        }
        foreach($data as $tmp){
            ExcuteExec("fpcmd unreal_open_white -i -t ".$tmp['t_ip_mac']." -tp ".$tmp['t_port']);
        }

        SyncTimestampUpdate(); // 更新配置同步时间戳
    }

}