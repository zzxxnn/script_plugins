<?php
namespace app\index\logs;
use think\Controller;
use think\Db;

class Logs extends Controller {
    
    public function AttackLogs($orderby, $order, $page, $row, $search = []) {
        if (empty($orderby)) {
            $orderby = 'a.end_time';
        } elseif (!empty($orderby) && $orderby == 'description') {
            $orderby = 'm.description';
        } elseif (!empty($orderby) && $orderby == 'is_block') {
            $orderby = 'is_block';
        } else {
            $orderby = 'a.'.$orderby;
        }
        if (empty($order)) {
            $order = 'desc';
        }
        if (empty($page)) {
            $page = 1;
        }
        if (empty($row)) {
            $row = 10;
        }
        $filter = [];
        if (isset($search['attack_source']) && !empty($search['attack_source'])) {
            $filter['a.attack_source'] = ['like', '%'.$search['attack_source'].'%'];
        }
        if (!empty($search['start_time']) && !empty($search['end_time'])) {
            $filter['a.end_time'] = ['between',[date('Y-m-d H:i:s',$search['start_time']),date('Y-m-d H:i:s',$search['end_time'])]];
        } elseif (!empty($search['start_time']) && empty($search['end_time'])) {
            $filter['a.end_time'] = ['>=', date('Y-m-d H:i:s',$search['start_time'])];
        } elseif (empty($search['start_time']) && !empty($search['end_time'])) {
            $filter['a.end_time'] = ['<=', date('Y-m-d H:i:s',$search['end_time'])];
        }
        $subsql = Db::table('attack_log_stat')
            ->field('attack_source,max(end_time) as end_time')
            ->group('attack_source')
            ->buildSql();
        $blockstat = BlockInfo();
        $blockstat = array_map(function($item) {
            return "'".$item['source']."'";
        }, $blockstat);
        $blockstat = empty($blockstat) ? ["'"."'"] : $blockstat;
        $blockstat = '('.implode(',', $blockstat).')';
        $count = Db::table('attack_log_stat')
            ->alias('a')
            ->join([$subsql => 'b'], 'a.attack_source=b.attack_source and a.end_time=b.end_time', 'RIGHT')
            ->join('mac_info m', 'a.attack_source=m.mac', 'LEFT')
            ->where($filter)
            ->count();
        $logs = Db::table('attack_log_stat')
            ->alias('a')
            ->join([$subsql => 'b'], 'a.attack_source=b.attack_source and a.end_time=b.end_time', 'RIGHT')
            ->join('mac_info m', 'a.attack_source=m.mac', 'LEFT')
            ->field('a.attack_source,m.description,a.attack_type,a.count,a.groupid,a.start_time,CASE WHEN a.attack_source IN '.$blockstat.' THEN 1 ELSE 0 END as is_block,a.end_time')
            ->group('a.attack_source')
            ->where($filter)
            ->order($orderby.' '.$order.',a.end_time desc')
            ->limit(($page - 1) * $row, $row)
            ->select();
        $uid = session('user_auth.u_id');
        if (!empty($uid)) {
            $time_now = date('Y-m-d H:i:s', time());
            $check = Db::table('attack_log_check')->where(['u_id'=>$uid])->find();
            if (!empty($check)) {
                Db::table('attack_log_check')->where(['id'=>$check['id']])->update(['check_time'=>$time_now]);
            } else {
                Db::table('attack_log_check')->insert(['u_id'=>$uid,'check_time'=>$time_now]);
            }
        }
        return ['count'=>$count,'logs'=>$logs];
    }

    public function SourceAttackLogs($source, $orderby, $order, $page, $row) {
        if (empty($orderby)) {
            $orderby = 'end_time';
        }
        if (empty($order)) {
            $order = 'desc';
        }
        if (empty($page)) {
            $page = 1;
        }
        if (empty($row)) {
            $row = 10;
        }
        $count = Db::table('attack_log_stat')
            ->where(['attack_source'=>$source])
            ->count();
        $logs = Db::table('attack_log_stat')
            ->field('id as log_id,attack_type,count,groupid,start_time,end_time')
            ->where(['attack_source'=>$source])
            ->order($orderby.' '.$order.',end_time desc')
            ->limit(($page - 1) * $row, $row)
            ->select();
        return ['count'=>$count,'logs'=>$logs];
    }

    public function DetailAttackLogs($log_id,$orderby,$order,$page,$row) {
        if (empty($orderby)) {
            $orderby = 'attack_time';
        }
        if (empty($order)) {
            $order = 'desc';
        }
        if (empty($page)) {
            $page = 1;
        }
        if (empty($row)) {
            $row = 10;
        }
        $log_stat = Db::table('attack_log_stat')->where(['id'=>$log_id])->find();
        if (empty($log_stat)) {
            return ['count'=>0,'logs'=>[]];
        }
        $logs = Db::table('attack_log')
            ->where([
                'attack_source'=>$log_stat['attack_source'],
                'attack_type'=>$log_stat['attack_type'],
                'groupid'=>$log_stat['groupid'],
                'attack_time' => ['between',[$log_stat['start_time'],$log_stat['end_time']]]        
            ])
            ->field('target_ip,target_port,attack_time')
            ->order($orderby.' '.$order.',attack_time desc')
            ->limit(($page - 1) * $row, $row)
            ->select();
        return ['count'=>$log_stat['count'],'logs'=>$logs];
    }

    public function AttackLogsStat($subt, $source, $limit) {
        if (empty($limit)) {
            $limit = 10;
        }
        $stat = [];
        $time_now = time();
        foreach ($subt as $t) {
            switch ($t) {
                case '1':
                    $start = date('Y-m-d', $time_now);
                    $end = date('Y-m-d H:i:s', $time_now);
                    $stat['1'] = Db::table('attack_log_stat')
                        ->alias('a')
                        ->join('mac_info b', 'a.attack_source=b.mac', 'LEFT')
                        ->group('a.attack_source')
                        ->field('a.attack_source,b.description,sum(a.count) as count')
                        ->where([
                            'a.start_time'=>['>=', $start],
                            'a.end_time'=>['<=', $end]
                        ])
                        ->order('count desc')
                        ->limit($limit)
                        ->select();
                    break;
                case '2':
                    $start = date('Y-m-d', $time_now);
                    $end = date('Y-m-d H:i:s', $time_now);
                    $stat['2'] = Db::table('attack_log_stat')
                        ->alias('a')
                        ->join('mac_info b', 'a.attack_source=b.mac', 'LEFT')
                        ->group('a.attack_source')
                        ->field('a.attack_source,b.description,sum(a.count) as count')
                        ->where([
                            'a.start_time'=>['>=', $start],
                            'a.end_time'=>['<=', $end],
                            'a.attack_type'=>['in',[1,5]]
                        ])
                        ->order('count desc')
                        ->limit($limit)
                        ->select();
                    break;
                case '3':
                    $start = date('Y-m-d', $time_now);
                    $end = date('Y-m-d H:i:s', $time_now);
                    $stat['3'] = Db::table('attack_log_stat')
                        ->alias('a')
                        ->join('mac_info b', 'a.attack_source=b.mac', 'LEFT')
                        ->group('a.attack_source')
                        ->field('a.attack_source,b.description,sum(a.count) as count')
                        ->where([
                            'a.start_time'=>['>=', $start],
                            'a.end_time'=>['<=', $end],
                            'a.attack_type'=>['in',[2,6,7]]
                        ])
                        ->order('count desc')
                        ->limit($limit)
                        ->select();
                    break;
                case '4':
                    $start = date('Y-m', $time_now);
                    $end = date('Y-m-d H:i:s', $time_now);
                    $stat['4'] = Db::table('attack_log_stat')
                        ->alias('a')
                        ->join('mac_info b', 'a.attack_source=b.mac', 'LEFT')
                        ->group('a.attack_source')
                        ->field('a.attack_source,b.description,sum(a.count) as count')
                        ->where([
                            'a.start_time'=>['>=', $start],
                            'a.end_time'=>['<=', $end]
                        ])
                        ->order('count desc')
                        ->limit($limit)
                        ->select();
                    break;
                case '5':
                    $start = date('Y-m', $time_now);
                    $end = date('Y-m-d H:i:s', $time_now);
                    $stat['5'] = Db::table('attack_log_stat')
                        ->alias('a')
                        ->join('mac_info b', 'a.attack_source=b.mac', 'LEFT')
                        ->group('a.attack_source')
                        ->field('a.attack_source,b.description,sum(a.count) as count')
                        ->where([
                            'a.start_time'=>['>=', $start],
                            'a.end_time'=>['<=', $end],
                            'a.attack_type'=>['in',[1,5]]
                        ])
                        ->order('count desc')
                        ->limit($limit)
                        ->select();
                    break;
                case '6':
                    $start = date('Y-m', $time_now);
                    $end = date('Y-m-d H:i:s', $time_now);
                    $stat['6'] = Db::table('attack_log_stat')
                        ->alias('a')
                        ->join('mac_info b', 'a.attack_source=b.mac', 'LEFT')
                        ->group('a.attack_source')
                        ->field('a.attack_source,b.description,sum(a.count) as count')
                        ->where([
                            'a.start_time'=>['>=', $start],
                            'a.end_time'=>['<=', $end],
                            'a.attack_type'=>['in',[2,6,7]]
                        ])
                        ->order('count desc')
                        ->limit($limit)
                        ->select();
                    break;
                case '7':
                    $start = strtotime(date('Y-m-d', strtotime('-1 month', $time_now)));
                    $end =strtotime(date('Y-m-d', time()));

                    $date_arr = $this->getdate_arr($start,$end,"day");
                    $res_arr = [];
                    
                    foreach ($date_arr as $key => $value) {
                        $where = [];
                        $where = [
                            'start_time'=>['>=', $value["start"]],
                            'end_time'=>['<=', $value["end"]]
                        ];
                        if(!empty($source)){
                            $where['attack_source'] = ['=', $source];
                        }
                        $res = Db::table('attack_log_stat')
                        ->field('date(end_time) as x, sum(count) as sum, sum(CASE WHEN attack_type=1 or attack_type=5 THEN count END) icmp, sum(CASE WHEN attack_type=2 or attack_type=6 or attack_type=7 THEN count END) port')
                        ->where($where)->group('x')->select();

                        if (empty($res)) {
                            $res_arr[strtotime($value["start"])] = ["x"=>$value["start"],"sum"=>"0","port"=>"0","icmp"=>"0"];
                            continue;
                        }
                        $res_arr[strtotime($value["start"])] = $res[0];
                    }

                    $where = [];
                    $where = [
                        'start_time'=>['>=', date('Y-m-d', time())],
                        'end_time'=>['<=', date('Y-m-d H:i:s', time())]
                    ];
                    if(!empty($source)){
                        $where['attack_source'] = ['=', $source];
                    }
                    $res = Db::table('attack_log_stat')
                    ->field('date(end_time) as x, sum(count) as sum, sum(CASE WHEN attack_type=1 or attack_type=5 THEN count END) icmp, sum(CASE WHEN attack_type=2 or attack_type=6 or attack_type=7 THEN count END) port')
                    ->where($where)->group('x')->select();

                    if (empty($res)) {
                        $res_arr[strtotime(date('Y-m-d', time()))] = ["x"=>date('Y-m-d', time()),"sum"=>"0","port"=>"0","icmp"=>"0"];
                    }else{
                        $res_arr[strtotime(date('Y-m-d', time()))] = $res[0];
                    }

                    ksort($res_arr);

                    $ress = [];
                    foreach ($res_arr as $key => $value) {
                        array_push($ress, $value);
                    }

                    $stat["7"] = $ress;
                    break;
                case '8':

                    $start = strtotime(date('Y-m', strtotime('-1 year', $time_now)));

                    $end =strtotime(date('Y-m', time()));

                    $date_arr = $this->getdate_arr($start, $end,"month");

                    $res_arr = [];

                    foreach ($date_arr as $key => $value) {
                        $where = [];
                        $where = [
                            'start_time'=>['>=', $value["start"]],
                            'end_time'=>['<=', $value["end"]]
                        ];
                        if(!empty($source)){
                            $where['attack_source'] = ['=', $source];
                        }
                        $stat['8'] = Db::table('attack_log_stat')
                        ->field("date_format(start_time,'%Y-%m') x, sum(count) sum, sum(CASE WHEN attack_type=1 or attack_type=5 THEN count END) icmp, sum(CASE WHEN attack_type=2 or attack_type=6 or attack_type=7 THEN count END) port ")
                        ->where($where)->group('x')->select();
                        if (empty($res)) {
                            $res_arr[strtotime($value["start"])] = ["x"=>$value["start"],"sum"=>"0","port"=>"0","icmp"=>"0"];
                            continue;
                        }
                        $res_arr[strtotime($value["start"])] = $res[0];
                    }

                    $where = [];
                    $where = [
                        'start_time'=>['>=', date('Y-m-d', time())],
                        'end_time'=>['<=', date('Y-m-d H:i:s', time())]
                    ];
                    if(!empty($source)){
                        $where['attack_source'] = ['=', $source];
                    }
                    $res = Db::table('attack_log_stat')
                    ->field("date_format(start_time,'%Y-%m') x, sum(count) sum, sum(CASE WHEN attack_type=1 or attack_type=5 THEN count END) icmp, sum(CASE WHEN attack_type=2 or attack_type=6 or attack_type=7 THEN count END) port ")
                    ->where($where)->group('x')->select();

                    if (empty($res)) {
                        $res_arr[strtotime(date('Y-m', time()))] = ["x"=>date('Y-m', time()),"sum"=>"0","port"=>"0","icmp"=>"0"];
                    }else{
                        $res_arr[strtotime(date('Y-m', time()))] = $res[0];
                    }

                    ksort($res_arr);

                    $ress = [];
                    foreach ($res_arr as $key => $value) {
                        array_push($ress, $value);
                    }

                    $stat["8"] = $ress;
                    break;
                default:
                    break;
            }
        }
        return $stat;
    }

    private function getdate_arr($start_time,$end_time,$type){
        $res = [];
        $end = 0;

        $format = $type == "day" ?  "Y-m-d" : "Y-m";

        $start_time_str = date('Y-m-d H:i:s', $start_time);
        for (;;) {
            if ($end == $start_time_str) {
                break;
            }
            $end = date('Y-m-d H:i:s', $end_time);
            $start = date($format, strtotime('-1 '.$type, $end_time));
            $res[] = ["start" => $start ,"end" => $end];
            $end_time = strtotime($start);
        }

        return $res;
    }

    public function IpVaryLogs($orderby, $order, $page, $row, $search = []) {
        if (empty($orderby)) {
            $orderby = 'a.online_time';
        } elseif (!empty($orderby) && $orderby == 'description') {
            $orderby = 'b.description';
        } else {
            $orderby = 'a.'.$orderby;
        }
        if (empty($order)) {
            $order = 'desc';
        }
        if (empty($page)) {
            $page = 1;
        }
        if (empty($row)) {
            $row = 10;
        }
        $filter = [];
        if (isset($search['groupid']) && !empty($search['groupid'])) {
            $filter['a.groupid'] = $search['groupid'];
        } 
        if (isset($search['mac']) && !empty($search['mac'])) {
            $filter['a.mac'] = ['like', '%'.$search['mac'].'%'];
        }
        if (!empty($search['start_time']) && !empty($search['end_time'])) {
            $filter['a.vary_time'] = ['between',[date('Y-m-d H:i:s',$search['start_time']),date('Y-m-d H:i:s',$search['end_time'])]];
        } elseif (!empty($search['start_time']) && empty($search['end_time'])) {
            $filter['a.vary_time'] = ['>=', date('Y-m-d H:i:s',$search['start_time'])];
        } elseif (empty($search['start_time']) && !empty($search['end_time'])) {
            $filter['a.vary_time'] = ['<=', date('Y-m-d H:i:s',$search['end_time'])];
        }
        $count = Db::table('ipvary_log')
            ->alias('a')
            ->group('a.rip,a.wip,a.mac,a.groupid,a.online_time')
            ->where($filter)
            ->count();
        $logs = Db::table('ipvary_log')
            ->alias('a')
            ->join('mac_info b', 'a.mac=b.mac', 'LEFT')
            ->field('a.id,a.rip,a.wip,a.mac,a.groupid,a.online_time,b.description')
            ->where($filter)
            ->group('a.rip,a.wip,a.mac,a.groupid,a.online_time')
            ->order($orderby.' '.$order.',a.online_time desc')
            ->limit(($page - 1) * $row, $row)
            ->select();
        return ['count'=>$count,'logs'=>$logs];
    }

    public function DetailIpVaryLogs($log_id, $orderby, $order, $page, $row) {
        if (empty($orderby)) {
            $orderby = 'vary_time';
        }
        if (empty($order)) {
            $order = 'desc';
        }
        if (empty($page)) {
            $page = 1;
        }
        if (empty($row)) {
            $row = 10;
        }
        $log_stat = Db::table('ipvary_log')->where(['id'=>$log_id])->find();
        $count = Db::table('ipvary_log')
            ->where([
                'rip'   =>  $log_stat['rip'],
                'wip'   =>  $log_stat['wip'],
                'mac'   =>  $log_stat['mac'],
                'groupid'   =>  $log_stat['groupid'],
                'online_time'   =>  $log_stat['online_time']
            ])
            ->count();
        $logs = Db::table('ipvary_log')
            ->where([
                'rip'   =>  $log_stat['rip'],
                'wip'   =>  $log_stat['wip'],
                'mac'   =>  $log_stat['mac'],
                'groupid'   =>  $log_stat['groupid'],
                'online_time'   =>  $log_stat['online_time']
            ])
            ->field('vip,vary_time')
            ->order($orderby.' '.$order)
            ->limit(($page - 1) * $row, $row)
            ->select();
        return ['count'=>$count, 'logs'=>$logs];
    }

    public function OfflineLogs($orderby, $order, $page, $row, $search) {
        if (empty($orderby)) {
            $orderby = 'a.offline_time';
        } elseif (!empty($orderby) && $orderby == 'description') {
            $orderby = 'b.description';
        } else {
            $orderby = 'a.'.$orderby;
        }
        if (empty($order)) {
            $order = 'desc';
        }
        if (empty($page)) {
            $page = 1;
        }
        if (empty($row)) {
            $row = 10;
        }
        $filter = [];
        if (isset($search['groupid']) && !empty($search['groupid'])) {
            $filter['a.groupid'] = $search['groupid'];
        } 
        if (isset($search['mac']) && !empty($search['mac'])) {
            $filter['a.mac'] = ['like', '%'.$search['mac'].'%'];
        }
        if (!empty($search['start_time']) && !empty($search['end_time'])) {
            $filter['a.offline_time'] = ['between',[date('Y-m-d H:i:s',$search['start_time']),date('Y-m-d H:i:s',$search['end_time'])]];
        } elseif (!empty($search['start_time']) && empty($search['end_time'])) {
            $filter['a.offline_time'] = ['>=', date('Y-m-d H:i:s',$search['start_time'])];
        } elseif (empty($search['start_time']) && !empty($search['end_time'])) {
            $filter['a.offline_time'] = ['<=', date('Y-m-d H:i:s',$search['end_time'])];
        }
        $count = Db::table('offline_log')
            ->alias('a')
            ->where($filter)
            ->count();
        $logs = Db::table('offline_log')
            ->alias('a')
            ->join('mac_info b', 'a.mac=b.mac', 'LEFT')
            ->field('a.id,a.groupid,a.mac,b.description,a.rip,a.wip,a.online_time,a.offline_time')
            ->where($filter)
            ->order($orderby.' '.$order.',a.offline_time desc')
            ->limit(($page - 1) * $row, $row)
            ->select();
        return ['count'=>$count,'logs'=>$logs];
    }

    public function BlockLogs($orderby, $order, $page, $row, $search) {
        if (empty($orderby)) {
            $orderby = 'a.time';
        } elseif (!empty($orderby) && $orderby == 'description') {
            $orderby = 'b.description';
        } elseif (!empty($orderby) && $orderby == 'username') {
            $orderby = 'username';
        } else {
            $orderby = 'a.'.$orderby;
        }
        if (empty($order)) {
            $order = 'desc';
        }
        if (empty($page)) {
            $page = 1;
        }
        if (empty($row)) {
            $row = 10;
        }
        $filter = [];
        if (isset($search['source']) && !empty($search['source'])) {
            $filter['a.source'] = ['like', '%'.$search['source'].'%'];
        }
        if (isset($search['type'])) {
            $filter['a.type'] = $search['type'];
        }
        if (!empty($search['start_time']) && !empty($search['end_time'])) {
            $filter['a.time'] = ['between',[date('Y-m-d H:i:s',$search['start_time']),date('Y-m-d H:i:s',$search['end_time'])]];
        } elseif (!empty($search['start_time']) && empty($search['end_time'])) {
            $filter['a.time'] = ['>=', date('Y-m-d H:i:s',$search['start_time'])];
        } elseif (empty($search['start_time']) && !empty($search['end_time'])) {
            $filter['a.time'] = ['<=', date('Y-m-d H:i:s',$search['end_time'])];
        }
        $count = Db::table('block_log')
            ->alias('a')
            ->where($filter)
            ->count();
        $logs = Db::table('block_log')
            ->alias('a')
            ->join('mac_info b', 'a.source=b.mac', 'LEFT')
            ->join('user c', 'a.uid=c.u_id', 'LEFT')
            ->field('a.source,b.description,a.type,a.uid,(if(a.uid=0,"sys",c.user_id)) as username,a.time')
            ->where($filter)
            ->order($orderby.' '.$order.',a.time desc')
            ->limit(($page - 1) * $row, $row)
            ->select();
        return ['count'=>$count,'logs'=>$logs];
    }

    public function OperLogs($orderby, $order, $page, $row, $search) {
        if (empty($orderby)) {
            $orderby = 'a.time';
        } elseif ($orderby == 'username') {
            $orderby = 'b.user_id';
        } else {
            $orderby = 'a.'.$orderby;
        }
        if (empty($order)) {
            $order = 'desc';
        }
        if (empty($page)) {
            $page = 1;
        }
        if (empty($row)) {
            $row = 10;
        }
        $filter = [];
        if (isset($search['username']) && !empty($search['username'])) {
            $filter['b.user_id'] = ['like', '%'.$search['username'].'%'];
        }
        if (isset($search['clientip']) && !empty($search['clientip'])) {
            $filter['a.clientip'] = ['like', '%'.$search['clientip'].'%'];
        }
        if (!empty($search['start_time']) && !empty($search['end_time'])) {
            $filter['a.time'] = ['between',[date('Y-m-d H:i:s',$search['start_time']),date('Y-m-d H:i:s',$search['end_time'])]];
        } elseif (!empty($search['start_time']) && empty($search['end_time'])) {
            $filter['a.time'] = ['>=', date('Y-m-d H:i:s',$search['start_time'])];
        } elseif (empty($search['start_time']) && !empty($search['end_time'])) {
            $filter['a.time'] = ['<=', date('Y-m-d H:i:s',$search['end_time'])];
        }
        $count = Db::table('oper_log')
            ->alias('a')
            ->join('user b', 'a.uid=b.u_id', 'LEFT')
            ->where($filter)
            ->count();
        $logs = Db::table('oper_log')
            ->alias('a')
            ->join('user b', 'a.uid=b.u_id', 'LEFT')
            ->field('a.id,a.type,a.subtype,a.clientip,a.content,a.time,b.user_id as username')
            ->where($filter)
            ->order($orderby.' '.$order.',a.time desc')
            ->limit(($page - 1) * $row, $row)
            ->select();
        foreach ($logs as &$log) {
            $log = TranslateLog($log);
        }
        
        if(input('get.export') == 'html'){
            $this->_exportForOperLogs('html', $logs);
            exit(0);
        }elseif(input('get.export') == 'xml'){
            $this->_exportForOperLogs('xml', $logs);
            exit(0);
        }
            
        return ['count'=>$count,'logs'=>$logs];
    }

    public function EventLogs($orderby, $order, $page, $row, $search) {
        if (empty($orderby)) {
            $orderby = 'time';
        }
        if (empty($order)) {
            $order = 'desc';
        }
        if (empty($page)) {
            $page = 1;
        }
        if (empty($row)) {
            $row = 10;
        }
        $filter = [];
        if (isset($search['level']) && !empty($search['level'])) {
            if ($search['level'] == 1) {
                $filter['type'] = ['in',[1,2,3,4,5,6,7]];
            }
            if ($search['level'] == 2) {
                $filter['type'] = ['in',[8,9]];
            }
            if ($search['level'] == 3) {
                $filter['type'] = 10;
            }
        }
        if (isset($search['type']) && !empty($search['type'])) {
            $filter['type'] = $search['type'];
        }
        if (!empty($search['start_time']) && !empty($search['end_time'])) {
            $filter['time'] = ['between',[date('Y-m-d H:i:s',$search['start_time']),date('Y-m-d H:i:s',$search['end_time'])]];
        } elseif (!empty($search['start_time']) && empty($search['end_time'])) {
            $filter['time'] = ['>=', date('Y-m-d H:i:s',$search['start_time'])];
        } elseif (empty($search['start_time']) && !empty($search['end_time'])) {
            $filter['time'] = ['<=', date('Y-m-d H:i:s',$search['end_time'])];
        }
        $count = Db::table('event_log')
            ->where($filter)
            ->count();
        $logs = Db::table('event_log')
            ->where($filter)
            ->field('CASE type WHEN 10 THEN 3 WHEN 8 THEN 2 WHEN 9 THEN 2 ELSE 1 END as level,type,content,time')
            ->order($orderby.' '.$order.',time desc')
            ->limit(($page - 1) * $row, $row)
            ->select();

        $log = TranslateEventLog($logs);

        if(input('get.export') == 'html'){
            $this->_exportForEventLogs('html', $logs);
            exit(0);
        }elseif(input('get.export') == 'xml'){
            $this->_exportForEventLogs('xml', $logs);
            exit(0);
        }

        return ['count'=>$count,'logs'=>$log];
    }

    public function clearAttackLogs(){ // 清空渗透日志
        Db::table('attack_log')->delete(true);
        Db::table('attack_log_stat')->delete(true);
        Db::table('attack_log_check')->delete(true);
        // 清空redis渗透日志缓存
        $redis = new \Redis();
        $redis->pconnect('127.0.0.1');
        $redis->delete('attack_log_stat');
    }
    public function clearIpVaryLogs(){ // 清空主机变换日志
        $result = Db::table('ipvary_log')->delete(true);
        if($result < 0){
            Error('20001');
        }
    }
    public function clearOfflineLogs(){ // 清空主机上下线日志
        $result = Db::table('offline_log')->delete(true);
        if($result < 0){
            Error('20001');
        }
    }
    public function clearBlockLogs(){ // 清空封堵日志
        $result = Db::table('block_log')->where('type', 1)->delete();
        if($result < 0){
            Error('20001');
        }
    }
    public function clearUnblockLogs(){ // 清空解封日志
        $result = Db::table('block_log')->where('type', 0)->delete();
        if($result < 0){
            Error('20001');
        }
    }
    public function clearOperLogs(){ // 清空操作日志
        $result = Db::table('oper_log')->delete(true);
        if($result < 0){
            Error('20001');
        }
    }
    public function clearEventLogs(){ // 清空事件日志
        $result = Db::table('event_log')->where('type', '<>', 5)->delete();
        if($result < 0){
            Error('20001');
        }
    }

    private function _exportForEventLogs($type, $data){
        if($type == 'html'){
            $name = "事件日志".date("Y_m_d_h_m_i").".html";
            $template = file_get_contents(APP_PATH."index/view/template" . "/event_template.html");
            $html_content = "";
            $i = 0;
            
            foreach($data as $d) {
                $c = $i%2 == 0 ? "row1" : "row2";

                $type_desc = $d["type"];
                $level_desc = $d["level"];
                $note = $d["content"];
                $time = $d["time"];

                if (empty($level_desc) || empty($type_desc)) {
                    continue;
                }

                $i ++;

                if ($d["level"] == "1") {
                    $level_desc = "<font color='red'>$level_desc</font>";
                } else if ($d["level"] == "2") {
                    $level_desc = "<font color='coral'>$level_desc</font>";
                } 

                $html_content .= " <tr class='$c'>
                <td class='center'>$i</td>
                <td class='center'>$level_desc</td>
                <td class='center'>$type_desc</td>
                <td class='center'>$note</td>
                <td class='center'>$time</td>
                </tr>";
            }

            $str = str_replace('${PLACE_HOLDER}', $html_content, $template);
        }else{
            $name = "事件日志".date("Y_m_d_h_m_i").".xml";
            $r = [];

            foreach($data as $d) {
                $note = $d["content"];
                $time = $d["time"];
                $type_desc = $d["type"];
                $level_desc = $d["level"];

                if (empty($level_desc) || empty($type_desc)) {
                    continue;
                }

                $r[] = [
                    "level" => $level_desc,
                    "note" => $note,
                    "time" => $time,
                    "type" => $type_desc
                ];
            }

            $xml_fac = controller('Xmlfactory', 'tools');
            $str = $xml_fac->mwxmlDumpDoc(["oper"=>$r], "root", "xmlns:xipc=\"http://www.6wind.com/xms/xipc/1.0\"");
        }

        header("Content-Transfer-Encoding: binary");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Expires: 0");
        header("Pragma: public");
        header("Content-Type: application/octet-stream");
        header("Accept-Ranges: bytes");
        header("Accept-Length: ".sizeof($str));
        header("Content-Disposition: attachment; filename=$name");

        echo $str;
    }

    private function _exportForOperLogs($type, $data){
        if($type == 'html'){
            $name = "操作日志".date("Y_m_d_h_m_i").".html";
            $template = file_get_contents(APP_PATH."index/view/template" . "/oper_template.html");
            $html_content = "";
            $i = 0;
            
            foreach($data as $d) {
                $c = $i%2 == 0 ? "row1" : "row2";

                $user = $d["username"];
                $type = $d["type"];
                $subtype = $d["subtype"];
                $ip = $d["clientip"];
                $content = $d["content"];
                $time = $d["time"];

                $i ++;

                $html_content .= " <tr class='$c'>
                <td class='center'>$i</td>
                <td class='center'>$user</td>
                <td class='center'>$type</td>
                <td class='center'>$subtype</td>
                <td class='center'>$ip</td>
                <td class='center'>$content</td>
                <td class='center'>$time</td>
                </tr>";
            }

            $str = str_replace('${PLACE_HOLDER}', $html_content, $template);
        }else{
            $name = "操作日志".date("Y_m_d_h_m_i").".xml";
            $r = [];

            foreach($data as $d) {
                $user = $d["username"];
                $type = $d["type"];
                $subtype = $d["subtype"];
                $ip = $d["clientip"];
                $content = $d["content"];
                $time = $d["time"];
                
                $r[] = [
                    "user" => $user,
                    "type" => $type,
                    "subtype" => $subtype,
                    "ip" => $ip,
                    "content" => $content,
                    "time" => $time
                ];
            }

            $xml_fac = controller('Xmlfactory', 'tools');
            $str = $xml_fac->mwxmlDumpDoc(["oper"=>$r], "root", "xmlns:xipc=\"http://www.6wind.com/xms/xipc/1.0\"");
        }

        header("Content-Transfer-Encoding: binary");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Expires: 0");
        header("Pragma: public");
        header("Content-Type: application/octet-stream");
        header("Accept-Ranges: bytes");
        header("Accept-Length: ".sizeof($str));
        header("Content-Disposition: attachment; filename=$name");

        echo $str;
    }
}