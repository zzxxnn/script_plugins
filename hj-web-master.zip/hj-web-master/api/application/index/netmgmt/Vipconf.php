<?php
namespace app\index\netmgmt;
use app\index\model\NetVip;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;

/**
 * 虚拟IP配置及虚拟IP保留配置 分层控制器
 */
class Vipconf extends Controller {

    protected $V_netips; 
    protected $M_net_vip; 
    
    public function _initialize(){
        $this->V_netips = Loader::validate('NetIps');
        $this->M_net_vip = new NetVip;
    }

    //【接口】获取查询
    public function get($exclude){
        if(!$this->V_netips->scene('get_rip_vip_vnet')->check(input()))
            Error($this->V_netips->getError());

        $page = empty(input('get.page')) ? 1 : input('get.page');
        $row = empty(input('get.row')) ? 10 : input('get.row');
        $by = empty(input('get.by')) ? 'id' : input('get.by');
        $order = empty(input('get.order')) ? 'desc' : input('get.order');
        $counts = NULL;$datas = [];

        $counts = $this->M_net_vip->countVip($exclude);
        $datas = $counts == 0 ? [] : $this->M_net_vip->selectVipPages($exclude, $page, $row, $by, $order);

        return ["data" => $datas, "count" => $counts];
    }

    //【接口】添加操作
    public function add($exclude){
        $param = $exclude ? ['add_r_v_v' => input("post.12")] : ['add_r_v_v' => input("post.11")];

        if(!$this->V_netips->scene('add_rip_vip_vnet')->check($param))
            Error($this->V_netips->getError());

        $tmp_arr = explode("|",$param['add_r_v_v']);
        $conf_map = [
            "ip"        =>  $tmp_arr[0],
            "mask"      =>  $tmp_arr[1],
            "vlan_id"   =>  $tmp_arr[2],
            "group_id"  =>  $tmp_arr[3],
        ];

        $result = $this->M_net_vip->selectSameRow($conf_map); // 验证记录是否存在相同配置
        if(!is_null($result))
            Error("14002");

        $conf_map["exclude"] = $exclude;
        $result = $this->M_net_vip->insertRip($conf_map);
        if($result <= 0){
            Error("20001");
        }

        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】更新操作
    public function update($exclude){
        $param = $exclude ? ['update_r_v_v' => input("post.12")] : ['update_r_v_v' => input("post.11")];

        if(!$this->V_netips->scene('update_rip_vip_vnet')->check($param))
            Error($this->V_netips->getError());

        $tmp_arr = explode("|",$param['update_r_v_v']);
        $conf_id = $tmp_arr[0];
        $conf_map = [
            "ip"        =>  $tmp_arr[1],
            "mask"      =>  $tmp_arr[2],
            "vlan_id"   =>  $tmp_arr[3],
            "group_id"  =>  $tmp_arr[4],
        ];

        $result = $this->M_net_vip->get($conf_id); // 验证记录是否存在
        if(is_null($result))
            Error("14001");

        $result = $this->M_net_vip->selectSameRowNoThisId($conf_id, $conf_map);
        if(!is_null($result))
            Error("14002");

        $result = $this->M_net_vip->updateById($conf_id, $conf_map);
        if($result < 0){
            Error("20001");
        }

        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】删除操作
    public function del($exclude){
        $param = $exclude ? ['ids' => input("post.12")] : ['ids' => input("post.11")];
        if(!$this->V_netips->scene('del_by_ids')->check($param))
            Error($this->V_netips->getError());

        $ids_arr = explode(",", $param['ids']);
        $result = $this->M_net_vip->deleteByIds($ids_arr);
        if($result < 0){
            Error("20001");
        }

        if($result > 0){
            $this->_toCli();
        }
    }

    // 构建cli命令
    private function _toCli(){
        ExcuteExec("fpcmd vip_conf -f"); // 清空之前所有配置

        $data = $this->M_net_vip->selectAllVip();
        if(empty($data)){
            SyncTimestampUpdate(); // 更新配置同步时间戳            
            return ;
        }

        foreach($data as $tmp){
            if($tmp['exclude'] == 0){
                ExcuteExec("fpcmd vip_conf -vi ".$tmp['ip']." -m ".$tmp['mask']." -v ".$tmp['vlan_id']." -g ".$tmp['group_id']);
            }else{
                ExcuteExec("fpcmd vip_conf -ev ".$tmp['ip']." -m ".$tmp['mask']." -v ".$tmp['vlan_id']." -g ".$tmp['group_id']);
            }
        }

        SyncTimestampUpdate(); // 更新配置同步时间戳
    }

}