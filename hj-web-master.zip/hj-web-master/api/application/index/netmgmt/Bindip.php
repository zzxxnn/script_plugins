<?php
namespace app\index\netmgmt;
use app\index\model\NetMacThrough;
use app\index\model\NetBindIp;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;
use think\Db;

/**
 * 静态地址 分层控制器
 */
class Bindip extends Controller {

    protected $V_netips; 
    protected $M_net_bind_ip; 
    
    public function _initialize(){
        $this->V_netips = Loader::validate('NetIps');
        $this->M_net_bind_ip = new NetBindIp;
    }

    //【接口】获取查询
    public function get(){
        if(!$this->V_netips->scene('get_bind_ip')->check(input()))
            Error($this->V_netips->getError());

        $page = empty(input('get.page')) ? 1 : input('get.page');
        $row = empty(input('get.row')) ? 10 : input('get.row');
        $by = empty(input('get.by')) ? 'id' : input('get.by');
        $order = empty(input('get.order')) ? 'desc' : input('get.order');
        $counts = NULL;$datas = [];

        $counts = $this->M_net_bind_ip->countBindIp();
        $datas = $counts == 0 ? [] : $this->M_net_bind_ip->selectBindIpPages($page, $row, $by, $order);
        
        return ["data" => $datas, "count" => $counts];
    }

    //【接口】添加操作
    public function add(){
        $param = ['add_b_ip' => input("post.23")];
        if(!$this->V_netips->scene('add_bind_ip')->check($param))
            Error($this->V_netips->getError());

        $tmp_arr = explode("|",$param['add_b_ip']);
        $conf_map = [
            "mac"     =>  FormatMac($tmp_arr[0]),
            "ip"      =>  $tmp_arr[1]
        ];

        $result = $this->M_net_bind_ip->selectSameRow($conf_map); // 验证记录是否存在相同配置
        if(!is_null($result))
            Error("14002");

        $result = Db::table("net_mac_through")->where(["ip" => $conf_map["ip"]])->find(); // 主机透传与静态地址不可同时配置一个ip
        if(!is_null($result))
            Error("10022");

        $result = $this->M_net_bind_ip->insertRip($conf_map);
        if($result <= 0){
            Error("20001");
        }

        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】更新操作
    public function update(){
        $param = ['update_b_ip' => input("post.23")];
        if(!$this->V_netips->scene('update_bind_ip')->check($param))
            Error($this->V_netips->getError());

        $tmp_arr = explode("|",$param['update_b_ip']);
        $conf_id = $tmp_arr[0];
        $conf_map = [
            "mac"     =>  FormatMac($tmp_arr[1]),
            "ip"      =>  $tmp_arr[2]
        ];

        $result = $this->M_net_bind_ip->get($conf_id); // 验证记录是否存在
        if(is_null($result))
            Error("14001");

        $result = $this->M_net_bind_ip->selectSameRowNoThisId($conf_id, $conf_map); // 验证记录是否重复
        if(!is_null($result))
            Error("14002");

        $result = Db::table("net_mac_through")->where(["ip" => $conf_map["ip"]])->find(); // 主机透传与静态地址不可同时配置一个ip
        if(!is_null($result))
            Error("10022");

        $result = $this->M_net_bind_ip->updateById($conf_id, $conf_map);
        if($result < 0){
            Error("20001");
        }

        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】删除操作
    public function del(){
        $param = ['ids' => input("post.23")];
        if(!$this->V_netips->scene('del_by_ids')->check($param))
            Error($this->V_netips->getError());

        $ids_arr = explode(",", $param['ids']);
        $result = $this->M_net_bind_ip->deleteByIds($ids_arr);
        if($result < 0){
            Error("20001");
        }

        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】导出Excel
    public function export(){
        RecordOperLog(323, 4); // 记录操作日志

        $data = $this->M_net_bind_ip->selectAllBindIp();
        $excel_fac = controller('Excelfactory', 'tools');
        $excel_fac->exportExcel('bind_ip', $data);
    }

    //【接口】导入excel
    public function upload(){
        $path = UploadExcel();
        $excel_fac = controller('Excelfactory', 'tools');
        $datas = $excel_fac->praseExcel($path);
        $conf_map = $this->_praseBindIp($datas);
        exec("rm -rf ".$path);

        $result = $this->M_net_bind_ip->saveAll($conf_map);
        if($result < 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    // 构建cli命令
    private function _toCli(){
        ExcuteExec("fpcmd mac_bind_wip -f"); // 清空之前所有配置

        $data = $this->M_net_bind_ip->selectAllBindIp();
        if(empty($data)){
            SyncTimestampUpdate(); // 更新配置同步时间戳
            return ;
        }

        foreach($data as $tmp){
            ExcuteExec("fpcmd mac_bind_wip -i -w ".$tmp['ip']." -m ".$tmp['mac']);
        }

        SyncTimestampUpdate(); // 更新配置同步时间戳
    }

    // 将解析excel出的数据进行结构整理与筛选
    private function _praseBindIp($datas){
        $data = $this->M_net_bind_ip->selectAllBindIp();
        $already_key = array_map(function ($tmp) {
            return $tmp['mac']."_".$tmp['ip'];
        },$data);

        $M_net_mac_through = new NetMacThrough;
        $data = $M_net_mac_through->selectAllMacThrough();
        $mac_th_ip = array_map(function ($tmp) {
            return $tmp['ip'];
        },$data);
        $already_mac_th_ip = array_flip($mac_th_ip);

        $conf_map = [];
        foreach($datas as $tmp){
            if(count($tmp) != 2){
                Error('12024');
            }
            if(is_null($tmp[0]) && is_null($tmp[1])){
                continue;
            }
            if(is_null($tmp[0]) || is_null($tmp[1])){
                Error('12024');
            }

            $conf = [];
            foreach($tmp as $mac_ip){
                if(CheckMac($mac_ip)){
                    $conf['mac']= FormatMac($mac_ip);
                }elseif(CheckIp($mac_ip)){
                    $conf['ip']= $mac_ip;
                }else{
                    Error('12024');
                }
            }

            $exist_flag = false;
            foreach($already_key as $e_key){
                $tmp = explode("_", $e_key);
                if(($tmp[0] == $conf['mac']) || ($tmp[1] == $conf['ip']) || isset($already_mac_th_ip[$conf['ip']])){
                    $exist_flag = true;
                    break;
                }
                continue;
            }

            if(!$exist_flag){
                $conf_map[] = $conf;
                $already_key[] = $conf['mac']."_".$conf['ip'];
            }
        }

        return $conf_map;
    }

}