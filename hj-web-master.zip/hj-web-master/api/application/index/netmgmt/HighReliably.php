<?php
namespace app\index\netmgmt;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;
use think\Validate;
use think\Db;

/**
 * 高可靠性 分层控制器
 */
class HighReliably extends Controller {

    protected $V_netips; 
    public function _initialize(){
        $this->V_netips = Loader::validate('NetIps');
    }

    //【接口】获取
    public function get(){
        $json_content = file_get_contents("/hard_disk/ha/config.json");
        $json_arr = json_decode($json_content, true);

        $eth_chart = GetEthChart();
        $eth_desc = array_filter($eth_chart, function ($tmp) use ($json_arr) {
            return in_array($tmp['eth'], explode(",", $json_arr['eth']['monitor']));
        });
        $eths = array_map(function ($tmp) {
            return $tmp['desc'];
        }, $eth_desc);
        $json_arr['eth']['monitor'] = implode(",", $eths);

        if(!isset($json_arr['mgt'])){
            $json_arr['mgt'] = $this->_getMGT("no");
        }

        $mgt_ips = $this->_getMGT();
        $json_arr['mgts'] = $mgt_ips;

        $vlan_ids = $this->_getVlanId();
        $json_arr['vlans'] = $vlan_ids;

        $eth_info = $this->_getEth();
        $json_arr['eths'] = $eth_info;

        $status = $this->_getHighRelStatus();
        $json_arr['status'] = (int)$status;

        return $json_arr;
    }

    //【接口】更新操作
    public function update(){
        $config = input("post.30/a");
        if(!$this->_checkConfig($config))
            Error("12019");

        $eth_desc = GetEthChart();
        $eth_chart = array_filter($eth_desc, function ($tmp) use ($config) {
            return in_array($tmp['desc'], explode(",", $config['eth']['monitor']));
        });
        $eths = array_map(function ($tmp) {
            return $tmp['eth'];
        }, $eth_chart);
        $config['eth']['monitor'] = implode(",", $eths);
        
        file_put_contents("/hard_disk/ha/config.json", json_encode($config, JSON_PRETTY_PRINT));
    }

    /**
     * 校验配置json格式内容
     */
    private function _checkConfig($config){
        if(is_null($config)){
            return false;
        }
        if(!isset($config['mode']) || !isset($config['mgt']) || !isset($config['remoteip']) || !isset($config['heartbeat']) || !isset($config['ttl']) 
        || !isset($config['ports_follow_switch']) || !isset($config['synswitch']) || !isset($config['eth'])){
            return false;
        }
        if(!isset($config['eth']['switch']) || !isset($config['eth']['monitor'])){
            return false;
        }
        if(!in_array($config['mode'], ['ports_pile', 'stp', 'mstp'])){
            return false;
        }
        if(!in_array($config['mgt'], [0,1,2])){
            return false;
        }
        if((!empty($config['remoteip'])) && (!ip2long($config['remoteip']))){
            return false;
        }
        if(!(is_int($config['heartbeat']) && ($config['heartbeat'] >= 1 || $config['heartbeat'] <= 120))){
            return false;
        }
        if(!(is_int($config['ttl']) && ($config['ttl'] >= 1 || $config['ttl'] <= 300))){
            return false;
        }
        if(!(is_int($config['synswitch']) && in_array($config['synswitch'], [0,1]))){
            return false;
        }
        if(!(is_int($config['ports_follow_switch']) && in_array($config['ports_follow_switch'], [0,1]))){
            return false;
        }
        if(!(is_int($config['eth']['switch']) && in_array($config['eth']['switch'], [0,1]))){
            return false;
        }
        if($config['eth']['switch'] === 1){
            foreach(explode(",", $config['eth']['monitor']) as $tmp){
                if(!in_array($tmp, explode(",", $this->_getEth()))){
                    return false;
                }
            }
        }

        if($config['mode'] == 'stp'){
            if(!isset($config['stp'])){
                return false;
            }
            if(!isset($config['stp']['priority'])){
                return false;
            }
            if(!(is_int($config['stp']['priority']) && $config['stp']['priority'] >= 1 && $config['stp']['priority'] <= 255)){
                return false;
            }
        }elseif($config['mode'] == 'mstp'){
            if(!isset($config['mstp'])){
                return false;
            }
            if(!isset($config['mstp']['vlanid'])){
                return false;
            }
            if($config['mstp']['vlanid'] == ""){
                return false;
            }
        }

        return true;
    }

    /**
     * 获取管理口ip
     */
    private function _getMGT($type=""){
        $data = Db::table('net_config')->where(["conf_type" => 8])->field("conf_value")->select();
        if($type == 'no'){ // 获取正在使用管理口ip序号
            $host = GetServerIP();
            $used_ip = 0;
            foreach(explode("|", $data[0]["conf_value"]) as $k => $ip_range){
                $ip = explode("/", $ip_range)[0];
                if($ip == $host){
                    $used_ip = $k+1 ;
                    break;
                }
            }
            return $used_ip;
        }else{
            $mgt_arr = explode("|", $data[0]['conf_value']);
            $mgt = array_map(function ($ip_mask) {
                return explode("/", $ip_mask)[0];
            },$mgt_arr);
            return implode(",", $mgt);
        }
    }

    /**
     * 获取vlan_id
     */
    private function _getVlanId(){
        $result = null;
        $status = null;
        exec("fpcmd get_vlanid -s", $result, $status);
        if($status !== 0){
            Error("20002", "error: fpcmd get_vlanid -s");
        }
        if(empty($result)){
            return "";
        }   
        $vlan_arr = explode(" ", trim($result[0]));
        return implode(",", $vlan_arr);
    }

    /**
     * 获取网口信息
     */
    private function _getEth(){
        $eth_chart = GetEthChart();
        $eth_info = array_map(function ($eth) {
            return $eth['desc'];
        }, $eth_chart);
        return implode(",", $eth_info);
    }

    /**
     * 获取HA状态
     */
    private function _getHighRelStatus(){
        $result = null;
        $status = null;
        exec("fpcmd ha_status -s", $result, $status);
        if($status !== 0){
            return "";
        }
        return $result[0];
    }
}