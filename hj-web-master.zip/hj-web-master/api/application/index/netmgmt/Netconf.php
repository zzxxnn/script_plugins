<?php
namespace app\index\netmgmt;
use app\index\model\NetConfig;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;

/**
 * 全局配置 虚假响应 协议透传 分层控制器
 */
class Netconf extends Controller {

    //【接口】获取查询
    public function get($conf_type){
        $result = null;
        $M_net_config = new NetConfig;
        $data = $M_net_config->selectValueByConfType($conf_type);
        if(empty($data))
            return $result;

        $result = $data[0]["conf_value"];

        if($conf_type == 8){
            $host = GetServerIP();
            $used_ip = 0;
            foreach(explode("|", $data[0]["conf_value"]) as $k => $ip_range){
                $ip = explode("/", $ip_range)[0];
                if($ip == $host){
                    $used_ip = $k+1 ;
                    break;
                }
            }
            $result = $data[0]["conf_value"]."|".$used_ip;
        }
        return $result;
    }

    //更新
    public function update($conf_type){
        $M_net_config = new NetConfig;
        $V_netconf = Loader::validate('Netconf');

        //校验！
        switch($conf_type){
            case "1": // DHCP开关
                if(!$V_netconf->scene('typeswitch')->check(['switch' => input("post.1")]))
                    Error($V_netconf->getError());
                break;
            case "2": // 首选DNS 备选DNS
                if(!$V_netconf->scene('type2')->check(['double_dns' => input("post.2")]))
                    Error($V_netconf->getError());
                break;
            case "3": // DHCP 租期
                if(!$V_netconf->scene('type3')->check(['sec_time' => input("post.3")]))
                    Error($V_netconf->getError());
                break;
            case "4": // 主机信息有效时间
                if(!$V_netconf->scene('type4')->check(['sec_time' => input("post.4")]))
                    Error($V_netconf->getError());
                break;
            case "5": // 真实IP访问开关
                if(!$V_netconf->scene('typeswitch')->check(['switch' => input("post.5")]))
                    Error($V_netconf->getError());
                break;
            case "6": // 主机自动封堵开关
                if(!$V_netconf->scene('typeswitch')->check(['switch' => input("post.6")]))
                    Error($V_netconf->getError());
                break;
            case "7": // 虚拟IP变换间隔 | 虚拟域名变换间隔 | 虚拟网络变换间隔
                if(!$V_netconf->scene('type7')->check(['trible_sec_times' => input("post.7")]))
                    Error($V_netconf->getError());
                break;
            case "8": // 管理口1 | 管理口2
                if(!$V_netconf->scene('type8')->check(['double_ipmask' => input("post.8")]))
                    Error($V_netconf->getError());

                    $param_arr = explode("|", input("post.8"));
                    if($param_arr[2] == 0){ // 当前使用管理ip非当前设备的两个管理口
                        $host = GetServerIP();
                        $used_ip = explode("/", $param_arr[0])[0] == $host || explode("/", $param_arr[1])[0] == $host ? true : false;
                        if($used_ip === false){
                            Error("10014");
                        }
                    }
                break;
            case "17": // Liunx、Windows、Server主机比例
                if(!$V_netconf->scene('type17')->check(['trible_per' => input("post.17")]))
                    Error($V_netconf->getError());
                break;
            case "18": // 端口响应概率
                if(!$V_netconf->scene('type18')->check(['per' => input("post.18")]))
                    Error($V_netconf->getError());
                break;
            case "19": // Linux端口
                if(!$V_netconf->scene('typeport')->check(['multi_ports' => input("post.19")]))
                    Error($V_netconf->getError());
                break;
            case "20": // Windows端口
                if(!$V_netconf->scene('typeport')->check(['multi_ports' => input("post.20")]))
                    Error($V_netconf->getError());
                break;
            case "21": // Server端口
                if(!$V_netconf->scene('typeport')->check(['multi_ports' => input("post.21")]))
                    Error($V_netconf->getError());
                break;
            case "22": // 响应mac标识
                if(!$V_netconf->scene('type22')->check(['multi_mac_ids' => input("post.22")]))
                    Error($V_netconf->getError());
                break;
            case "26": // 协议透传 STP开关
                if(!$V_netconf->scene('typeswitch')->check(['switch' => input("post.26")]))
                    Error($V_netconf->getError());
                break;
            case "27": // 协议透传 Communication_Redundancy开关
                if(!$V_netconf->scene('typeswitch')->check(['switch' => input("post.27")]))
                    Error($V_netconf->getError());
                break;
            case "28": // 主机准入开关
                if(!$V_netconf->scene('typeswitch')->check(['switch' => input("post.28")]))
                    Error($V_netconf->getError());
                break;
            default:
                #code...
                break;
        }

        // to update
        $conf_value = input("post.$conf_type");
        if($conf_type == '8'){ // 管理口
            $param_arr = explode("|", input("post.8"));
            $conf_value = $param_arr[0]."|".$param_arr[1];
        }
        $M_net_config = new NetConfig;
        $result = $M_net_config->updateValueByConfType($conf_type, $conf_value);
        if($result < 0)
            Error("20001");

        $this->_excuteCli($conf_type, $conf_value);
    }

    //进行更新
    private function _excuteCli($conf_type, $conf_value){
        switch($conf_type){
            case "1": // DHCP开关
                ExcuteExec("fpcmd dhcp_switch -i $conf_value");
                break;
            case "2": // 首选DNS 备选DNS
                $dns = explode("|", $conf_value);
                ExcuteExec("fpcmd dhcp_dns -i $dns[0],$dns[1]");
                break;
            case "3": // DHCP 租期
                ExcuteExec("fpcmd dhcp_time -i $conf_value");
                break;
            case "4": // 主机信息有效时间
                ExcuteExec("fpcmd host_status_ttl -i $conf_value");
                break;
            case "5": // 真实IP访问开关
                ExcuteExec("fpcmd rip_access_switch -i $conf_value");
                break;
            case "6": // 主机自动封堵开关
                ExcuteExec("fpcmd host_status_switch -i $conf_value");
                break;
            case "7": // 虚拟IP变换间隔 | 虚拟域名变换间隔 | 虚拟网络变换间隔
                $conf = explode("|", $conf_value);
                ExcuteExec("fpcmd vip_alter_time -i ".$conf[0]*60);
                ExcuteExec("fpcmd vname_alter_time -i ".$conf[1]*60);
                ExcuteExec("fpcmd vnetwork_alter_time -i ".$conf[2]*60);
                break;
            case "8": // 管理口1 | 管理口2
                $eth_mapping = $this->_ethMappingMGT();
                $conf_arr = explode("|", $conf_value); // "192.168.2.1/24|192.168.3.1/24|1"
                $ip_arr = [$conf_arr[0],$conf_arr[1]];
                foreach($ip_arr as $k => $ip_mask){
                    $ip = explode("/", $ip_mask)[0];
                    $mask = ParseMask(explode("/", $ip_mask)[1]);
                    ExcuteExec("ifconfig ". $eth_mapping["MGT".($k+1)] ." ".$ip." netmask ".$mask);
                }
                break;
            case "17": // Liunx、Windows、Server主机比例
                $per = explode("|", $conf_value);
                ExcuteExec("fpcmd linux_per -i $per[0]");
                ExcuteExec("fpcmd windows_per -i $per[1]");
                ExcuteExec("fpcmd server_per -i $per[2]");
                break;
            case "18": // 端口响应概率
                ExcuteExec("fpcmd virtual_port_percent -i $conf_value");
                break;
            case "19": // Linux端口
                ExcuteExec("fpcmd linux_port -f");
                ExcuteExec("fpcmd linux_port -i $conf_value");
                break;
            case "20": // Windows端口
                ExcuteExec("fpcmd windows_port -f");
                ExcuteExec("fpcmd windows_port -i $conf_value");
                break;
            case "21": // Server端口
                ExcuteExec("fpcmd server_port -f");
                ExcuteExec("fpcmd server_port -i $conf_value");
                break;
            case "22": // 响应mac标识
                ExcuteExec("fpcmd company_mac -f");
                ExcuteExec("fpcmd company_mac -i $conf_value");
                break;
            case "26": // 协议透传 STP开关
                ExcuteExec("fpcmd stp_switch -i $conf_value");
                break;
            case "28": // 主机准入开关
                ExcuteExec("fpcmd mac_filter_switch -i $conf_value");
                break;
            default:
                #code...
                break;
        }
    }

    /**
     * 获取管理口对应网口
     * @return Array $eth_map["MGT1"] $eth_map["MGT2"]
     */
    private function _ethMappingMGT(){
        exec("fpcmd set_eth_info -s", $result, $status);
        if($status != 0){
            Error('20002','error: fpcmd set_eth_info -s');
        }
        $result = trim($result[0], "|\t\n\r\0\x0B");
        $mapping = explode("|", $result);
        $eth_map = [];
        foreach($mapping as $m){
            $m_arr = explode(" ", $m);
            if($m_arr[2] == "MGT1"){
                $eth_map["MGT1"] = $m_arr[0];
            }
            if($m_arr[2] == "MGT2"){
                $eth_map["MGT2"] = $m_arr[0];
            }
        }
        return $eth_map;
    }

}