<?php
namespace app\index\netmgmt;
use app\index\model\NetBindRouter;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;

/**
 * 静态路由 分层控制器
 */
class Bindrouter extends Controller {

    protected $V_netips; 
    protected $M_net_bind_router; 
    
    public function _initialize(){
        $this->V_netips = Loader::validate('NetIps');
        $this->M_net_bind_router = new NetBindRouter;
    }

    //【接口】获取查询
    public function get(){
        if(!$this->V_netips->scene('get_bind_router')->check(input()))
            Error($this->V_netips->getError());

        $page = empty(input('get.page')) ? 1 : input('get.page');
        $row = empty(input('get.row')) ? 10 : input('get.row');
        $by = empty(input('get.by')) ? 'id' : input('get.by');
        $order = empty(input('get.order')) ? 'desc' : input('get.order');
        $counts = NULL;$datas = [];

        $counts = $this->M_net_bind_router->countBindRouter();
        $datas = $counts == 0 ? [] : $this->M_net_bind_router->selectBindRouterPages($page, $row, $by, $order);

        return ["data" => $datas, "count" => $counts];
    }

    //【接口】添加操作
    public function add(){
        $param = ['add_b_router' => input("post.24")];
        if(!$this->V_netips->scene('add_bind_router')->check($param))
            Error($this->V_netips->getError());

        $tmp_arr = explode("|",$param['add_b_router']);
        $conf_map = [
            "ip"        =>  $tmp_arr[0],
            "gateway"   =>  $tmp_arr[1]
        ];

        $result = $this->M_net_bind_router->selectSameRow($conf_map); // 验证记录是否存在相同配置
        if(!is_null($result))
            Error("14002");

        $result = $this->M_net_bind_router->insertRip($conf_map);
        if($result <= 0){
            Error("20001");
        }

        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】更新操作
    public function update(){
        $param = ['update_b_router' => input("post.24")];
        if(!$this->V_netips->scene('update_bind_router')->check($param))
            Error($this->V_netips->getError());

        $tmp_arr = explode("|",$param['update_b_router']);
        $conf_id = $tmp_arr[0];
        $conf_map = [
            "ip"        =>  $tmp_arr[1],
            "gateway"   =>  $tmp_arr[2]
        ];

        $result = $this->M_net_bind_router->get($conf_id); // 验证记录是否存在
        if(is_null($result))
            Error("14001");

        $result = $this->M_net_bind_router->selectSameRowNoThisId($conf_id, $conf_map); // 验证记录是否重复
        if(!is_null($result))
            Error("14002");

        $result = $this->M_net_bind_router->updateById($conf_id, $conf_map);
        if($result < 0){
            Error("20001");
        }

        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】删除操作
    public function del(){
        $param = ['ids' => input("post.24")];
        if(!$this->V_netips->scene('del_by_ids')->check($param))
            Error($this->V_netips->getError());

        $ids_arr = explode(",", $param['ids']);
        $result = $this->M_net_bind_router->deleteByIds($ids_arr);
        if($result < 0){
            Error("20001");
        }

        if($result > 0){
            $this->_toCli();
        }
    }

    // 构建cli命令
    private function _toCli(){
        ExcuteExec("fpcmd static_route -f"); // 清空之前所有配置

        $data = $this->M_net_bind_router->selectAllBindRouter();
        if(empty($data)){
            return ;
        }

        foreach($data as $tmp){
            ExcuteExec("fpcmd static_route -i -n ".$tmp['ip']." -g ".$tmp['gateway']);
        }
    }

}