<?php
namespace app\index\netmgmt;
use app\index\model\NetConfig;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;

/**
 * 软件bypass 分层控制器
 */
class Bypass extends Controller {

    protected $V_netips;
    protected $M_net_config;
    
    public function _initialize(){
        $this->V_netips = Loader::validate('NetIps');
        $this->M_net_config = new NetConfig;
    }

    //【接口】添加操作
    public function add(){
        if(!$this->V_netips->scene('add_bypass')->check(['add_bp' => input("post.29")]))
            Error($this->V_netips->getError());

        $new_group_id = input("post.29");
        if(!in_array($new_group_id, $this->_getEethGroups())){
            Error('10015');
        }

        $result = $this->M_net_config->get(['conf_type' => '29']);
        $value = $result->conf_value;
        if(empty($value) && $value != '0'){
            $value_arr = [];
        }else{
            $value_arr = explode(',', $value);
        }

        if(in_array($new_group_id, $value_arr)){
            Error('14002');
        }

        array_push($value_arr, $new_group_id);
        usort($value_arr, function($a, $b) {
            return intval($a) - intval($b);
        });
        $result = $this->M_net_config->updateValueByConfType(29, implode(',', $value_arr));
        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】删除操作
    public function del(){
        if(!$this->V_netips->scene('del_bypass')->check(['del_bp' => input("post.29")]))
            Error($this->V_netips->getError());

        $remove_group_arr = explode(",", input("post.29"));
        $result = $this->M_net_config->get(['conf_type' => '29']);
        $value = $result->conf_value;
        if(empty($value) && $value != '0'){
            return ;
        }else{
            $value_arr = explode(',', $value);
        }

        foreach($value_arr as $k => $a){
            if(in_array($a, $remove_group_arr)){
                unset($value_arr[$k]);
            }
        }
        $result = $this->M_net_config->updateValueByConfType(29, implode(',', $value_arr));
        if($result > 0){
            $this->_toCli();
        }
    }

    // 构建cli命令
    private function _toCli(){
        ExcuteExec("fpcmd bypass_groupids -f"); // 清空之前所有配置

        $data = $this->M_net_config->selectValueByConfType(29);
        if(empty($data)){
            SyncTimestampUpdate(); // 更新配置同步时间戳
            return ;
        }
        $value = $data[0]['conf_value'];
        if(empty($value) && $value != '0'){
            SyncTimestampUpdate(); // 更新配置同步时间戳
            return ;
        }

        $value_arr = explode(',', $value);
        foreach($value_arr as $tmp){
            ExcuteExec("fpcmd bypass_groupids -i ".$tmp);
        }

        SyncTimestampUpdate(); // 更新配置同步时间戳
    }
    
    //获取物理线路
    private function _getEethGroups(){
        $groups = [];
        $eth_chart = GetEthChart();
        foreach($eth_chart as $table) {
            if(!($table['groupid'] > 0)) {
                continue;
            }
            if(in_array($table['groupid'],$groups)) {
                continue;
            }
            array_push($groups,$table['groupid']);
        }
        return $groups;
    }
}