<?php
namespace app\index\netmgmt;
use app\index\model\NetMacThrough;
use app\index\model\NetBindIp;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;
use think\Validate;
use think\Db;

/**
 * 主机透传 分层控制器
 */
class Macthrough extends Controller {

    protected $V_netips; 
    protected $M_net_mac_through; 
    
    public function _initialize(){
        $this->V_netips = Loader::validate('NetIps');
        $this->M_net_mac_through = new NetMacThrough;
    }

    //【接口】获取查询
    public function get(){
        if(!$this->V_netips->scene('get_mac_through')->check(input()))
            Error($this->V_netips->getError());

        $page = empty(input('get.page')) ? 1 : input('get.page');
        $row = empty(input('get.row')) ? 10 : input('get.row');
        $by = empty(input('get.by')) ? 'id' : input('get.by');
        $order = empty(input('get.order')) ? 'desc' : input('get.order');
        $counts = NULL;$datas = [];

        $counts = $this->M_net_mac_through->countMacThrough();
        $datas = $counts == 0 ? [] : $this->M_net_mac_through->selectMacThroughPages($page, $row, $by, $order);

        return ["data" => $datas, "count" => $counts];
    }

    //【接口】添加操作
    public function add(){
        $param = ['add_m_th' => input("post.25")];
        if(!$this->V_netips->scene('add_mac_through')->check($param))
            Error($this->V_netips->getError());

        $tmp_arr = explode("|",$param['add_m_th']);
        $conf_map = [
            "mac"       =>  FormatMac($tmp_arr[0]),
            "ip"        =>  $tmp_arr[1],
            "vlan_id"   =>  $tmp_arr[2],
            "group_id"  =>  $tmp_arr[3],
        ];

        $result = $this->M_net_mac_through->selectSameRow(["ip" => $conf_map["ip"]]); // 验证记录是否存在相同配置
        if(!is_null($result))
            Error("14002");

        $result = Db::table("net_bind_ip")->where(["ip" => $conf_map["ip"]])->find(); // 主机透传与静态地址不可同时配置一个ip
        if(!is_null($result))
            Error("10022");

        $result = $this->M_net_mac_through->insertRip($conf_map);
        if($result <= 0){
            Error("20001");
        }

        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】更新操作
    public function update(){
        $param = ['update_m_th' => input("post.25")];
        if(!$this->V_netips->scene('update_mac_through')->check($param))
            Error($this->V_netips->getError());

        $tmp_arr = explode("|",$param['update_m_th']);
        $conf_id = $tmp_arr[0];
        $conf_map = [
            "mac"       =>  FormatMac($tmp_arr[1]),
            "ip"        =>  $tmp_arr[2],
            "vlan_id"   =>  $tmp_arr[3],
            "group_id"  =>  $tmp_arr[4],
        ];

        $result = $this->M_net_mac_through->get($conf_id); // 验证记录是否存在
        if(is_null($result))
            Error("14001");

        $result = $this->M_net_mac_through->selectSameRowNoThisId($conf_id, ["ip" => $conf_map["ip"]]); // 验证记录是否重复
        if(!is_null($result))
            Error("14002");

        $result = Db::table("net_bind_ip")->where(["ip" => $conf_map["ip"]])->find(); // 主机透传与静态地址不可同时配置一个ip
        if(!is_null($result))
            Error("10022");

        $result = $this->M_net_mac_through->updateById($conf_id, $conf_map);
        if($result < 0){
            Error("20001");
        }

        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】删除操作
    public function del(){
        $param = ['ids' => input("post.25")];
        if(!$this->V_netips->scene('del_by_ids')->check($param))
            Error($this->V_netips->getError());

        $ids_arr = explode(",", $param['ids']);
        $result = $this->M_net_mac_through->deleteByIds($ids_arr);
        if($result < 0){
            Error("20001");
        }

        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】导入excel
    public function upload(){
        $path = UploadExcel();
        $excel_fac = controller('Excelfactory', 'tools');
        $datas = $excel_fac->praseExcel($path);
        $conf_map = $this->_praseMacThrough($datas);
        exec("rm -rf ".$path);

        $result = $this->M_net_mac_through->saveAll($conf_map);
        if($result < 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】导出Excel
    public function export(){
        RecordOperLog(325, 4); // 记录操作日志
        
        $data = $this->M_net_mac_through->selectAllMacThrough();
        $excel_fac = controller('Excelfactory', 'tools');
        $excel_fac->exportExcel('mac_through', $data);
    }

    // 构建cli命令
    private function _toCli(){
        ExcuteExec("fpcmd mac_bind_passthrough -f"); // 清空之前所有配置

        $data = $this->M_net_mac_through->selectAllMacThrough();
        if(empty($data)){
            SyncTimestampUpdate(); // 更新配置同步时间戳            
            return ;
        }

        foreach($data as $tmp){
            ExcuteExec("fpcmd mac_bind_passthrough -i -w ".$tmp['ip']." -m ".$tmp['mac']." -g ".$tmp['group_id']." -v ".$tmp['vlan_id']);
        }

        SyncTimestampUpdate(); // 更新配置同步时间戳
    }

    // 将解析excel出的数据进行结构整理与筛选
    private function _praseMacThrough($datas){
        $data = $this->M_net_mac_through->selectAllMacThrough();
        $mac_th_ip = array_map(function ($tmp) {
            return $tmp['ip'];
        },$data);

        $M_net_bind_ip = new NetBindIp;
        $data = $M_net_bind_ip->selectAllBindIp();
        $bind_ip = array_map(function ($tmp) {
            return $tmp['ip'];
        },$data);

        $already_ip = array_merge($bind_ip, $mac_th_ip);

        $conf_map = [];
        foreach($datas as $tmp){
            if(count($tmp) != 4){
                Error('12024');
            }
            if(is_null($tmp[0]) && is_null($tmp[1]) && is_null($tmp[2]) && is_null($tmp[3])){
                continue;
            }
            if(is_null($tmp[0]) || is_null($tmp[1]) || is_null($tmp[2]) || is_null($tmp[3])){
                Error('12024');
            }

            $conf = [];
            foreach($tmp as $k => $t){
                if($k == 0 && !CheckMac($t)){
                    Error('12024');
                }
                if($k == 1 && !CheckIp($t)){
                    Error('12024');
                }
                if($k == 2 && !(Validate::is($t, "integer") && Validate::egt($t, 0, null) && Validate::elt($t, 4096, null))){
                    Error('12024');
                }
                if($k == 3 && !(Validate::is($t, "integer") && Validate::egt($t, 0, null))){
                    Error('12024');
                }
            }
            
            $conf = [
                'mac' => FormatMac($tmp[0]),
                'ip' => $tmp[1],
                'vlan_id' => $tmp[3] == 0 ? 0 : $tmp[2],
                'group_id' => $tmp[3]
            ];
            
            $exist_flag = false;
            foreach($already_ip as $e_ip){
                if($e_ip === $conf['ip']){
                    $exist_flag = true;
                    break;
                }
                continue;
            }

            if(!$exist_flag){
                $conf_map[] = $conf;
                $already_ip[] = $conf['ip'];
            }
        }
        return $conf_map;
    }

}