<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/6/14
 * Time: 11:14
 */

namespace app\index\repository;


use app\index\model\User;
use app\index\model\UserLoginStatus;
use app\index\tools\HSEncrypt;

class SSORepository
{
    /**
     * 处理幻势SSO登陆
     *
     * @param $token
     * @return bool|\SSOTokenInvalidException
     * @throws \app\common\exception\DecryptException
     */
    public function processHsSSO($token)
    {
        $encrypt = new HSEncrypt();
        // 对SSO Token 进行校验
        if (!$encrypt->isValid($token)) {
            return new \SSOTokenInvalidException();
        }

        $data = $encrypt->decrypt($token);
        // 校验SSO Token 有效期
        $expire = !empty($data['expire']) ? $data['expire'] : null;
        if ($expire <= time()) {    // 如果Token 已过期，SSO登陆失败！
            return false;
        }

        if (!$this->userLogin()) {
            return false;
        }

        return true;
    }

    private function userLogin()
    {
        $transferConf = config('transfer.hs');
        $transferUser = array_get($transferConf, 'user', 'admin');
        // 查询用户名为 Admin 的用户作为SSO登录用户
        $user = User::where('user_id', $transferUser)->findOrFail();

        // 更新用户最后登录时间
        $clientIp = request()->ip();
        $logTime = date('Y-m-d H:i:s', time());
        if (!(new UserLoginStatus())->setLoginStatus($user->user_id, $clientIp, $logTime)) {
            return false;
        }

        // 存储登录信息
        $auth = [
            'u_id'         => $user->u_id,
            'username'     => $user->user_id,
            'user_group'   => $user->user_group,
            'access_token' => $user->token,
        ];
        session('user_auth', $auth);
        session('user_auth_sign', AuthSign($auth));

        // 写入登录时间
        $eventLog = ['type' => 3, 'content' => $user->user_id . '|' . $clientIp, 'time' => $logTime];
        $redisRes = (new \Redis());
        $redisRes->pconnect('127.0.0.1');
        $redisRes->rPush('event_log_list', json_encode($eventLog));

        return true;
    }
}