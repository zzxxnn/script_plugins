<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/6/15
 * Time: 9:46
 */

namespace app\index\repository;


class LicenseRepository
{

    public function get()
    {
        $licenceInfo = self::getLicenceInfo();
        if ($licenceInfo["status"] === "valid" || $licenceInfo["status"] === "expired") {
            $licenceInfo["user"] = base64_decode($licenceInfo["user"]);
            $licenceInfo["desc"] = base64_decode($licenceInfo["desc"]);
            $licenceInfo["copy_right"] = base64_decode($licenceInfo["copy_right"]);
            $licenceInfo["licence_owner"] = base64_decode($licenceInfo["licence_owner"]);
            $licenceInfo["model"] = base64_decode($licenceInfo["model"]);
        } else {
            exec("fpcmd serial_no", $serial_no);
            $licenceInfo["device_id"] = $serial_no[0];
        }

        return $licenceInfo;
    }

    public static function getLicenceInfo()
    {
        if (config('app_debug') === 'local') {
            $licenceInfo = ['{"status":"valid","id":"4ab37813d8ed8246","desc":"eHh4","lang":"chinese",' .
                '"licence_owner":"5YyX5Lqs5Y2r6L6+56eR5oqA5pyJ6ZmQ5YWs5Y+4","copy_right":"5YyX5Lqs5Y2r6L6+56eR5oqA5pyJ6ZmQ5YWs5Y+4",' .
                '"type":"official","device_id":"a3f0f5f42806cca3","user":"56CU5Y+R5Lit5b+D","model":"5bm75aKDMeezuw==",' .
                '"create_time":1529378597,"start_time":1529378578,"end_time":1560873600,"max_hosts":1024,"max_flows":100000,' .
                '"alive_time":27868511,"tick_count":331787,"utc_timestamp":1533005298}'];
        }else{
            exec("fpcmd licence_status", $licenceInfo);

        }

        return json_decode($licenceInfo[0], true);
    }
}