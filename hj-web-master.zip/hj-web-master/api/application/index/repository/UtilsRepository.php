<?php namespace app\index\repository;

/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/6/11
 * Time: 10:49
 */

class UtilsRepository
{
    protected $redis;

    public function __construct()
    {
        $this->redis = new \Redis();
        $this->redis->pconnect('127.0.0.1');
    }

    /**
     * 主机 封堵/解封
     * @param $operation
     * @param $ipMac
     * @return bool
     */
    public function setBlock($operation, $ipMac)
    {
        $commend = $operation === "block" ? "fpcmd block_list -i " . $ipMac : "fpcmd block_list -d " . $ipMac;
        ExcuteExec($commend);
        $log = [
            'attack_source' => $ipMac,
            'type'          => $operation === "block" ? 1 : 0,
            'uid'           => session('user_auth.u_id') ?: null,
            'time'          => time()
        ];
        $this->redis->rPush('block_log_list', json_encode($log));

        return true;
    }
}