<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/6/15
 * Time: 11:14
 */

namespace app\index\repository;


use app\index\model\SysConfig;
use app\index\model\User;

class SysConfRepository
{
    const COMMAND_POWEROFF = 8;
    const COMMAND_REBOOT = 9;

    public function sysCommand($type)
    {
        $cmd = "";
        switch ($type) {
            case self::COMMAND_POWEROFF:
                $cmd = 'poweroff';
                break;
            case self::COMMAND_REBOOT:
                $cmd = 'reboot';
                break;
            default;
        }

        header("Content-Type: application/json");
        echo json_encode(['errcode' => 0, 'errmsg' => 'ok']);
        // 刷新buffer
        ob_flush();
        flush();
        fastcgi_finish_request();

        ExcuteExec($cmd);
    }

    /**
     * 重置Admin 用户的登陆密码
     *
     * @param $password
     * @return bool
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function resetPwd($password)
    {
        $transferConf = config('transfer.hs.user');
        $transferUser = array_get($transferConf, 'user', 'admin');
        $user = User::where('user_id', $transferUser)->findOrFail();

        $result = $user->save(['password' => password_hash($password, PASSWORD_DEFAULT)]);

        return (bool)$result;
    }


    public function getSysConf($confType, $default = null)
    {
        $sysConf = (new SysConfig)->where('conf_type', $confType)->find();

        return $sysConf ? $sysConf->conf_value : $default;
    }

    public function updateSysConf($confType, $confValue)
    {
        $sysConf = (new SysConfig())->where('conf_type', $confType)->find();
        if ($sysConf) {
            $result = $sysConf->save(['conf_value' => $confValue], ['conf_type' => $confType]);
        } else {
            $result = SysConfig::create(['conf_type' => $confType, 'conf_value' => $confValue]);
        }

        return $result === false ? false : true;
    }

    /**
     * 获取系统SNTP服务器设置
     * @return array|mixed|null
     */
    public function getSntpConf()
    {
        $confVal = $this->getSysConf(SysConfig::CONF_SNTP_CONF, '');
        $confVal = explode('|', $confVal);
        $confVal = [
            'sntp_enable'        => (int)($confVal[0] ?? 0),
            'sntp_host'          => $confVal[1] ?? "",
            'sntp_sync_interval' => (int)($confVal[2] ?? 0),
        ];

        return $confVal;
    }

    /**
     * 更新系统SNTP服务器设置
     * @param $sntpEnable
     * @param $sntpHost
     * @param $sntpSyncInterval
     * @return bool
     */
    public function updateSntpConf($sntpEnable, $sntpHost, $sntpSyncInterval)
    {
        $confVal = $sntpEnable . '|' . $sntpHost . '|' . $sntpSyncInterval;

        if ($updateRslt = $this->updateSysConf(SysConfig::CONF_SNTP_CONF, $confVal)) {
            // 记录操作日志
            RecordOperLog(0, 3, '更新【系统SNTP服务配置】');
        }

        if ($updateRslt && !config('app_debug')) {
            $sntpEnable ? $this->setSNTPSync($sntpHost, $sntpSyncInterval) : $this->stopSNTPSync();
        }

        return (bool)$updateRslt;
    }

    /**
     * 重设SNTP同步
     * @param $sntpHost
     * @param $sntpSyncInterval
     */
    private function setSNTPSync($sntpHost, $sntpSyncInterval)
    {
        $order = sprintf('uroot fpcmd ntp-conf -i %s %u', $sntpHost, $sntpSyncInterval * 60);
        ExcuteExec($order);
    }

    /**
     * 停止SNTP同步
     *
     */
    private function stopSNTPSync()
    {
        ExcuteExec('uroot fpcmd ntp-conf -f');
    }

}