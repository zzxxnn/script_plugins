<?php

namespace app\index\controller;
use think\Controller;
use think\Session;
use think\Loader;

// 网络管理 主控制器
class Netmgmt extends Controller{

    protected $V_netmgmt; 
    protected $beforeActionList = [
        'checkPost'  => ['only' => 'add,update,del'],
        'checkGet'   => ['only' => 'get'],
        'checkAccess',
        'checkLogin',
        'checkValid'
    ];

    public function _initialize(){
        $this->V_netmgmt = Loader::validate('Netmgmt');
    }

    //【接口】获取
    public function get(){
        if(!$this->V_netmgmt->scene('get')->check(input()))
            return Finalfail($this->V_netmgmt->getError());

        $result = [];
        $type_arr = input('get.t');
        foreach (explode('|', $type_arr) as $type) {
            switch($type){
                case "1": // DHCP开关
                    $result['1'] = (int)$this->_getNetConf(1);
                    break;
                case "2": // 首选DNS 备选DNS
                    $result['2'] = $this->_getNetConf(2);
                    break;
                case "3": // DHCP 租期
                    $result['3'] = (int)$this->_getNetConf(3);
                    break;
                case "4": // 主机信息有效时间
                    $result['4'] = (int)$this->_getNetConf(4);
                    break;
                case "5": // 真实IP访问开关
                    $result['5'] = (int)$this->_getNetConf(5);
                    break;
                case "6": // 主机自动封堵开关
                    $result['6'] = (int)$this->_getNetConf(6);
                    break;
                case "7": // 虚拟IP变换间隔 | 虚拟域名变换间隔 | 虚拟网络变换间隔
                    $result['7'] = $this->_getNetConf(7);
                    break;
                case "8": // 管理口1 | 管理口2
                    $result['8'] = $this->_getNetConf(8);
                    break;
                case "9": // 真实IP网段
                    $result['9'] = $this->_getRip(0);
                    break;
                case "10": // 真实IP保留网段
                    $result['10'] = $this->_getRip(1);
                    break;
                case "11": // 虚拟IP网段
                    $result['11'] = $this->_getVip(0);
                    break;
                case "12": // 虚拟IP保留网段
                    $result['12'] = $this->_getVip(1);
                    break;
                case "13": // 外网IP网段
                    $result['13'] = $this->_getWip(0);
                    break;
                case "14": // 外网IP保留网段
                    $result['14'] = $this->_getWip(1);
                    break;
                case "15": // 虚拟网络网段
                    $result['15'] = $this->_getVnet(0);
                    break;
                case "16": // 虚拟网络保留网段
                    $result['16'] = $this->_getVnet(1);
                    break;
                case "17": // Liunx、Windows、Server主机比例
                    $result['17'] = $this->_getNetConf(17);
                    break;
                case "18": // 端口响应概率
                    $result['18'] = $this->_getNetConf(18);
                    break;
                case "19": // Linux端口
                    $result['19'] = $this->_getNetConf(19);
                    break;
                case "20": // Windows端口
                    $result['20'] = $this->_getNetConf(20);
                    break;
                case "21": // Server端口
                    $result['21'] = $this->_getNetConf(21);
                    break;
                case "22": // 响应mac标识
                    $result['22'] = $this->_getNetConf(22);
                    break;
                case "23": // 静态地址
                    $result['23'] = $this->_getBindIp();
                    break;
                case "24": // 静态路由
                    $result['24'] = $this->_getBindRouter();
                    break;
                case "25": // 主机透传
                    $result['25'] = $this->_getMacThrough();
                    break;
                // case "26": // 协议透传 STP开关
                //     $result['26'] = (int)$this->_getNetConf(26);
                //     break;
                // case "27": // 协议透传 Communication_Redundancy开关
                //     $result['27'] = (int)$this->_getNetConf(27);
                //     break;
                case "28": // 主机准入开关
                    $result['28'] = (int)$this->_getNetConf(28);
                    break;
                case "29": // 软件bypass
                    $result['29'] = $this->_getNetConf(29);
                    break;
                case "30": // 高可靠性
                    $result['30'] = $this->_getHiRel();
                    break;
                default:
                    #code...
                    break;
            }
        }
        return Finalsuccess($result);
    }

    //【接口】添加
    public function add(){
        if(!$this->V_netmgmt->scene('add')->check(input()))
            return Finalfail($this->V_netmgmt->getError());

        $type_arr = input('get.t');
        foreach (explode('|', $type_arr) as $type) {
            switch($type){
                case "9": // 真实IP网段
                    $this->_addRip(0);
                    break;
                case "10": // 真实IP保留网段
                    $this->_addRip(1);
                    break;
                case "11": // 虚拟IP网段
                    $this->_addVip(0);
                    break;
                case "12": // 虚拟IP保留网段
                    $this->_addVip(1);
                    break;
                case "13": // 外网IP网段
                    $this->_addWip(0);
                    break;
                case "14": // 外网IP保留网段
                    $this->_addWip(1);
                    break;
                case "15": // 虚拟网络网段
                    $this->_addVnet(0);
                    break;
                case "16": // 虚拟网络保留网段
                    $this->_addVnet(1);
                    break;
                case "23": // 静态地址
                    $this->_addBindIp();
                    break;
                case "24": // 静态路由
                    $this->_addBindRouter();
                    break;
                case "25": // 主机透传
                    $this->_addMacThrough();
                    break;
                case "29": // 软件 bypass
                    $this->_addBypass();
                    break;
                default:
                    #code...
                    break;
            }
        }
        return Finalsuccess();
    }

    // 【接口】更新
    public function update(){
        if(!$this->V_netmgmt->scene('update')->check(input()))
            return Finalfail($this->V_netmgmt->getError());

        $type_arr = input('get.t');
        foreach (explode('|', $type_arr) as $type) {
            switch($type){
                case "1": // DHCP开关
                    $this->_updateNetConf(1);
                    break;
                case "2": // 首选DNS 备选DNS
                    $this->_updateNetConf(2);
                    break;
                case "3": // DHCP 租期
                    $this->_updateNetConf(3);
                    break;
                case "4": // 主机信息有效时间
                    $this->_updateNetConf(4);
                    break;
                case "5": // 真实IP访问开关
                    $this->_updateNetConf(5);
                    break;
                case "6": // 主机自动封堵开关
                    $this->_updateNetConf(6);
                    break;
                case "7": // 虚拟IP变换间隔 | 虚拟域名变换间隔 | 虚拟网络变换间隔
                    $this->_updateNetConf(7);
                    break;
                case "8": // 管理口1 | 管理口2
                    $this->_updateNetConf(8);
                    break;
                case "9": // 真实IP网段
                    $this->_updateRip(0);
                    break;
                case "10": // 真实IP保留网段
                    $this->_updateRip(1);
                    break;
                case "11": // 虚拟IP网段
                    $this->_updateVip(0);
                    break;
                case "12": // 虚拟IP保留网段
                    $this->_updateVip(1);
                    break;
                case "13": // 外网IP网段
                    $this->_updateWip(0);
                    break;
                case "14": // 外网IP保留网段
                    $this->_updateWip(1);
                    break;
                case "15": // 虚拟网络网段
                    $this->_updateVnet(0);
                    break;
                case "16": // 虚拟网络保留网段
                    $this->_updateVnet(1);
                    break;
                case "17": // Liunx、Windows、Server主机比例
                    $this->_updateNetConf(17);
                    break;
                case "18": // 端口响应概率
                    $this->_updateNetConf(18);
                    break;
                case "19": // Linux端口
                    $this->_updateNetConf(19);
                    break;
                case "20": // Windows端口
                    $this->_updateNetConf(20);
                    break;
                case "21": // Server端口
                    $this->_updateNetConf(21);
                    break;
                case "22": // 响应mac标识
                    $this->_updateNetConf(22);
                    break;
                case "23": // 静态地址
                    $this->_updateBindIp();
                    break;
                case "24": // 静态路由
                    $this->_updateBindRouter();
                    break;
                case "25": // 主机透传
                    $this->_updateMacThrough();
                    break;
                // case "26": // 协议透传 STP开关
                //     $this->_updateNetConf(26);
                //     break;
                // case "27": // 协议透传 Communication_Redundancy开关
                //     $this->_updateNetConf(27);
                //     break;
                case "28": // 主机准入开关
                    $this->_updateNetConf(28);
                    break;
                case "30": // 高可靠性
                    $this->_updateHiRel();
                    break;
                default:
                    #code...
                    break;
            }
        }
        SyncTimestampUpdate(); // 更新配置同步时间戳
        return Finalsuccess();
    }

    //【接口】删除
    public function del(){
        if(!$this->V_netmgmt->scene('del')->check(input()))
            return Finalfail($this->V_netmgmt->getError());

        $type_arr = input('get.t');
        foreach (explode('|', $type_arr) as $type) {
            switch($type){
                case "9": // 真实IP网段
                    $this->_delRip(0);
                    break;
                case "10": // 真实IP保留网段
                    $this->_delRip(1);
                    break;
                case "11": // 虚拟IP网段
                    $this->_delVip(0);
                    break;
                case "12": // 虚拟IP保留网段
                    $this->_delVip(1);
                    break;
                case "13": // 外网IP网段
                    $this->_delWip(0);
                    break;
                case "14": // 外网IP保留网段
                    $this->_delWip(1);
                    break;
                case "15": // 虚拟网络网段
                    $this->_delVnet(0);
                    break;
                case "16": // 虚拟网络保留网段
                    $this->_delVnet(1);
                    break;
                case "23": // 静态地址
                    $this->_delBindIp();
                    break;
                case "24": // 静态路由
                    $this->_delBindRouter();
                    break;
                case "25": // 主机透传
                    $this->_delMacThrough();
                    break;
                case "29": // 软件bypass
                    $this->_delBypass();
                    break;
                default:
                    #code...
                    break;
            }
        }
        return Finalsuccess();
    }

    //【接口】导出
    public function export(){
        if(!$this->V_netmgmt->scene('export')->check(input()))
            return Finalfail($this->V_netmgmt->getError());

        $type = input('get.t');
        switch($type){
            case "23": // 静态地址
                $this->_exportBindIp();
                break;
            case "25": // 主机透传
                $this->_exportMacThrough();
                break;
            default:
                #code...
                break;
            }
    }

    //【接口】导入
    public function upload(){
        if(!$this->V_netmgmt->scene('upload')->check(input()))
            return Finalfail($this->V_netmgmt->getError());

        $type = input('get.t');
        switch($type){
            case "23": // 静态地址
                $this->_uploadBindIp();
                break;
            case "25": // 主机透传
                $this->_uploadMacThrough();
                break;
            default:
                #code...
                break;
            }
        return Finalsuccess();
    }

    //---------------------------------------------------------------------------

    private function _getNetConf($conf_type){
        $C_netconf = controller('Netconf', 'netmgmt');
        $result = $C_netconf->get($conf_type);
        return $result;
    }
    private function _getRip($exclude){
        $C_rip = controller('Ripconf', 'netmgmt');
        $result = $C_rip->get($exclude);
        return $result;
    }
    private function _getVip($exclude){
        $C_vip = controller('Vipconf', 'netmgmt');
        $result = $C_vip->get($exclude);
        return $result;
    }
    private function _getWip($exclude){
        $C_wip = controller('Wipconf', 'netmgmt');
        $result = $C_wip->get($exclude);
        return $result;
    }
    private function _getVnet($exclude){
        $C_vnet = controller('Vnetconf', 'netmgmt');
        $result = $C_vnet->get($exclude);
        return $result;
    }
    private function _getBindIp(){
        $C_bindip = controller('Bindip', 'netmgmt');
        $result = $C_bindip->get();
        return $result;
    }
    private function _getBindRouter(){
        $C_bindrouter = controller('Bindrouter', 'netmgmt');
        $result = $C_bindrouter->get();
        return $result;
    }
    private function _getMacThrough(){
        $C_mac_through = controller('Macthrough', 'netmgmt');
        $result = $C_mac_through->get();
        return $result;
    }
    private function _getHiRel(){
        $C_hi_rel = controller('HighReliably', 'netmgmt');
        $result = $C_hi_rel->get();
        return $result;
    }
    //---------------------------------------------------------------------------

    private function _addRip($exclude){
        $C_rip = controller('Ripconf', 'netmgmt');
        $C_rip->add($exclude);
    }
    private function _addVip($exclude){
        $C_vip = controller('Vipconf', 'netmgmt');
        $C_vip->add($exclude);
    }
    private function _addWip($exclude){
        $C_wip = controller('Wipconf', 'netmgmt');
        $C_wip->add($exclude);
    }
    private function _addVnet($exclude){
        $C_vnet = controller('Vnetconf', 'netmgmt');
        $C_vnet->add($exclude);
    }
    private function _addBindIp(){
        $C_bindip = controller('Bindip', 'netmgmt');
        $C_bindip->add();
    }
    private function _addBindRouter(){
        $C_bindrouter = controller('Bindrouter', 'netmgmt');
        $C_bindrouter->add();
    }
    private function _addMacThrough(){
        $C_mac_through = controller('Macthrough', 'netmgmt');
        $C_mac_through->add();
    }
    private function _addBypass(){
        $C_bypass = controller('Bypass', 'netmgmt');
        $C_bypass->add();
    }

    //---------------------------------------------------------------------------

    private function _updateNetConf($conf_type){
        $C_netconf = controller('Netconf', 'netmgmt');
        $C_netconf->update($conf_type);
    }
    private function _updateRip($exclude){
        $C_rip = controller('Ripconf', 'netmgmt');
        $C_rip->update($exclude);
    }
    private function _updateVip($exclude){
        $C_vip = controller('Vipconf', 'netmgmt');
        $C_vip->update($exclude);
    }
    private function _updateWip($exclude){
        $C_wip = controller('Wipconf', 'netmgmt');
        $C_wip->update($exclude);
    }
    private function _updateVnet($exclude){
        $C_vnet = controller('Vnetconf', 'netmgmt');
        $C_vnet->update($exclude);
    }
    private function _updateBindIp(){
        $C_bindip = controller('Bindip', 'netmgmt');
        $C_bindip->update();
    }
    private function _updateBindRouter(){
        $C_bindrouter = controller('Bindrouter', 'netmgmt');
        $C_bindrouter->update();
    }
    private function _updateMacThrough(){
        $C_mac_through = controller('Macthrough', 'netmgmt');
        $C_mac_through->update();
    }
    private function _updateHiRel(){
        $C_hi_rel = controller('HighReliably', 'netmgmt');
        $C_hi_rel->update();
    }

    //---------------------------------------------------------------------------

    private function _delRip($exclude){
        $C_rip = controller('Ripconf', 'netmgmt');
        $C_rip->del($exclude);
    }
    private function _delVip($exclude){
        $C_vip = controller('Vipconf', 'netmgmt');
        $C_vip->del($exclude);
    }
    private function _delWip($exclude){
        $C_wip = controller('Wipconf', 'netmgmt');
        $C_wip->del($exclude);
    }
    private function _delVnet($exclude){
        $C_vnet = controller('Vnetconf', 'netmgmt');
        $C_vnet->del($exclude);
    }
    private function _delBindIp(){
        $C_bindip = controller('Bindip', 'netmgmt');
        $C_bindip->del();
    }
    private function _delBindRouter(){
        $C_bindrouter = controller('Bindrouter', 'netmgmt');
        $C_bindrouter->del();
    }
    private function _delMacThrough(){
        $C_mac_through = controller('Macthrough', 'netmgmt');
        $C_mac_through->del();
    }
    private function _delBypass(){
        $C_bypass = controller('Bypass', 'netmgmt');
        $C_bypass->del();
    }

    //---------------------------------------------------------------------------

    private function _exportBindIp(){
        $C_bindip = controller('Bindip', 'netmgmt');
        $C_bindip->export();
    }
    private function _exportMacThrough(){
        $C_mac_through = controller('Macthrough', 'netmgmt');
        $C_mac_through->export();
    }

    private function _uploadBindIp(){
        $C_bindip = controller('Bindip', 'netmgmt');
        $C_bindip->upload();
    }
    private function _uploadMacThrough(){
        $C_mac_through = controller('Macthrough', 'netmgmt');
        $C_mac_through->upload();
    }
    
    //---------------------------------------------------------------------------

    //【前置方法】验证访问策略
    protected function checkAccess(){
        if(!CheckAccess())
            Error('15006','access denied');
    }
    //【前置方法】验证登陆
    protected function checkLogin(){
        if(!CheckLoginToken())
            Error('15005','need login or token error');
    }
    //【前置方法】验证设备授权
    protected function checkValid(){
        $status = CheckValid();
        if($status != '0')
            Error($status,'need valid');
    }
    //【前置方法】验证post请求
    protected function checkPost(){
        if(!request()->isPost())
            Error("15001","need post method");
    }
    //【前置方法】验证get请求
    protected function checkGet(){
        if(!request()->isGet())
            Error("15002","need get method");
    }
    //【空方法】
    public function _empty(){
        $this->redirect('/errorpage');
    }
}
