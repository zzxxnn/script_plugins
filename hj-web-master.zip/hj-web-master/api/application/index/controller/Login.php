<?php

namespace app\index\controller;

use app\index\model\UserLoginStatus;
use app\index\model\User;
use app\index\model\SysConfig;
use app\index\model\UserPass;
use think\Controller;
use think\Session;
use think\Loader;
use think\Db;

// 管理员用户登陆 主控制器
class Login extends Controller
{
    protected $V_login;
    protected $beforeActionList = [
        'checkPost'  => ['only' => 'login'],
        'checkGet'   => ['only' => 'info']
    ];

    public function _initialize()
    {
        $this->V_login = Loader::validate('Login');
        $this->redis = new \Redis();
    }

    //【接口】登陆
    public function login()
    {
        if (!$this->V_login->scene('login')->check(input())) {
            return Finalfail($this->V_login->getError());
        }
        
        $username = input('post.username');
        $password = input('post.password');
        $M_user = new User;
        $M_user_login_status = new UserLoginStatus;
        $M_sys_config = new SysConfig;
        $client_ip = GetClientIp();
    
        $this->redis->pconnect('127.0.0.1');

        $uid_data = $M_user->selectUidByUsername($username);
        if (empty($uid_data)) {
            $login_event_log = [
                'type' => 8,
                'content' => "$username|$client_ip",
                'time' => date('Y-m-d H:i:s', time())
            ];
            $this->redis->rPush('event_log_list', json_encode($login_event_log));

            return Finalfail("10003");
        }

        $u_id = $uid_data[0]['u_id']; // 用户id
        
        $login_status = $M_user_login_status->selectStatusByUsernameIp($username, $client_ip); //获取登陆状态 若第一次登陆则生成状态
        if (empty($login_status)) {
            $result = $M_user_login_status->insertLoginStatus($username, $client_ip);
            if ($result <= 0) {
                return Finalfail("20001", "insert login status error");
            }

            $login_status = $M_user_login_status->selectStatusByUsernameIp($username, $client_ip);
        }

        $last_login_time = strtotime($login_status[0]["last_login_time"]); // 最近一次登陆时间
        $err_counts = $login_status[0]["error_count"]; // 密码已经错误次数
        $now_time = strtotime("now"); // 当前时间

        $data = $M_sys_config->selectValueByConfType("punish");
        $punish_times = $data[0]['conf_value']*60; // 惩罚时间

        $data = $M_sys_config->selectValueByConfType("max_times");
        $max_counts = $data[0]['conf_value']; // 最大登陆次数
        
        if (!empty($last_login_time) && ($now_time <= ($punish_times + $last_login_time)) && ($err_counts >= $max_counts)) {
            $time =[
                'last_login_time' => date('Y-m-d H:i:s', $last_login_time),
                'overplus_time' => $punish_times - ($now_time - $last_login_time),
            ];
            return Finalfail("10004", "punish time", $time);
        }

        $pwd_data = $M_user->selectPwdByUid($u_id); // 获取用户密码进行验证

        $result = $M_user_login_status->updateLastLoginTime($username, $client_ip, date('Y-m-d H:i:s', strtotime('now'))); // 更新登陆时间
        if ($result < 0) {
            return Finalfail("20001", "update login status error");
        }

        if (!password_verify($password, $pwd_data[0]['password'])) { // 登陆失败

            $login_event_log = [
                'type' => 8,
                'content' => "$username|$client_ip",
                'time' => date('Y-m-d H:i:s', time())
            ];
            $this->redis->rPush('event_log_list', json_encode($login_event_log));

            $result = $M_user_login_status->updateErrorCounts($username, $client_ip, $err_counts+1);
            if ($result < 0) {
                return Finalfail("20001", "update error counts error");
            }

            return Finalfail("10003", "password error, only ".($max_counts-$err_counts-1)." times left");
        }

        $result = $M_user_login_status->updateErrorCounts($username, $client_ip, 0); // 登陆成功重置次数
        if ($result < 0) {
            return Finalfail("20001", "update error counts error");
        }

        $user_data = $M_user->selectUserByUid($u_id); // 登陆获取用户信息
        $auth = array(
            'u_id'        => $u_id,
            'username'    => $user_data[0]['user_id'],
            'user_group'  => $user_data[0]['user_group'],
            'access_token'=> $user_data[0]['token'],
        );
        session('user_auth', $auth);
        session('user_auth_sign', AuthSign($auth));
        $auth['access'] = CheckAccess();

        $login_event_log = [
            'type' => 3,
            'content' => "$username|$client_ip",
            'time' => date('Y-m-d H:i:s', time())
        ];
        $this->redis->rPush('event_log_list', json_encode($login_event_log));

        return Finalsuccess($auth);
    }

    //【接口】登陆状态检测
    public function info()
    {
        $access = CheckAccess() ? true : false;
        if (IsLogin() === 0) {
            return Finalsuccess(['access'=>$access, 'is_login'=>false]);
        } else {
            $user['access'] = $access;
            $user['is_login'] = true;
            $user['username'] = session("user_auth.username");
            $user['user_group'] = session("user_auth.user_group");
            $user['access_token'] = session("user_auth.access_token");
            return Finalsuccess($user);
        }
    }

    //【接口】注销
    public function logout()
    {
        if (IsLogin()) {
            $user_id = session("user_auth.username");
            $ip = GetClientIp();
            $login_event_log = [
                'type' => 4,
                'content' => "$user_id|$ip",
                'time' => date('Y-m-d H:i:s', time())
            ];
            $this->redis->pconnect('127.0.0.1');
            $this->redis->rPush('event_log_list', json_encode($login_event_log));

            session('user_auth', null);
            session('user_auth_sign', null);
            session_destroy();
        }
        return Finalsuccess();
    }

    //【前置方法】验证登陆
    protected function checkLogin()
    {
        if (!CheckLoginToken()) {
            Error('15005', 'need login or token error');
        }
    }
    //【前置方法】验证设备授权
    protected function checkValid()
    {
        $status = CheckValid();
        if ($status != '0') {
            Error($status, 'need valid');
        }
    }
    //【前置方法】验证post请求
    protected function checkPost()
    {
        if (!request()->isPost()) {
            Error("15001", "need post method");
        }
    }
    //【前置方法】验证get请求
    protected function checkGet()
    {
        if (!request()->isGet()) {
            Error("15002", "need get method");
        }
    }
    //【空方法】
    public function _empty()
    {
        $this->redirect('/errorpage');
    }
}
