<?php

namespace app\index\controller;

use app\index\model\SysConfig;
use app\index\repository\SysConfRepository;
use app\index\traits\ControllerGuard;
use app\index\validate\Sysconf as SysconfValidator;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;

// 系统配置 主控制器
class Sysconf extends Controller
{
    use ControllerGuard;

    protected $V_sysconf;

    protected $beforeActionList = [
        'checkPost'  => ['only' => 'add,update,del'],
        'checkGet'   => ['only' => 'get,command'],
        'checkAccess',
        'checkLogin' => ['except' => 'get'],
        'checkValid'
    ];

    public function __construct(Request $request = null)
    {
        $this->V_sysconf = new SysconfValidator();
        parent::__construct($request);
    }

    // 【接口】获取 
    public function get()
    {
        if (!$this->V_sysconf->scene('get')->check(input()))
            return Finalfail($this->V_sysconf->getError());

        $result = [];
        $type_arr = input('get.t');
        foreach (explode('|', $type_arr) as $type) {
            switch ($type) {
                case "1":  // Web UI超时
                    $result['1'] = (int)$this->_getSysConf("web_ui");
                    break;
                case "2": // 登录惩罚时间 
                    $result['2'] = (int)$this->_getSysConf("punish");
                    break;
                case "3":  // 最大登陆次数
                    $result['3'] = (int)$this->_getSysConf("max_times");
                    break;
                case "4":  // 集中管理
                    $result['4'] = $this->_getSysConf("remote");
                    break;
                case "5":  // 系统时间
                    $result['5'] = $this->_sysTime('get');
                    break;
                case "6":  // 获取网管策略
                    $result['6'] = $this->_getWebmgmt();
                    break;
                case "7":  // 日志服务器
                    $result['7'] = $this->_getLogServer();
                    break;
                default:
                    #code...
                    break;
            }
        }

        return Finalsuccess($result);
    }

    //【接口】添加
    public function add()
    {
        if (!$this->V_sysconf->scene('add')->check(input()))
            return Finalfail($this->V_sysconf->getError());

        $type_arr = input('get.t');
        foreach (explode('|', $type_arr) as $type) {
            switch ($type) {
                case "6": // 网管策略
                    $this->_addWebmgmt();
                    break;
                case "7":  // 日志服务器
                    $this->_addLogServer();
                    break;
                default:
                    #code...
                    break;
            }
        }

        return Finalsuccess();
    }

    // 【接口】更新
    public function update()
    {
        if (!$this->V_sysconf->scene('update')->check(input()))
            return Finalfail($this->V_sysconf->getError());

        $result = NULL;
        $type_arr = input('get.t');
        foreach (explode('|', $type_arr) as $type) {
            switch ($type) {
                case "1": // Web UI超时
                    $this->_setSysConf("web_ui");
                    break;
                case "2": // 登录惩罚时间 
                    $this->_setSysConf("punish");
                    break;
                case "3":  // 最大登陆次数
                    $this->_setSysConf("max_times");
                    break;
                case "4": // 集中管理
                    $this->_setSysConf("remote");
                    exec("cd /web/www_root && php think metric --restart >/dev/null 2>&1");
                    break;
                case "5": // 系统时间
                    $result['5'] = $this->_sysTime('update');
                    break;
                case "6": // 网管策略
                    $this->_updateWebmgmt();
                    break;
                case "7":  // 日志服务器
                    $this->_updateLogServer();
                    break;
                default:
                    #code...
                    break;
            }
        }

        return Finalsuccess($result);
    }

    //【接口】删除
    public function del()
    {
        if (!$this->V_sysconf->scene('add')->check(input()))
            return Finalfail($this->V_sysconf->getError());

        $type_arr = input('get.t');
        foreach (explode('|', $type_arr) as $type) {
            switch ($type) {
                case "6": // 网管策略
                    $this->_delWebmgmt();
                    break;
                case "7":  // 日志服务器
                    $this->_delLogServer();
                    break;
                default:
                    #code...
                    break;
            }
        }

        return Finalsuccess();
    }

    //【接口】导出
    public function export()
    {
        if (!$this->V_sysconf->scene('export')->check(input()))
            return Finalfail($this->V_sysconf->getError());

        $type = input('get.t');
        switch ($type) {
            case "10": // 导出系统配置备份  
                $this->_exportSysConf();
                break;
            default:
                #code...
                break;
        }
    }

    //【接口】导入
    public function upload()
    {
        if (!$this->V_sysconf->scene('upload')->check(input()))
            return Finalfail($this->V_sysconf->getError());

        $type = input('get.t');
        switch ($type) {
            case "10": // 导入系统配置备份 
                $this->_uploadSysConf();
                break;
            default:
                #code...
                break;
        }

        return Finalsuccess();
    }

    //【接口】执行
    public function command()
    {
        if (!$this->V_sysconf->scene('command')->check(input()))
            return Finalfail($this->V_sysconf->getError());

        $type = input('get.t');
        switch ($type) {
            case "8": // 关机 
                $this->_sysCommand($type);
                break;
            case "9": // 重启 
                $this->_sysCommand($type);
                break;
            case "11": // 恢复出厂设置 
                $this->_sysDefault();
                break;
            default:
                #code...
                break;
        }

        return Finalsuccess();
    }

    //【接口】升级
    public function upgrade()
    {
        if (!$this->V_sysconf->scene('upgrade')->check(input()))
            return Finalfail($this->V_sysconf->getError());

        $type = input('get.t');
        switch ($type) {
            case "12": // 升级系统 
                $this->_uploadBzImage();
                break;
            default:
                #code...
                break;
        }

        return Finalsuccess();
    }

    /**
     * 获取SNTP设置
     * @param SysConfRepository $repository
     * @return String
     */
    public function getSntpConf(SysConfRepository $repository)
    {
        $confVal = $repository->getSntpConf();

        return Finalsuccess(['data' => $confVal]);
    }

    /**
     * 更新SNTP设置
     * @param Request $request
     * @param SysConfRepository $repository
     * @return Object|String
     */
    public function updateSntpConf(Request $request, SysConfRepository $repository)
    {
        $data = $request->only(['sntp_enable', 'sntp_host', 'sntp_sync_interval']);
        if (!$this->V_sysconf->scene('update_sntp_conf')->check($data)) {
            return Finalfail(422, $this->V_sysconf->getError());
        }

        if (!$repository->updateSntpConf($data['sntp_enable'], $data['sntp_host'], $data['sntp_sync_interval'])) {
            return Finalfail(1, 'SNTP设置更新失败！');
        }

        return Finalsuccess(null, 'SNTP设置已更新！');
    }


    //-----------------------------------------------------------------------

    //【方法】获取、修改系统时间
    private function _sysTime($oper)
    {
        if ($oper == 'get') {
            return date('Y-m-d H:i:s');
        }
        if (!$this->V_sysconf->scene('set_time')->check(['time' => input('post.5')]))
            Error($this->V_sysconf->getError());

        $time = strtotime(input('post.5'));
        ExcuteExec('date -s "' . date('Y-m-d H:i:s', $time) . '"');

        return date('Y-m-d H:i:s', $time);
    }

    //【方法】获取 1 Web UI超时 2 登录惩罚时间 3 最大登陆次数 4 集中管理
    private function _getSysConf($type)
    {
        $M_sysconf = new SysConfig;
        $result = $M_sysconf->selectValueByConfType($type);

        return $result[0]["conf_value"];
    }

    //【方法】修改 1 Web UI超时 2 登录惩罚时间 3 最大登陆次数 4 集中管理
    private function _setSysConf($type)
    {
        if ($type === "web_ui") {
            if (!$this->V_sysconf->scene('set_web_ui')->check(["web_ui" => input('post.1')]))
                Error($this->V_sysconf->getError());
            $value = input('post.1');
        }
        if ($type === "punish") {
            if (!$this->V_sysconf->scene('set_punish')->check(["punish" => input('post.2')]))
                Error($this->V_sysconf->getError());
            $value = input('post.2');
        }
        if ($type === "max_times") {
            if (!$this->V_sysconf->scene('set_max_times')->check(["max_times" => input('post.3')]))
                Error($this->V_sysconf->getError());
            $value = input('post.3');
        }
        if ($type === "remote") {
            if (!$this->V_sysconf->scene('set_remote')->check(["remote" => input('post.4')]))
                Error($this->V_sysconf->getError());
            $value = input('post.4') . "|0";
        }

        $M_sysconf = new SysConfig;
        $result = $M_sysconf->updateValueByConfType($type, $value);
        if ($result < 0) {
            Error('20001');
        }
    }

    //【方法】系统配置备份
    private function _exportSysConf()
    {
        $C_maker = controller('Makeconfjson', 'tools');
        $json_content = $C_maker->make();
        $name = "Configuration_" . date("YmdHis");

        header("Content-Transfer-Encoding: binary");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Expires: 0");
        header("Pragma: public");
        header("Content-Type: application/octet-stream");
        header("Accept-Ranges: bytes");
        header("Accept-Length: " . sizeof($json_content));
        header("Content-Disposition: attachment; filename=$name");
        echo $json_content;

        RecordOperLog(210, 4); // 记录操作日志
    }

    //【方法】系统配置恢复
    private function _uploadSysConf()
    {
        $file = request()->file('file');
        if (is_null($file))
            Error('10020', 'file null');

        $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
        $file = $info->getPathName();
        if (filesize($file) === 0)
            Error('10020', 'file null');

        $fp = fopen($file, "r");
        $json_content = fread($fp, filesize($file));
        fclose($fp);
        exec("rm -rf " . $file);

        if (!is_array(json_decode($json_content, TRUE)))
            Error('12025');

        $C_parse = controller('Parseconfjson', 'tools');
        $C_parse->parse($json_content);
    }

    //【方法】系统执行重启关机
    private function _sysCommand($type)
    {
        (new SysConfRepository())->sysCommand($type);
    }

    //【方法】系统恢复默认配置
    private function _sysDefault()
    {
        $file = APP_PATH . "index/tools/default_configuration.json";
        $fp = fopen($file, "r");
        $json_content = fread($fp, filesize($file));
        fclose($fp);

        if (!is_array(json_decode($json_content, TRUE)))
            Error('12025');

        $C_parse = controller('Parseconfjson', 'tools');
        $C_parse->parse($json_content);
    }

    //【方法】升级系统
    private function _uploadBzImage()
    {
        $fileElementName = 'file';
        if (!empty($_FILES[$fileElementName]['error'])) {
            if ($_FILES[$fileElementName]['size'] < 30 * 1024 * 1024)
                Error('12026');
        }
        if (empty($_FILES[$fileElementName]['tmp_name']) || $_FILES[$fileElementName]['tmp_name'] == 'none')
            Error("10020");

        $tag = @file_get_contents($_FILES[$fileElementName]['tmp_name'], false, null, 0, 2);

        if (empty($tag) || ord($tag[0]) !== 0xea || ord($tag[1]) !== 5)
            Error("12026");

        if (!@move_uploaded_file($_FILES[$fileElementName]['tmp_name'], "/hard_disk/boot/bzImage"))
            Error("10017");

        exec('cat /etc/version', $sysinfo);
        $sysinfo = trim($sysinfo[0]);
        $sysinfo = preg_split("/\s+/", $sysinfo);
        $v_old = $sysinfo[0] . "." . $sysinfo[3];
        exec("touch /hard_disk/.upgrade && chmod 777 /hard_disk/.upgrade"); // 写入数据库版本flag
        file_put_contents("/hard_disk/.upgrade", $v_old);
    }

    private function _getWebmgmt()
    {
        $C_webmgmt = controller('Webmgmt', 'sysconf');
        $result = $C_webmgmt->get();

        return $result;
    }

    private function _addWebmgmt()
    {
        $C_webmgmt = controller('Webmgmt', 'sysconf');
        $C_webmgmt->add();
    }

    private function _updateWebmgmt()
    {
        $C_webmgmt = controller('Webmgmt', 'sysconf');
        $C_webmgmt->update();
    }

    private function _delWebmgmt()
    {
        $C_webmgmt = controller('Webmgmt', 'sysconf');
        $C_webmgmt->del();
    }

    private function _getLogServer()
    {
        $C_log_server = controller('Logservers', 'sysconf');
        $result = $C_log_server->get();

        return $result;
    }

    private function _addLogServer()
    {
        $C_log_server = controller('Logservers', 'sysconf');
        $C_log_server->add();
    }

    private function _updateLogServer()
    {
        $C_log_server = controller('Logservers', 'sysconf');
        $C_log_server->update();
    }

    private function _delLogServer()
    {
        $C_log_server = controller('Logservers', 'sysconf');
        $C_log_server->del();
    }

}
