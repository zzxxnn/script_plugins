<?php
namespace app\index\controller;
use app\index\repository\UtilsRepository;
use think\Controller;
use think\Loader;
use think\Request;

// 工具类 主控制器
class Utils extends Controller {

    protected $redis;
    protected $V_utils;
    protected $beforeActionList = [
        'checkGet'   => ['only' => 'ethgroups,clearsession'],
        'checkPost'  => ['only' => 'setblock,pingremoteip'],
        'checkAccess',
        'checkLogin' => ['except' => 'checkstart'],
        'checkValid'
    ];

    public function _initialize(){
        $this->V_utils = Loader::validate('Utils');
        $this->redis = new \Redis();
        $this->redis->pconnect('127.0.0.1');
    }

    //【接口】获取物理线路ID
    public function ethGroups(){
        $groups = [];
        $eth_chart = GetEthChart();
        
        foreach($eth_chart as $table) {
            if(!($table['groupid'] > 0)) {
                continue;
            }
            if(in_array($table['groupid'],$groups)) {
                continue;
            }
            array_push($groups,$table['groupid']);
        }
        
        usort($groups,function($a,$b){   
            return intval($a) - intval($b);
        }); 
        
        return Finalsuccess(['group_id' => $groups]);
    }

    //【接口】用户监控清空会话
    public function clearSession(){
        ExcuteExec("fpcmd host_flows -f");
        return Finalsuccess();
    }

    //【接口】封堵解封
    public function setBlock(UtilsRepository $repository){
        if(!$this->V_utils->scene('setBlock')->check(input())){
            return Finalfail($this->V_utils->getError());
        }

        $oper = input("post.oper");
        $ipmac = input("post.ipmac");
        if (!$repository->setBlock($oper, $ipmac)) {
            return Finalfail('操作失败！');
        }

        return Finalsuccess();
    }

    //【接口】 ping诊断
    public function ping() {
        if (!$this->V_utils->scene('get')->check(input()))
            return Finalfail($this->V_utils->getError());
        $t = input('get.t');
        switch ($t) {
            case '1':
                if (!$this->V_utils->scene('ping')->check(input()))
                    return Finalfail($this->V_utils->getError());

                $ip = input('post.ip');
                $times = input('post.times');
                $length = input('post.length');
                $file_name = "/tmp/ping".session_id();

                if(file_exists($file_name)) {
                    exec("ps -ef | grep $file_name | grep -v grep | awk '{print \"kill -9 \" $2}' | sh && rm -rf $file_name");
                }

                pclose(popen("touch $file_name && ping $ip -c $times -s $length > $file_name 2>&1 || true && sleep 2 && rm -rf $file_name &", "r"));
                
                return Finalsuccess();
                break;
            case '2':
                $file_name = "/tmp/ping".session_id();
                if(file_exists($file_name)) {
                    exec("cat $file_name",$result);
                    return Finalsuccess(["ping"=>$result]);
                }else{
                    return Finalfail('10021','session over!');
                }
                break;
            default:
                break;
        }
    }

    //【接口】 traceroute诊断
    public function traceroute() {
        if (!$this->V_utils->scene('get')->check(input()))
            return Finalfail($this->V_utils->getError());
        $t = input('get.t');
        switch ($t) {
            case '1':
                if (!$this->V_utils->scene('traceroute')->check(input()))
                    return Finalfail($this->V_utils->getError());
                $ip = input('post.ip');
                $min_ttl = input('post.min_ttl');
                $max_ttl = input('post.max_ttl');
                $file_name = "/tmp/traceroute".session_id();
                if(file_exists($file_name)) {
                    exec("ps -ef | grep $file_name | grep -v grep | awk '{print \"kill -9 \" $2}' | sh && rm -rf $file_name");
                }
                pclose(popen("touch $file_name && traceroute -n -f $min_ttl -m $max_ttl $ip > $file_name 2>&1 || true && sleep 2 && rm -rf $file_name &", "r"));

                return Finalsuccess();
                break;
            case '2':
                $file_name = "/tmp/traceroute".session_id();
                if(file_exists($file_name)) {
                    exec("cat $file_name",$result);
                    return Finalsuccess(["traceroute"=>$result]);
                }else{
                    return Finalfail('10021','session over!');
                }
                break;
            default:
                break;
        }        
    }

    //测试对端ip（ping）
    public function pingRemoteIp(){
        if (!$this->V_utils->scene('pingremoteip')->check(input()))
            return Finalfail($this->V_utils->getError());

        $ip = input('post.ip');
        if(empty($ip)){
            return Finalfail('10024');
        }

        exec('/bin/sh /sbin/ping.sh '.$ip, $result, $status);
        if($status !== 0){
            return Finalfail('10024');
        }
        if($result[0] === 'down'){
            return Finalfail('10024');
        }
        return Finalsuccess();
    }
    // 【接口】检测开机
    public function checkStart(){
        return Finalsuccess();
    }

    // 【接口】虚拟网络变换cli
    public function vnetalter(){
        ExcuteExec("nohup fpcmd alter_vnetwork >/dev/null 2>&1 &");
        return Finalsuccess();
    }
    
    //-------------------------------------------------------

    //【前置方法】验证访问策略
    protected function checkAccess(){
        if(!CheckAccess())
            Error('15006','access denied');
    }
    //【前置方法】验证登陆
    protected function checkLogin(){
        if(!CheckLoginToken())
            Error('15005','need login or token error');
    }
    //【前置方法】验证设备授权
    protected function checkValid(){
        $status = CheckValid();
        if($status != '0')
            Error($status,'need valid');
    }
    //【前置方法】验证post请求
    protected function checkPost(){
        if(!request()->isPost())
            Error("15001","need post method");
    }
    //【前置方法】验证get请求
    protected function checkGet(){
        if(!request()->isGet())
            Error("15002","need get method");
    }
    //【空方法】
    public function _empty(){
        $this->redirect('/errorpage');
    }

}