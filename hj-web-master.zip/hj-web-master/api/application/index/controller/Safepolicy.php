<?php

namespace app\index\controller;
use think\Controller;
use think\Session;
use think\Loader;

// 安全策略 主控制器
class Safepolicy extends Controller{

    protected $V_safepolicy; 
    protected $beforeActionList = [
        'checkPost'  => ['only' => 'ad,update,del'],
        'checkGet'   => ['only' => 'get'],
        'checkAccess',
        'checkLogin',
        'checkValid'
    ];

    public function _initialize(){
        $this->V_safepolicy = Loader::validate('Safepolicy');
    }

    //【接口】获取
    public function get(){
        if(!$this->V_safepolicy->scene('get')->check(input()))
            return Finalfail($this->V_safepolicy->getError());

        $result = [];
        $type_arr = input('get.t');
        foreach (explode('|', $type_arr) as $type) {
            switch($type){
                case "1": // 内网防火墙
                    $result['1'] = $this->_getInnerFw();
                    break;
                case "2": // 蜜罐主机
                    $result['2'] = $this->_getHoneyHost();
                    break;
                case "3": // 主机备注
                    $result['3'] = $this->_getHostInfo();
                    break;
                case "4": // 主机黑名单
                    $result['4'] = $this->_getHostBwlist(1);
                    break;
                case "5": // 主机白名单
                    $result['5'] = $this->_getHostBwlist(0);
                    break;
                case "6": // 主机准入
                    $result['6'] = $this->_getHostAllow();
                    break;
                case "7": // 全息伪装
                    $result['7'] = $this->_getServerMask();
                    break;
                case "8": // 虚开配置
                    $result['8'] = $this->_getPortUnreal();
                    break;
                case "9": // 虚开白名单
                    $result['9'] = $this->_getPortUnrWlist();
                    break;
                case "10": // 应用访问策略
                    $result['10'] = $this->_getAccessSt();
                    break;
                default:
                    #code...
                    break;
            }
        }
        return Finalsuccess($result);
    }
    
    //【接口】添加
    public function add(){
        if(!$this->V_safepolicy->scene('add')->check(input()))
            return Finalfail($this->V_safepolicy->getError());

        $result = NULL;
        $type_arr = input('get.t');
        foreach (explode('|', $type_arr) as $type) {
            switch($type){
                case "1": // 内网防火墙
                    $this->_addInnerFw();
                    break;
                case "2": // 蜜罐主机
                    $this->_addHoneyHost();
                    break;
                case "3": // 主机备注
                    if(input('get.quick') == 'true'){
                        $this->_quickSetHostInfo();
                    }else{
                        $this->_addHostInfo();
                    }
                    break;
                case "4": // 主机黑名单
                    $this->_addHostBwlist(1);
                    break;
                case "5": // 主机白名单
                    $this->_addHostBwlist(0);
                    break;
                case "6": // 主机准入
                    $this->_addHostAllow();
                    break;
                case "7": // 全息伪装
                    $this->_addServerMask();
                    break;
                case "8": // 虚开配置
                    $this->_addPortUnreal();
                    break;
                case "9": // 虚开白名单
                    $this->_addPortUnrWlist();
                    break;
                case "10": // 应用访问策略
                    $this->_addAccessSt();
                    break;
                default:
                    #code...
                    break;
            }
        }
        return Finalsuccess($result);
    }

    // 【接口】更新
    public function update(){
        if(!$this->V_safepolicy->scene('update')->check(input()))
            return Finalfail($this->V_safepolicy->getError());

        $result = NULL;
        $type_arr = input('get.t');
        foreach (explode('|', $type_arr) as $type) {
            switch($type){
                case "1": // 内网防火墙
                    $this->_updateInnerFw();
                    break;
                case "3": // 主机备注
                    $this->_updateHostInfo();
                    break;
                case "7": // 全息伪装
                    $this->_updateServerMask();
                    break;
                case "8": // 虚开配置
                    $this->_updatePortUnreal();
                    break;
                case "9": // 虚开白名单
                    $this->_updatePortUnrWlist();
                    break;
                case "10": // 应用访问策略
                    $this->_updateAccessSt(input('get.zero'));
                    break;    
                default:
                    #code...
                    break;
            }
        }
        return Finalsuccess($result);
    }

    //【接口】删除
    public function del(){
        if(!$this->V_safepolicy->scene('del')->check(input()))
            return Finalfail($this->V_safepolicy->getError());

        $result = NULL;
        $type_arr = input('get.t');
        foreach (explode('|', $type_arr) as $type) {
            switch($type){
                case "1": // 内网防火墙
                    $this->_delInnerFw();
                    break;
                case "2": // 蜜罐主机
                    $this->_delHoneyHost();
                    break;
                case "3": // 主机备注
                    $this->_delHostInfo();
                    break;
                case "4": // 主机黑名单
                    $this->_delHostBwlist(1);
                    break;
                case "5": // 主机白名单
                    $this->_delHostBwlist(0);
                    break;
                case "6": // 主机准入
                    $this->_delHostAllow();
                    break;
                case "7": // 全息伪装
                    $this->_delServerMask();
                    break;
                case "8": // 虚开配置
                    $this->_delPortUnreal();
                    break;
                case "9": // 虚开白名单
                    $this->_delPortUnrWlist();
                    break;
                case "10": // 应用访问策略
                    $this->_delAccessSt();
                    break; 
                default:
                    #code...
                    break;
            }
        }
        return Finalsuccess($result);
    }

    //【接口】导出
    public function export(){
        if(!$this->V_safepolicy->scene('export')->check(input()))
            return Finalfail($this->V_safepolicy->getError());

        $result = NULL;
        $type = input('get.t');
        switch($type){
            case "3": // 主机备注
                $this->_exportHostInfo();
                break;
            case "6": // 主机准入
                $this->_exportHostAllow();
                break;
            default:
                #code...
                break;
            }
    }

    //【接口】导入
    public function upload(){
        if(!$this->V_safepolicy->scene('upload')->check(input()))
            return Finalfail($this->V_safepolicy->getError());

        $result = NULL;
        $type = input('get.t');
        switch($type){
            case "3": // 主机备注
                $this->_uploadHostInfo();
                break;
            case "6": // 主机准入
                $this->_uploadHostAllow();
                break;
            default:
                #code...
                break;
            }
        return Finalsuccess();
    }

    //---------------------------------------------------------------------------

    private function _getInnerFw(){
        $C_inner_fw = controller('Innerfirewall', 'safepolicy');
        $result = $C_inner_fw->get();
        return $result;
    }
    private function _getHoneyHost(){
        $C_honey_host = controller('Honeyhost', 'safepolicy');
        $result = $C_honey_host->get();
        return $result;
    }
    private function _getHostInfo(){
        $C_host_info = controller('Hostinfo', 'safepolicy');
        $result = $C_host_info->get();
        return $result;
    }
    private function _quickSetHostInfo(){
        $C_host_info = controller('Hostinfo', 'safepolicy');
        $result = $C_host_info->quickSet();
        return $result;
    }
    private function _getHostBwlist($mark){
        $C_host_bwlist = controller('Hostbwlist', 'safepolicy');
        $result = $C_host_bwlist->get($mark);
        return $result;
    }
    private function _getHostAllow(){
        $C_host_allow = controller('Hostallow', 'safepolicy');
        $result = $C_host_allow->get();
        return $result;
    }
    private function _getServerMask(){
        $C_server_mask = controller('Holomask', 'safepolicy');
        $result = $C_server_mask->get();
        return $result;
    }
    private function _getPortUnreal(){
        $C_port_unreal = controller('Portunreal', 'safepolicy');
        $result = $C_port_unreal->get();
        return $result;
    }
    private function _getPortUnrWlist(){
        $C_port_unr_wlist = controller('Portunrwlist', 'safepolicy');
        $result = $C_port_unr_wlist->get();
        return $result;
    }
    private function _getAccessSt(){
        $C_access_st = controller('Accessst', 'safepolicy');
        $result = $C_access_st->get();
        return $result;
    }

    //---------------------------------------------------------------------------

    private function _addInnerFw(){
        $C_inner_fw = controller('Innerfirewall', 'safepolicy');
        $C_inner_fw->add();
    }
    private function _addHoneyHost(){
        $C_honey_host = controller('Honeyhost', 'safepolicy');
        $C_honey_host->add();
    }
    private function _addHostInfo(){
        $C_host_info = controller('Hostinfo', 'safepolicy');
        $C_host_info->add();
    }
    private function _addHostBwlist($mark){
        $C_host_bwlist = controller('Hostbwlist', 'safepolicy');
        $C_host_bwlist->add($mark);
    }
    private function _addHostAllow(){
        $C_host_allow = controller('Hostallow', 'safepolicy');
        $C_host_allow->add();
    }
    private function _addServerMask(){
        $C_server_mask = controller('Holomask', 'safepolicy');
        $C_server_mask->add();
    }
    private function _addPortUnreal(){
        $C_port_unreal = controller('Portunreal', 'safepolicy');
        $C_port_unreal->add();
    }
    private function _addPortUnrWlist(){
        $C_port_unr_wlist = controller('Portunrwlist', 'safepolicy');
        $C_port_unr_wlist->add();
    }
    private function _addAccessSt(){
        $C_access_st = controller('Accessst', 'safepolicy');
        $C_access_st->add();
    }

    //---------------------------------------------------------------------------

    private function _updateInnerFw(){
        $C_inner_fw = controller('Innerfirewall', 'safepolicy');
        $C_inner_fw->update();
    }
    private function _updateHostInfo(){
        $C_host_info = controller('Hostinfo', 'safepolicy');
        $C_host_info->update();
    }
    private function _updateServerMask(){
        $C_server_mask = controller('Holomask', 'safepolicy');
        $C_server_mask->update();
    }
    private function _updatePortUnreal(){
        $C_port_unreal = controller('Portunreal', 'safepolicy');
        $C_port_unreal->update();
    }
    private function _updatePortUnrWlist(){
        $C_port_unr_wlist = controller('Portunrwlist', 'safepolicy');
        $C_port_unr_wlist->update();
    }
    private function _updateAccessSt($type){
        $C_access_st = controller('Accessst', 'safepolicy');
        if($type==="true"){
            $C_access_st->clearing();
        }else{
            $C_access_st->update();
        }
    }

    //---------------------------------------------------------------------------

    private function _delInnerFw(){
        $C_inner_fw = controller('Innerfirewall', 'safepolicy');
        $C_inner_fw->del();
    }
    private function _delHoneyHost(){
        $C_honey_host = controller('Honeyhost', 'safepolicy');
        $C_honey_host->del();
    }
    private function _delHostInfo(){
        $C_host_info = controller('Hostinfo', 'safepolicy');
        $C_host_info->del();
    }
    private function _delHostBwlist($mark){
        $C_host_bwlist = controller('Hostbwlist', 'safepolicy');
        $C_host_bwlist->del($mark);
    }
    private function _delHostAllow(){
        $C_host_allow = controller('Hostallow', 'safepolicy');
        $C_host_allow->del();
    }
    private function _delServerMask(){
        $C_server_mask = controller('Holomask', 'safepolicy');
        $C_server_mask->del();
    }
    private function _delPortUnreal(){
        $C_port_unreal = controller('Portunreal', 'safepolicy');
        $C_port_unreal->del();
    }
    private function _delPortUnrWlist(){
        $C_port_unr_wlist = controller('Portunrwlist', 'safepolicy');
        $C_port_unr_wlist->del();
    }
    private function _delAccessSt(){
        $C_access_st = controller('Accessst', 'safepolicy');
        $C_access_st->del();
    }

    //---------------------------------------------------------------------------

    private function _exportHostInfo(){
        $C_host_info = controller('Hostinfo', 'safepolicy');
        $C_host_info->export();
    }
    private function _exportHostAllow(){
        $C_host_allow = controller('Hostallow', 'safepolicy');
        $C_host_allow->export();
    }
    
    private function _uploadHostInfo(){
        $C_host_info = controller('Hostinfo', 'safepolicy');
        $C_host_info->upload();
    }
    private function _uploadHostAllow(){
        $C_host_allow = controller('Hostallow', 'safepolicy');
        $C_host_allow->upload();
    }

    //--------------------------------------------------------------------------

    //【前置方法】验证访问策略
    protected function checkAccess(){
        if(!CheckAccess())
            Error('15006','access denied');
    }
    //【前置方法】验证登陆
    protected function checkLogin(){
        if(!CheckLoginToken())
            Error('15005','need login or token error');
    }
    //【前置方法】验证设备授权
    protected function checkValid(){
        $status = CheckValid();
        if($status != '0')
            Error($status,'need valid');
    }
    //【前置方法】验证post请求
    protected function checkPost(){
        if(!request()->isPost())
            Error("15001","need post method");
    }
    //【前置方法】验证get请求
    protected function checkGet(){
        if(!request()->isGet())
            Error("15002","need get method");
    }
    //【空方法】
    public function _empty(){
        $this->redirect('/errorpage');
    }
}
