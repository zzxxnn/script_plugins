<?php
namespace app\index\controller;
use think\Controller;
use think\Loader;

/**
 * 状态监控 主控制器
 */
class Stats extends Controller {

    protected $V_stats;// 校验器-状态监控
    protected $beforeActionList = [
        'checkGet'   => ['only' => 'get'],
        'checkLogin',
        'checkAccess',
        'checkValid'
    ];
    
    public function _initialize(){
        $this->redis = new \Redis();
        $this->V_stats = Loader::validate('Stats');
    }

    //【接口】获取状态监控
    public function get(){
        if(!$this->V_stats->scene('get')->check(input()))
            return Finalfail($this->V_stats->getError());

        $result = [];
        $type_arr = input('get.t');
        $type_arr = explode('|', $type_arr);
        $C_system = controller('System', 'stats');
        $C_network = controller('Network', 'stats');
        foreach ($type_arr as $type) {
            switch($type){
                case "1":
                    // CPU实时状态
                    $result['1'] = $C_system->RealCPUStats();
                    break;
                case "2":
                    // 内存实时状态
                    $result['2'] = $C_system->RealRAMStats();
                    break;
                case "3":
                    // 硬盘实时状态
                    $result['3'] = $C_system->RealHDStats();
                    break;
                case "4":
                    // 在线节点个数实时状态
                    $result['4'] = $C_network->RealHostCount();
                    break;
                case "5":
                    // CPU最近15分钟状态
                    $result['5'] = ArrayDistinctByKey($C_system->RecentCPUStats(), 'timestamp');
                    break;
                case "6":
                    // 内存最近15分钟状态
                    $result['6'] = ArrayDistinctByKey($C_system->RecentRAMStats(), 'timestamp');
                    break;
                case "7":
                    // 硬盘最近15分钟状态
                    $result['7'] = ArrayDistinctByKey($C_system->RecentHDStats(), 'timestamp');
                    break;
                case "8":
                    // 在线节点个数最近15分钟状态
                    $result['8'] = ArrayDistinctByKey($C_network->RecentHostCount(), 'timestamp');
                    break;
                case "9":
                    // 网卡信息实时状态
                    if (!$this->V_stats->scene('get_ethstats')->check(input()))
                        Error($this->V_stats->getError());
                    $orderby = input('get.orderby');
                    $order = input('get.order');                    
                    $result['9'] = $C_system->EthStats($orderby, $order);
                    break;
                case "10":
                    // 在线节点实时状态
                    if (!$this->V_stats->scene('get_10stats')->check(input()))
                        Error($this->V_stats->getError());
                    $orderby = input('get.orderby10');
                    $order = input('get.order10');
                    $page = input('get.page10');
                    $row = input('get.row10');
                    $result['10'] = $C_network->RealHostStats($orderby, $order, $page, $row, [
                        'mac'           =>  input('get.mac10'),
                        'desc'          =>  input('get.desc10'),
                        'rip'           =>  input('get.rip10'),
                        'vip'           =>  input('get.vip10'),
                        'wip'           =>  input('get.wip10'),
                        'name'          =>  input('get.name10'),
                        'groupid'       =>  input('get.groupid10'),
                        'vlanid'        =>  input('get.vlanid10'),
                        'start_time'    =>  input('get.start_time10'),
                        'end_time'      =>  input('get.end_time10'),
                        'is_block'      =>  input('get.is_block')
                    ]);
                    break;
                case "11":
                    // 在线用户实时状态
                    if (!$this->V_stats->scene('get_11stats')->check(input()))
                        Error($this->V_stats->getError());
                    $orderby = input('get.orderby11');
                    $order = input('get.order11');
                    $page = input('get.page11');
                    $row = input('get.row11');
                    $result['11'] = $C_network->RealHostStats($orderby, $order, $page, $row, [
                        'groupid'   =>  input('get.groupid11')
                    ]);
                    break;
                case "12":
                    // 封堵列表
                    if (!$this->V_stats->scene('get_blockstats')->check(input()))
                        Error($this->V_stats->getError());
                    $orderby = input('get.orderby12');
                    $order = input('get.order12');
                    $page = input('get.page12');
                    $row = input('get.row12');                     
                    $result['12'] = $C_network->BlockList($orderby, $order, $page, $row, [
                        'source'        =>  input('get.source12'),
                        'desc'          =>  input('get.desc12'),
                        'start_time'    =>  input('get.start_time12'),
                        'end_time'      =>  input('get.end_time12')
                    ]);
                    break;
                case "13":
                    // 白名单
                    $C_host_bwlist = controller('Hostbwlist', 'safepolicy');
                    $result['13'] = $C_host_bwlist->get(0);
                    break;
                case "14":
                    // 黑名单
                    $C_host_bwlist = controller('Hostbwlist', 'safepolicy');
                    $result['14'] = $C_host_bwlist->get(1);
                    break;
                case "15":
                    // 攻击状态
                    $result['15'] = $C_network->AttackStats();
                    break;
                case "16":
                    // 最近攻击记录
                    $recent = input('get.recent');
                    $result['16'] = $C_network->RecentAttackLogs($recent);
                    break;
                case "17":
                    // 活跃终端
                    $limit = input('get.limit');
                    $result['17'] = $C_network->RealHostStats('speed','desc',1,$limit);
                    break;
                case "18":
                    // 并发连接数目
                    $result['18'] = $C_network->RealHostConnects();
                    break;
                case "19":
                    // 开机时间
                    $result['19'] = $C_system->UpTime();
                    break;
                case "20":
                    // 运行时间
                    $result['20'] = $C_system->UpTime();
                    break;
                case "21":
                    // 安全域
                    $result['21'] = $C_network->VirtualHosts();
                    break;
                case "22":
                    // 最近事件记录
                    $recent = input('get.recent22');
                    $result['22'] = $C_system->RecentEventLogs($recent);
                    break;
                case "23":
                    // 系统版本
                    $result['23'] = $C_system->SysVersion();
                    break;
                case "24":
                    // 系统时间
                    $result['24'] = time();
                    break;
                default:
                    #code...
                    break;
            }
        }
        return Finalsuccess($result);
    }

    //【接口】删除
    public function del(){
        if(!$this->V_stats->scene('del')->check(input()))
            return Finalfail($this->V_stats->getError());

        $type_arr = input('get.t');
        $C_network = controller('Network', 'stats');
        foreach (explode('|', $type_arr) as $type) {
            switch($type){
                case "10": //在线节点
                    $C_network->delHostStats();
                    break;
                default:
                    #code...
                    break;
            }
        }
        return Finalsuccess();
    }

    
    //---------------------------------------------------------------------------

    //【前置方法】验证访问策略
    protected function checkAccess(){
        if(!CheckAccess())
            Error('15006','access denied');
    }
    //【前置方法】验证登陆
    protected function checkLogin(){
        if(!CheckLoginToken())
            Error('15005','need login or token error');
    }
    //【前置方法】验证设备授权
    protected function checkValid(){
        $status = CheckValid();
        if($status != '0')
            Error($status,'need valid');
    }
    //【前置方法】验证post请求
    protected function checkPost(){
        if(!request()->isPost())
            Error("15001","need post method");
    }
    //【前置方法】验证get请求
    protected function checkGet(){
        if(!request()->isGet())
            Error("15002","need get method");
    }
    //【空方法】
    public function _empty(){
        $this->redirect('/errorpage');
    }

}