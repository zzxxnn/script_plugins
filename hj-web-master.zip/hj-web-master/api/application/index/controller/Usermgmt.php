<?php

namespace app\index\controller;
use app\index\model\User;
use think\Controller;
use think\Log;
use think\Session;
use think\Loader;

// 管理员用户 主控制器
class Usermgmt extends Controller{

    protected $M_user;
    protected $V_usermgmt;
    protected $beforeActionList = [
        'checkGet'   => ['only' => 'get,gettoken,freshtoken'],
        'checkPost'  => ['only' => 'add,update,updatepwd,del'],
        'checkAccess',
        'checkLogin',
        'checkValid'
    ];

    public function _initialize(){
        $this->V_usermgmt = Loader::validate('Usermgmt');
        $this->M_user = new User;
    }

    // 【接口】获取用户列表
    public function get(){
        $user_group = session('user_auth.user_group');
        if($user_group > 2)
            return Finalfail('15003');

        $data = $this->M_user->selectAllUsers();
        return Finalsuccess(["users" => $data]);
    }
    // 【接口】添加
    public function add(){
        if(!$this->V_usermgmt->scene('add')->check(input()))
            return Finalfail($this->V_usermgmt->getError());

        $type = input('get.t');
        switch($type){
            case "1": // 添加管理员用户
                $this->_addAdmin();
                break;
            default:
                #code...
                break;
        }
        return Finalsuccess();
    }
    // 【接口】更新资料
    public function update(){
        if(!$this->V_usermgmt->scene('update')->check(input()))
            return Finalfail($this->V_netmgmt->getError());

        $result = NULL;
        $type = input('get.t');
        switch($type){
            case "1": // 更新用户资料
                $this->_updateUserinfo();
                break;
            case "2": // 更改用户密码
                $this->_updatePwd();
                break;
            default:
                #code...
                break;
        }
        return Finalsuccess();
    }
    // 【接口】删除用户
    public function del(){
        if(!$this->V_usermgmt->scene('del')->check(input()))
            return Finalfail($this->V_usermgmt->getError());

        $result = NULL;
        $type = input('get.t');
        switch($type){
            case "1": // 删除用户资料
                $this->_delAdmin();
                break;
            default:
                #code...
                break;
        }
        return Finalsuccess();
    }
    //【接口】查询现在用户access_token
    public function getToken(){
        $username = session("user_auth.username");
        $token = $this->M_user->selectAccessTokenByUname($username);
        return Finalsuccess($token[0]);
    }
    //【接口】刷新生成access_token
    public function freshToken(){
        $salt = RandChars();
        $username = session("user_auth.username");
        $token = TokenHash($username.$salt);
        $result = $this->M_user->updateAccessTokenByUname($username, $token);
        if($result > 0){
            return Finalsuccess(["access_token"=>$token]);
        }else{
            return Finalfail("20001");
        }
    }

    // 添加管理员用户
    private function _addAdmin(){
        if(!$this->V_usermgmt->scene('user_add')->check( ['u_add' => input("post.user")]))
            Error($this->V_usermgmt->getError());

        $tmp_arr = explode("|", input("post.user"));
        $result = $this->M_user->where('user_id', $tmp_arr[0])->find(); // 验证用户名重复
        if(!is_null($result))
            Error("10002");

        $conf_map = [
            "user_id"       =>  $tmp_arr[0],
            "password"      =>  password_hash($tmp_arr[1], PASSWORD_DEFAULT),
            "user_group"    =>  $tmp_arr[2],
            "real_name"     =>  $tmp_arr[3],
            "department"    =>  $tmp_arr[4],
            "email"         =>  $tmp_arr[5]
        ];
        $this->M_user->data($conf_map);
        $result = $this->M_user->save();
        if($result <= 0){
            Error("20001");
        }
        try {
            // 发送Metric 日志
            $userInfo = $this->M_user->toArray();
            unset($userInfo['password']);
            sendMetricLog($userInfo, 'user_info');
        } catch (\Exception $e) {
            Log::error($e->getMessage());
        }
    }

    // 更新用户资料
    private function _updateUserinfo()
    {
        if (!$this->V_usermgmt->scene('user_update')->check(['u_update' => input("post.user")]))
            Error($this->V_usermgmt->getError());

        $tmp_arr = explode("|", input("post.user"));
        $update_user_id = $tmp_arr[0];
        if ($update_user_id == "1")
            Error("10006");

        $update_username = $tmp_arr[1];
        $user_group = session('user_auth.user_group');
        if ($user_group > 2)
            Error("15003");

        $update_user_group = $tmp_arr[2];
        if ($update_user_group == '1')
            Error("10007");

        $userInfo = $this->M_user->get($update_user_id); // 验证记录是否存在
        if (is_null($userInfo))
            Error("14001");

        $result = $this->M_user->selectSameRowNoThisId($update_user_id, ["user_id" => $update_username]);
        if (!is_null($result))
            Error("10002");

        $conf_map = [
            "user_id"    => $update_username,
            "user_group" => $update_user_group,
            "real_name"  => $tmp_arr[3],
            "department" => $tmp_arr[4],
            "email"      => $tmp_arr[5]
        ];
        $result = $this->M_user->updateById($update_user_id, $conf_map);
        if ($result < 0) {
            Error("20001");
        }
        unset($userInfo['password'], $userInfo['token']);
        sendMetricLog($userInfo, 'user_info');

        return Finalsuccess();
    }
    //更改用户密码
    private function _updatePwd(){
        if(!$this->V_usermgmt->scene('pwd_update')->check( ['p_update' => input("post.pwd")]))
            Error($this->V_usermgmt->getError());

        $tmp_arr = explode("|", input("post.pwd"));
        $update_user_id = $tmp_arr[0];
        $old_pwd = $tmp_arr[1];
        $new_pwd = $tmp_arr[2];

        if($update_user_id == "1")
            Error("10010");

        $update_user = $this->M_user->get($update_user_id); // 验证记录是否存在
        if(is_null($update_user))
            Error("14001");

        $now_user_group = session('user_auth.user_group');
        if($now_user_group > $update_user->user_group)
            Error("10009");

        if(!password_verify($old_pwd, $update_user->password))
            Error("10008");
        
        $result = $this->M_user->updateById($update_user_id, ['password' => password_hash($new_pwd, PASSWORD_DEFAULT)]);
        if($result < 0){
            Error("20001");
        }
        if($result == "0"){
            Error("10010");
        }
        return Finalsuccess();
    }
    // 删除用户
    public function _delAdmin(){
        if(!$this->V_usermgmt->scene('user_del')->check(input()))
            Error($this->V_usermgmt->getError());

        $ids_arr = explode("|", input("post.ids"));
        if(in_array(1, $ids_arr))
            Error("10011");

        $now_u_id = session('user_auth.u_id');
        if(in_array($now_u_id, $ids_arr))
            Error("10012");

        $now_user_group = session('user_auth.user_group');
        $userInfoArr = [];
        foreach($ids_arr as $id){
            $user_info = $this->M_user->get($id);
            if(is_null($user_info)){
                Error("14001");
            }elseif($now_user_group > $user_info->user_group){
                Error("10013");
            }
            $userInfoArr[] = $user_info;
        }
        $result = $this->M_user->destroy($ids_arr);
        if($result < 0){
            Error("20001");
        }
    }

    //【前置方法】验证访问策略
    protected function checkAccess(){
        if(!CheckAccess())
            Error('15006','access denied');
    }
    //【前置方法】验证登陆
    protected function checkLogin(){
        if(!CheckLoginToken())
            Error('15005','need login or token error');
    }
    //【前置方法】验证设备授权
    protected function checkValid(){
        $status = CheckValid();
        if($status != '0')
            Error($status,'need valid');
    }
    //【前置方法】验证post请求
    protected function checkPost(){
        if(!request()->isPost())
            Error("15001","need post method");
    }
    //【前置方法】验证get请求
    protected function checkGet(){
        if(!request()->isGet())
            Error("15002","need get method");
    }
    //【空方法】
    public function _empty(){
        $this->redirect('/errorpage');
    }
}
