<?php
namespace app\index\controller;
use app\index\repository\LicenseRepository;
use think\Controller;

// 设备证书 主控制器
class License extends Controller {

    protected $beforeActionList = [
        'checkGet'  => ['only' => 'read'],
        'checkPost' => ['only' => 'upload'],
        'checkAccess',
        'checkLogin' => ['only' => 'upload']
    ];

    //【接口】证书状态查询接口
    public function read(){
        return Finalsuccess(['cert' => $this->get()]);
    }

    //【接口】证书上传接口
    public function upload(){
        if(input('get.t') !== '1'){
            Error("10001|param missing t");
        }
        exec("mkdir -p /hard_disk/grub");
        $public_path = ROOT_PATH . 'public' . DS . 'uploads';

        $file = request()->file('file');
        if(is_null($file))
            return Finalfail('10020', 'file null');

        $info = $file->validate(['size'=>15678,'ext'=>'lic'])->move($public_path);
        if(!$info)
            return Finalfail('12020', 'license size or ext error');

        $filename = $info->getFilename(); 
        $save_path = $public_path .'/'.$info->getSaveName(); 

        $fp = fopen($save_path, "rb");
        $bin = fread($fp, 4); //只读4字节
        fclose($fp);
        if($bin !== "VEDA"){
            unlink($save_path);
            return Finalfail("12020", 'invalid license');
        }

        //命令验证证书是否有效
        exec("fpcmd load_licence --test ".$save_path,$result);
        if($result[0] !== "valid") 
            return Finalfail("12020", 'invalid license');

        //移动证书到licence
        exec("mv ".$save_path." /hard_disk/grub/licence");
        exec("rm ".$save_path);
        exec("fpcmd load_licence");
        
        return Finalsuccess(['cert'=>$this->get()]);
    }

    //【方法】证书状态查询接口（提供给同级控制器）
    public function get(){
        return (new LicenseRepository())->get();
    }

    //【前置方法】验证访问策略
    protected function checkAccess(){
        if(!CheckAccess())
            Error('15006','access denied');
    }
    //【前置方法】验证登陆
    protected function checkLogin(){
        if(!CheckLoginToken())
            Error('15005','need login or token error');
    }
    //【前置方法】验证设备授权
    protected function checkValid(){
        $status = CheckValid();
        if($status != '0')
            Error($status,'need valid');
    }
    //【前置方法】验证post请求
    protected function checkPost(){
        if(!request()->isPost())
            Error("15001","need post method");
    }
    //【前置方法】验证get请求
    protected function checkGet(){
        if(!request()->isGet())
            Error("15002","need get method");
    }
    //【空方法】
    public function _empty(){
        $this->redirect('/errorpage');
    }

}