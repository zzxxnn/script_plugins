<?php
namespace app\index\controller;
use think\Controller;
use think\Loader;
use think\Request;

// 同步控制 主控制器
class Sync extends Controller {

    protected $V_sync; 
    protected $beforeActionList = [
        'checkAccess',
        'checkLogin' 
    ];

    public function _initialize(){
        $this->V_sync = Loader::validate('Sync');
    }

    //【接口】手动同步
    public function handle(){
        if(!$this->V_sync->scene('sync')->check(input()))
            return Finalfail($this->V_sync->getError());

        $result = [];
        $type_arr = input('get.t');
        foreach (explode('|', $type_arr) as $type) {
            switch($type){
                case "1": 
                    $this->_sysConfHandle();
                    break;
                case "2": 
                    $this->_hostInfoHandle();
                    break;
                default:
                    #code...
                    break;
            }
        }
        return Finalsuccess();
    }

    //【接口】拉取同步
    public function pull(){
        if(!$this->V_sync->scene('sync')->check(input()))
            return Finalfail($this->V_sync->getError());

        $result = [];
        $type_arr = input('get.t');
        foreach (explode('|', $type_arr) as $type) {
            switch($type){
                case "1": 
                    $result = $this->_sysConfPull();
                    break;
                case "2": 
                    break;
                default:
                    #code...
                    break;
            }
        }
        return Finalsuccess($result);
    }

    // 【接口】接收同步
    public function recep(){
        if(!$this->V_sync->scene('sync')->check(input()))
            return Finalfail($this->V_sync->getError());

        $result = [];
        $type_arr = input('get.t');
        foreach (explode('|', $type_arr) as $type) {
            switch($type){
                case "1": 
                $this->_sysConfRecep();
                    break;
                case "2": 
                    break;
                default:
                    #code...
                    break;
            }
        }
        return Finalsuccess();
    }

    // 手动同步
    private function _sysConfHandle(){
        $content = file_get_contents("/hard_disk/ha/config.json");
        $arr = json_decode($content, true);
        $remoteip = $arr['remoteip'];

        $json_arr = $this->_sysConfPull(); 
        $result = PostContent("https://".$remoteip."/sync/recep?t=1&token=MGU3ZjgxMWFjYzU2YWMwNDM1ZmVjZmQ5ZGNiNDgyNWQ3ODUzOTY2Zg==", json_encode($json_arr));
        if($result === false){
            Error("10025", "POST ERROR: https://".$remoteip."/sync/recep?t=1");
        }
        if($result['errcode'] !== 0){
            Error($result['errcode'], $result['errmsg']);
        }
    }

    private function _sysConfPull(){
        $C_maker = controller('Makeconfjson', 'tools');
        $json_content = $C_maker->make();

        $json_arr = json_decode($json_content, true);
        if(isset($json_arr['mgt1_ip'])){
            unset($json_arr['mgt1_ip']);
        }
        if(isset($json_arr['mgt2_ip'])){
            unset($json_arr['mgt2_ip']);
        }
        if(isset($json_arr['static_route'])){
            unset($json_arr['static_route']);
        }

        return ["1" => $json_arr];
    }

    private function _sysConfRecep(){
        $config = input("post.1/a");
        if(empty($config))
            Error("12019");
        
        $C_parse = controller('Parseconfjson', 'tools');
        $C_parse->syncparse(json_encode($config));
    }

    private function _hostInfoHandle(){
        exec("fpcmd send_host_status", $result, $status);
        if($status !== 0){
            Error("12020", "error: fpcmd send_host_status");
        }
        if($result[0] !== "succeed"){
            Error("10025");
        }
    }

    //【前置方法】验证访问策略
    protected function checkAccess(){
        if(!CheckAccess())
            Error('15006','access denied');
    }
    //【前置方法】验证登陆
    protected function checkLogin(){
        if(!CheckLoginToken())
            Error('15005','need login or token error');
    }
    //【前置方法】验证设备授权
    protected function checkValid(){
        $status = CheckValid();
        if($status != '0')
            Error($status,'need valid');
    }
    //【前置方法】验证post请求
    protected function checkPost(){
        if(!request()->isPost())
            Error("15001","need post method");
    }
    //【前置方法】验证get请求
    protected function checkGet(){
        if(!request()->isGet())
            Error("15002","need get method");
    }
    //【空方法】
    public function _empty(){
        $this->redirect('/errorpage');
    }

}