<?php
namespace app\index\controller;
use think\Controller;
use think\Loader;

/**
 * 日志 主控制器
 */
class Logs extends Controller {

    protected $V_logs;
    protected $beforeActionList = [
        'checkGet'   => ['only' => 'get,clear'],
        'checkAccess',
        'checkLogin',
        'checkValid'
    ];
    
    public function _initialize() {
        $this->V_logs = Loader::validate('Logs');
    }
    
    public function get() {
        if (!$this->V_logs->scene('get')->check(input()))
            return Finalfail($this->V_logs->getError());
        $result = [];
        $type_arr = input('get.t');
        $type_arr = explode('|', $type_arr);
        $C_logs = controller('Logs', 'logs');
        $orderby = input('get.orderby');
        $order = input('get.order');
        $page = input('get.page');
        $row = input('get.row');
        foreach ($type_arr as $type) {
            switch ($type) {
                case "1":
                    // 渗透日志
                    $result['1'] = $C_logs->AttackLogs($orderby,$order,$page,$row,[
                        'attack_source' =>  input('get.attack_source'),
                        'start_time'    =>  input('get.start_time'),
                        'end_time'      =>  input('get.end_time')
                    ]);
                    break;
                case "2":
                    // 固定攻击源渗透日志概况
                    $source = input('get.attack_source');
                    $result['2'] = $C_logs->SourceAttackLogs($source,$orderby,$order,$page,$row);
                    break;
                case "3":
                    // 渗透日志详情
                    $log_id = input('get.log_id');
                    $result['3'] = $C_logs->DetailAttackLogs($log_id,$orderby,$order,$page,$row);
                    break;
                case "4":
                    // 渗透统计
                    $subt = input('get.subt');
                    $subt = explode('|',$subt);
                    $source = input('get.attack_source');
                    $limit = input('get.limit');
                    $result['4'] = $C_logs->AttackLogsStat($subt, $source, $limit);
                    break;
                case "5":
                    // IP变换日志
                    $result['5'] = $C_logs->IpVaryLogs($orderby,$order,$page,$row,[
                        'groupid'   =>  input('get.groupid'),
                        'mac'   =>  input('get.mac'),
                        'start_time'    =>  input('get.start_time'),
                        'end_time'  =>  input('get.end_time')
                    ]);
                    break;
                case "6":
                    // IP变换日志详情
                    $log_id = input('get.log_id');
                    $result['6'] = $C_logs->DetailIpVaryLogs($log_id,$orderby,$order,$page,$row);
                    break;
                case "7":
                    // 主机下线日志
                    $result['7'] = $C_logs->OfflineLogs($orderby,$order,$page,$row,[
                        'groupid'   =>  input('get.groupid'),
                        'mac'   =>  input('get.mac'),
                        'start_time'    =>  input('get.start_time'),
                        'end_time'  =>  input('get.end_time')
                    ]);
                    break;
                case "8":
                    // 封堵解封日志
                    $result['8'] = $C_logs->BlockLogs($orderby,$order,$page,$row,[
                        'source'    =>  input('get.source'),
                        'type'  =>  input('get.type'),
                        'start_time'    =>  input('get.start_time'),
                        'end_time'  =>  input('get.end_time')
                    ]);
                    break;
                case "9":
                    // 操作日志
                    $result['9'] = $C_logs->OperLogs($orderby,$order,$page,$row,[
                        'username'   =>  input('get.username'),
                        'clientip'  =>  input('get.clientip'),
                        'start_time'    =>  input('get.start_time'),
                        'end_time'  =>  input('get.end_time')
                    ]);
                    break;
                case "10":
                    // 事件日志
                    $result['10'] = $C_logs->EventLogs($orderby,$order,$page,$row,[
                        'level' =>  input('get.level'),
                        'type'  =>  input('get.type'),
                        'start_time'    =>  input('get.start_time'),
                        'end_time'  =>  input('get.end_time')
                    ]);
                    break;
                default:
                    break;
            }
        }
        return Finalsuccess($result);
    }

    public function clear() {
        if (!$this->V_logs->scene('clear')->check(input()))
            return Finalfail($this->V_logs->getError());

        $result = [];
        $type_arr = explode('|', input('get.t'));
        $C_logs = controller('Logs', 'logs');
        foreach ($type_arr as $type) {
            switch ($type) {
                case "1":
                    // 渗透日志
                    $C_logs->clearAttackLogs();
                    break;
                case "5":
                    // IP变换日志
                    $C_logs->clearIpVaryLogs();
                    break;
                case "7":
                    // 主机下线日志
                    $C_logs->clearOfflineLogs();
                    break;
                case "8":
                    // 封堵解封日志
                    if(input('get.type') == '1'){
                        $C_logs->clearBlockLogs();
                    }elseif(input('get.type') == '0'){
                        $C_logs->clearUnblockLogs();
                    }
                    break;
                case "9":
                    // 操作日志
                    $C_logs->clearOperLogs();
                    break;
                case "10":
                    // 事件日志
                    $C_logs->clearEventLogs();
                    break;
                default:
                    break;
            }
        }
        return Finalsuccess();
    }

    //【前置方法】验证访问策略
    protected function checkAccess(){
        if(!CheckAccess())
            Error('15006','access denied');
    }
    //【前置方法】验证登陆
    protected function checkLogin(){
        if(!CheckLoginToken())
            Error('15005','need login or token error');
    }
    //【前置方法】验证设备授权
    protected function checkValid(){
        $status = CheckValid();
        if($status != '0')
            Error($status,'need valid');
    }
    //【前置方法】验证post请求
    protected function checkPost(){
        if(!request()->isPost())
            Error("15001","need post method");
    }
    //【前置方法】验证get请求
    protected function checkGet(){
        if(!request()->isGet())
            Error("15002","need get method");
    }
    //【空方法】
    public function _empty(){
        $this->redirect('/errorpage');
    }
}