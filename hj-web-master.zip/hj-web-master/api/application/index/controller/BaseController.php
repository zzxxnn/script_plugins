<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/7/31
 * Time: 14:21
 */

namespace app\index\controller;


use think\Controller;

class BaseController extends Controller
{

    //【空方法】
    public function _empty()
    {
        $this->redirect('/errorpage');
    }
}