<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/6/14
 * Time: 11:13
 */

namespace app\index\controller;


use app\index\repository\SSORepository;
use think\Controller;
use think\Log;

class SSO extends Controller
{
    protected $beforeActionList = [
//        'validHSParams'                      // 参数校验，校验参数是否被更改
    ];

    public function hs(SSORepository $repository)
    {
        try {
            $token = input('get.token', null);
            if (!$token) {
                return abort(403, 'Permission deny!');
            }

            if (!$repository->processHsSSO($token)) {
                return redirect('/login');
            }
            sleep(2);
            return redirect('/home');
        } catch (\Exception $e) {

//            Log::error('HS SSO login error' . $e->getMessage());

            return Finalfail(403, $e->getMessage());
//            return redirect('/login');
        }
    }
}