<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/6/8
 * Time: 14:35
 */

namespace app\index\controller;


use app\index\repository\LicenseRepository;
use app\index\repository\SysConfRepository;
use app\index\repository\UtilsRepository;
use app\index\traits\ControllerGuard;
use think\Controller;
use think\Request;

/**
 * 暴露给 幻势集中管理平台 的API
 *
 * Class Api
 * @package app\index\controller
 */
class Api extends Controller
{
    use ControllerGuard;

    protected $beforeActionList = [ // FIXME 真是环境需要打开此校验
//        'fromCentralize',                    // 检查来源是否是幻势集中管理
        'validApiParams'                      // 参数校验，校验参数是否被更改
    ];

    /**
     * 主机 封堵
     *
     * @param Request $request
     * @param UtilsRepository $repository
     * @return bool
     */
    public function hostBlock(Request $request, UtilsRepository $repository)
    {
        try {
            $data = $request->only('data');
            if (empty($data['data'])) {
                return Finalfail(1, '封堵失败！');
            }

            $payload = decrypt($data['data']);
            $hostMac = isset($payload['hostMac']) ? $payload['hostMac'] : null;
            if (!$repository->setBlock('block', $hostMac)) {
                return Finalfail(1, '封堵失败！');
            }

            return Finalsuccess('已封堵！');
        } catch (\Exception $e) {
            return Finalfail(1, $e->getMessage());
        }
    }

    /**
     * 主机 解封
     * @param Request $request
     * @param UtilsRepository $repository
     * @return bool
     */
    public function hostUnBlock(Request $request, UtilsRepository $repository)
    {
        try {
            $data = $request->only('data');
            if (empty($data['data'])) {
                return Finalfail(1, '封堵失败！');
            }

            $payload = decrypt($data['data']);
            $hostMac = isset($payload['hostMac']) ? $payload['hostMac'] : null;

            if (!$repository->setBlock('unblock', $hostMac)) {
                return Finalfail(1, '解封失败！');
            }

            return Finalsuccess('已解封！');
        } catch (\Exception $e) {
            return Finalfail(1, $e->getMessage());
        }
    }

    /**
     * 获取设备的授权信息
     *
     * @return String
     */
    public function getLicence()
    {
        try {
            $license = (new LicenseRepository())->get();

            return Finalsuccess($license);
        } catch (\Exception $e) {
            return Finalfail(1, $e->getMessage());
        }
    }

    /**
     * 设备重启
     */
    public function reboot()
    {
        try {
            (new SysConfRepository())->sysCommand(SysConfRepository::COMMAND_REBOOT);
        } catch (\Exception $e) {
            return Finalfail(1, $e->getMessage());
        }
    }

    /**
     * 设备重启
     */
    public function powerOff()
    {
        try {
            (new SysConfRepository())->sysCommand(SysConfRepository::COMMAND_POWEROFF);
        } catch (\Exception $e) {
            return Finalfail(1, $e->getMessage());
        }
    }

    public function resetPwd(Request $request, SysConfRepository $repository)
    {
        try {
            $data = $request->only('data');
            if (empty($data['data'])) {
                return Finalfail(1, '缺少必要参数!');
            }

            $payload = decrypt($data['data']);
            if (!isset($payload['password'])) {
                return Finalfail('缺少密码！');
            }

            if (!$repository->resetPwd($payload['password'])) {
                return Finalfail(1, '密码更新失败！');
            }

            return Finalsuccess();
        } catch (\Exception $e) {
            return Finalfail(1, $e->getMessage());
        }
    }

    /**
     * 获取主机封堵列表
     *
     * @return array|Object
     */
    public function hostBlockList()
    {
        try {
            $blockList = BlockInfo();

            return Finalsuccess(['list' => $blockList]);
        } catch (\Exception $e) {
            return Finalfail(1, $e->getMessage());
        }
    }

    /**
     * 获取当前系统的状态
     *
     * @return String
     */
    public function status()
    {
        return Finalsuccess();
    }
}