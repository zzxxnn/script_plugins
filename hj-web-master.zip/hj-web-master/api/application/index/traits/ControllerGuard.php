<?php namespace app\index\traits;

use app\common\exception\PermissionDenyException;
use app\index\model\SysConfig;
use app\index\tools\HSEncrypt;

/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/6/8
 * Time: 15:08
 */
trait ControllerGuard
{
    use CustomLogger;

    /**
     * 检查API来源是否是幻势集中管理平台
     *
     * @return bool
     */
    public function fromCentralize()
    {
        try {
            $reqIp = request()->ip();
            $confType = (new SysConfig)->where(['conf_type' => 'remote'])->find();

            if ($confType) {
                list($confRemote) = explode('|', $confType['conf_value']);
                // 是否配置为IP地址
                if (ip2long($confRemote) !== false && $confRemote == $reqIp) {
                    return true;
                }

                // 当配置为域名时，需要先获取域名的IP地址
                $confIps = (array)gethostbynamel($confRemote);

                // 判断当前的请求IP是否合法
                if (in_array($reqIp, $confIps)) {
                    return true;
                }
            }

            throw new PermissionDenyException();
        } catch (\Exception $e) {
            $this->errorHandle($e);
            abort(403, 'Permission Deny!');
        }
    }

    /**
     * 检查请求参数是否是是正确加密的参数
     */
    public function validApiParams()
    {
        try {
            $data = input('data');
            if ((new HSEncrypt())->isValid($data)) {
                return true;
            }

            throw new PermissionDenyException('Params invalid!');
        } catch (\Exception $e) {
            $this->errorHandle($e);
            abort(403, 'Params invalid!');
        }
    }


    //【前置方法】验证访问策略
    public function checkAccess()
    {
        if (!CheckAccess()) {
            Error('15006', 'access denied');
        }
    }

    //【前置方法】验证登陆
    public function checkLogin()
    {
        if (!CheckLoginToken()) {
            Error('15005', 'need login or token error');
        }
    }

    //【前置方法】验证设备授权
    public function checkValid()
    {
        $status = CheckValid();
        if ($status != '0') {
            Error($status, 'need valid');
        }
    }

    //【前置方法】验证post请求
    public function checkPost()
    {
        if (!request()->isPost()) {
            Error("15001", "need post method");
        }
    }

    //【前置方法】验证get请求
    public function checkGet()
    {
        if (!request()->isGet()) {
            Error("15002", "need get method");
        }
    }

}