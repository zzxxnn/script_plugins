<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/7/31
 * Time: 18:31
 */

namespace app\index\traits;


use think\Validate;

trait ValidatorRules
{
    protected function domain($value)
    {
        //验证域名
        $pattern = '\b([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}\b';
        if (!Validate::regex($value, $pattern)) {
            return "域名不符合规范！";
        }

        if (count(explode('.', $value)) < 2) {
            return "域名不符合规范！";
        }

        return true;
    }
}