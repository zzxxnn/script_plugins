<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/6/8
 * Time: 15:47
 */

namespace app\index\traits;


use think\Log;

trait CustomLogger
{
    protected $logPath;

    /**
     * 添加日志异常记录
     * @param int $msg
     * @param string $lvl
     */
    public function saveLog($msg = null, $lvl = 'error')
    {
        try {
            !empty($logPath) && $logPath = RUNTIME_PATH . 'error-log';

            $logFile = $this->logPath . DS . date('Ymd') . '.log';

            // 检查日志目录是否存在
            if (!is_dir(dirname($logFile))) {
                mkdir(dirname($logFile), 0755, true);
            }

            $url = request()->method() . " " . request()->url();
            $content = sprintf('[' . date('Y-m-d H:i:s') . ']' . '[%s] [%s]:' . PHP_EOL, strtoupper($lvl), $url);
            $content .= 'REQUEST: ' . var_export($this->getLogRequest(), true) . PHP_EOL;
            $content .= 'MSG: ' . var_export($msg, true) . PHP_EOL;
            $content .= '---------------------------------------------------------------' . PHP_EOL;

            file_put_contents($logFile, $content, FILE_APPEND);
        } catch (\Exception $e) {
            Log::error($e->getMessage());
        }
    }

    private function getLogRequest()
    {
        return ['URL' => request()->url(), 'HEADER' => request()->header(), 'PARAM' => request()->param()];
    }

    /**
     * 控制器异常处理
     *
     * @param \Exception $e
     */
    protected function errorHandle(\Exception $e)
    {
        $this->saveLog(['file' => $e->getFile(), 'code' => $e->getCode(), 'msg' => $e->getMessage(), 'line' => $e->getLine()]);
    }
}