<?php

namespace app\index\validate;
use think\Validate;

class NetIps extends Validate{

    protected $rule = [
        'page'      =>  'integer|gt:0',
        'row'       =>  'integer|gt:0',
        'order'     =>  'in:asc,desc',
        'by'        =>  '',

        'add_r_v_v'      =>  'require|checkCount:4|checkAddRipVipVnet',
        'add_w'          =>  'require|checkCount:5|checkAddWip',
        'add_ew'         =>  'require|checkCount:4|checkAddEwip',
        'add_b_ip'       =>  'require|checkCount:2|checkAddBindIp',
        'add_b_router'   =>  'require|checkCount:2|checkAddBindRouter',
        'add_m_th'       =>  'require|checkCount:4|checkAddMacThrough',
        'add_bp'         =>  'require|checkCount:1|checkGroupId',
        
        'update_r_v_v'      =>  'require|checkCount:5|checkUpdateRipVipVnet',
        'update_w'          =>  'require|checkCount:6|checkUpdateWip',
        'update_ew'         =>  'require|checkCount:5|checkUpdateEwip',
        'update_b_ip'       =>  'require|checkCount:3|checkUpdateBindIp',
        'update_b_router'   =>  'require|checkCount:3|checkUpdateBindRouter',
        'update_m_th'       =>  'require|checkCount:5|checkUpdateMacThrough',
        
        'ids'       =>  'require|checkMultiIds',
        'del_bp'    =>  'require|checkMultiGroupId',
        
    ];

    protected $message  =   [
        'page.integer'      =>  '13002',
        'page.gt'           =>  '13002',
        'row.integer'       =>  '13003',
        'row.gt'            =>  '13003',
        'order.in'          =>  '13004',
        'by.in'             =>  '13004',

        'add_r_v_v.require'         =>  '10001',
        'add_r_v_v.checkCount'      =>  '10001|need 4 params',
        'add_w.require'             =>  '10001',
        'add_w.checkCount'          =>  '10001|need 5 params',
        'add_ew.require'            =>  '10001',
        'add_ew.checkCount'         =>  '10001|need 4 params',
        'add_b_ip.require'          =>  '10001',
        'add_b_ip.checkCount'       =>  '10001|need 2 params',
        'add_b_router.require'      =>  '10001',
        'add_b_router.checkCount'   =>  '10001|need 2 params',
        'add_m_th.require'          =>  '10001',
        'add_m_th.checkCount'       =>  '10001|need 4 params',
        'add_bp.require'            =>  '10001',
        'add_bp.checkGroupId'       =>  '12010',

        'update_r_v_v.require'      =>  '10001',
        'update_r_v_v.checkCount'   =>  '10001|need 5 params',
        'update_w.require'          =>  '10001',
        'update_w.checkCount'       =>  '10001|need 6 params',
        'update_ew.require'         =>  '10001',
        'update_ew.checkCount'      =>  '10001|need 5 params',
        'update_b_ip.require'       =>  '10001',
        'update_b_ip.checkCount'    =>  '10001|need 3 params',
        'update_b_router.require'   =>  '10001',
        'update_b_router.checkCount'=>  '10001|need 3 params',
        'update_m_th.require'       =>  '10001',
        'update_m_th.checkCount'    =>  '10001|need 5 params',

        'ids.require'               =>  '10001',
        'ids.checkMultiIds'         =>  '12012',
        'del_bp.require'            =>  '10001',
        'del_bp.checkMultiGroupId'  =>  '12010',

    ];

    protected $scene = [
        'get_rip_vip_vnet'  =>  ['page', 'row', 'order', 'by'=>"in:ip,mask,vlan_id,group_id"],
        'get_wip'           =>  ['page', 'row', 'order', 'by'=>"in:ip,mask,gateway,vlan_id,group_id"],
        'get_bind_ip'       =>  ['page', 'row', 'order', 'by'=>"in:ip,mac,description"],
        'get_bind_router'   =>  ['page', 'row', 'order', 'by'=>"in:ip,gateway"],
        'get_mac_through'   =>  ['page', 'row', 'order', 'by'=>"in:ip,mac,vlan_id,group_id,description"],

        'add_rip_vip_vnet'  =>  ['add_r_v_v'],
        'add_wip'           =>  ['add_w'],
        'add_ewip'          =>  ['add_ew'],
        'add_bind_ip'       =>  ['add_b_ip'],
        'add_bind_router'   =>  ['add_b_router'],
        'add_mac_through'   =>  ['add_m_th'],
        'add_bypass'        =>  ['add_bp'],

        'update_rip_vip_vnet'   =>  ['update_r_v_v'],
        'update_wip'            =>  ['update_w'],
        'update_ewip'           =>  ['update_ew'],
        'update_bind_ip'        =>  ['update_b_ip'],
        'update_bind_router'    =>  ['update_b_router'],
        'update_mac_through'    =>  ['update_m_th'],
        
        'del_by_ids'    =>  ['ids'],
        'del_bypass'    =>  ['del_bp']
        
    ];

    //验证参数个数
    protected function checkCount($value, $rule){
        $valueArr = explode('|', $value);
        return $rule == count($valueArr);
    }

    //验证 rip vip vnet 新增操作参数
    protected function checkAddRipVipVnet($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return "12001";
            }
            if($k == 1 && !$this->checkMask($value)){
                return "12005";
            }
            if($k == 2 && !$this->checkVlanId($value)){
                return "12009";
            }
            if($k == 3 && !$this->checkGroupId($value)){
                return "12010";
            }
        }
        return true;
    }

    //验证 wip 新增操作参数
    protected function checkAddWip($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return "12001";
            }
            if($k == 1 && !$this->checkMask($value)){
                return "12005";
            }
            if($k == 2 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return "12001";
            }
            if($k == 3 && !$this->checkVlanId($value)){
                return "12009";
            }
            if($k == 4 && !$this->checkGroupId($value)){
                return "12010";
            }
        }
        return true;
    }

    //验证 wip 保留配置新增操作参数
    protected function checkAddEwip($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return "12001";
            }
            if($k == 1 && !$this->checkMask($value)){
                return "12005";
            }
            if($k == 2 && !$this->checkVlanId($value)){
                return "12009";
            }
            if($k == 3 && !$this->checkGroupId($value)){
                return "12010";
            }
        }
        return true;
    }

    //验证 静态地址 新增操作参数
    protected function checkAddBindIp($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !$this->checkMac($value)){
                return "12006";
            }
            if($k == 1 && !(Validate::is($value, "ip") && ($value != "0.0.0.0")) ){
                return "12001";
            }
        }
        return true;
    }

    //验证 主机透传 新增操作参数
    protected function checkAddMacThrough($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !$this->checkMac($value)){
                return "12006";
            }
            if($k == 1 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return "12001";
            }
            if($k == 2 && !$this->checkVlanId($value)){
                return "12009";
            }
            if($k == 3 && !$this->checkGroupId($value)){
                return "12010";
            }
        }
        return true;
    }

    //验证 静态路由 更新操作参数
    protected function checkAddBindRouter($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(CheckIpMask($value) || $value == "0.0.0.0/0" )){
                return "12002";
            }
            if($k == 1 && !(Validate::is($value, "ip") && ($value != "0.0.0.0")) ){
                return "12001";
            }
        }
        return true;
    }

    //验证 rip vip vnet 更新操作参数
    protected function checkUpdateRipVipVnet($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null)) ){
                return "12011";
            }
            if($k == 1 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return "12001";
            }
            if($k == 2 && !$this->checkMask($value)){
                return "12005";
            }
            if($k == 3 && !$this->checkVlanId($value)){
                return "12009";
            }
            if($k == 4 && !$this->checkGroupId($value)){
                return "12010";
            }
        }
        return true;
    }

    //验证 wip 更新操作参数
    protected function checkUpdateWip($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null)) ){
                return "12011";
            }
            if($k == 1 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return "12001";
            }
            if($k == 2 && !$this->checkMask($value)){
                return "12005";
            }
            if($k == 3 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return "12001";
            }
            if($k == 4 && !$this->checkVlanId($value)){
                return "12009";
            }
            if($k == 5 && !$this->checkGroupId($value)){
                return "12010";
            }
        }
        return true;
    }

    //验证 wip 保留配置更新操作参数
    protected function checkUpdateEwip($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null)) ){
                return "12011";
            }
            if($k == 1 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return "12001";
            }
            if($k == 2 && !$this->checkMask($value)){
                return "12005";
            }
            if($k == 3 && !$this->checkVlanId($value)){
                return "12009";
            }
            if($k == 4 && !$this->checkGroupId($value)){
                return "12010";
            }
        }
        return true;
    }

    //验证 静态地址 更新操作参数
    protected function checkUpdateBindIp($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null)) ){
                return "12011";
            }
            if($k == 1 && !$this->checkMac($value)){
                return "12006";
            }
            if($k == 2 && !(Validate::is($value, "ip") && ($value != "0.0.0.0")) ){
                return "12001";
            }
        }
        return true;
    }

    //验证 静态路由 更新操作参数
    protected function checkUpdateBindRouter($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null)) ){
                return "12011";
            }
            if($k == 1 && !(CheckIpMask($value) || $value == "0.0.0.0/0")){
                return "12002";
            }
            if($k == 2 && !(Validate::is($value, "ip") && ($value != "0.0.0.0")) ){
                return "12001";
            }
        }
        return true;
    }

    //验证 主机透传 更新操作参数
    protected function checkUpdateMacThrough($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null)) ){
                return "12011";
            }
            if($k == 1 && !$this->checkMac($value)){
                return "12006";
            }
            if($k == 2 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return "12001";
            }
            if($k == 3 && !$this->checkVlanId($value)){
                return "12009";
            }
            if($k == 4 && !$this->checkGroupId($value)){
                return "12010";
            }
        }
        return true;
    }

    // 验证多个id "," 隔开
    protected function checkMultiIds($value){
        $ids_arr = explode(',', $value);
        $valid_arr = array_filter($ids_arr,function($value){
            return Validate::is($value,'integer') && Validate::egt($value, 0, null);
        });

        return count($ids_arr) == count($valid_arr);
    }

    // 验证多个group_id "," 隔开
    protected function checkMultiGroupId($value){
        $ids_arr = explode(',', $value);
        $valid_arr = array_filter($ids_arr,function($value){
            return Validate::is($value,'integer') && Validate::egt($value, 0, null);
        });
        return count($ids_arr) == count($valid_arr);
    }

    //验证 掩码 255.255.255.0
    protected function checkMask($mask){
        $m = @ip2long($mask);
        if(empty($m)) {
            return false;
        }
        $m = ~$m & 0xffffffff;
        return ($m&($m+1)) == 0;
    }

    //验证 VLAN_ID
    protected function checkVlanId($value){
        return Validate::is($value, "integer") && Validate::egt($value, 0, null) && Validate::elt($value, 4096, null);
    }

    //验证 物理线路
    protected function checkGroupId($value){
        return Validate::is($value, "integer") && Validate::egt($value, 0, null);
    }

    //验证 MAC地址
    protected function checkMac($value){
        return filter_var($value, FILTER_VALIDATE_MAC) === false ? false : true;
    }
    
}

