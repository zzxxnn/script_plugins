<?php

namespace app\index\validate;
use think\Validate;

class Safepolicy extends Validate{

    protected $rule = [
        't'         =>  'require|checkConfType:1,2,3,4,5,6,7,8,9,10',
        'page'      =>  'integer|gt:0',
        'row'       =>  'integer|gt:0',
        'order'     =>  'in:asc,desc',
        'by'        =>  '',
        'add_fw_pol'    =>  'require|checkCount:7|checkAddFwPol',
        'add_h_pot'     =>  'require|checkCount:3|checkAddHpot',
        'add_m_i'       =>  'require|checkCount:3|checkAddMacInfo',
        'add_m_bw'      =>  'require|checkCount:2|checkAddMacBwlist',
        'add_m_a'       =>  'require|checkCount:1|checkAddMacAllow',
        'add_h_m'       =>  'require|checkCount:5|checkAddHoloMask',
        'add_s_t'       =>  'require|checkCount:8|checkAddServerTrap',
        'add_p_u_w'     =>  'require|checkCount:2|checkAddServerTrapWlist',
        'add_acs_st'    =>  'require|checkCount:5|checkAddAccessSt',
        'update_fw_pol' =>  'require|checkCount:8|checkUpdateFwPol',
        'update_m_i'    =>  'require|checkCount:3|checkUpdateMacInfo',
        'edit_m_i'      =>  'require|checkCount:2|checkQeditMacInfo',
        'update_h_m'    =>  'require|checkCount:6|checkUpdateHoloMask',
        'update_s_t'    =>  'require|checkCount:9|checkUpdateServerTrap',
        'update_p_u_w'  =>  'require|checkCount:3|checkUpdateServerTrapWlist',
        'update_acs_st' =>  'require|checkCount:6|checkUpdateAccessSt',
        'ids'           =>  'require|checkMultiIds',
    ];

    protected $message  =   [
        't.require'         =>  '10001|param missing t',
        't.checkConfType'   =>  '13001',
        'page.integer'      =>  '13002',
        'page.gt'           =>  '13002',
        'row.integer'       =>  '13003',
        'row.gt'            =>  '13003',
        'order.in'          =>  '13004',
        'by.in'             =>  '13004',
        'add_fw_pol.require'        =>  '10001',
        'add_fw_pol.checkCount'     =>  '10001|need 7 params',
        'add_h_pot.require'         =>  '10001',
        'add_h_pot.checkCount'      =>  '10001|need 3 params',
        'add_m_i.require'           =>  '10001',
        'add_m_i.checkCount'        =>  '10001|need 3 params',
        'add_m_bw.require'          =>  '10001',
        'add_m_bw.checkCount'       =>  '10001|need 2 params',
        'add_m_a.require'           =>  '10001',
        'add_m_a.checkCount'        =>  '10001|need 1 params',
        'add_h_m.require'           =>  '10001',
        'add_h_m.checkCount'        =>  '10001|need 5 params',
        'add_s_t.require'           =>  '10001',
        'add_s_t.checkCount'        =>  '10001|need 8 params',
        'add_p_u_w.require'         =>  '10001',
        'add_p_u_w.checkCount'      =>  '10001|need 2 params',
        'add_acs_st.require'        =>  '10001',
        'add_acs_st.checkCount'     =>  '10001|need 5 params',
        'update_fw_pol.require'     =>  '10001',
        'update_fw_pol.checkCount'  =>  '10001|need 8 params',
        'update_m_i.require'        =>  '10001',
        'update_m_i.checkCount'     =>  '10001|need 3 params',
        'edit_m_i.require'          =>  '10001',
        'edit_m_i.checkCount'       =>  '10001|need 2 params',
        'update_h_m.require'        =>  '10001',
        'update_h_m.checkCount'     =>  '10001|need 6 params',
        'update_s_t.require'        =>  '10001',
        'update_s_t.checkCount'     =>  '10001|need 9 params',
        'update_p_u_w.require'      =>  '10001',
        'update_p_u_w.checkCount'   =>  '10001|need 3 params',
        'update_acs_st.require'     =>  '10001',
        'update_acs_st.checkCount'  =>  '10001|need 6 params',
        'ids.require'               =>  '10001',
        'ids.checkMultiIds'         =>  '12012',
    ];

    protected $scene = [
        'get'           =>  ['t'],
        'add'           =>  ['t'],
        'update'        =>  ['t' => 'checkConfType:1,3,7,8,9,10'],
        'export'        =>  ['t' => 'checkConfType:3,6'],
        'upload'        =>  ['t' => 'checkConfType:3,6'],
        'del'           =>  ['t'],
        'get_inner_fw_pol'  =>  ['page', 'row', 'order', 'by'=>"in:protocol_id,src_ip,dst_ip,s_port,d_port,action,description"],
        'get_honey_pot'     =>  ['page', 'row', 'order', 'by'=>"in:v_port,h_ip,h_port"],
        'get_mac_info'      =>  ['page', 'row', 'order', 'by'=>"in:gid,mac,description"],
        'get_mac_bwlist'    =>  ['page', 'row', 'order', 'by'=>"in:mac,note,timestamp,description"],
        'get_mac_allow'     =>  ['page', 'row', 'order', 'by'=>"in:mac,description"],
        'get_holo_mask'     =>  ['page', 'row', 'order', 'by'=>"in:name,r_ip,v_ip,vlan_id,group_id"],
        'get_server_trap'   =>  ['page', 'row', 'order', 'by'=>"in:name,s_ip,s_port,t_ip_mac,t_port,t_ip_type,vlan_id,group_id"],
        'get_port_unr_wlist'=>  ['page', 'row', 'order', 'by'=>"in:t_ip_mac,t_port"],
        'get_access_st'     =>  ['page', 'row', 'order', 'by'=>"in:name,protocol_id,s_port,d_port,effect_time"],
        'add_inner_fw_pol'  =>  ['add_fw_pol'],
        'add_honey_pot'     =>  ['add_h_pot'],
        'add_mac_info'      =>  ['add_m_i'],
        'add_mac_bwlist'    =>  ['add_m_bw'],
        'add_mac_allow'     =>  ['add_m_a'],
        'add_holo_mask'     =>  ['add_h_m'],
        'add_server_trap'   =>  ['add_s_t'],
        'add_port_unr_wlist'=>  ['add_p_u_w'],
        'add_access_st'     =>  ['add_acs_st'],
        'update_inner_fw_pol'  =>  ['update_fw_pol'],
        'update_mac_info'      =>  ['update_m_i'],
        'quick_edit_mac_info'  =>  ['edit_m_i'],
        'update_holo_mask'     =>  ['update_h_m'],
        'update_server_trap'   =>  ['update_s_t'],
        'update_port_unr_wlist'=>  ['update_p_u_w'],
        'update_access_st'  =>  ['update_acs_st'],
        'del_inner_fw_pol'  =>  ['ids'],
        'del_honey_pot'     =>  ['ids'],
        'del_mac_info'      =>  ['ids'],
        'del_mac_bwlist'    =>  ['ids'],
        'del_mac_allow'     =>  ['ids'],
        'del_holo_mask'     =>  ['ids'],
        'del_server_trap'   =>  ['ids'],
        'del_port_unr_wlist'=>  ['ids'],
        'del_access_st'     =>  ['ids']
    ];

    //验证多个类型|隔开
    protected function checkConfType($value, $rule){
        $valueArr = explode('|', $value);
        $ruleArr = explode(',', $rule);
        
        $resultArr = array_filter($valueArr, function ($item) use ($ruleArr) {
            return in_array($item, $ruleArr);
        });

        return count($resultArr) == count($valueArr);
    }

    //验证参数个数
    protected function checkCount($value, $rule){
        $valueArr = explode('|', $value);
        return $rule == count($valueArr);
    }

    //验证 内网防火墙 新增操作参数
    protected function checkAddFwPol($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !$this->checkProtocol($value)){
                return "12013";
            }
            if($k == 1 && !empty($value) && !$this->checkIpOrIpRange($value)){
                return "12004";
            }
            if($k == 2 && !empty($value) && !$this->checkIpOrIpRange($value)){
                return "12004";
            }
            if($k == 3 && ($value!="") && !($this->checkMultiPortOrPortRange($value))){
                return "12018";
            }
            if($k == 4 && ($value!="") && !($this->checkMultiPortOrPortRange($value))){
                return "12018";
            }
            if($k == 5 && !Validate::in($value, "0,1")){
                return "13006";
            }
            if($k == 6 && (!empty($value) && !(Validate::is($value, "chsDash") && strlen($value)<=50 )) ){
                return "12014";
            }
        }
        return true;
    }
    //验证 蜜罐主机 新增操作参数
    protected function checkAddHpot($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !$this->checkPort($value)){
                return "12007";
            }
            if($k == 1 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return "12005";
            }
            if($k == 2 && !$this->checkPort($value)){
                return "12007";
            }
        }
        return true;
    }
    //验证 主机备注 新增操作参数
    protected function checkAddMacInfo($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null)) ){
                return "11001";
            }
            if($k == 1 && !$this->checkMac($value)){
                return "12006";
            }
            if($k == 2 && !(Validate::is($value, "chsDash") && strlen($value)<=32 )){
                return "12014";
            }
        }
        return true;
    }
    //验证 主机黑白名单 新增操作参数
    protected function checkAddMacBwlist($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !($this->checkMac($value) || (Validate::is($value, "ip") && ($value != "0.0.0.0"))) ){
                return "12021";
            }
            if($k == 1 && $value!='' && !(Validate::is($value, "chsDash") && strlen($value)<=32 )){
                return "12014";
            }
        }
        return true;
    }
    //验证 主机准入 新增操作参数
    protected function checkAddMacAllow($value){
        $valueArr = explode(',', $value);
        foreach($valueArr as $k => $value){
            if(!$this->checkMac($value)){
                return "12006";
            }
        }
        return true;
    }
    
    //验证 全息节点 新增操作参数
    protected function checkAddHoloMask($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "chsDash") && strlen($value)<=32 )){
                return "12014";
            }
            if($k == 1 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return "12001";
            }
            if($k == 2 && !((Validate::is($value, "ip") && ($value != "0.0.0.0")) || CheckIpRange($value) || CheckIpMask($value) )){
                return "12004";
            }
            if($k == 3 && !$this->checkVlanId($value)){
                return "12009";
            }
            if($k == 4 && !$this->checkGroupId($value)){
                return "12010";
            }
        }
        return true;
    }
    //验证 端口虚开 新增操作参数
    protected function checkAddServerTrap($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "chsDash") && strlen($value)<=32 )){
                return "12014";
            }
            if($k == 1 && !$this->checkMultiMacIpRange($value) ){
                return "12021";
            }
            if($k == 2){
                if(!Validate::in($value, "0,1,2,3")){
                    return "13007";
                }elseif($this->checkMac($valueArr[1]) && !(Validate::in($value, "1,2,3"))){
                    return "10019";
                }
            }
            if($k == 3 && !$this->checkMultiPortOrPortRange($value)){
                return "12007";
            }
            if($k == 4 && !empty($value) && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return "12001";
            }
            if($k == 5 && !(empty($value) && $value != '0') && !$this->checkMultiPort($value)){
                return "12007";
            }
            
            if($k == 6 && !$this->checkVlanId($value)){
                return "12009";
            }
            if($k == 7 && !$this->checkGroupId($value)){
                return "12010";
            }
            if((!empty($valueArr[4]) && (empty($valueArr[5]) && $valueArr[5]!='0')) || (empty($valueArr[4]) && !(empty($valueArr[5]) && $valueArr[5]!='0')) ){
                return "10018";
            }
            
        }
        return true;
    }
    //验证 端口虚开白名单 新增操作参数
    protected function checkAddServerTrapWlist($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !((Validate::is($value, "ip") && ($value != "0.0.0.0")) || CheckIpRange($value) || CheckIpMask($value) || $this->checkMac($value) )){
                return "12021";
            }
            if($k == 1 && !$this->checkMultiPort($value)){
                return "12007";
            }
        }
        return true;
    }
    //验证 应用访问策略 新增操作参数
    protected function checkAddAccessSt($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && ( !(Validate::is($value, "chsDash") && strlen($value)<=50 )) ){
                return "12014";
            }
            if($k == 1 && !Validate::in($value, "6,17")){
                return "12013";
            }
            if($k == 2 && !(empty($value) && $value != '0') && !$this->checkMultiPort($value)){
                return "12007";
            }
            if($k == 3 && !(empty($value) && $value != '0') && !$this->checkMultiPort($value)){
                return "12007";
            }
            if($k == 4 && !empty($value) && !($this->checkTimeRange($value))){
                return "12017";
            }
        }
        return true;
    }

    //验证 内网防火墙 更新操作参数
    protected function checkUpdateFwPol($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null)) ){
                return "12011";
            }
            if($k == 1 && !$this->checkProtocol($value)){
                return "12013";
            }
            if($k == 2 && !empty($value) && !$this->checkIpOrIpRange($value)){
                return "12004";
            }
            if($k == 3 && !empty($value) && !$this->checkIpOrIpRange($value)){
                return "12004";
            }
            if($k == 4 && !empty($value) && !($this->checkMultiPortOrPortRange($value))){
                return "12018";
            }
            if($k == 5 && !empty($value) && !($this->checkMultiPortOrPortRange($value))){
                return "12018";
            }
            if($k == 6 && !Validate::in($value, "0,1")){
                return "13006";
            }
            if($k == 7 && (!empty($value) && !(Validate::is($value, "chsDash") && strlen($value)<=32 )) ){
                return "12014";
            }
        }
        return true;
    }
    //验证 主机备注 更新操作参数
    protected function checkUpdateMacInfo($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null)) ){
                return "12011";
            }
            if($k == 1 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null)) ){
                return "11001";
            }
            if($k == 2 && !(Validate::is($value, "chsDash") && strlen($value)<=32 )){
                return "12014";
            }
        }
        return true;
    }
    //验证 主机备注 更新操作参数
    protected function checkQeditMacInfo($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !$this->checkMac($value)){
                return "12006";
            }
            if($k == 1 && !empty($value) && !(Validate::is($value, "chsDash") && strlen($value)<=32 )){
                return "12014";
            }
        }
        return true;
    }
    //验证 全息节点 更新操作参数
    protected function checkUpdateHoloMask($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null)) ){
                return "12011";
            }
            if($k == 1 && !(Validate::is($value, "chsDash") && strlen($value)<=32 )){
                return "12014";
            }
            if($k == 2 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return "12001";
            }
            if($k == 3 && !(Validate::is($value, "ip") || CheckIpRange($value) || CheckIpMask($value) )){
                return "12004";
            }
            if($k == 4 && !$this->checkVlanId($value)){
                return "12009";
            }
            if($k == 5 && !$this->checkGroupId($value)){
                return "12010";
            }
        }
        return true;
    }
    //验证 端口虚开 更新操作参数
    protected function checkUpdateServerTrap($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null)) ){
                return "12011";
            }
            if($k == 1 && !(Validate::is($value, "chsDash") && strlen($value)<=32 )){
                return "12014";
            }
            if($k == 2 && !$this->checkMultiMacIpRange($value) ){
                return "12021";
            }
            if($k == 3){
                if(!Validate::in($value, "0,1,2,3")){
                    return "13007";
                }elseif($this->checkMac($valueArr[2]) && !(Validate::in($value, "1,2,3"))){
                    return "10019";
                }
            }
            if($k == 4 && !$this->checkMultiPortOrPortRange($value)){
                return "12007";
            }
            if($k == 5 && !empty($value) && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return "12001";
            }
            if($k == 6 && !(empty($value) && $value != '0') && !$this->checkMultiPort($value)){
                return "12007";
            }
            if((!empty($valueArr[5]) && (empty($valueArr[6]) && $valueArr[6]!='0')) || (empty($valueArr[5]) && !(empty($valueArr[6]) && $valueArr[6]!='0')) ){
                return "10018";
            }
            if($k == 7 && !$this->checkVlanId($value)){
                return "12009";
            }
            if($k == 8 && !$this->checkGroupId($value)){
                return "12010";
            }
        }
        return true;
    }
    //验证 端口虚开白名单 更新操作参数
    protected function checkUpdateServerTrapWlist($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null)) ){
                return "12011";
            }
            if($k == 1 && !( (Validate::is($value, "ip") && ($value != "0.0.0.0")) || CheckIpRange($value) || CheckIpMask($value) || $this->checkMac($value) )){
                return "12021";
            }
            if($k == 2 && !$this->checkMultiPort($value)){
                return "12007";
            }
        }
        return true;
    }
    //验证 应用访问策略 新增操作参数
    protected function checkUpdateAccessSt($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null)) ){
                return "12011";
            }
            if($k == 1 && ( !(Validate::is($value, "chsDash") && strlen($value)<=32 )) ){
                return "12014";
            }
            if($k == 2 && !Validate::in($value, "6,17")){
                return "12013";
            }
            if($k == 3 && !(empty($value) && $value != '0') && !$this->checkMultiPort($value)){
                return "12007";
            }
            if($k == 4 && !(empty($value) && $value != '0') && !$this->checkMultiPort($value)){
                return "12007";
            }
            if($k == 5 && !empty($value) && !($this->checkTimeRange($value))){
                return "12017";
            }
        }
        return true;
    }

    // 端口或端口范围混合
    protected function checkMultiPortOrPortRange($value){
        $valueArr = explode(',', $value);
        $resultArr = array_filter($valueArr, function ($item) {
            return $this->checkPort($item) || $this->checkPortRange($item);
        });
        return count($resultArr) == count($valueArr);
    }
    // 验证多个id "," 隔开
    protected function checkMultiIds($value){
        $ids_arr = explode(',', $value);
        $valid_arr = array_filter($ids_arr,function($value){
            return Validate::is($value,'integer') && Validate::egt($value, 0, null);
        });
        return count($ids_arr) == count($valid_arr);
    }
    //验证多个端口 "," 隔开
    protected function checkMultiPort($value){
        $valueArr = explode(',', $value);
        $resultArr = array_filter($valueArr, function ($item) {
            return Validate::is($item, 'integer') && Validate::egt($item, 1, null) && Validate::elt($item, 65535, null);
        });
        return count($resultArr) == count($valueArr);
    }
    // 端口范围 11:22
    protected function checkPortRange($value){
        $valueArr = explode(':', $value);
        if(count($valueArr) != 2){
            return false;
        }
        if($valueArr[0] >= $valueArr[1]){
            return false;
        }
        $resultArr = array_filter($valueArr, function ($item) {
            return Validate::is($item, 'integer') && Validate::egt($item, 1, null) && Validate::elt($item, 65535, null);
        });
        if(count($resultArr) != count($valueArr)){
            return false;
        }
        return true;
    }
    //验证多个ip 或IP段 或mac地址 "," 隔开
    protected function checkMultiMacIpRange($value){
        $valueArr = explode(',', $value);
        $resultArr = array_filter($valueArr, function ($value) {
            return (Validate::is($value, "ip") && ($value != "0.0.0.0")) || CheckIpRange($value) || CheckIpMask($value) || $this->checkMac($value);
        });
        return count($resultArr) == count($valueArr);
    }

    //验证ip 或IP段 
    protected function checkIpOrIpRange($value){
        return (Validate::is($value, "ip") && ($value != "0.0.0.0")) || CheckIpRange($value) || CheckIpMask($value);
    }

    //验证 协议号
    protected function checkProtocol($value){
        return Validate::is($value, "integer") && ($value >= 0 && $value <= 137);
    }
    //验证 VLAN_ID
    protected function checkVlanId($value){
        return Validate::is($value, "integer") && Validate::egt($value, 0, null) && Validate::elt($value, 4096, null);
    }
    //验证 物理线路
    protected function checkGroupId($value){
        return Validate::is($value, "integer") && Validate::egt($value, 0, null);
    }
    //验证 MAC地址
    protected function checkMac($value){
        return filter_var($value, FILTER_VALIDATE_MAC) === false ? false : true;
    }
    //验证 端口
    protected function checkPort($value){
        return Validate::is($value, 'integer') && Validate::egt($value, 1, null) && Validate::elt($value, 65535, null);
    }
    //验证 小时:分钟 区间
    protected function checkTimeRange($value){
        $valueArr = explode('-', $value);        
        if(count($valueArr) !== 2)
            return false;

        $resultArr = array_filter($valueArr, function ($value) {
            return Validate::dateFormat($value, "H:m");
        });
        return count($resultArr) == count($valueArr);
    }
}

