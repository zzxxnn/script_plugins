<?php

namespace app\index\validate;
use think\Validate;

class Netconf extends Validate{

    protected $rule = [
        'switch'        =>  'require|in:0,1',
        'double_dns'    =>  'require|checkCount:2|checkMultiIp',
        'sec_time'      =>  'require|integer|egt:0',
        'trible_sec_times'      =>  'require|checkCount:3|checkMultiSecTime',
        'double_ipmask' =>  'require|checkCount:3|checkMgt',
        'trible_per'    =>  'require|checkCount:3|checkMultiPer',
        'per'           =>  'require|number|egt:0|elt:100',
        'multi_ports'   =>  'require|checkMultiPort',
        'multi_mac_ids' =>  'require|checkMacId'        
    ];

    protected $message  =   [
        'switch.require'        =>  '10001',
        'switch.in'             =>  '13009',
        'double_dns.require'    =>  '10001',
        'double_dns.checkCount' =>  '10001|need 2 params',
        'double_dns.checkMultiIp'       =>  '12001',
        'sec_time.require'              =>  '10001',
        'sec_time.integer'              =>  '11001',
        'sec_time.egt'                  =>  '11001',
        'trible_sec_times.require'      =>  '10001',
        'trible_sec_times.checkCount'   =>  '10001|need 3 params',
        'trible_sec_times.checkMultiSecTime'    =>  '11001',
        'double_ipmask.require'         =>  '10001',
        'double_ipmask.checkCount'      =>  '10001|need 3 params',
        'trible_per.require'            =>  '10001',
        'trible_per.checkCount'         =>  '10001|need 3 params',
        'per.require'                   =>  '10001',
        'per.number'                    =>  '11002',
        'per.gt'                        =>  '11002',
        'per.lt'                        =>  '11002',
        'multi_ports.require'           =>  '10001',
        'multi_ports.checkMultiPort'    =>  '12007',
        'multi_mac_ids.require'         =>  '10001',
        'multi_mac_ids.checkMacId'      =>  '12008'
    ];

    protected $scene = [
        'typeswitch'=>  ['switch'],
        'type2'     =>  ['double_dns'],
        'type3'     =>  ['sec_time'],
        'type4'     =>  ['sec_time'],
        'type7'     =>  ['trible_sec_times'],
        'type8'     =>  ['double_ipmask'],
        'type17'    =>  ['trible_per'],
        'type18'    =>  ['per'],
        'typeport'  =>  ['multi_ports'],
        'type22'    =>  ['multi_mac_ids']        
    ];

    //验证参数个数
    protected function checkCount($value, $rule){
        $valueArr = explode('|', $value);
        return $rule == count($valueArr);
    }

    //验证多个ip 以|隔开
    protected function checkMultiIp($value){
        $valueArr = explode('|', $value);
        $resultArr = array_filter($valueArr, function ($item) {
            return Validate::is($item, 'ip') && ($item != "0.0.0.0");
        });
        return count($resultArr) == count($valueArr);
    }

    //验证多个秒级时间 以|隔开
    protected function checkMultiSecTime($value){
        $valueArr = explode('|', $value);
        $resultArr = array_filter($valueArr, function ($item) {
            return Validate::is($item, 'integer') && Validate::egt($item, 0, null);
        });
        return count($resultArr) == count($valueArr);
    }

    //验证管理口ip/mask
    protected function checkMgt($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $tmp){
            if(($k === 0 || $k === 1) && !CheckIpMask($tmp)){
                return "12002";
            }
            if($k === 2 && !Validate::in($tmp, "0,1,2")){
                return "13001";
            }
        }
        return true;
    }

    //验证多个百分比且相加不大于1
    protected function checkMultiPer($value){
        $valueArr = explode('|', $value);
        $resultArr = array_filter($valueArr, function ($item) {
            return Validate::egt($item, 0, null) && Validate::elt($item, 100, null);
        });
        if(count($resultArr) != count($valueArr))
            return '11002';
        
        $n = 0;
        foreach($valueArr as $a){
            $n += $a;
        }
        if($n>100)
            return '13005';
        
        return true;
    }

    //验证多个端口 "," 隔开
    protected function checkMultiPort($value){
        $valueArr = explode(',', $value);
        $resultArr = array_filter($valueArr, function ($item) {
            return Validate::is($item, 'integer') && Validate::egt($item, 1, null) && Validate::elt($item, 65535, null);
        });
        return count($resultArr) == count($valueArr);
    }

    //验证mac标识 为6个由 0-9 a-f 的字符组成
    protected function checkMacId($value){
        $valueArr = explode(',', $value);
        $resultArr = array_filter($valueArr, function ($item) {
            if(strlen($item) != 6){
                return false;
            }
            for($i = 0 ; $i < strlen($item) ; $i++){
                if(!Validate::in(strtolower($item{$i}), ['a','b','c','d','e','f','0','1','2','3','4','5','6','7','8','9'])){
                    return false;
                }
            }
            return true;
        });
        return count($resultArr) == count($valueArr);
    }

}

