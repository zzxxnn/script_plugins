<?php

namespace app\index\validate;
use think\Validate;

class Netmgmt extends Validate{

    protected $rule = [
        't'         =>  'require|checkConfType:1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,28,29,30',
    ];

    protected $message  =   [
        't.require'         =>  '10001|param missing t',
        't.checkConfType'   =>  '13001'
    ];

    protected $scene = [
        'get'           =>  ['t'],
        'add'           =>  ['t'=>"checkConfType:9,10,11,12,13,14,15,16,23,24,25,29"],
        'update'        =>  ['t'],
        'export'        =>  ['t'=>'checkConfType:23,25'],
        'upload'        =>  ['t'=>'checkConfType:23,25'],
        'del'           =>  ['t'=>"checkConfType:9,10,11,12,13,14,15,16,23,24,25,29"],
    ];

    //验证多个类型|隔开
    protected function checkConfType($value, $rule){
        $valueArr = explode('|', $value);
        $ruleArr = explode(',', $rule);
        
        $resultArr = array_filter($valueArr, function ($item) use ($ruleArr) {
            return in_array($item, $ruleArr);
        });

        return count($resultArr) == count($valueArr);
    }

}

