<?php

namespace app\index\validate;

use app\index\traits\ValidatorRules;
use think\Validate;

class Sysconf extends Validate
{
    use ValidatorRules;

    protected $rule = [
        't'                  => 'require|checkConfType:1,2,3,4,5,6,7',
        'page'               => 'integer|gt:0',
        'row'                => 'integer|gt:0',
        'order'              => 'in:asc,desc',
        'by'                 => '',
        'time'               => 'require|checkTime',
        'web_ui'             => 'require|integer|gt:0',
        'punish'             => 'require|integer|gt:0',
        'max_times'          => 'require|integer|gt:0',
        'remote'             => 'require|checkCount:3|checkRemote',
        'add_u_p'            => 'require|checkCount:3|checkAddUserPass',
        'add_l_s'            => 'require|checkCount:4|checkAddLogServer',
        'update_u_p'         => 'require|checkCount:4|checkUpdateUserPass',
        'update_l_s'         => 'require|checkCount:5|checkUpdateLogServer',
        'ids'                => 'require|checkMultiIds',
        'sntp_enable'        => 'require|in:0,1',
        'sntp_host'          => 'require|sntpHost',
        'sntp_sync_interval' => 'require|integer|>=:1'
    ];

    protected $field = [
        'sntp_enable'        => 'SNTP状态',
        'sntp_host'          => 'SNTP主机地址',
        'sntp_sync_interval' => 'SNTP同步频率',
    ];

    protected $message = [
        't.require'             => '10001|param missing t',
        't.checkConfType'       => '13001',
        'time.require'          => '10001|param missing time',
        'time.checkTime'        => '12017',
        'web_ui.require'        => '10001',
        'web_ui.integer'        => '11001',
        'web_ui.gt'             => '11001',
        'punish.require'        => '10001',
        'punish.integer'        => '11001',
        'punish.gt'             => '11001',
        'max_times.require'     => '10001',
        'max_times.integer'     => '11001',
        'max_times.gt'          => '11001',
        'remote.require'        => '10001',
        'remote.checkCount'     => '10001|need 3 params',
        'page.integer'          => '13002',
        'page.gt'               => '13002',
        'row.integer'           => '13003',
        'row.gt'                => '13003',
        'order.in'              => '13004',
        'by.in'                 => '13004',
        'add_u_p.require'       => '10001',
        'add_u_p.checkCount'    => '10001|need 3 params',
        'update_u_p.require'    => '10001',
        'update_u_p.checkCount' => '10001|need 4 params',
        'add_l_s.require'       => '10001',
        'add_l_s.checkCount'    => '10001|need 4 params',
        'update_l_s.require'    => '10001',
        'update_l_s.checkCount' => '10001|need 5 params',
        'ids.require'           => '10001',
        'ids.checkMultiIds'     => '12012',
    ];

    protected $scene = [
        'get'               => ['t'],
        'add'               => ['t' => 'require|checkConfType:6,7'],
        'update'            => ['t'],
        'del'               => ['t' => 'require|checkConfType:6,7'],
        'command'           => ['t' => 'require|checkConfType:8,9,10,11'],
        'export'            => ['t' => 'require|checkConfType:10'],
        'upload'            => ['t' => 'require|checkConfType:10'],
        'upgrade'           => ['t' => 'require|checkConfType:12'],
        'set_time'          => ['time'],
        'set_web_ui'        => ['web_ui'],
        'set_punish'        => ['punish'],
        'set_max_times'     => ['max_times'],
        'set_remote'        => ['remote'],
        'get_user_pass'     => ['page', 'row', 'order', 'by' => "in:name,ip_mac,note"],
        'get_log_server'    => ['page', 'row'],
        'add_user_pass'     => ['add_u_p'],
        'add_log_server'    => ['add_l_s'],
        'update_user_pass'  => ['update_u_p'],
        'update_log_server' => ['update_l_s'],
        'del_user_pass'     => ['ids'],
        'del_log_server'    => ['ids'],
        'update_sntp_conf'  => ['sntp_enable', 'sntp_host', 'sntp_sync_interval'],
    ];

    //验证 网管策略 新增操作参数
    protected function checkAddUserPass($value)
    {
        $valueArr = explode('|', $value);
        foreach ($valueArr as $k => $value) {
            if ($k == 0 && !(Validate::is($value, "chsDash") && strlen($value) <= 32)) {
                return "12014";
            }
            if ($k == 1 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))) {
                return "12001";
            }
            if ($k == 2 && !(empty($value) && $value != '0') && !(Validate::is($value, "chsDash") && strlen($value) <= 32)) {
                return "12014";
            }
        }

        return true;
    }

    //验证 日志服务器 新增操作参数
    protected function checkAddLogServer($value)
    {
        $valueArr = explode('|', $value);
        foreach ($valueArr as $k => $value) {
            if ($k == 0 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))) {
                return "12001";
            }
            if ($k == 1 && !$this->checkPort($value)) {
                return "12007";
            }
            if ($k == 2 && !(Validate::in($value, "0,1"))) {
                return "13009";
            }
            if ($k == 3 && !$this->checkMultiLogType($value)) {
                return "13010";
            }
        }

        return true;
    }

    //验证 网管策略 更新操作参数
    protected function checkUpdateUserPass($value)
    {
        $valueArr = explode('|', $value);
        foreach ($valueArr as $k => $value) {
            if ($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null))) {
                return "12011";
            }
            if ($k == 1 && !(Validate::is($value, "chsDash") && strlen($value) <= 32)) {
                return "12014";
            }
            if ($k == 2 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))) {
                return "12001";
            }
            if ($k == 3 && !(empty($value) && $value != '0') && !(Validate::is($value, "chsDash") && strlen($value) <= 32)) {
                return "12014";
            }
        }

        return true;
    }

    //验证 日志服务器 更新操作参数
    protected function checkUpdateLogServer($value)
    {
        $valueArr = explode('|', $value);
        foreach ($valueArr as $k => $value) {
            if ($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null))) {
                return "12011";
            }
            if ($k == 1 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))) {
                return "12001";
            }
            if ($k == 2 && !$this->checkPort($value)) {
                return "12007";
            }
            if ($k == 3 && !(Validate::in($value, "0,1"))) {
                return "13009";
            }
            if ($k == 4 && !$this->checkMultiLogType($value)) {
                return "13010";
            }
        }

        return true;
    }

    //验证多个类型|隔开
    protected function checkConfType($value, $rule)
    {
        $valueArr = explode('|', $value);
        $ruleArr = explode(',', $rule);

        $resultArr = array_filter($valueArr, function ($item) use ($ruleArr) {
            return in_array($item, $ruleArr);
        });

        return count($resultArr) == count($valueArr);
    }

    // 验证多个id "," 隔开
    protected function checkMultiIds($value)
    {
        $ids_arr = explode(',', $value);
        $valid_arr = array_filter($ids_arr, function ($value) {
            return Validate::is($value, 'integer') && Validate::egt($value, 0, null);
        });

        return count($ids_arr) == count($valid_arr);
    }

    //验证参数个数
    protected function checkCount($value, $rule)
    {
        $valueArr = explode('|', $value);

        return $rule == count($valueArr);
    }

    //验证时间日期格式
    protected function checkTime($value)
    {
        $result = strtotime($value);

        return $result ? true : false;
    }

    //验证集中管理配置
    protected function checkRemote($value, $rule)
    {
        $valueArr = explode('|', $value);
        foreach ($valueArr as $k => $value) {
            if ($k == 1 && (!$this->checkPort($value))) {
                return "12007";
            }
        }

        return true;
    }

    //验证 端口
    protected function checkPort($value)
    {
        return Validate::is($value, 'integer') && Validate::egt($value, 1, null) && Validate::elt($value, 65535, null);
    }

    // 验证多个日志类型 "," 隔开
    protected function checkMultiLogType($value)
    {
        $log_arr = explode(',', $value);
        $valid_arr = array_filter($log_arr, function ($value) {
            return Validate::is($value, 'integer') && Validate::in($value, "1,4,5,6,7,8,9");
        });

        return count($log_arr) == count($valid_arr);
    }

    protected function sntpHost($value)
    {
        $invalid = false;    // true 非法， false 合法
        if (!Validate::ip($value, 'ipv4') && $this->domain($value) !== true) {
            return 'SNTP主机地址必须是IP或域名！';
        }

        // 如果是域名，校验域名是否可达
        if ($this->domain($value) === true) {
            $host = gethostbyname($value);
            $invalid = $host === $value;
        }

        return $invalid ? 'SNTP主机不是真实有效的IP或域名！' : true;
    }
}

