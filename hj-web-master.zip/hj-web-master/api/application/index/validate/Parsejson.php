<?php

namespace app\index\validate;
use think\Validate;

class Parsejson extends Validate{

    protected $rule = [
        'switch'        =>  'require|in:0,1',
        'double_dns'    =>  'require|checkMultiIp',
        'sec_time'      =>  'require|integer|egt:0',
        'trible_sec_times'      =>  'require|checkMultiSecTime',
        'double_ipmask' =>  'require|checkMultiIpMask',
        'trible_per'    =>  'require|checkMultiPer',
        'percent'       =>  'require|number|egt:0|elt:100',
        'multi_ports'   =>  'require|checkMultiPort',
        'multi_mac_ids' =>  'require|checkMacId',
        'groupids'      =>  'require|checkMultiInt',      
        'multi_integer' =>  'require|checkMultiInt',
        'r_v_v'         =>  'require|checkRipVipVnet',
        'w_ip'          =>  'require|checkWip',
        'w_e_ip'        =>  'require|checkWeip',
        'ip'            =>  'require|ip',
        'mac'           =>  'require|checkMac',
        'f_w_pol'       =>  'require|checkFwPol',
        'h_pot'         =>  'require|checkHpot',
        'l_ser'         =>  'require|checkLogServer',
        'mac_through'   =>  'require|checkMacThrough',
        'mac_b_ip'      =>  'require|checkBindIp',
        'ports_u_o'     =>  'require|checkServerTrap',
        'ports_u_o_wlist'     =>  'require|checkServerTrapWlist',
        's_pre'         =>  'require|checkHoloMask',
        's_route'       =>  'require|checkBindRouter',
        'acs_st'        =>  'require|checkAccessSt'
    ];

    protected $scene = [
        'switchtype'    =>  ['switch'],
        'dhcp_dns'      =>  ['double_dns'],
        'dhcp_time'     =>  ['sec_time'],
        'host_status_ttl'   =>  ['sec_time'],
        'alter_time'    =>  ['trible_sec_times'],
        'mgt_ip'        =>  ['double_ipmask'],
        'per'           =>  ['trible_per'],
        'virtual_port_percent'=>  ['percent'],
        'ports'             =>  ['multi_ports'],
        'company_mac'       =>  ['multi_mac_ids'],
        'bypass_groupids'   =>  ['groupids'],
        'host_block_config' =>  ['multi_integer'],
        'rip'   =>  ['r_v_v'],
        'vip'   =>  ['r_v_v'],
        'vnet'  =>  ['r_v_v'],
        'wip'   =>  ['w_ip'],
        'weip'  =>  ['w_e_ip'],
        'ips'   =>  ['ip'],
        'macs'  =>  ['mac'],
        'firewall'      =>  ['f_w_pol'],
        'honey_pot'     =>  ['h_pot'],
        'log_server'    =>  ['l_ser'],
        'mac_bind_passthrough' =>  ['mac_through'],
        'mac_bind_wip'      =>  ['mac_b_ip'],
        'ports_unreal_open' =>  ['ports_u_o'],
        'unreal_open_white' =>  ['ports_u_o_wlist'],
        'server_pretend'    =>  ['s_pre'],
        'static_route'      =>  ['s_route'],
        'access_strategy'   =>  ['acs_st']
    ];

    //验证 应用访问策略 参数
    protected function checkAccessSt($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null)) ){
                return false;
            }
            if($k == 1 && ( !(Validate::is($value, "chsDash") && strlen($value)<=32 )) ){
                return false;
            }
            if($k == 2 && !Validate::in($value, "6,17")){
                return false;
            }
            if($k == 3 && !(empty($value) && $value != '0') && !$this->checkMultiPort($value)){
                return false;
            }
            if($k == 4 && !(empty($value) && $value != '0') && !$this->checkMultiPort($value)){
                return false;
            }
            if($k == 5 && !empty($value) && !($this->checkTimeRange($value))){
                return false;
            }
        }
        return true;
    }
    //验证 静态路由 参数
    protected function checkBindRouter($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(CheckIpMask($value) || $value == "0.0.0.0/0" )){
                return false;
            }
            if($k == 1 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return false;
            }
        }
        return true;
    }

    //验证 全息节点 参数
    protected function checkHoloMask($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "chsDash") && strlen($value)<=32 )){
                return false;
            }
            if($k == 1 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return false;
            }
            if($k == 2 && !(Validate::is($value, "ip") || CheckIpRange($value) || CheckIpMask($value) )){
                return false;
            }
            if($k == 3 && !$this->checkVlanId($value)){
                return false;
            }
            if($k == 4 && !$this->checkGroupId($value)){
                return false;
            }
        }
        return true;
    }

    //验证 端口虚开白名单 参数
    protected function checkServerTrapWlist($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !( Validate::is($value, "ip") || CheckIpRange($value) || CheckIpMask($value) || $this->checkMac($value) )){
                return false;
            }
            if($k == 1 && !$this->checkMultiPort($value)){
                return false;
            }
        }
        return true;
    }

    //验证 端口虚开 参数
    protected function checkServerTrap($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "chsDash") && strlen($value)<=32 )){
                return false;
            }
            if($k == 1 && !$this->checkMultiMacIpRange($value) ){
                return false;
            }
            if($k == 2){
                if(!Validate::in($value, "0,1,2,3")){
                    return false;
                }elseif($this->checkMac($valueArr[1]) && !(Validate::in($value, "1,2,3"))){
                    return false;
                }
            }
            if($k == 3 && !$this->checkMultiPortOrPortRange($value)){
                return false;
            }
            if($k == 4 && !empty($value) && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return false;
            }            
            if($k == 5 && !(empty($value) && $value != '0') && !$this->checkMultiPort($value)){
                return false;
            }
            if($k == 6 && !$this->checkVlanId($value)){
                return false;
            }
            if($k == 7 && !$this->checkGroupId($value)){
                return false;
            }
            if((!empty($valueArr[4]) && (empty($valueArr[5]) && $valueArr[5]!='0')) || (empty($valueArr[4]) && !(empty($valueArr[5]) && $valueArr[5]!='0')) ){
                return false;
            }
        }
        return true;
    }

    //验证 静态地址 参数
    protected function checkBindIp($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !$this->checkMac($value)){
                return false;
            }
            if($k == 1 && !(Validate::is($value, "ip") && ($value != "0.0.0.0")) ){
                return false;
            }
        }
        return true;
    }

    //验证 主机透传 参数
    protected function checkMacThrough($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !$this->checkMac($value)){
                return false;
            }
            if($k == 1 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return false;
            }
            if($k == 2 && !$this->checkVlanId($value)){
                return false;
            }
            if($k == 3 && !$this->checkGroupId($value)){
                return false;
            }
        }
        return true;
    }

    //验证 日志服务器 参数
    protected function checkLogServer($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return false;
            }
            if($k == 1 && !$this->checkPort($value)){
                return false;
            }
            if($k == 2 && !(Validate::in($value, "0,1"))){
                return false;
            }
            if($k == 3 && !$this->checkMultiLogType($value)){
                return false;
            }
        }
        return true;
    }

    //验证 蜜罐主机 参数
    protected function checkHpot($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return false;
            }
            if($k == 1 && !$this->checkPort($value)){
                return false;
            }
            if($k == 2 && !$this->checkPort($value)){
                return false;
            }
        }
        return true;
    }

    //验证 内网防火墙 参数
    protected function checkFwPol($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !$this->checkProtocol($value)){
                return false;
            }
            if($k == 1 && !empty($value) && !$this->checkIpOrIpRange($value)){
                return false;
            }
            if($k == 2 && !empty($value) && !($this->checkMultiPortOrPortRange($value))){
                return false;
            }
            if($k == 3 && !empty($value) && !$this->checkIpOrIpRange($value)){
                return false;
            }
            if($k == 4 && !empty($value) && !($this->checkMultiPortOrPortRange($value))){
                return false;
            }
            if($k == 5 && !Validate::in($value, "0,1")){
                return false;
            }
        }
        return true;
    }

    //验证 wip 参数
    protected function checkWip($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return false;
            }
            if($k == 1 && !$this->checkMask($value)){
                return false;
            }
            if($k == 2 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return false;
            }
            if($k == 3 && !$this->checkVlanId($value)){
                return false;
            }
            if($k == 4 && !$this->checkGroupId($value)){
                return false;
            }
        }
        return true;
    }

    //验证 wip 参数
    protected function checkWeip($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return false;
            }
            if($k == 1 && !$this->checkMask($value)){
                return false;
            }
            if($k == 2 && !$this->checkVlanId($value)){
                return false;
            }
            if($k == 3 && !$this->checkGroupId($value)){
                return false;
            }
        }
        return true;
    }

    //验证 rip vip vnet 参数
    protected function checkRipVipVnet($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "ip") && ($value != "0.0.0.0"))){
                return false;
            }
            if($k == 1 && !$this->checkMask($value)){
                return false;
            }
            if($k == 2 && !$this->checkVlanId($value)){
                return false;
            }
            if($k == 3 && !$this->checkGroupId($value)){
                return false;
            }
        }
        return true;
    }

    //验证参数个数
    protected function checkCount($value, $rule){
        $valueArr = explode('|', $value);
        return $rule == count($valueArr);
    }

    //验证多个整数
    protected function checkMultiInt($value){
        $valueArr = explode(',', $value);
        $resultArr = array_filter($valueArr, function ($item) {
            return Validate::is($item, 'integer') && Validate::egt($item, 0, null);
        });
        return count($resultArr) == count($valueArr);
    }

    //验证多个ip 以|隔开
    protected function checkMultiIp($value){
        $valueArr = explode('|', $value);
        $resultArr = array_filter($valueArr, function ($item) {
            return Validate::is($item, 'ip');
        });
        return count($resultArr) == count($valueArr);
    }

    //验证多个秒级时间 以|隔开
    protected function checkMultiSecTime($value){
        $valueArr = explode('|', $value);
        $resultArr = array_filter($valueArr, function ($item) {
            return Validate::is($item, 'integer') && Validate::egt($item, 0, null);
        });
        return count($resultArr) == count($valueArr);
    }

    //验证多个 ip/mask
    protected function checkMultiIpMask($value){
        $valueArr = explode('|', $value);
        $resultArr = array_filter($valueArr, function ($item) {
            return CheckIpMask($item);
        });
        return count($resultArr) == count($valueArr);
    }

    //验证多个百分比且相加不大于1
    protected function checkMultiPer($value){
        $valueArr = explode('|', $value);
        $resultArr = array_filter($valueArr, function ($item) {
            return Validate::egt($item, 0, null) && Validate::elt($item, 100, null);
        });
        if(count($resultArr) != count($valueArr))
            return false;
        
        $n = 0;
        foreach($valueArr as $a){
            $n += $a;
        }
        if($n>100)
            return false;
        
        return true;
    }

    // 端口或端口范围混合
    protected function checkMultiPortOrPortRange($value){
        $valueArr = explode(',', $value);
        $resultArr = array_filter($valueArr, function ($item) {
            return $this->checkPort($item) || $this->checkPortRange($item);
        });
        return count($resultArr) == count($valueArr);
    }
    
    //验证多个端口 "," 隔开
    protected function checkMultiPort($value){
        $valueArr = explode(',', $value);
        $resultArr = array_filter($valueArr, function ($item) {
            return Validate::is($item, 'integer') && Validate::egt($item, 1, null) && Validate::elt($item, 65535, null);
        });
        return count($resultArr) == count($valueArr);
    }

    // 端口范围 11:22
    protected function checkPortRange($value){
        $valueArr = explode(':', $value);
        if(count($valueArr) != 2){
            return false;
        }
        if($valueArr[0] >= $valueArr[1]){
            return false;
        }
        $resultArr = array_filter($valueArr, function ($item) {
            return Validate::is($item, 'integer') && Validate::egt($item, 1, null) && Validate::elt($item, 65535, null);
        });
        if(count($resultArr) != count($valueArr)){
            return false;
        }
        return true;
    }

    //验证mac标识 为6个由 0-9 a-f 的字符组成
    protected function checkMacId($value){
        $valueArr = explode(',', $value);
        $resultArr = array_filter($valueArr, function ($item) {
            if(strlen($item) != 6){
                return false;
            }
            for($i = 0 ; $i < strlen($item) ; $i++){
                if(!Validate::in(strtolower($item{$i}), ['a','b','c','d','e','f','0','1','2','3','4','5','6','7','8','9'])){
                    return false;
                }
            }
            return true;
        });
        return count($resultArr) == count($valueArr);
    }
    //验证 VLAN_ID
    protected function checkVlanId($value){
        return Validate::is($value, "integer") && Validate::egt($value, 0, null) && Validate::elt($value, 4096, null);
    }
    //验证 物理线路
    protected function checkGroupId($value){
        return Validate::is($value, "integer") && Validate::egt($value, 0, null);
    }
    //验证 MAC地址
    protected function checkMac($value){
        return filter_var($value, FILTER_VALIDATE_MAC) === false ? false : true;
    }
    //验证 掩码 255.255.255.0
    protected function checkMask($mask){
        $m = @ip2long($mask);
        if(empty($m)) {
            return false;
        }
        $m = ~$m & 0xffffffff;
        return ($m&($m+1)) == 0;
    }
    //验证 协议号
    protected function checkProtocol($value){
        return Validate::is($value, "integer") && ($value >= 0 && $value <= 137);
    }
    //验证 端口
    protected function checkPort($value){
        return Validate::is($value, 'integer') && Validate::egt($value, 1, null) && Validate::elt($value, 65535, null);
    }
    // 验证多个日志类型 "," 隔开
    protected function checkMultiLogType($value){
        $log_arr = explode(',', $value);
        $valid_arr = array_filter($log_arr,function($value){
            return Validate::is($value,'integer') && Validate::in($value, "1,4,5,6,7,8,9");
        });
        return count($log_arr) == count($valid_arr);
    }
    //验证多个ip 或IP段 或mac地址 "," 隔开
    protected function checkMultiMacIpRange($value){
        $valueArr = explode(',', $value);
        $resultArr = array_filter($valueArr, function ($value) {
            return Validate::is($value, "ip") || CheckIpRange($value) || CheckIpMask($value) || $this->checkMac($value);
        });
        return count($resultArr) == count($valueArr);
    }
    //验证ip 或IP段 
    protected function checkIpOrIpRange($value){
        return (Validate::is($value, "ip") && ($value != "0.0.0.0")) || CheckIpRange($value) || CheckIpMask($value);
    }
    //验证 小时:分钟 区间
    protected function checkTimeRange($value){
        $valueArr = explode('-', $value);
        if(count($valueArr) !== 2)
            return false;

        $resultArr = array_filter($valueArr, function ($value) {
            return Validate::dateFormat($value, "H:m");
        });
        return count($resultArr) == count($valueArr);
    }
}

