<?php

namespace app\index\validate;
use think\Validate;

class Login extends Validate{

    protected $rule = [
        'username'  =>  'require',
        'password'  =>  'require',
        
    ];

    protected $message  =   [
        'username.require'  =>  '10001|param missing username',
        'password.require'  =>  '10001|param missing password',
        
    ];

    protected $scene = [
        'login'  =>  ['username','password']
    ];

}

