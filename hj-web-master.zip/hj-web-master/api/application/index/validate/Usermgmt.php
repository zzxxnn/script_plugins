<?php

namespace app\index\validate;
use think\Validate;

class Usermgmt extends Validate{

    protected $rule = [
        'username'  =>  'require',
        'password'  =>  'require',
        'u_add'     =>  'require|checkCount:6|checkAddUser',
        'u_update'  =>  'require|checkCount:6|checkUpdateUser',
        'p_update'  =>  'require|checkCount:3|checkUpdatePwd',
        'ids'       =>  'require|checkMultiIds',
        't'         =>  'require|in:1,2',

    ];

    protected $message  =   [
        't.require'          =>  '10001|param missing t',
        't.in'               =>  '13001',
        'username.require'   =>  '10001|param missing username',
        'password.require'   =>  '10001|param missing password',
        'u_add.require'      =>  '10001',
        'u_add.checkCount'   =>  '10001|need 6 params',
        'u_update.require'   =>  '10001',
        'u_update.checkCount'=>  '10001|need 6 params',
        'p_update.require'   =>  '10001',
        'p_update.checkCount'=>  '10001|need 3 params',
        'ids.require'        =>  '10001',
        'ids.checkMultiIds'  =>  '12012',
    ];

    protected $scene = [
        'login'         =>  ['username','password'],
        'user_add'      =>  ['u_add'],
        'add'           =>  ['t' => 'require|in:1'],
        'update'        =>  ['t'],
        'del'           =>  ['t' => 'require|in:1'],
        'user_update'   =>  ['u_update'],
        'pwd_update'    =>  ['p_update'],
        'user_del'      =>  ['ids'],
    ];

    //验证多个类型|隔开
    protected function checkConfType($value, $rule){
        $valueArr = explode('|', $value);
        $ruleArr = explode(',', $rule);
        
        $resultArr = array_filter($valueArr, function ($item) use ($ruleArr) {
            return in_array($item, $ruleArr);
        });

        return count($resultArr) == count($valueArr);
    }

    //验证参数个数
    protected function checkCount($value, $rule){
        $valueArr = explode('|', $value);
        return $rule == count($valueArr);
    }

    //验证添加用户操作参数
    protected function checkAddUser($value){
        $valueArr = explode('|', $value);
        if($valueArr[2] == '1'){
            return "10023";
        }
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "alphaDash") && strlen($value)>=6 && strlen($value)<=18 )){
                return "12015";
            }
            if($k == 1 && !($this->checkPasswordFormat($value))){
                return "10005";
            }
            if($k == 2 && !(Validate::in($value, '1,2,3'))){
                return "13008";
            }
            if($k == 3 && !empty($value) && !(Validate::is($value, "chsDash") && strlen($value)<=32 )){
                return "10005";
            }
            if($k == 4 && !empty($value) && !(Validate::is($value, "chsDash") && strlen($value)<=32 )){
                return "10005";
            }
            if($k == 5 && !empty($value) && !(Validate::is($value, "email"))){
                return "12016";
            }
        }
        return true;
    }

    //验证更新用户操作参数
    protected function checkUpdateUser($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null)) ){
                return "11001";
            }
            if($k == 1 && !(Validate::is($value, "chsDash") && strlen($value)>=6 && strlen($value)<=18 )){
                return "12015";
            }
            if($k == 2 && !(Validate::in($value, '1,2,3'))){
                return "13008";
            }
            if($k == 3 && !empty($value) && !(Validate::is($value, "chsDash") && strlen($value)<=32 )){
                return "10005";
            }
            if($k == 4 && !empty($value) && !(Validate::is($value, "chsDash") && strlen($value)<=32 )){
                return "10005";
            }
            if($k == 5 && !empty($value) && !(Validate::is($value, "email"))){
                return "12016";
            }
        }
        return true;
    }

    //验证更新密码操作参数
    protected function checkUpdatePwd($value){
        $valueArr = explode('|', $value);
        foreach($valueArr as $k => $value){
            if($k == 0 && !(Validate::is($value, "integer") && Validate::egt($value, 0, null)) ){
                return "11001";
            }
            if($k == 2 && !($this->checkPasswordFormat($value))){
                return "13008";
            }
        }
        return true;
    }

    //验证密码复杂度 长度至少为8位 包括数字、字母大小写
    protected function checkPasswordFormat($value){
        if(strlen($value) < 8 || strlen($value) > 16){
            return false;
        }
        $n=preg_match('/[0-9]/', $value);
        $e=preg_match('/[a-zA-Z]/', $value);
        if( $n && $e ){
            return true;
        }else{
            return false;
        }
    }

    // 验证多个id "," 隔开
    protected function checkMultiIds($value){
        $ids_arr = explode(',', $value);
        $valid_arr = array_filter($ids_arr,function($value){
            return Validate::is($value,'integer') && Validate::egt($value, 0, null);
        });
        return count($ids_arr) == count($valid_arr);
    }

}

