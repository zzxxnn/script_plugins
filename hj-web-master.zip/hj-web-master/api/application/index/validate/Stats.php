<?php

namespace app\index\validate;
use think\Validate;

class Stats extends Validate{

    protected $rule = [
        't'        => 'require|checkConfType:1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24',
        'r'        => 'in:1,2,3,4,5,6,7,8,9',
        'ip'       => 'ip',
        'orderby'  => 'in:in_bps,out_bps,in_pps,out_pps,tcp_conn,udp_conn',
        'limit'    => 'integer|egt:0',
        'order'     => 'in:asc,desc'

    ];

    protected $message  =   [
        't.require'         =>  '10001',
        't.checkConfType'   =>  '13001',
        'r.in'              =>  '13001',
        'ip.ip'             =>  '12001',
        'orderby.in'        =>  '13004',
        'limit.integer'     =>  '13003',
        'limit.egt'         =>  '13003',
        'order.in'          =>  '13004',

        'orderby12.in'      =>  '13004',
        'order12.in'        =>  '13004',
        'page12.integer'    =>  '13002',
        'page12.egt'        =>  '13002',
        'row12.integer'     =>  '13003',
        'row12.egt'         =>  '13003',
        'start_time12.integer'  =>  '12022',
        'start_time12.egt'      =>  '12022',
        'end_time12.integer'    =>  '12022',
        'end_time12.egt'        =>  '12022',

        'orderby10.in'      =>  '13004',
        'order10.in'        =>  '13004',
        'page10.integer'    =>  '13002',
        'page10.egt'        =>  '13002',
        'row10.integer'     =>  '13003',
        'row10.egt'         =>  '13003',
        'start_time10.integer'  =>  '12022',
        'start_time10.egt'      =>  '12022',
        'end_time10.integer'    =>  '12022',
        'end_time10.egt'        =>  '12022',
        
    ];

    protected $scene = [
        'get'               =>  ['t'],
        'get_colligate'     =>  ['r' => 'in:1,2,3,4', 'ip'],
        'get_device'        =>  ['r' => 'in:1,2,3,4,5,6,7,8,9'],
        'get_network'       =>  [''],
        'get_ethstats'      =>  [
            'orderby' => 'in:desc,desc_no,up,name,macaddr,in_bytes,in_dropped,in_errors,in_packets,in_Bps,out_bytes,out_dropped,out_errors,out_packets,out_Bps',
            'order'
        ],
        'get_blockstats'    =>  [
            'orderby12' => 'in:source,desc,timestamp',
            'order12'   => 'in:asc,desc',
            'page12'    => 'integer|egt:1',
            'row12'     => 'integer|egt:1',
            'start_time12'  =>  'integer|egt:0',
            'end_time12'    =>  'integer|egt:0'
        ],
        'get_10stats'       =>  [
            'orderby10'     =>  'in:mac,desc,rip,vip,name,groupid,vlanid,time,is_block',
            'order10'       =>  'in:asc,desc',
            'page10'        =>  'integer|egt:1',
            'row10'         =>  'integer|egt:1',
            'start_time10'  =>  'integer|egt:0',
            'end_time10'    =>  'integer|egt:0'
        ],
        'get_11stats'       =>  [
            'orderby11'     =>  'in:mac,desc,rip,groupid,total_bytes,up_speed,down_speed,connects',
            'order11'       =>  'in:asc,desc',
            'page11'        =>  'integer|egt:1',
            'row11'         =>  'integer|egt:1'
        ],
        'del'               =>  ['t'=>'require|checkConfType:10'],
    ];

    //验证多个类型|隔开
    protected function checkConfType($value, $rule){
        $valueArr = explode('|', $value);
        $ruleArr = explode(',', $rule);
        
        $resultArr = array_filter($valueArr, function ($item) use ($ruleArr) {
            return in_array($item, $ruleArr);
        });

        return count($resultArr) == count($valueArr);
    }

}

