<?php

namespace app\index\validate;
use think\Validate;

class Utils extends Validate{

    protected $rule = [
        'oper'    =>  'require|in:block,unblock',
        'ipmac'   =>  'require|checkMacOrIp',
        'ip'      =>  'require|ip',
        'times'   =>  'require|integer|egt:1|elt:100',
        'length'  =>  'require|integer|egt:64|elt:1500',
        'min_ttl' =>  'require|integer|egt:1|elt:255',
        'max_ttl' =>  'require|integer|egt:1|elt:255',
        't'       =>  '',       
    ];

    protected $message  =   [
        'oper.require'      =>  '10001|param missing oper',
        'oper.in'           =>  '13011',
        'ipmac.require'     =>  '10001|param missing ipmac',
        'ipmac.checkMacOrIp'=>  '12021',
        'ip.require'        =>  '10001|param missing ip',
        'ip.ip'             =>  '12001',
        'times.require'     =>  '10001|param missing times',
        'length.require'    =>  '10001|param missing length',
        't.require'         =>  '10001|param missing t',
        't.in'              =>  '13001',
        'min_ttl.require'   =>  '10001|param missing min_ttl',
        'max_ttl.require'   =>  '10001|param missing max_ttl'
       
    ];

    protected $scene = [
        'setBlock'   =>  ['oper','ipmac'],
        'get'        =>  ['t'=>'require|in:1,2'],
        'ping'       =>  ['ip','times','length'],
        'traceroute' =>  ['ip','min_ttl','max_ttl'],
        'pingremoteip'=>  ['ip']
    ];

    //验证 MAC地址
    protected function checkMacOrIp($value){
        return filter_var($value, FILTER_VALIDATE_MAC) || (Validate::is($value, "ip") && ($value != "0.0.0.0")) ? true : false ;
    }
}

