<?php

namespace app\index\validate;
use think\Validate;

class Sync extends Validate{

    protected $rule = [
        't'         =>  'require|checkConfType:1,2',
    ];

    protected $message  =   [
        't.require'         =>  '10001|param missing t',
        't.checkConfType'   =>  '13001'
    ];

    protected $scene = [
        'sync'           =>  ['t'],
    ];

    //验证多个类型|隔开
    protected function checkConfType($value, $rule){
        $valueArr = explode('|', $value);
        $ruleArr = explode(',', $rule);
        
        $resultArr = array_filter($valueArr, function ($item) use ($ruleArr) {
            return in_array($item, $ruleArr);
        });

        return count($resultArr) == count($valueArr);
    }

}

