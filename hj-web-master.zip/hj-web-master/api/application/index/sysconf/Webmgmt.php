<?php
namespace app\index\sysconf;
use app\index\model\UserPass;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;

/**
 * 网管策略 分层控制器
 */
class Webmgmt extends Controller {

    protected $V_sysconf; 
    protected $M_user_pass; 
    
    public function _initialize(){
        $this->V_sysconf = Loader::validate('Sysconf');
        $this->M_user_pass = new UserPass;
    }

    //【接口】获取
    public function get(){
        if(!$this->V_sysconf->scene('get_user_pass')->check(input()))
            Error($this->V_sysconf->getError());

        $page = empty(input('get.page')) ? 1 : input('get.page');
        $row = empty(input('get.row')) ? 10 : input('get.row');
        $by = empty(input('get.by')) ? 'id' : input('get.by');
        $order = empty(input('get.order')) ? 'desc' : input('get.order');
        $counts = NULL;$datas = [];

        $counts = $this->M_user_pass->countUserBan();
        $datas = $counts == 0 ? [] : $this->M_user_pass->selectUserBanPages($page, $row, $by, $order);
        
        return ["data" => $datas, "count" => $counts];
    }

    //【接口】添加
    public function add(){
        if(!$this->V_sysconf->scene('add_user_pass')->check(['add_u_p' => input("post.6")]))
            Error($this->V_sysconf->getError());

        $tmp_arr = explode("|",input("post.6"));
        

        $result = $this->M_user_pass->where(["ip_mac" => $tmp_arr[1]])->select(); // 验证记录是否存在相同配置
        if(count($result) > 0)
            Error("14002");

        $conf_map = [
            "name"      =>  $tmp_arr[0],
            "ip_mac"    =>  $tmp_arr[1],
            "note"      =>  $tmp_arr[2]
        ];
        $this->M_user_pass->data($conf_map);
        $result = $this->M_user_pass->save();
        if($result <= 0){
            Error("20001");
        }
    }

    //【接口】更新
    public function update(){
        if(!$this->V_sysconf->scene('update_user_pass')->check(['update_u_p' => input("post.6")]))
            Error($this->V_sysconf->getError());

        $tmp_arr = explode("|", input("post.6"));
        $conf_id = $tmp_arr[0];
        $conf_map = [
            "name"      =>  $tmp_arr[1],
            "ip_mac"    =>  $tmp_arr[2],
            "note"      =>  $tmp_arr[3]
        ];

        $result = $this->M_user_pass->get($conf_id); // 验证记录是否存在
        if(is_null($result))
            Error("14001");

        $result = $this->M_user_pass->selectSameRowNoThisId($conf_id, ["ip_mac" => $tmp_arr[2]]); // 验证记录是否重复
        if(!is_null($result))
            Error("14002");

        $result = $this->M_user_pass->save($conf_map, ['id' => $conf_id]);
        if($result < 0){
            Error("20001");
        }
    }

    //【接口】删除
    public function del(){
        if(!$this->V_sysconf->scene('del_user_pass')->check(['ids' => input("post.6")]))
            Error($this->V_sysconf->getError());

        $ids_arr = explode(",", input("post.6"));
        $result = $this->M_user_pass->destroy($ids_arr);
        if($result < 0){
            Error("20001");
        }
    }

}