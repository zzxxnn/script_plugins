<?php
namespace app\index\sysconf;
use app\index\model\LogServer;
use think\Controller;
use think\Request;
use think\Session;
use think\Loader;

/**
 * 日志服务器 分层控制器
 */
class Logservers extends Controller {

    protected $V_sysconf; 
    protected $M_log_server; 
    
    public function _initialize(){
        $this->V_sysconf = Loader::validate('Sysconf');
        $this->M_log_server = new LogServer;
    }

    //【接口】获取
    public function get(){
        if(!$this->V_sysconf->scene('get_log_server')->check(input()))
            Error($this->V_sysconf->getError());

        $page = empty(input('get.page')) ? 1 : input('get.page');
        $row = empty(input('get.row')) ? 3 : input('get.row');
        $counts = NULL;$datas = [];

        $counts = $this->M_log_server->countLogServer();
        $datas = $counts == 0 ? [] : $this->M_log_server->selectLogServerPages($page, $row);
        
        return ["data" => $datas, "count" => $counts];
    }

    //【接口】添加
    public function add(){
        if(!$this->V_sysconf->scene('add_log_server')->check(['add_l_s' => input("post.7")]))
            Error($this->V_sysconf->getError());

        $tmp_arr = explode("|",input("post.7"));
        $result = $this->M_log_server->where(["ip" => $tmp_arr[0], "port" => $tmp_arr[1]])->select(); // 验证记录是否存在相同配置
        if(count($result) > 0)
            Error("14002");

        $conf_map = [
            "ip"      =>  $tmp_arr[0],
            "port"    =>  $tmp_arr[1],
            "switch"  =>  $tmp_arr[2],
            "types"   =>  $tmp_arr[3]
        ];
        $this->M_log_server->data($conf_map);
        $result = $this->M_log_server->save();
        if($result <= 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】更新
    public function update(){
        if(!$this->V_sysconf->scene('update_log_server')->check(['update_l_s' => input("post.7")]))
            Error($this->V_sysconf->getError());

        $tmp_arr = explode("|", input("post.7"));
        $conf_id = $tmp_arr[0];
        if($conf_id == "1")
            Error("14003");

        $result = $this->M_log_server->get($conf_id); // 验证记录是否存在
        if(is_null($result))
            Error("14001");

        $result = $this->M_log_server->selectSameRowNoThisId($conf_id, ["ip" => $tmp_arr[1], "port" => $tmp_arr[2]]); // 验证记录是否重复
        if(!is_null($result))
            Error("14002");

        $conf_map = [
            "ip"      =>  $tmp_arr[1],
            "port"    =>  $tmp_arr[2],
            "switch"  =>  $tmp_arr[3],
            "types"   =>  $tmp_arr[4]
        ];
        $result = $this->M_log_server->save($conf_map, ['id' => $conf_id]);
        if($result < 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    //【接口】删除
    public function del(){
        if(!$this->V_sysconf->scene('del_log_server')->check(['ids' => input("post.7")]))
            Error($this->V_sysconf->getError());

        $ids_arr = explode(",", input("post.7"));
        if(in_array(1, $ids_arr))
            Error("14003");
        
        $result = $this->M_log_server->destroy($ids_arr);
        if($result < 0){
            Error("20001");
        }
        if($result > 0){
            $this->_toCli();
        }
    }

    // 构建cli命令
    private function _toCli(){
        ExcuteExec("fpcmd log_server -f"); // 清空之前所有配置

        $data = $this->M_log_server->selectAllLogServer();
        if(empty($data)){
            SyncTimestampUpdate(); // 更新配置同步时间戳            
            return ;
        }
        foreach($data as $tmp){
            ExcuteExec("fpcmd log_server -i -s ".$tmp['switch']." -h ".$tmp['ip']." -p ".$tmp['port']." -t ".$tmp['types']);
        }

        SyncTimestampUpdate(); // 更新配置同步时间戳
    }

}