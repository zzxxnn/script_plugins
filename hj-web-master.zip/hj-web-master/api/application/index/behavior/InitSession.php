<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/4/3
 * Time: 14:05
 */

namespace app\index\behavior;

use app\index\model\SysConfig;
use think\Cookie;
use think\Session;

/**
 * 初始化Session
 * Class InitSession
 * @package app\index\behavior
 */
class InitSession implements BehaviorInterface
{
    public function run()
    {
        if (IS_CLI) { // 命令行模式不启用Session
            return;
        }

        // 获取系统设置的Session 有效期
        $sysConf = SysConfig::where('conf_type', SysConfig::CONF_TYPE_WEB_UI)->find();

        if ($sysConf) {
            // 默认为两个小时
            $confVal = !empty($sysConf->conf_value) ? $sysConf->conf_value : 120;

            // 将前台设置的分钟数，转换为秒数
            $seconds = $confVal * 60;
            $sessionConfig = array_merge(
                config('session'),
                ['expire' => $seconds]
            );

            // 初始化 Session
            Session::init($sessionConfig);

            // 设置客户端Cookie 有效期
            Cookie::set(session_name(), session_id(), ['expire' => 0]);
        }
    }

}