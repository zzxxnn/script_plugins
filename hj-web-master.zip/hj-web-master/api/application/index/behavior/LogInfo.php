<?php
namespace app\index\behavior;
use think\Request;

class LogInfo {
    public function run() {
        $return_info = config('return_info');
        // 只对操作成功的操作日志进行记录
        $log_result = $return_info['errcode'];
        if ($log_result === 0) {
            $request_obj = Request::instance();

            $path = $request_obj->path();
            $path = explode('/', $path);
            
            $logs = [];

            $log_type_map = $this->log_type_map();

            if (in_array($path[0], array_keys($log_type_map['type'])) && in_array($path[1], array_keys($log_type_map['subtype']))) {
                // 客体IP地址
                $client_ip = $request_obj->server()['REMOTE_ADDR'];
                // 客体用户ID
                $uid = session('user_auth.u_id');
                // 日志内容
                $post_content = $request_obj->post();
                // 操作
                $log_subtype = intval($log_type_map['subtype'][$path[1]]);
                // 日志分类
                $type = $request_obj->get();
                $type = isset($type['t']) ? $type['t'] : '';
                if($type == "1|2|3|4|5|6|7|8"){
                    $logs[] = ['uid'=>$uid,'type'=>30,'subtype'=>$log_subtype,'clientip'=>$client_ip,'content'=>"",'time'=>date('Y-m-d H:i:s', time())];
                }elseif($type == "17|18|19|20|21|22"){
                    $logs[] = ['uid'=>$uid,'type'=>331,'subtype'=>$log_subtype,'clientip'=>$client_ip,'content'=>"",'time'=>date('Y-m-d H:i:s', time())];
                }else{
                    $type = explode('|', $type);
                    // 拼接日志记录
                    foreach ($type as $sub) {
                        $log_type = intval($log_type_map['type'][$path[0]].$sub);
                        $log_content = isset($post_content[$sub]) ? $post_content[$sub] : '';
                        $time = date('Y-m-d H:i:s', time());
                        $logs[] = ['uid'=>$uid,'type'=>$log_type,'subtype'=>$log_subtype,'clientip'=>$client_ip,'content'=>$log_content,'time'=>$time];
                    }
                }
                
            }

            // 日志入库
            if (!empty($logs)) {
                $redis = new \Redis();
                $redis->pconnect('127.0.0.1');
                foreach ($logs as $log) {
                    $redis->rPush('oper_log_list', json_encode($log));
                }
            }
        }
    }

    public function log_type_map() {
        return [
            'type' => [
                'safe' => 1,
                'sysconf' => 2,
                'netmgmt' => 3,
                'usermgmt' => 4,
                'license'  => 5
            ],
            'subtype' => [
                'add' => 1,
                'del' => 2,
                'update' => 3,
                'export' => 4,
                'upload' => 5,
                'command' => 6,
                'upgrade' => 7
            ],
        ];
    }
}