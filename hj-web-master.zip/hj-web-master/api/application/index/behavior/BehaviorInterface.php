<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/4/3
 * Time: 14:05
 */

namespace app\index\behavior;


interface BehaviorInterface
{
    public function run();
}