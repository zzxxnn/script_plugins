<?php

namespace app\index\model;
use think\Model;
use think\Db;

class MacAllow extends Model{

    protected $table = 'mac_allow';
    protected $pk = 'id';

    public function countMacAllow($mac, $desc){
        $where_map = [];
        if(!is_null($mac)){
            $where_map['a.mac'] = ['LIKE', '%'.$mac.'%'];
        }
        if(!is_null($desc)){
            $where_map['description'] = ['LIKE', '%'.$desc.'%'];
        }
        $count = db('mac_allow')->alias('a')->field("a.id,a.mac,i.description")
                ->join('mac_info i', 'a.mac=i.mac','LEFT')->where($where_map)->count();
        return $count;
    }

    public function selectMacAllowPages($page, $row, $by, $order, $mac, $desc){
        $where_map = [];
        if(!is_null($mac)){
            $where_map['a.mac'] = ['LIKE', '%'.$mac.'%'];
        }
        if(!is_null($desc)){
            $where_map['description'] = ['LIKE', '%'.$desc.'%'];
        }
        $data = db('mac_allow')->alias('a')->field("a.id,a.mac,i.description")
                ->join('mac_info i', 'a.mac=i.mac','LEFT')->where($where_map)->page($page, $row)
                ->order($by." ".$order)->select();
        return $data;
    }

    public function selectAllMacAllow(){
        $data = db('mac_allow')->select();
        return $data;
    }

    public function selectAllMacAllowWithNote(){
        $data = db('mac_allow')->alias('a')->field("a.id,a.mac,i.description")
                ->join('mac_info i', 'a.mac=i.mac','LEFT')->select();
        return $data;
    }

    public function deleteAll(){
        $data = db('mac_allow')->delete(true);
        return $data;
    }
}