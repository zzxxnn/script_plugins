<?php

namespace app\index\model;
use think\Model;
use think\Db;

class NetVnet extends Model{

    protected $table = 'net_vnet';
    protected $pk = 'id';

    public function selectVnetPages($exclude, $page, $row, $by, $order){
        $data = db('net_vnet')->where("exclude", $exclude)->page($page, $row)->order($by." ".$order)->select();
        return $data;
    }

    public function countVnet($exclude){
        $count = db('net_vnet')->where("exclude", $exclude)->count();
        return $count;
    }

    public function selectSameRow($conf_map){
        $result = db('net_vnet')->where($conf_map)->find();
        return $result;
    }

    public function insertRip($conf_map){
        $result = db('net_vnet')->insert($conf_map);
        return $result;
    }

    public function selectSameRowNoThisId($id, $conf_map){
        $result = db('net_vnet')->where('id', '<>', $id)->where($conf_map)->find();
        return $result;
    }

    public function updateById($id, $conf_map){
        $result = db('net_vnet')->where('id', $id)->update($conf_map);
        return $result;
    }

    public function selectAllVnet(){
        $data = db('net_vnet')->field("exclude,ip,mask,vlan_id,group_id")->select();
        return $data;
    }

    public function deleteByIds($id_arr){
        $result = db('net_vnet')->delete($id_arr);
        return $result;
    }

}