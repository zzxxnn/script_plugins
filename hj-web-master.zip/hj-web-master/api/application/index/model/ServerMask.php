<?php

namespace app\index\model;
use think\Model;
use think\Db;

class ServerMask extends Model{

    protected $table = 'server_mask';
    protected $pk = 'id';

    public function countServerMask(){
        $count = db('server_mask')->count();
        return $count;
    }

    public function selectServerMaskPages($page, $row, $by, $order){
        $data = db('server_mask')->page($page, $row)->order($by." ".$order)->select();
        return $data;
    }

    public function selectSameRowNoThisId($id, $conf_map){
        $result = db('server_mask')->where('id', '<>', $id)->where($conf_map)->find();
        return $result;
    }

    public function selectAllServerMask(){
        $data = db('server_mask')->select();
        return $data;
    }

    public function deleteAll(){
        $data = db('server_mask')->delete(true);
        return $data;
    }
}