<?php

namespace app\index\model;
use think\Model;
use think\Db;

class ServerTrap extends Model{

    protected $table = 'server_trap';
    protected $pk = 'id';

    public function countServerTrap(){
        $count = db('server_trap')->count();
        return $count;
    }

    public function selectServerTrapPages($page, $row, $by, $order){
        $data = db('server_trap')->page($page, $row)->order($by." ".$order)->select();
        return $data;
    }

    public function selectSameRowNoThisId($id, $conf_map){
        $result = db('server_trap')->where('id', '<>', $id)->where($conf_map)->find();
        return $result;
    }

    public function selectRowByIpMac($ip_mac){
        $data = db('server_trap')->where('t_ip_mac', 'IN', $ip_mac)->select();
        return $data;
    }

    public function selectAllServerTrap(){
        $data = db('server_trap')->select();
        return $data;
    }

    public function deleteAll(){
        $data = db('server_trap')->delete(true);
        return $data;
    }
}