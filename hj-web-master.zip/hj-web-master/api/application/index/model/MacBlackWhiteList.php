<?php

namespace app\index\model;
use think\Model;
use think\Db;

class MacBlackWhiteList extends Model{

    protected $table = 'mac_black_white_list';
    protected $pk = 'id';

    public function countMacBwlist($ip_mac, $start_time, $end_time, $mark){
        $where_map = ['type'=>$mark];

        if(!is_null($ip_mac)){
            $where_map['l.mac'] = ['LIKE', '%'.$ip_mac.'%'];
        }
        if(!is_null($start_time) && !is_null($end_time)){
            $where_map['l.timestamp'] = ['between time', $start_time.",".$end_time];
        }elseif(!is_null($start_time)){
            $where_map['l.timestamp'] = ['>=', $start_time];
        }elseif(!is_null($end_time)){
            $where_map['l.timestamp'] = ['<=', $end_time];
        }
        $count = db('mac_black_white_list')->alias('l')->field("l.id,l.mac,l.note,l.timestamp,i.description")
                 ->join('mac_info i', 'l.mac=i.mac','LEFT')->where($where_map)->count();
        return $count;
    }

    public function selectMacBwlist($ip_mac, $start_time, $end_time, $mark, $page, $row, $by, $order){
        $where_map = ['type'=>$mark];

        if(!is_null($ip_mac)){
            $where_map['l.mac'] = ['LIKE', '%'.$ip_mac.'%'];
        }
        if(!is_null($start_time) && !is_null($end_time)){
            $where_map['l.timestamp'] = ['between time', $start_time.",".$end_time];
        }elseif(!is_null($start_time)){
            $where_map['l.timestamp'] = ['>=', $start_time];
        }elseif(!is_null($end_time)){
            $where_map['l.timestamp'] = ['<=', $end_time];
        }
        $data = db('mac_black_white_list')->alias('l')->field("l.id,l.mac,l.note,l.timestamp,i.description")
                ->join('mac_info i', 'l.mac=i.mac','LEFT')->where($where_map)->page($page, $row)
                ->order($by." ".$order)->select();
        return $data;
    }

    public function selectAllMacBwlist(){
        $data = db('mac_black_white_list')->select();
        return $data;
    }
}