<?php

namespace app\index\model;
use think\Model;
use think\Db;

class UserLoginStatus extends Model{

    protected $table = 'user_login_status';
    protected $pk = 'id';

    public function selectStatusByUsernameIp($username, $ip){
        $where_map = [
            "user_id"   => $username,
            "client_ip" => $ip
        ];
        $data = db("user_login_status")->where($where_map)->select();
        return $data;
    }

    public function insertLoginStatus($username, $ip, $loginTime = null){
        $insert_map = [
            "user_id"     => $username,
            "client_ip"   => $ip,
            "error_count" => 0
        ];
        $loginTime && $insert_map['last_login_time'] = $loginTime;
        $result = db("user_login_status")->insert($insert_map);
        return $result;
    }

    public function updateLastLoginTime($username, $ip, $timestamp){
        $where_map = [
            "user_id"   => $username,
            "client_ip" => $ip
        ];
        $update_map = ["last_login_time" => $timestamp];
        $result = db("user_login_status")->where($where_map)->update($update_map);
        return $result;
    }

    public function updateErrorCounts($username, $ip, $counts){
        $where_map = [
            "user_id"   => $username,
            "client_ip" => $ip
        ];
        $update_map = ["error_count" => $counts];
        $result = db("user_login_status")->where($where_map)->update($update_map);
        return $result;
    }

    /**
     * 更新用户登录状态
     *
     * @param $username
     * @param $ip
     * @param $loginTime
     * @return bool
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function setLoginStatus($username, $ip, $loginTime)
    {
        $condition = [
            "user_id"   => $username,
            "client_ip" => $ip
        ];
        $status = (new UserLoginStatus())->where($condition)->find();
        if (!$status) { // 没有记录时，进行写入
            $result = $this->insertLoginStatus($username, $ip, $loginTime);
            return (bool) $result > 0;
        } else {
            $result = $this->updateLastLoginTime($username, $ip, $loginTime);
            return (bool) $result >= 0;
        }
    }

}