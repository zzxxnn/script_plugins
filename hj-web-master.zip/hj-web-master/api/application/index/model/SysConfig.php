<?php

namespace app\index\model;
use think\Model;
use think\Db;

class SysConfig extends Model{

    protected $table = 'sys_config';
    protected $pk = 'id';

    //------------------------- Conf Type -------------------------------

    const CONF_TYPE_WEB_UI = 'web_ui';
    const CONF_NETWORK_MODE = 'net_work_mode';  // 工作模式
    const CONF_SNTP_CONF = 'sntp_conf'; // SNTP配置

    //------------------------- Conf Type -------------------------------

    public function selectValueByConfType($conf_type){
        $data = db('sys_config')->where(["conf_type" => $conf_type])->select();
        return $data;
    }

    public function updateValueByConfType($conf_type, $conf_value){
        $result = db('sys_config')->where(["conf_type" => $conf_type])->update(['conf_value' => $conf_value]);
        return $result;
    }

}