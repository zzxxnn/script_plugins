<?php

namespace app\index\model;
use think\Model;
use think\Db;

class LogServer extends Model{

    protected $table = 'log_server';
    protected $pk = 'id';

    public function countLogServer(){
        $count = db('log_server')->count();
        return $count;
    }

    public function selectLogServerPages($page, $row){
        $data = db('log_server')->page($page, $row)->select();
        return $data;
    }

    public function selectSameRowNoThisId($id, $conf_map){
        $result = db('log_server')->where('id', '<>', $id)->where($conf_map)->find();
        return $result;
    }

    public function selectAllLogServer(){
        $data = db('log_server')->select();
        return $data;
    }
}