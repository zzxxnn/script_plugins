<?php

namespace app\index\model;
use think\Model;
use think\Db;

class MacInfo extends Model{

    protected $table = 'mac_info';
    protected $pk = 'id';

    public function countMacInfo($gid, $mac, $desc){
        $where_map = [];
        if(!is_null($gid)){
            $where_map['gid'] = ['=', $gid];
        }
        if(!is_null($mac)){
            $where_map['mac'] = ['LIKE', '%'.$mac.'%'];
        }
        if(!is_null($desc)){
            $where_map['description'] = ['LIKE', '%'.$desc.'%'];
        }
        $count = db('mac_info')->where($where_map)->count();
        return $count;
    }

    public function selectMacInfoPages($page, $row, $by, $order, $gid, $mac, $desc){
        $where_map = [];
        if(!is_null($gid)){
            $where_map['gid'] = ['=', $gid];
        }
        if(!is_null($mac)){
            $where_map['mac'] = ['LIKE', '%'.$mac.'%'];
        }
        if(!is_null($desc)){
            $where_map['description'] = ['LIKE', '%'.$desc.'%'];
        }
        $data = db('mac_info')->where($where_map)->page($page, $row)->order($by." ".$order)->select();
        return $data;
    }

    public function selectSameRowNoThisId($id, $conf_map){
        $result = db('mac_info')->where('id', '<>', $id)->where($conf_map)->find();
        return $result;
    }

    public function selectAllMacInfo(){
        $data = db('mac_info')->select();
        return $data;
    }

    public function deleteAllMacInfo(){
        $result = db('mac_info')->delete(true);
        return $result;
    }
}