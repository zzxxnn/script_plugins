<?php

namespace app\index\model;
use think\Model;
use think\Db;

class UserPass extends Model{

    protected $table = 'user_pass';
    protected $pk = 'id';

    public function countUserBan(){
        $count = db('user_pass')->count();
        return $count;
    }

    public function selectUserBanPages($page, $row, $by, $order){
        $data = db('user_pass')->page($page, $row)->order($by." ".$order)->select();
        return $data;
    }

    public function selectSameRowNoThisId($id, $conf_map){
        $result = db('user_pass')->where('id', '<>', $id)->where($conf_map)->find();
        return $result;
    }
}