<?php

namespace app\index\model;
use think\Model;
use think\Db;

class NetVip extends Model{

    protected $table = 'net_vip';
    protected $pk = 'id';

    public function selectVipPages($exclude, $page, $row, $by, $order){
        $data = db('net_vip')->where("exclude", $exclude)->page($page, $row)->order($by." ".$order)->select();
        return $data;
    }

    public function countVip($exclude){
        $count = db('net_vip')->where("exclude", $exclude)->count();
        return $count;
    }

    public function selectSameRow($conf_map){
        $result = db('net_vip')->where($conf_map)->find();
        return $result;
    }

    public function insertRip($conf_map){
        $result = db('net_vip')->insert($conf_map);
        return $result;
    }

    public function selectSameRowNoThisId($id, $conf_map){
        $result = db('net_vip')->where('id', '<>', $id)->where($conf_map)->find();
        return $result;
    }

    public function updateById($id, $conf_map){
        $result = db('net_vip')->where('id', $id)->update($conf_map);
        return $result;
    }

    public function selectAllVip(){
        $data = db('net_vip')->field("exclude,ip,mask,vlan_id,group_id")->select();
        return $data;
    }

    public function deleteByIds($id_arr){
        $result = db('net_vip')->delete($id_arr);
        return $result;
    }
}