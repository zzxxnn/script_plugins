<?php

namespace app\index\model;
use think\Model;
use think\Db;

class NetBindIp extends Model{

    protected $table = 'net_bind_ip';
    protected $pk = 'id';

    public function selectBindIpPages($page, $row, $by, $order){
        $data = db('net_bind_ip')->alias('b')->field("b.id,b.ip,b.mac,i.description")
        ->join('mac_info i', 'b.mac=i.mac','LEFT')->page($page, $row)->order($by." ".$order)->select();
        return $data;
    }

    public function countBindIp(){
        $count = db('net_bind_ip')->count();
        return $count;
    }

    public function selectSameRow($conf_map){
        $result = db('net_bind_ip')->where("mac", $conf_map['mac'])->whereor("ip", $conf_map['ip'])->find();
        return $result;
    }

    public function insertRip($conf_map){
        $result = db('net_bind_ip')->insert($conf_map);
        return $result;
    }

    public function selectSameRowNoThisId($id, $conf_map){
        $result = db('net_bind_ip')->where('id', '<>', $id)->where($conf_map)->find();
        return $result;
    }

    public function updateById($id, $conf_map){
        $result = db('net_bind_ip')->where('id', $id)->update($conf_map);
        return $result;
    }

    public function selectAllBindIp(){
        $data = db('net_bind_ip')->field("ip,mac")->select();
        return $data;
    }

    public function deleteByIds($id_arr){
        $result = db('net_bind_ip')->delete($id_arr);
        return $result;
    }

    public function deleteAll(){
        $data = db('net_bind_ip')->delete(true);
        return $data;
    }
}