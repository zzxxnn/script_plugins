<?php

namespace app\index\model;
use think\Model;
use think\Db;

class InnerfirewallPol extends Model{

    protected $table = 'inner_firewall_pol';
    protected $pk = 'id';

    public function countFwPols(){
        $count = db('inner_firewall_pol')->count();
        return $count;
    }

    public function selectFwPolsPages($page, $row, $by, $order){
        $data = db('inner_firewall_pol')->page($page, $row)->order($by." ".$order)->select();
        return $data;
    }

    public function selectSameRowNoThisId($id, $conf_map){
        $result = db('inner_firewall_pol')->where('id', '<>', $id)->where($conf_map)->find();
        return $result;
    }

    public function selectAllFwPol(){
        $data = db('inner_firewall_pol')->select();
        return $data;
    }

    public function deleteAll(){
        $data = db('inner_firewall_pol')->delete(true);
        return $data;
    }
}