<?php

namespace app\index\model;
use think\Model;
use think\Db;

class NetWip extends Model{

    protected $table = 'net_wip';
    protected $pk = 'id';

    public function selectWipPages($exclude, $page, $row, $by, $order){
        $data = db('net_wip')->where("exclude", $exclude)->page($page, $row)->order($by." ".$order)->select();
        return $data;
    }

    public function countWip($exclude){
        $count = db('net_wip')->where("exclude", $exclude)->count();
        return $count;
    }

    public function selectSameRow($conf_map){
        $result = db('net_wip')->where($conf_map)->find();
        return $result;
    }

    public function insertRip($conf_map){
        $result = db('net_wip')->insert($conf_map);
        return $result;
    }

    public function selectSameRowNoThisId($id, $conf_map){
        $result = db('net_wip')->where('id', '<>', $id)->where($conf_map)->find();
        return $result;
    }

    public function updateById($id, $conf_map){
        $result = db('net_wip')->where('id', $id)->update($conf_map);
        return $result;
    }

    public function selectAllWip(){
        $data = db('net_wip')->field("exclude,ip,mask,gateway,vlan_id,group_id")->select();
        return $data;
    }

    public function deleteByIds($id_arr){
        $result = db('net_wip')->delete($id_arr);
        return $result;
    }
}