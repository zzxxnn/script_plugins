<?php

namespace app\index\model;
use think\Model;
use think\Db;

class ServerTrapWhiteList extends Model{

    protected $table = 'server_trap_white_list';
    protected $pk = 'id';

    public function countServerTrapWlist(){
        $count = db('server_trap_white_list')->count();
        return $count;
    }

    public function selectServerTrapWlistPages($page, $row, $by, $order){
        $data = db('server_trap_white_list')->page($page, $row)->order($by." ".$order)->select();
        return $data;
    }

    public function selectSameRowNoThisId($id, $conf_map){
        $result = db('server_trap_white_list')->where('id', '<>', $id)->where($conf_map)->find();
        return $result;
    }

    public function selectAllServerTrapWlist(){
        $data = db('server_trap_white_list')->select();
        return $data;
    }

    public function deleteAll(){
        $data = db('server_trap_white_list')->delete(true);
        return $data;
    }
}