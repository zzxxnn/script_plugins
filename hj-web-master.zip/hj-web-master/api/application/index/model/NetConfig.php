<?php

namespace app\index\model;
use think\Model;
use think\Db;

class NetConfig extends Model{

    protected $table = 'net_config';
    protected $pk = 'id';

    public function selectValueByConfType($conf_type){
        $data = db('net_config')->where(["conf_type" => $conf_type])->select();
        return $data;
    }

    public function updateValueByConfType($conf_type, $conf_value){
        $result = db('net_config')->where(["conf_type" => $conf_type])->update(["conf_value" => $conf_value]);
        return $result;
    }

    public function selectAllConfValue(){
        $data = db('net_config')->field('conf_type, conf_value')->select();
        return $data;
    }

}