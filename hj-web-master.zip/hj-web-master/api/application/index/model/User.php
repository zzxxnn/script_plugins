<?php

namespace app\index\model;
use think\Model;
use think\Db;

class User extends Model{

    protected $table = 'user';
    protected $pk = 'u_id';

    // 根据用户名获取用户id
    public function selectUidByUsername($username){
        $data = db('user')->field("u_id")->where(["user_id" => $username])->select();
        return $data;
    }

    // 根据用户名获取用户信息
    public function selectUserByUid($id){
        $data = db('user')->where(["u_id" => $id])->select();
        return $data;
    }

    // 根据用户名获取密码
    public function selectPwdByUid($id){
        $data = db('user')->field("password")->where(["u_id" => $id])->select();
        return $data;
    }

    // 获取所有用户
    public function selectAllUsers(){
        $data = db('user')->field("u_id,user_id,user_group,real_name,department,email")->select();
        return $data;
    }

    // 验证用户名是否重复
    public function selectSameRowNoThisId($id, $conf_map){
        $result = db('user')->where('u_id', '<>', $id)->where($conf_map)->find();
        return $result;
    }

    // 根据用户id更新用户信息
    public function updateById($id, $conf_map){
        $result = db('user')->where('u_id', $id)->update($conf_map);
        return $result;
    }

    //查询用户token
    public function selectAccessTokenByUname($username){
        $result = db('user')->field('token')->where('user_id', $username)->select();
        return $result;
    }

    // 更新用户access_token
    public function updateAccessTokenByUname($username, $token){
        $result = db('user')->where('user_id', $username)->update(['token' => $token]);
        return $result;
    }

}