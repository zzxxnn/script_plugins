<?php

namespace app\index\model;
use think\Model;
use think\Db;

class NetBindRouter extends Model{

    protected $table = 'net_bind_router';
    protected $pk = 'id';

    public function selectBindRouterPages($page, $row, $by, $order){
        $data = db('net_bind_router')->page($page, $row)->order($by." ".$order)->select();
        return $data;
    }

    public function countBindRouter(){
        $count = db('net_bind_router')->count();
        return $count;
    }
    
    public function selectSameRow($conf_map){
        $result = db('net_bind_router')->where($conf_map)->find();
        return $result;
    }

    public function insertRip($conf_map){
        $result = db('net_bind_router')->insert($conf_map);
        return $result;
    }

    public function selectSameRowNoThisId($id, $conf_map){
        $result = db('net_bind_router')->where('id', '<>', $id)->where($conf_map)->find();
        return $result;
    }

    public function updateById($id, $conf_map){
        $result = db('net_bind_router')->where('id', $id)->update($conf_map);
        return $result;
    }

    public function selectAllBindRouter(){
        $data = db('net_bind_router')->field("ip,gateway")->select();
        return $data;
    }

    public function deleteByIds($id_arr){
        $result = db('net_bind_router')->delete($id_arr);
        return $result;
    }

    public function deleteAll(){
        $data = db('net_bind_router')->delete(true);
        return $data;
    }

}