<?php

namespace app\index\model;
use think\Model;
use think\Db;

class NetRip extends Model{

    protected $table = 'net_rip';
    protected $pk = 'id';

    public function selectRipPages($exclude, $page, $row, $by, $order){
        $data = db('net_rip')->where("exclude", $exclude)->page($page, $row)->order($by." ".$order)->select();
        return $data;
    }

    public function countRip($exclude){
        $count = db('net_rip')->where("exclude", $exclude)->count();
        return $count;
    }

    public function selectSameRow($conf_map){
        $result = db('net_rip')->where($conf_map)->find();
        return $result;
    }

    public function insertRip($conf_map){
        $result = db('net_rip')->insert($conf_map);
        return $result;
    }
    
    public function selectSameRowNoThisId($id, $conf_map){
        $result = db('net_rip')->where('id', '<>', $id)->where($conf_map)->find();
        return $result;
    }

    public function updateById($id, $conf_map){
        $result = db('net_rip')->where('id', $id)->update($conf_map);
        return $result;
    }

    public function selectAllRip(){
        $data = db('net_rip')->field("exclude,ip,mask,vlan_id,group_id")->select();
        return $data;
    }

    public function deleteByIds($id_arr){
        $result = db('net_rip')->delete($id_arr);
        return $result;
    }
}