<?php

namespace app\index\model;
use think\Model;
use think\Db;

class AccessSt extends Model{

    protected $table = 'access_st';
    protected $pk = 'id';

    public function countAccessSt(){
        $count = db('access_st')->count();
        return $count;
    }

    public function selectAccessStPages($page, $row, $by, $order){
        $data = db('access_st')->page($page, $row)->order($by." ".$order)->select();
        return $data;
    }

    public function selectSameRowNoThisId($id, $conf_map){
        $result = db('access_st')->where('id', '<>', $id)->where($conf_map)->find();
        return $result;
    }

    public function selectAllAccessSt(){
        $data = db('access_st')->select();
        return $data;
    }

    public function deleteAll(){
        $data = db('access_st')->delete(true);
        return $data;
    }

    public function insertAllConf($conf){
        $result = db('access_st')->insertAll($conf);
        return $result;
    }
}