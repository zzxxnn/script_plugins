<?php

namespace app\index\model;
use think\Model;
use think\Db;

class HoneyPot extends Model{

    protected $table = 'honey_pot';
    protected $pk = 'id';

    public function countHoneyPot(){
        $count = db('honey_pot')->count();
        return $count;
    }

    public function selectHoneyPotPages($page, $row, $by, $order){
        $data = db('honey_pot')->page($page, $row)->order($by." ".$order)->select();
        return $data;
    }

    public function selectSameRowNoThisId($id, $conf_map){
        $result = db('honey_pot')->where('id', '<>', $id)->where($conf_map)->find();
        return $result;
    }

    public function selectAllHoneyPot(){
        $data = db('honey_pot')->select();
        return $data;
    }

    public function deleteAll(){
        $data = db('honey_pot')->delete(true);
        return $data;
    }
}