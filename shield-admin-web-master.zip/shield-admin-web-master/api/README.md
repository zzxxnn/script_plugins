### 幻盾
---

1. api目录下的模块分配:

    - admin  B端管理中心
    - client C端管理中心
    - agent  代理商管理中心

2. api/common为公共文件夹

    - model 公共模型
    - controller 控制器
    - exception 异常
    - behavior 行为
    - repository 仓库
    - service 服务
    - traits 类
    - validate 验证
    - view 邮件模板
    
3. view目录为前端单页面应用

    - agent 代理管理中心
    - index 管理端管理中心
    - client 客户端管理中
    
4. 登录账户

    - B端 管理端
    
    ```
        admin
        veda2017
    ```
    
    - C端 用户端
    
    ```
        用户名: client
        邮箱: client@veda.com
        密码: veda2017

        用户名: test
        邮箱: test@veda.com
        密码: veda2017

    ```
    
    - A端 代理商端
    
    ```
        用户名:agent
        邮箱：agent@veda.com
        手机:17089497810
        密码：veda2017
    ```
    
5. application目录
    
    - command.php 命令
    - common.php 公共函数
    - config.php 配置
    - constant.php 常量
    - database.php 数据库配置
    - route.php 路由
    - tags 标签