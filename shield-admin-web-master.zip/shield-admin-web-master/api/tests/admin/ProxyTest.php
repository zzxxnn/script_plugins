<?php

namespace tests\admin;

use app\common\model\SiteModel;

class ProxyTest extends AdminBase
{  
    /**
     * 测试 添加高防节点失败：参数错误
     */
    public function testAddProxyNodeParamsFailure()
    {
        $data = [
            'line_type' => 3,
            'node_ip' => [
                ['ip' => '0.0.0.10', 'line' => 1],
                ['ip' => '0.0.0.11', 'line' => 2]
            ],
            'areas' => 37,
            'node_type' => 1,
            'site_limit_count' => 10,
            'bandwidth' => '30M'
        ];
        
        parent::sendRequest('post', '/v1/antinodes', $data)->seeErrCode(REP_CODE_PARAMS_INVALID);
    }

    /**
     * 测试 添加高防节点失败：高防节点配置错误
     */
    public function testAddProxyNodeConfigFailure()
    {
        $data = [
            'line_type' => 3,
            'node_ip' => [
                ['ip' => '0.0.0.10', 'line' => 1]
            ],
            'area' => 37,
            'node_type' => 1,
            'site_limit' => 10,
            'bandwidth' => '30M'
        ];
        
        parent::sendRequest('post', '/v1/antinodes', $data)->seeErrCode(REP_CODE_PROXY_NODE_CONFIG_ERROR);
    }

    /**
     * 测试 添加高防节点失败：网站上限数错误
     */
    public function testAddProxyNodeSiteLimitFailure()
    {
        $data = [
            'line_type' => 3,
            'node_ip' => [
                ['ip' => '0.0.0.10', 'line' => 1],
                ['ip' => '0.0.0.11', 'line' => 2]
            ],
            'area' => 37,
            'node_type' => 1,
            'site_limit' => 1,
            'bandwidth' => '30M'
        ];
        
        parent::sendRequest('post', '/v1/antinodes', $data)->seeErrCode(REP_CODE_PROXY_NODE_SITE_LIMIT_ERROR);
    }

    /**
     * 测试 添加 网站类-共享 高防节点成功
     */
    public function testAddSiteShareProxyNodeSuccess()
    {
        $data = [
            'line_type' => 3,
            'node_ip' => [
                ['ip' => '0.0.0.10', 'line' => 1],
                ['ip' => '0.0.0.11', 'line' => 2]
            ],
            'area' => 37,
            'node_type' => 1,
            'site_limit' => 10,
            'bandwidth' => '30M'
        ];
        
        $response = parent::sendRequest('post', '/v1/antinodes', $data)->seeErrCode(0);

        $proxy_node = json_decode($response->getContent(), true)['data'];

        sleep(2);

        return $proxy_node;
    }

    /**
     * 测试 添加 网站类-独享 高防节点成功
     */
    public function testAddSiteSingleProxyNodeSuccess()
    {
        $data = [
            'line_type' => 1,
            'node_ip' => [
                ['ip' => '0.0.0.12', 'line' => 1],
            ],
            'area' => 11,
            'node_type' => 2,
            'site_limit' => 1,
            'bandwidth' => '100M'
        ];
        
        $response = parent::sendRequest('post', '/v1/antinodes', $data)->seeErrCode(0);

        $site_single_proxy_node = json_decode($response->getContent(), true)['data'];

        return $site_single_proxy_node;
    }

    /**
     * 测试 添加 应用类 高防节点成功
     */
    public function testAddAppProxyNodeSuccess()
    {
        $data = [
            'line_type' => 4,
            'node_ip' => [
                ['ip' => '0.0.0.13', 'line' => 4],
            ],
            'area' => 31,
            'node_type' => 3,
            'site_limit' => 1,
            'bandwidth' => '100M'
        ];
        
        $response = parent::sendRequest('post', '/v1/antinodes', $data)->seeErrCode(0);

        $app_proxy_node = json_decode($response->getContent(), true)['data'];

        return $app_proxy_node;
    }

    /**
     * 测试 添加高防节点失败：添加重复
     */
    public function testAddProxyNodeRepeatFailure()
    {
        $data = [
            'line_type' => 3,
            'node_ip' => [
                ['ip' => '0.0.0.10', 'line' => 1],
                ['ip' => '0.0.0.11', 'line' => 2]
            ],
            'area' => 37,
            'node_type' => 1,
            'site_limit' => 10,
            'bandwidth' => '30M'
        ];
        
        parent::sendRequest('post', '/v1/antinodes', $data)->seeErrCode(REP_CODE_PROXY_NODE_REPEAT_ERROR);
    }

    /**
     * 测试 查询高防节点：根据地区查询
     */
    public function testSearchProxyByArea()
    {
        $data = [
            '_from' => 1, '_size' => 10, 'area' => 3
        ];

        $response = parent::sendRequest('get', '/v1/antinodes', $data)->seeErrCode(0);

        $this->seeProxyList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 查询高防节点：根据地区省份查询
     */
    public function testSearchByPrvc()
    {
        $data = [
            '_from' => 1, '_size' => 10, 'area' => 3, 'prvc' => 37
        ];
    
        $response = parent::sendRequest('get', '/v1/antinodes', $data)->seeErrCode(0);
    
        $this->seeProxyList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 查询高防节点：根据节点类型查询
     */
    public function testSearchByNodeType()
    {
        $data = [
            '_from' => 1, '_size' => 10, 'node_type' => 1
        ];
    
        $response = parent::sendRequest('get', '/v1/antinodes', $data)->seeErrCode(0);
    
        $this->seeProxyList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 查询高防节点：根据线路类型查询
     */
    public function testSearchByLineType()
    {
        $data = [
            '_from' => 1, '_size' => 10, 'line_type' => 3
        ];
    
        $response = parent::sendRequest('get', '/v1/antinodes', $data)->seeErrCode(0);
    
        $this->seeProxyList(json_decode($response->getContent(), true));
    }

    /**
     * @depends testAddSiteShareProxyNodeSuccess
     * 
     * 测试 查询高防节点：根据节点ID查询
     */
    public function testSearchByProxyNodeId($proxy_node)
    {
        $data = [
            '_from' => 1, '_size' => 10, 'node_id' => $proxy_node['node_id']
        ];
    
        $response = parent::sendRequest('get', '/v1/antinodes', $data)->seeErrCode(0);
    
        $this->seeProxyList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 查询高防节点：根据节点线路IP查询
     */
    public function testSearchByLineIp()
    {
        $data = [
            '_from' => 1, '_size' => 10, 'ip' => '0.0.0.10'
        ];
    
        $response = parent::sendRequest('get', '/v1/antinodes', $data)->seeErrCode(0);
    
        $this->seeProxyList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 查询高防节点：根据用户查询
     */
    public function testSearchByUsername()
    {
        $data = [
            '_from' => 1, '_size' => 10, 'username' => 'test@veda.com'
        ];
    
        $response = parent::sendRequest('get', '/v1/antinodes', $data)->seeErrCode(0);
    
        $this->seeProxyList(json_decode($response->getContent(), true));
    }

    /**
     * @depends testAddSiteShareProxyNodeSuccess
     *
     * 测试 获取高防节点网站或应用详情
     */
    public function testGetUserAppConfigSuccess($proxy_node)
    {
        $data = [
            'page' => 1, 'row' => 10
        ];

        $response = parent::sendRequest('get', '/v1/antinodes/'. $proxy_node['node_id'] .'/apps', $data)->seeErrCode(0);
        $response = json_decode($response->getContent(), true);

        $this->assertArrayHasKey('errcode', $response, '结果中应包含"errcode"字段！');
        $this->assertArrayHasKey('errmsg', $response, '结果中应包含"errmsg"字段！');
        $this->assertArrayHasKey('list', $response, '结果中应包含"list"字段！');
    }

    /**
     * @depends testAddSiteShareProxyNodeSuccess
     *
     * 测试 修改共享类高防节点的网站上限失败：高防节点不存在
     */
    public function testUpdateShareProxyNodeSitelimitFailure($proxy_node)
    {
        $id = 'missing';
        $data = [
            'site_limit' => $proxy_node['site_limit'] + 1
        ];

        parent::sendRequest('put', '/v1/antinodes/'. $id .'/sitelimit', $data)->seeErrCode(REP_CODE_SOURCE_NOT_FOUND);
    }

    /**
     * @depends testAddSiteShareProxyNodeSuccess
     *
     * 测试 修改共享类高防节点的网站上限失败：不得小于当前上限
     */
    public function testUpdateProxyNodeSitelimitFailure($proxy_node)
    {
        $data = [
            'site_limit' => $proxy_node['site_limit'] - 1
        ];

        parent::sendRequest('put', '/v1/antinodes/'. $proxy_node['node_id'] .'/sitelimit', $data)->seeErrCode(REP_CODE_PROXY_NODE_SITE_LIMIT_ERROR);
    }

    /**
     * @depends testAddSiteShareProxyNodeSuccess
     *
     * 测试 修改共享类高防节点的网站上限成功
     */
    public function testUpdateShareProxyNodeSitelimitSuccess($proxy_node)
    {
        $data = [
            'site_limit' => $proxy_node['site_limit'] + 1
        ];

        parent::sendRequest('put', '/v1/antinodes/'. $proxy_node['node_id'] .'/sitelimit', $data)->seeErrCode(0);
    }

    /**
     * @depends testAddSiteShareProxyNodeSuccess
     *
     * 测试 删除高防节点
     */
    public function testDeleteProxyNodeSuccess($proxy_node)
    {
        $data = [
            'ids' => [$proxy_node['node_id']]
        ];
        parent::sendRequest('delete', '/v1/antinodes/delete', $data)->seeErrCode(0);
    }

    /**
     * @depends testAddSiteSingleProxyNodeSuccess
     *
     * 测试 删除网站独享类高防节点
     */
    public function testDeleteSiteSingleProxyNodeSuccess($site_single_proxy_node)
    {
        $data = [
            'ids' => [$site_single_proxy_node['node_id']]
        ];
        parent::sendRequest('delete', '/v1/antinodes/delete', $data)->seeErrCode(0);
    }

    /**
     * @depends testAddAppProxyNodeSuccess
     *
     * 测试 删除网站独享类高防节点
     */
    public function testDeleteAppProxyNodeSuccess($app_proxy_node)
    {
        $data = [
            'ids' => [$app_proxy_node['node_id']]
        ];
        parent::sendRequest('delete', '/v1/antinodes/delete', $data)->seeErrCode(0);
    }

    /**
     * 检查高防节点列表字段信息
     *
     * @param array $array
     * @return void
     */
    private function seeProxyList($array)
    {
        $this->assertArrayHasKey('errcode', $array, '结果中应包含"errcode"字段！');
        $this->assertArrayHasKey('errmsg', $array, '结果中应包含"errmsg"字段！');
        $this->assertArrayHasKey('list', $array, '结果中应包含"list"字段！');
        $this->assertArrayHasKey('total', $array, '结果中应包含"total"字段！');

        if ($array['list']) {
            foreach ($array['list'] as $each) {
                if ($each['node_type'] === SiteModel::USER_APP_TYPE_SHARED || $each['node_type'] === SiteModel::USER_APP_TYPE_SINGLE) {
                    $fields = ['id','line_type','area','bandwidth','last_update','line_type','node_id','node_ip','node_type',
                    'site_limit','total_site_count','user_count','user_detail'];
                } elseif ($each['node_type'] === SiteModel::USER_APP_TYPE_PORT) {
                    $fields = ['id','line_type','area','bandwidth','last_update','line_type','node_id','node_ip','node_type',
                    'total_app_count','user_count','user_detail'];
                }

                foreach ($fields as $field) {
                    $this->assertArrayHasKey($field, $each, '结果中应包含 "' . $field . '" 字段！');
                }
            }
        }
    }
}
