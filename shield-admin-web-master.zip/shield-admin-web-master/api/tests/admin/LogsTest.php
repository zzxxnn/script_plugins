<?php

namespace tests\admin;

class LogsTest extends AdminBase
{
    
    /**
     * 测试 根据系统查询日志
     */
    public function testSearchLogsBySystem()
    {
        $data = [
            '_from' => 0, '_size' => 10, 'system' => 'index'
        ];
        $response = parent::sendRequest('get', '/v1/system-log', $data)->seeErrCode(0);

        $this->seeLogsList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据模块查询日志
     */
    public function testSearchLogsByModule()
    {
        $data = [
            '_from' => 0, '_size' => 10, 'system' => 'index', 'module' => ['用户管理']
        ];
        $response = parent::sendRequest('get', '/v1/system-log', $data)->seeErrCode(0);

        $this->seeLogsList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据操作类型查询日志
     */
    public function testSearchLogsByOperType()
    {
        $data = [
            '_from' => 0, '_size' => 10, 'type' => ['update', 'create']
        ];
        $response = parent::sendRequest('get', '/v1/system-log', $data)->seeErrCode(0);

        $this->seeLogsList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据日志属性查询日志
     */
    public function testSearchLogsByStatus()
    {
        $data = [
            '_from' => 0, '_size' => 10, 'status' => 'notice'
        ];
        $response = parent::sendRequest('get', '/v1/system-log', $data)->seeErrCode(0);

        $this->seeLogsList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据日志ID查询日志
     */
    public function testSearchLogsById()
    {
        $data = [
            '_from' => 0, '_size' => 10, 'id' => '2FZwy2UB0QRv2qOM9kXw'
        ];
        $response = parent::sendRequest('get', '/v1/system-log', $data)->seeErrCode(0);

        $this->seeLogsList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据操作用户查询日志
     */
    public function testSearchLogsByOperator()
    {
        $data = [
            '_from' => 0, '_size' => 10, 'ip' => 'admin'
        ];
        $response = parent::sendRequest('get', '/v1/system-log', $data)->seeErrCode(0);

        $this->seeLogsList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据IP查询日志
     */
    public function testSearchLogsByIp()
    {
        $data = [
            '_from' => 0, '_size' => 10, 'ip' => '192.168.9.99'
        ];
        $response = parent::sendRequest('get', '/v1/system-log', $data)->seeErrCode(0);

        $this->seeLogsList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据日志内容查询日志
     */
    public function testSearchLogsByContent()
    {
        $data = [
            '_from' => 0, '_size' => 10, 'content' => '商品'
        ];
        $response = parent::sendRequest('get', '/v1/system-log', $data)->seeErrCode(0);

        $this->seeLogsList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据日志开始结束时间查询日志
     */
    public function testSearchLogsByTime()
    {
        $data = [
            '_from' => 0, '_size' => 10, 'start_date' => strtotime('last week').'000', 'end_date' => time().'000'
        ];
        $response = parent::sendRequest('get', '/v1/system-log', $data)->seeErrCode(0);

        $this->seeLogsList(json_decode($response->getContent(), true));
    }

    private function seeLogsList($array)
    {
        $this->assertArrayHasKey('errcode', $array, '结果中应包含"errcode"字段！');
        $this->assertArrayHasKey('errmsg', $array, '结果中应包含"errmsg"字段！');
        $this->assertArrayHasKey('data', $array, '结果中应包含"data"字段！');
        $this->assertArrayHasKey('total', $array, '结果中应包含"total"字段！');

        if ($array['data']) {
            $fields = ['content','create_time','id','ip','method','module','operator','operator_type','path','reponse_data',
            'request_body','request_status','request_type','request_url','system','update_time'];

            foreach ($array['data'] as $each) {
                foreach ($fields as $field) {
                    $this->assertArrayHasKey($field, $each, '结果中应包含 "' . $field . '" 字段！');
                }
            }
        }
    }
}
