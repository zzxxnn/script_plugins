<?php

namespace tests\admin;

class DnsTest extends AdminBase
{
    /**
     * 测试 添加DNS失败：参数有误
     */
    public function testAddDnsParamsFailure()
    {
        $data = [
            'node_ip' => [
                ['ip' => '11.11.11.10', 'line' => 0]
            ],
            'line_type' => 3
        ];
        parent::sendRequest('post', '/v1/dnsnodes', $data)->seeErrCode(REP_CODE_PARAMS_INVALID);
    }

    /**
     * 测试 添加DNS失败：DNS节点配置有误
     */
    public function testAddDnsConfigFailure()
    {
        $data = [
            'node_ip' => [
                ['ip' => '11.11.11.10', 'line' => 0]
            ],
            'area' => 11,
            'line_type' => 3
        ];
        parent::sendRequest('post', '/v1/dnsnodes', $data)->seeErrCode(REP_CODE_DNS_NODE_CONFIG_ERROR);
    }
    
    /**
     * 测试 添加DNS成功
     */
    public function testAddDnsConfigSuccess()
    {
        $data = [
            'node_ip' => [
                ['ip' => '11.11.11.10', 'line' => 0]
            ],
            'area' => 11,
            'line_type' => 0
        ];
        $response = parent::sendRequest('post', '/v1/dnsnodes', $data)->seeErrCode(0);

        $dns_node = json_decode($response->getContent(), true)['data'];

        sleep(2);

        return $dns_node;
    }

    /**
     * 测试 添加DNS失败：DNS节点添加重复
     */
    public function testAddDnsConfigRepeatFailure()
    {
        $data = [
            'node_ip' => [
                ['ip' => '11.11.11.10', 'line' => 0]
            ],
            'area' => 11,
            'line_type' => 0
        ];
        parent::sendRequest('post', '/v1/dnsnodes', $data)->seeErrCode(REP_CODE_DNS_NODE_REPEAT_ERROR);
    }

    /**
     * @depends testAddDnsConfigSuccess
     *
     * 测试 根据节点线路IP查询DNS节点
     */
    public function testSearchDnsByLineIp($dns_node)
    {
        $data = [
            '_from' => 1, '_size' => 10, 'ip' => '11.11.11.10'
        ];

        $response = parent::sendRequest('get', '/v1/dnsnodes', $data)->seeErrCode(0);

        $this->seeDnsList(json_decode($response->getContent(), true));
    }

    /**
     * @depends testAddDnsConfigSuccess
     *
     * 测试 根据节点ID查询DNS节点
     */
    public function testSearchDnsById($dns_node)
    {
        $data = [
            '_from' => 1, '_size' => 10, 'node_id' => $dns_node['node_id']
        ];

        $response = parent::sendRequest('get', '/v1/dnsnodes', $data)->seeErrCode(0);

        $this->seeDnsList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据地区查询DNS节点
     */
    public function testSearchDnsByArea()
    {
        $data = [
            '_from' => 1, '_size' => 10, 'area' => 1
        ];
    
        $response = parent::sendRequest('get', '/v1/dnsnodes', $data)->seeErrCode(0);
    
        $this->seeDnsList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据地区省份查询DNS节点
     */
    public function testSearchDnsByPrvc()
    {
        $data = [
            '_from' => 1, '_size' => 10, 'area' => 1, 'prvc' => 11
        ];
    
        $response = parent::sendRequest('get', '/v1/dnsnodes', $data)->seeErrCode(0);
    
        $this->seeDnsList(json_decode($response->getContent(), true));
    }

    
    /**
     * 测试 获取DNS节点网站数详情
     */
    public function testGetDnsSiteDetail()
    {
        $data = [
            '_from' => 1, '_size' => 10
        ];
    
        $response = parent::sendRequest('get', '/v1/dnsnodes/sites')->seeErrCode(0);
        $response = json_decode($response->getContent(), true);

        $this->assertArrayHasKey('errcode', $response, '结果中应包含"errcode"字段！');
        $this->assertArrayHasKey('errmsg', $response, '结果中应包含"errmsg"字段！');
        $this->assertArrayHasKey('list', $response, '结果中应包含"list"字段！');
        $this->assertArrayHasKey('total', $response, '结果中应包含"total"字段！');
    }

    /**
     * @depends testAddDnsConfigSuccess
     *
     * 测试 删除DNS服务器
     */
    public function testDeleteDns($dns_node)
    {
        $data = [
            'ids' => [$dns_node['node_id']]
        ];
        parent::sendRequest('delete', '/v1/dnsnodes/delete', $data)->seeErrCode(0);
    }

    /**
     * 检查DNS节点列表字段信息
     *
     * @param array $array
     * @return void
     */
    private function seeDnsList($array)
    {
        $this->assertArrayHasKey('errcode', $array, '结果中应包含"errcode"字段！');
        $this->assertArrayHasKey('errmsg', $array, '结果中应包含"errmsg"字段！');
        $this->assertArrayHasKey('list', $array, '结果中应包含"list"字段！');
        $this->assertArrayHasKey('total', $array, '结果中应包含"total"字段！');

        if ($array['list']) {
            $fields = ['id','line_type','area','last_update','node_id','node_ip','site_count'];

            foreach ($array['list'] as $each) {
                foreach ($fields as $field) {
                    $this->assertArrayHasKey($field, $each, '结果中应包含 "' . $field . '" 字段！');
                }
            }
        }
    }
}