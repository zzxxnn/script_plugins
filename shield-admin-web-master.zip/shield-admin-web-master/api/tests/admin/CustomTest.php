<?php

namespace tests\admin;

use app\common\model\UserModel;
use app\common\model\AgentModel;

class CustomTest extends AdminBase
{
    /**
     * @test
     *
     * 添加测试用户数据
     */
    public function addTestCustom()
    {
        $time = time();
        $user_info = [
            'email'                 => 'test' . $time . '@veda.com',
            'password'              => password_hash('veda2017', PASSWORD_DEFAULT),
            'mobile'                => '15722222222',
            'avatar'                => 'avatar/support-user0.png',
            'create_time'           => date('Y-m-d H:i:s'),
            'safe_email'            => 'test' . $time . '@veda.com',
            'email_verify_status'   => 1,
            'real_name'             => 'veda',
            'id_number'             => '411111111111111111',
            'id_verify_status'      => 1,
            'username'              => 'test' . $time
        ];

        $user = new UserModel;
        $user->save($user_info);
        
        $custom_id['email'] = $user_info['email'];
        $custom_id['id'] = $user->id;

        $this->assertArrayHasKey('email', $custom_id);
        $this->assertArrayHasKey('id', $custom_id);

        return $custom_id;
    }

    /**
     * 测试 获取用户列表
     */
    public function testShowCustomListFailure()
    {
        $data = [
            '_from' => 'a', '_size' => 10
        ];

        parent::sendRequest('get', '/v1/customs', $data)->seeErrCode(REP_CODE_PARAMS_INVALID);
    }

    /**
     * 测试 获取用户列表
     */
    public function testShowCustomListSuccess()
    {
        $data = [
            '_from' => 1, '_size' => 10
        ];

        $response = parent::sendRequest('get', '/v1/customs', $data)->seeErrCode(0);
        
        $this->seeCustomList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据用户账户查询
     */
    public function testSearchCustomByAccount()
    {
        $data = [
            '_from' => 1, '_size' => 10, 'account' => 'autotest@veda.com'
        ];

        $response = parent::sendRequest('get', '/v1/customs', $data)->seeErrCode(0);

        $this->seeCustomList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据用户安全邮箱查询
     */
    public function testSearchCustomBySafemail()
    {
        $data = [
            '_from' => 1, '_size' => 10, 'safe_mail' => 'autotest@veda.com'
        ];

        $response = parent::sendRequest('get', '/v1/customs', $data)->seeErrCode(0);

        $this->seeCustomList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据用户手机号码查询
     */
    public function testSearchCustomByPhone()
    {
        $data = [
            '_from' => 1, '_size' => 10, 'phone' => '15722222222'
        ];

        $response = parent::sendRequest('get', '/v1/customs', $data)->seeErrCode(0);

        $this->seeCustomList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据用户身份证号查询
     */
    public function testSearchCustomByIdNum()
    {
        $data = [
            '_from' => 1, '_size' => 10, 'id_num' => '411111111111111111'
        ];

        $response = parent::sendRequest('get', '/v1/customs', $data)->seeErrCode(0);

        $this->seeCustomList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据用户名查询
     */
    public function testSearchCustomByUsername()
    {
        $data = [
            '_from' => 1, '_size' => 10, 'username' => 'autotest'
        ];

        $response = parent::sendRequest('get', '/v1/customs', $data)->seeErrCode(0);

        $this->seeCustomList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据是否绑定代理商查询
     */
    public function testSearchCustomByBindAgent()
    {
        $data = [
            '_from' => 1, '_size' => 10, 'if_bind_agent' => 'false'
        ];

        $response = parent::sendRequest('get', '/v1/customs', $data)->seeErrCode(0);

        $this->seeCustomList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据用户代理商查询查询
     */
    public function testSearchCustomByAgentId()
    {
        $data = [
            '_from' => 1, '_size' => 10, 'agent_id' => 1
        ];

        $response = parent::sendRequest('get', '/v1/customs', $data)->seeErrCode(0);

        $this->seeCustomList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 获取用户详情失败：用户不存在
     */
    public function testShowMissingCustomFailure()
    {
        $id = 'missing';

        parent::sendRequest('get', "/v1/customs/$id")->seeErrCode(REP_CODE_SOURCE_NOT_FOUND);
    }

    /**
     * @depends addTestCustom
     *
     * 测试 获取用户详情
     */
    public function testShowCustomSuccess($custom_id)
    {
        if ($custom_id) {
            $response = parent::sendRequest('get', "/v1/customs/" . $custom_id['email'])->seeErrCode(0);

            $fields = ['errcode','errmsg','data','agent','ddos_count','site_count','port_count','fees','orders','sale'];

            $data = json_decode($response->getContent(), true);
            
            foreach ($fields as $field) {
                $this->assertArrayHasKey($field, $data, '结果中应包含 "' . $field . '" 字段！');
            }
        }
    }

    /**
     * 测试 编辑用户失败：用户不存在
     */
    public function testUpdateMissingCustomFailure()
    {
        $id = 'missing';
        $data = [
            'mobile' => '15711111111', 'username' => 'test', 'avatar' => 'avatar/support-user0.png'
        ];

        parent::sendRequest('put', "/v1/customs/$id", $data)->seeErrCode(REP_CODE_SOURCE_NOT_FOUND);
    }

    /**
     * @depends addTestCustom
     *
     * 测试 编辑用户失败：手机号不合法
     */
    public function testUpdateCustomPhoneFailure($custom_id)
    {
        $data = [
            'mobile' => '0111231'
        ];

        parent::sendRequest('put', "/v1/customs/".$custom_id['id'], $data)->seeErrCode(REP_CODE_PARAMS_INVALID);
    }

    /**
     * @depends addTestCustom
     *
     * 测试 编辑用户失败：用户名不合法
     */
    public function testUpdateCustomUsernameFailure($custom_id)
    {
        $data = [
            'username' => 'w@#tqew'
        ];

        parent::sendRequest('put', "/v1/customs/".$custom_id['id'], $data)->seeErrCode(REP_CODE_PARAMS_INVALID);
    }

    /**
     * @depends addTestCustom
     *
     * 测试 编辑用户成功
     */
    public function testUpdateCustomSuccess($custom_id)
    {
        $data = [
            'mobile' => '15711111111', 'username' => 'test', 'avatar' => 'avatar/support-user0.png'
        ];

        parent::sendRequest('put', "/v1/customs/".$custom_id['id'], $data)->seeErrCode(0);
    }

    /**
     * @depends addTestCustom
     *
     * 测试 编辑用户失败：手机号重复
     */
    public function testUpdateCustomPhoneRepeatFailure($custom_id)
    {
        $data = [
            'mobile' => '15711111111'
        ];

        parent::sendRequest('put', "/v1/customs/".$custom_id['id'], $data)->seeErrCode(REP_CODE_PARAMS_INVALID);
    }

    /**
     * @depends addTestCustom
     *
     * 测试 编辑用户失败：未做修改
     */
    public function testNoUpdateCustomFailure($custom_id)
    {
        $data = [];

        parent::sendRequest('put', "/v1/customs/".$custom_id['id'], $data)->seeErrCode(REP_CODE_UPDATE_USER_NOTHING);
    }

    /**
     * @depends addTestCustom
     *
     * 测试 修改密码失败：密码规则不符合
     */
    public function testUpdatePasswordFailure($custom_id)
    {
        $data = [
            'new_password' => 'Veda1234', 'confirm_password' => 'qwe'
        ];

        parent::sendRequest('put', "/v1/customs/".$custom_id['id']."/password", $data)->seeErrCode(REP_CODE_PARAMS_INVALID);
    }

    /**
     * @depends addTestCustom
     *
     * 测试 修改密码成功
     */
    public function testUpdatePasswordSuccess($custom_id)
    {
        $data = [
            'new_password' => 'veda2017', 'confirm_password' => 'veda2017'
        ];

        parent::sendRequest('put', "/v1/customs/".$custom_id['id']."/password", $data)->seeErrCode(0);
    }

    /** 
     * @depends addTestCustom
     * 
     * 测试 充值成功
     */
    public function testCustomRechargeSuccess($custom_id)
    {        
        $data = [
            'amount' => 10000, 'approver_name' => '李四', 'receipt_number' => '4111510125', 'type' => 1
        ];

        $response = parent::sendRequest('post', '/v1/customs/' . $custom_id['id'] . '/recharge', $data, [])->seeErrCode(0);
        $response = json_decode($response->getContent(), true);
        $this->assertArrayHasKey('data', $response, '结果中应包含"data"字段！');
        $this->assertArrayHasKey('account', $response['data'], 'data中应包含"account"字段！');
    }

    /**
     * @depends addTestCustom
     *
     * TODO: 测试 绑定用户
     */
    // public function testCustomBundleSale($custom_id)
    // {
        // // 添加代理商
        // $time = time();
        // $agent_info = [
        //     'user_email'        =>  'testagent' . $time . '@veda.com',
        //     'user_name'         =>  'testagent' . $time,
        //     'user_type'         =>  
        //     'mobile'            =>
        //     'user_status'       =>
        //     'user_pass'         =>
        //     'last_login_ip'     =>
        //     'last_login_time'   =>  
        //     'avatar'            =>
        //     'user_invite_code'  =>  
        // ];
    // }

    /**
     * @depends addTestCustom
     * 
     * 测试 重置实名认证
     */
    public function testCustomResetRealnameSuccess($custom_id)
    {
        $response = parent::sendRequest('put', '/v1/customs/' . $custom_id['id'] . '/resetRealName')->seeErrCode(0);
    }

    /**
     * @depends addTestCustom
     *
     * 测试 删除用户成功
     */
    public function testDeleteCustomSuccess($custom_id)
    {
        $data = [
            'ids' => [$custom_id['id']]
        ];

        parent::sendRequest('delete', '/v1/customs/delete', $data)->seeErrCode(0);
    }

    /**
     * 检查用户列表字段信息
     *
     * @param array $array
     * @return void
     */
    private function seeCustomList($array)
    {
        $this->assertArrayHasKey('errcode', $array, '结果中应包含"errcode"字段！');
        $this->assertArrayHasKey('errmsg', $array, '结果中应包含"errmsg"字段！');
        $this->assertArrayHasKey('list', $array, '结果中应包含"list"字段！');
        $this->assertArrayHasKey('total', $array, '结果中应包含"total"字段！');

        if ($array['list']) {
            $fields = ['id','role','account','real_name','id_number','id_verify_status','username','email','safe_email',
                   'email_verify_status','avatar','last_login_ip','mobile','mobile_verify_status','agent_id','create_time',
                   'last_login_time','agent_name','role_name','img_url'];

            foreach ($fields as $field) {
                foreach ($array['list'] as $each) {
                    $this->assertArrayHasKey($field, $each, '结果中应包含 "' . $field . '" 字段！');
                }
            }
        }
    }
}
