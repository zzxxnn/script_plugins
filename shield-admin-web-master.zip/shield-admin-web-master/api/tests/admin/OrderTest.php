<?php

namespace tests\admin;

use app\common\model\OrderModel;
use app\common\model\InvoiceModel;
use app\client\repository\OrderRepository;
use think\Env;
use app\index\task\Order;

class OrderTest extends AdminBase
{
    /**
     * 创建充值订单
     *
     * @return void
     */
    public function testCreateRechargeOrderSuccess()
    {
        do {
            // 标识 + （年 + 日 + 月 + 时 + 分） + 随机码
            $orderId = OrderModel::ORDER_HD . date('ymdHi') . rand(100, 999);
            $result = (new OrderModel)->esGetById($orderId);
        } while ($result);

        $orderInfo = [
            'uid'            => "test@veda.com",
            'type'           => OrderModel::ORDER_TYPE_RECHARGE,
            'fee'            => 100,
            'final_fee'      => 100,
            'status'         => OrderModel::ORDER_STATUS_CREATED,
            'invoice_status' => InvoiceModel::INVOICE_STATUS_READY,
            'create_time'    => gmt_withTZ(),
            'pay_time'       => null,
            'detail'         => []
        ];

        $result = (new OrderModel)->esAdd($orderInfo, $orderId);
        if ($result['result'] === 'created') {
            $order =  array_merge(['order_id' => $result['_id']], $orderInfo);
        } else {
            $order = [];
        }

        $this->assertNotEmpty($order, '测试订单写入失败！');

        return $order;
    }

    /**
     * @depends testCreateRechargeOrderSuccess
     *
     * 测试 根据订单号查询订单成功
     */
    public function testSearchByOrderIdSuccess($order)
    {
        $data = ['_from' => 0, '_size' => 10, 'oid' => $order['order_id']];

        $response = parent::sendRequest('get', '/v1/order', $data)->seeErrCode(0);

        $this->seeOrderList(json_decode($response->getContent(), true));
    }

    /**
     * @depends testCreateRechargeOrderSuccess
     *
     * 测试 根据用户查询订单成功
     */
    public function testSearchByUserSuccess($order)
    {
        $data = ['_from' => 0, '_size' => 10, 'uid' => $order['uid']];

        $response = parent::sendRequest('get', '/v1/order', $data)->seeErrCode(0);

        $this->seeOrderList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据业务类型查询订单成功
     */
    public function testSearchByTypeSuccess()
    {
        $data = ['_from' => 0, '_size' => 10, 'type' => OrderModel::ORDER_TYPE_RECHARGE];

        $response = parent::sendRequest('get', '/v1/order', $data)->seeErrCode(0);

        $this->seeOrderList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据支付状态查询订单成功
     */
    public function testSearchByStatusSuccess()
    {
        $data = ['_from' => 0, '_size' => 10, 'status' => OrderModel::ORDER_STATUS_CREATED];

        $response = parent::sendRequest('get', '/v1/order', $data)->seeErrCode(0);

        $this->seeOrderList(json_decode($response->getContent(), true));
    }

    /**
     * 测试 根据时间范围查询订单成功
     */
    public function testSearchByTimeRangeSuccess()
    {
        $data = ['_from' => 0, '_size' => 10, 'start_date' => strtotime('last month').'000', 'end_date' => time().'000'];

        $response = parent::sendRequest('get', '/v1/order', $data)->seeErrCode(0);

        $this->seeOrderList(json_decode($response->getContent(), true));
    }

    /**
     * @depends testCreateRechargeOrderSuccess
     *
     * 测试 根据订单ID获取订单详情成功
     */
    public function testGetOrderDetailByIdSuccess($order)
    {
        $response = parent::sendRequest('get', '/v1/order/'.$order['order_id'])->seeErrCode(0);

        $this->seeOrderList(json_decode($response->getContent(), true), false);
    }

    /**
     * @depends testCreateRechargeOrderSuccess
     *
     * 测试 修改订单价格失败：密码错误
     */
    public function testUpdateOrderFeeFailure($order)
    {
        $data = [
            'password' => 'test1234', 'final_fee' => 90, 'approved_by' => 'test', 'approve_number' => '',
            'contract_number' => '123123', 'approved_number' => '123123'
        ];

        parent::sendRequest('put', '/v1/order/'.$order['order_id'], $data)->seeErrCode(REP_CODE_PASSWORD_ERROR);
    }

    /**
     * @depends testCreateRechargeOrderSuccess
     *
     * 测试 修改订单价格失败：优惠价格不得大于原金额
     */
    public function testUpdateOrderFeeLessFailure($order)
    {
        $data = [
            'password' => 'veda2017', 'final_fee' => 1000, 'approved_by' => 'test', 'approve_number' => '',
            'contract_number' => '123123', 'approved_number' => '123123'
        ];

        parent::sendRequest('put', '/v1/order/'.$order['order_id'], $data)->seeErrCode(REP_CODE_ORDER_TOO_MUCH_DISCOUNT_FEE);
    }

    /**
     * @depends testCreateRechargeOrderSuccess
     *
     * 测试 修改订单价格失败：优惠价格不能为空
     */
    public function testUpdateOrderEmptyFailure($order)
    {
        $data = [
            'password' => 'veda2017', 'final_fee' => '', 'approved_by' => 'test', 'approve_number' => '',
            'contract_number' => '123123', 'approved_number' => '123123'
        ];

        parent::sendRequest('put', '/v1/order/'.$order['order_id'], $data)->seeErrCode(REP_CODE_ORDER_ZERO_DISCOUNT_FEE);
    }

    /**
     * @depends testCreateRechargeOrderSuccess
     *
     * 测试 发送改价订单提醒成功
     */
    public function testSendOrderRemindSuccess($order)
    {
        $data = [
            'user' => ['email' => 'tests@veda.com', 'mobile' => '15733333333'],
            'support' => ['email' => 'tests@veda.com', 'mobile' => '15733333333'],
            'sale' => ['email' => 'tests@veda.com', 'mobile' => '15733333333'],
            'password' => 'veda2017'
        ];

        parent::sendRequest('post', '/v1/order/'.$order['order_id'].'/remind', $data)->seeErrCode(0);
    }

    /**
     * @depends testCreateRechargeOrderSuccess
     *
     * 测试 订单作废成功
     */
    public function testDeleteOrderSuccess($order)
    {
        parent::sendRequest('delete', '/v1/order/'.$order['order_id'])->seeErrCode(0);
    }

    /**
     * 检查订单列表字段信息
     *
     * @param array $array
     * @return void
     */
    private function seeOrderList($array, $list = true)
    {
        $this->assertArrayHasKey('errcode', $array, '结果中应包含"errcode"字段！');
        $this->assertArrayHasKey('errmsg', $array, '结果中应包含"errmsg"字段！');
        $this->assertArrayHasKey('data', $array, '结果中应包含"data"字段！');

        if ($list) {
            $this->assertArrayHasKey('total', $array, '结果中应包含"total"字段！');
            if ($array['data']) {
                foreach ($array['data'] as $each) {
                    if($each['type'] === OrderModel::ORDER_TYPE_RECHARGE){
                        $fields = ['create_time', 'fee', 'final_fee', 'invoice_content', 'invoice_display_status', 'invoice_id', 'invoice_status', 'oid',
                        'status', 'status_attr', 'type', 'type_attr', 'uid'];
                    }else{
                        $fields = ['create_time','fee','final_fee','invoice_content','invoice_display_status','invoice_id','invoice_status','oid','status',
                        'status_attr','type','type_attr','uid'];
                    }
                    foreach ($fields as $field) {
                        $this->assertArrayHasKey($field, $each, '结果中应包含 "' . $field . '" 字段！');
                    }
                }
            }
        } else {
            if($array['data']['type'] === OrderModel::ORDER_TYPE_RECHARGE){
                $fields = ["uid","type","fee","final_fee","status","invoice_status","create_time","pay_time","detail","order_id","type_attr"];
            }else{
                $fields = ['detail', 'create_time','fee','final_fee', 'invoice_status','status', 'status_attr','type','type_attr',
                'uid', 'start_date', 'end_date', 'last_update', 'order_id', 'pay_time', 'product_id', 'product_sku_id'];
            }
            foreach ($fields as $field) {
                $this->assertArrayHasKey($field, $array['data'], '结果中应包含 "' . $field . '" 字段！');
            }
        }
    }
}