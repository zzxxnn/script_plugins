<?php

namespace tests\admin;

use app\client\repository\ProductSkuRepository;
use app\common\model\ProductModel;
use app\index\repository\ProductRepository;

/**
 * Class ProductTest 商品单元测试
 *
 * @package tests\admin
 * @author Teddy Sun <sgsheg@163.com>
 */
class ProductTest extends AdminBase
{
    protected $productApi;
    protected $priceId;

    /**
     * ProductTest constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->productApi = '/v1/product';
        $this->priceId = 0;
    }

    /**
     * 商品列表获取成功
     */
    public function testProductListSuccess()
    {
        $response = $this->get($this->productApi);
        $this->assertJson($response->getContent(), 'API返回数据必须是JSON格式！');
        $result = $response->getData();
        $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    }

    /**
     * 商品列表获取失败
     */
    public function testProductListFailture()
    {
        $response = $this->get($this->productApi);
        $this->assertJson($response->getContent(), 'API返回数据必须是JSON格式！');
    }


    /**
     * 添加商品
     */
    public function testAddProductSuccess()
    {
        $data = [
            'product_name' => '测试应用',
            'product_type' => '实例',
            'product_description' => '测试商品-单元测试',
            'on_sale' => ProductModel::PRODUCT_OFF_SALE,
            'attributes' => [
                ['name' => 'area', 'description' => '地区', 'label' => '地区', 'type' => '离散属性'],
                ['name' => 'line', 'description' => '线路', 'label' => '线路', 'type' => '离散属性'],
                ['name' => 'base_bandwidth', 'description' => '保底带宽', 'label' => '保底带宽', 'type' => '离散计费属性'],
                ['name' => 'normal_bandwidth', 'description' => '业务带宽', 'label' => '业务带宽', 'type' => '离散计费属性'],
                ['name' => 'bandwidth', 'description' => '弹性带宽', 'label' => '弹性带宽', 'type' => '用后计费属性'],
                ['name' => 'sp_num', 'description' => '购买数量', 'label' => '购买数量', 'type' => '倍率计费属性'],
                ['name' => 'sp_time', 'description' => '购买时长', 'label' => '购买时长', 'type' => '倍率计费属性'],
            ]
        ];

        $response = parent::sendRequest('post', $this->productApi, $data);
        $this->assertJson($response->getContent(), 'API返回数据必须为JSON格式!');

        $result = $response->getData();
        $this->assertEquals(0, $result['errcode'], 'API错误码必须为0!');
        return $productId = $result['data']['product_id'];
    }

    /**
     * 商品名称查询商品
     * @depends testAddProductSuccess
     */
    public function testSearchProductByProductName()
    {
        $data = [
            '_from' => 1, '_size' => 10, 'product_name' => '应用'
        ];

        $response = parent::sendRequest('get', $this->productApi, $data)->seeErrCode(0);

        $this->getProductList(json_decode($response->getContent(), true));
    }

    /**
     * 商品sku列表
     * @depends testAddProductSkuSuccess
     */
    /*public function testProductSkuListSuccess($array)
    {
        $response = $this->get($this->productApi.'/'.$array['product_id']);
        $this->assertJson($response->getContent(), 'API返回数据必须是JSON格式！');
        $result = $response->getData();
        $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
        $response->seeList($result);
    }*/

    /**
     * sku列表获取失败
     * @depends testAddProductSkuSuccess
     */
    /*public function testProductSkuListFailture($array)
    {
        $response = $this->get($this->productApi . '/' . $array['product_id']);
        $this->assertJson($response->getContent(), 'API返回数据必须是JSON格式！');
    }*/

    /**
     * 添加sku信息
     *
     * @depends testAddProductSuccess
     */
    public function testAddProductSkuSuccess($productId)
    {
        $data =[
            'stock' => 100,
            'area' => '郑州',
            'line' => '电信',

            'base_bandwidth' => [
                ['bandwidth'=> '10G', 'price' => 20, 'label' => '保底带宽', 'type' => '离散计费属性'],
            ],
            'bandwidth' => [
                ['bandwidth' => '10G', 'price' => 10, 'label' => '弹性带宽', 'type' => '用后计费属性'],
            ],
            'normal_bandwidth' => [
                ['bandwidth' => '10M', 'price' => 10, 'label' => '业务带宽', 'type' => '离散计费属性'],
            ],
            'sp_num' => [
                ['max' => 10, 'min' => 1, 'price' => 10, 'label' => '购买数量', 'type' => '倍率计费属性'],
            ],
            'sp_time' => [
                ['min' => 1, 'max' => 10, 'price' => 20, 'label' => '购买时长', 'type' => '倍率计费属性'],
            ]
        ];

        $response = parent::sendRequest('post', $this->productApi.'/'.$productId.'/sku', $data);
        $this->assertJson($response->getContent(), 'API返回数据必须为JSON格式!');

        $result = $response->getData();
        \think\Log::write(['添加的商品sku' => $result['data']]);
        $this->assertEquals(0, $result['errcode'], 'API错误码必须为0!');
        return $array = ['price_id' => $result['data']['price_id'], 'product_id' => $productId];
    }

    /**
     * 查看商品规格详情
     *
     * @depends testAddProductSkuSuccess
     * @throws \Exception
     */
    public function testGetProductSkuSuccess($array)
    {
        $sku = $this->getProductSkuByPriceId($array['price_id']);
        $skuId = $sku['id'];
        $url = $this->productApi . '/' . $array['product_id'] . '/sku/'. $skuId;
        $response = parent::sendRequest('get', $url);
        $this->assertJson($response->getContent(), 'API返回数据必须是JSON格式！');
        $result = $response->getData();
        $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    }

    /**
     * 修改商品sku相关参数
     *
     * @depends testAddProductSkuSuccess
     * @throws \Exception
     */
    public function testProductSkuEditSuccess($array)
    {
        $sku = $this->getProductSkuByPriceId($array['price_id']);
        $skuId = $sku['id'];
        $data = [
            'area' => '测试',
            'line' => '电信',
            'stock' => 10,
        ];

        \think\Log::write(['skuId' => $skuId, 'sku' => $sku]);
        $url = $this->productApi.'/'.$array['product_id'].'/sku/'.$skuId;
        $response = parent::sendRequest('put', $url, $data);
        $this->assertJson($response->getContent(), 'API返回数据必须为JSON格式!');
        $result = $response->getData();
        $this->assertEquals(0, $result['errcode'], 'API错误码必须为0!');
    }

    /**
     * 删除sku信息 todo:获取到sku字段中的price_id
     * @depends testAddProductSkuSuccess
     * @throws \Exception
     */
    public function testDeleteProductSku($array)
    {
        //获取sku
        $sku = $this->getProductSkuByPriceId($array['price_id']);
        $data     = [
            'ids' => [$sku['id']],
        ];
        $response = parent::sendRequest('delete', $this->productApi . '/' . $array['product_id'] . '/sku', $data);
        $this->assertJson($response->getContent(), 'API返回数据必须为JSON格式!');
        $result = $response->getData();
        $this->assertEquals(0, $result['errcode'], 'API错误码必须为0!');
        return $productId = $array['product_id'];
    }

    /**
     * 修改商品信息成功
     *
     * @depends testDeleteProductSku
     * @throws \app\common\exception\RepositoryException
     */
    public function testUpdateProductSuccess($productId)
    {
        $id = $this->getIdByProductId($productId);
        \think\Log::write(['要进行修改商品id' => $id]);
        $data = [
            'product_name' => '测试修改应用1',
            'product_type' => '实例',
            'product_description' => '修改实例内容',
            'on_sale' => ProductModel::PRODUCT_ON_SALE,
        ];
        $response = parent::sendRequest('put', $this->productApi . '/' . $id, $data);
        \think\Log::write(['修改商品信息' => $response]);
        $this->assertJson($response->getContent(), 'API返回数据必须为JSON格式!');
        $result = $response->getData();
        $this->assertEquals(0, $result['errcode'], 'API错误码必须为0!');
    }

    /**
     * 修改商品信息失败
     * @depends testDeleteProductSku
     */
    public function testUpdateProductFailture()
    {
        $id = 'missing';
        $data = [
            'product_name' => '测试修改应用1',
            'product_type' => '实例',
            'product_description' => '修改实例内容',
            'on_sale' => ProductModel::PRODUCT_ON_SALE,
        ];
        parent::sendRequest('put', $this->productApi . '/' . $id, $data)->seeErrCode(REP_CODE_SOURCE_NOT_FOUND);
    }

    /**
     * 删除商品
     *
     * @deprecated
     * @depends testDeleteProductSku
     * @throws \app\common\exception\RepositoryException
     */
    public function testDeleteProductSuccess($productId)
    {
        $id = $this->getIdByProductId($productId);
        $data     = [
            'ids[]' => $id,
        ];
        $response = parent::sendRequest('delete', $this->productApi, $data);
        \think\Log::write(['删除结果' => $response]);
        $this->assertJson($response->getContent(), 'API返回数据必须为JSON格式!');
        $result = $response->getData();
        //再次尝试
        $i = 0;
        $sleep = [1, 10, 60];
        while ($result['errcode'] != 0) {
            sleep($sleep[$i]);
            $response = parent::sendRequest('delete', $this->productApi, $data);
            $result = $response->getData();
            if (++$i >= count($sleep)) {
                break;
            }
        }
        $this->assertEquals(0, $result['errcode'], 'API错误码必须为0!');
    }

    /**
     * 商品列表
     *
     * @param array $array
     * @return void
     */
    private function getProductList($array)
    {
        $this->assertArrayHasKey('errcode', $array, '结果中应包含"errcode"字段！');
        $this->assertArrayHasKey('errmsg', $array, '结果中应包含"errmsg"字段！');
        $this->assertArrayHasKey('data', $array, '结果中应包含"data"字段！');
        $this->assertArrayHasKey('total', $array, '结果中应包含"total"字段！');

        if ($array['data']) {
            $fields = ['id','product_id','product_name','product_type','on_sale','created_by','attributes'];

            foreach ($array['data'] as $each) {
                foreach ($fields as $field) {
                    $this->assertArrayHasKey($field, $each, '结果中应包含 "' . $field . '" 字段！');
                }
            }
        }
    }

    /**
     * @param $productId
     * @return string $id;
     * @throws \app\common\exception\RepositoryException
     */
    private function getIdByProductId($productId)
    {
        $productRepository = new ProductRepository();
        $filter = ['query' => ['term' => ['product_id' => $productId]]];
        $result  = $productRepository->findBy($filter);
        if ($result) {
            \think\Log::write(['传递product_id' => $productId, '获取到的商品id' => $result[0]['id']]);
            return $result[0]['id'];
        }
    }

    /**
     * 获取商品sku
     * @param $priceId
     * @return array|int
     * @throws \Exception
     */
    private function getProductSkuByPriceId($priceId)
    {
        $skuRepository = new ProductSkuRepository();
        $sku = $skuRepository->getProductSkuById($priceId);

        //todo:这种方法不是最理想的方法
        $i = 0;
        $sleep = [1, 10, 60];
        while ($sku === false) {
            sleep($sleep[$i]);
            $sku = $skuRepository->getProductSkuById($priceId);
            if (++$i >= count($sleep)) {
                break;
            }
        }

        return $sku;
    }
}