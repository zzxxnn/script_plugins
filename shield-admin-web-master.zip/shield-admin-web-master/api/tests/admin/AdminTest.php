<?php

namespace tests\admin;

class AdminTest extends AdminBase
{
    /**
     * 测试 添加管理员成功
     */
    public function testAddAdminSuccess()
    {
        $data = [
            'username' => 'autotest', 'password' => 'veda2017'
        ];
        $response = parent::sendRequest('post', '/v1/admins', $data)->seeErrCode(0);
        
        $data = $response->getData();

        $this->assertArrayHasKey('id', $data, '返回值中应包含新加管理员ID！');

        $admin_id = $data['id'];
        
        return $admin_id;
    }

    /**
     * 测试 添加管理员失败：重复添加
     */
    public function testAddAdminRepeatFailure()
    {
        $data = [
            'username' => 'autotest', 'password' => 'veda2017'
        ];
        parent::sendRequest('post', '/v1/admins', $data)->seeErrCode(REP_CODE_SOURCE_EXIST);
    }

    /**
     * @depends testAddAdminSuccess
     *
     * 测试 修改管理员密码失败：密码复杂度低
     */
    public function testUpdateAdminPasswordFailure($admin_id)
    {
        $data = ['new_pwd' => '1234'];

        parent::sendRequest('put', "/v1/admins/$admin_id/password", $data)->seeErrCode(REP_CODE_PARAMS_INVALID);
    }

    /**
     * 测试 修改管理员密码失败：管理员不存在
     */
    public function testUpdateMissingAdminPasswordFailure()
    {
        $data = ['new_pwd' => 'veda2018'];

        $id = 'missing';

        parent::sendRequest('put', "/v1/admins/$id/password", $data)->seeErrCode(REP_CODE_SOURCE_NOT_FOUND);
    }

    /**
     * @depends testAddAdminSuccess
     *
     * 测试 修改管理员密码成功
     */
    public function testUpdateAdminPasswordSuccess($admin_id)
    {
        $data = ['new_pwd' => 'veda2018'];

        parent::sendRequest('put', "/v1/admins/$admin_id/password", $data)->seeErrCode(0);
    }

    /**
     * 测试 修改管理员用户名失败：管理员不存在
     */
    public function testUpdateMissingAdminUsernameFailure()
    {
        $data = ['new_uname' => 'autotestname'];

        $id = 'missing';

        parent::sendRequest('put', "/v1/admins/$id/username", $data)->seeErrCode(REP_CODE_SOURCE_NOT_FOUND);
    }

    /**
     * @depends testAddAdminSuccess
     *
     * 测试 修改管理员用户名失败：用户名不符合要求
     */
    public function testUpdateAdminUsernameFailure($admin_id)
    {
        $data = ['new_uname' => '12'];

        parent::sendRequest('put', "/v1/admins/$admin_id/username", $data)->seeErrCode(REP_CODE_PARAMS_INVALID);
    }

    /**
     * @depends testAddAdminSuccess
     *
     * 测试 修改管理员用户名失败：用户名重复
     */
    public function testUpdateAdminUsernameRepeatFailure($admin_id)
    {
        $data = ['new_uname' => 'admin'];

        parent::sendRequest('put', "/v1/admins/$admin_id/username", $data)->seeErrCode(REP_CODE_SOURCE_EXIST);
    }

    /**
     * @depends testAddAdminSuccess
     *
     * 测试 修改管理员用户名成功
     */
    public function testUpdateAdminUsernameSuccess($admin_id)
    {
        $data = ['new_uname' => 'autotestname'];

        parent::sendRequest('put', "/v1/admins/$admin_id/username", $data)->seeErrCode(0);
    }

    /**
     * @depends testAddAdminSuccess
     *
     * 测试 删除管理员成功
     */
    public function testDeleteAdminSuccess($admin_id)
    {
        $data = [
            'ids' => [$admin_id]
        ];

        parent::sendRequest('delete', '/v1/admins/delete', $data)->seeErrCode(0);
    }
}
