<?php

namespace tests\admin;

use think\Env;

class AuthTest extends AdminBase
{
    /**
     * Auth不需要基境中的登录注销
     * 需重写父类 setUp tearDown
     */
    public function setUp()
    {
        $_SERVER['HTTP_HOST'] = Env::get('BACKGROUND_URL')?: 'admin.shield.com';
    }

    public function tearDown()
    {
    }

    /**
     * 测试 获取登陆正常状态信息
     */
    public function testLogInfoFailure()
    {
        parent::sendRequest('get', '/v1/loginfo')->seeErrCode(REP_CODE_NEED_LOGIN);
    }

    /**
     * 测试 登录失败：用户名错误
     */
    public function testLoginUsernameFailure()
    {
        $data = [
            'username' => 'test', 'password' => 'testveda', 'captcha' => '1234'
        ];

        parent::sendRequest('post', '/v1/login', $data)->seeErrCode(REP_CODE_SOURCE_NOT_FOUND);
    }

    /**
     * 测试 登录失败：密码错误
     */
    public function testLoginPasswordFailure()
    {
        $data = [
            'username' => 'admin', 'password' => 'testveda', 'captcha' => '1234'
        ];
        parent::sendRequest('post', '/v1/login', $data)->seeErrCode(REP_CODE_PASSWORD_ERROR);
    }

    /**
     * 测试 登陆成功
     */
    public function testLoginSuccess()
    {
        parent::login();
    }

    /**
     * 测试 获取登陆正常状态信息
     */
    public function testLogInfo()
    {
        $response = parent::sendRequest('get', '/v1/loginfo')->seeErrCode(0);

        $data = $response->getData();
        $this->assertArrayHasKey('is_login', $data);
        $this->assertArrayHasKey('uid', $data);
        $this->assertArrayHasKey('login_time', $data);
        $this->assertEquals(1, $data['is_login'], '登录状态为正常，此状态应为1！');
        $this->assertEquals('admin', $data['uid'], '登录状态为正常，uid应为admin！');
    }

    /**
     * 测试 注销
     */
    public function testLogout()
    {
        parent::logout();
    }
}
