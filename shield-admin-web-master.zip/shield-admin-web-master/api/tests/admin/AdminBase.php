<?php

namespace tests\admin;

use tests\BaseTestCase;
use think\Env;

class AdminBase extends BaseTestCase
{
    public function setUp()
    {
        parent::setUp();

        $_SERVER['HTTP_HOST'] = Env::get('BACKGROUND_URL')?: 'admin.shield.com';
        
        $this->login(); // 登录
    }

    public function tearDown()
    {
        parent::tearDown();
        
        $this->logout(); // 登出
    }

    public function logout()
    {
        parent::sendRequest('delete', '/v1/logout')->seeErrCode(0);
    }
    
    public function login()
    {
        $data = [
            'username' => 'admin', 'password' => 'veda2017', 'captcha' => '123456'
        ];
        parent::sendRequest('post', '/v1/login', $data)->seeErrCode(0);
    }
}
