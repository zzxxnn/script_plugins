<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/9/4
 * Time: 12:52
 */

namespace tests\traits;

use extend\submail\lib\MESSAGETemplatePOST;
use PHPUnit\Framework\Assert as PHPUnit;
use think\Cookie;
use think\helper\Arr;
use think\helper\Str;
use think\Response;

class HttpResponse
{

    use AssertionsTrait;

    protected $response;

    public function __construct(Response $response)
    {
        $this->response = $response;
    }

    public function seeStatusCode($status)
    {
        PHPUnit::assertEquals($status, $this->response->getCode(), 'API请求失败，HTTP状态码为：' . $this->response->getCode());

        return $this;
    }

    public function seeErrorCode($codes = [])
    {
        $result = (array)$this->response->getData();

        PHPUnit::assertContains($result['errcode'], (array) $codes);

        return $this;
    }

    public function seeJson($data = null, $negate = false)
    {
        if (is_null($data)) {
            PHPUnit::assertJson( $this->response->getContent(), "返回值非Json格式！" );

            return $this;
        }

        return $this->seeJsonContains($data, $negate);
    }

    public function seeJsonEquals(array $data)
    {
        $actual = json_encode(Arr::sortRecursive(json_decode($this->response->getContent(), true)));

        PHPUnit::assertEquals(json_encode(Arr::sortRecursive($data)), $actual);

        return $this;
    }

    protected function seeJsonContains(array $data, $negate = false)
    {
        $method = $negate ? 'assertFalse' : 'assertTrue';

        $actual = json_decode($this->response->getContent(), true);

        if (is_null($actual) || $actual === false) {
            PHPUnit::fail('Invalid JSON was returned from the route. Perhaps an exception was thrown?');
        }

        $actual = json_encode(Arr::sortRecursive((array) $actual));

        foreach (Arr::sortRecursive($data) as $key => $value) {
            $expected = $this->formatToExpectedJson($key, $value);

            PHPUnit::{$method}(Str::contains($actual, $expected),
                ( $negate ? 'Found unexpected' : 'Unable to find' )." JSON fragment [{$expected}] within [{$actual}].");
        }

        return $this;
    }

    /**
     * Format the given key and value into a JSON string for expectation checks.
     *
     * @param  string $key
     * @param  mixed  $value
     *
     * @return string
     */
    protected function formatToExpectedJson($key, $value)
    {
        $expected = json_encode([ $key => $value ]);

        if (Str::startsWith($expected, '{')) {
            $expected = substr($expected, 1);
        }

        if (Str::endsWith($expected, '}')) {
            $expected = substr($expected, 0, -1);
        }

        return $expected;
    }

    /**
     * @return null
     */
    public function getCode()
    {
        return $this->response->getCode();
    }

    public function getData()
    {
        return $this->response->getData();
    }

    public function getContent()
    {
        return $this->response->getContent();
    }

    public function getErrCode()
    {
        $result = $this->getData();

        return $result['errcode'] ?? null;
    }

    public function seeErrCode($code)
    {
        $result = $this->getData();

        PHPUnit::assertEquals($code, $result['errcode'], '接口错误码应为：'. $code . '，当前返回：' . $result['errcode'] . '！');

        return $this;
    }

    protected function seeModule($module)
    {
        PHPUnit::assertEquals($module, request()->module());

        return $this;
    }

    protected function seeController($controller)
    {
        PHPUnit::assertEquals($controller, request()->controller());

        return $this;
    }

    protected function seeAction($action)
    {
        PHPUnit::assertEquals($action, request()->action());

        return $this;
    }

    protected function seeHeader($headerName, $value = null)
    {
        $headers = $this->response->getHeader();

        PHPUnit::assertTrue(! empty($headers[$headerName]), "Header [{$headerName}] not present on response.");

        if ( ! is_null($value)) {
            PHPUnit::assertEquals($headers[$headerName], $value,
                "Header [{$headerName}] was found, but value [{$headers[$headerName]}] does not match [{$value}].");
        }

        return $this;
    }

    protected function seeCookie($cookieName, $value = null)
    {

        $exist = Cookie::has($cookieName);

        PHPUnit::assertTrue($exist, "Cookie [{$cookieName}] not present on response.");

        if ( ! is_null($value)) {
            $cookie = Cookie::get($cookieName);
            PHPUnit::assertEquals($cookie, $value,
                "Cookie [{$cookieName}] was found, but value [{$cookie}] does not match [{$value}].");
        }

        return $this;
    }

    protected function withServerVariables(array $server)
    {
        $this->serverVariables = $server;

        return $this;
    }

    protected function transformHeadersToServerVars(array $headers)
    {
        $server = [];
        $prefix = 'HTTP_';

        foreach ($headers as $name => $value) {
            $name = strtr(strtoupper($name), '-', '_');

            if ( ! Str::startsWith($name, $prefix) && $name != 'CONTENT_TYPE') {
                $name = $prefix.$name;
            }

            $server[$name] = $value;
        }

        return $server;
    }

    /**
     * 检查列表获取
     *
     * @param $requires
     *
     * @return $this
     */
    public function seeList($requires)
    {
        $result = (array) $this->response->getData();

        if ( ! isset($result['total']) || ! isset($result['list'])) {
            PHPUnit::fail('Invalid List Total was returned from the route');
        }

        foreach ($result['list'] as $item) {
            foreach ($requires as $require) {
                if (isset($item[$require])) {
                    continue;
                } else {
                    PHPUnit::fail('Invalid item in List was returned from the route');
                }
            }
        }

        return $this;
    }

}
