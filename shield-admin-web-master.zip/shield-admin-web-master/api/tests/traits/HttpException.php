<?php

namespace think\testing;

use PHPUnit\Framework\ExpectationFailedException;

class HttpException extends ExpectationFailedException
{
    //
}
