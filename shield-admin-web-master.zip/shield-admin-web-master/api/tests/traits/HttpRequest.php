<?php namespace tests\traits;

use think\App;
use think\Error;
use think\Exception;
use think\helper\Str;
use think\Request;

/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/9/4
 * Time: 13:06
 */
trait HttpRequest
{
    protected $currentUri;

    protected $baseUrl;

    protected $serverVariables = [];

    /**
     * @param       $uri
     * @param array $data
     * @param array $headers
     *
     * @return HttpResponse
     */
    public function get($uri, array $data = [], array $headers = [])
    {
        $server = $this->transformHeadersToServerVars($headers);

        return $this->call('GET', $uri, $data, [], [], $server);
    }

    /**
     * @param $uri
     * @param array $data
     * @param array $headers
     * @return HttpResponse
     */
    public function post($uri, array $data = [], array $headers = [])
    {
        $server = $this->transformHeadersToServerVars($headers);

        return $this->call('POST', $uri, $data, [], [], $server);
    }

    /**
     * @param $uri
     * @param array $data
     * @param array $headers
     * @return HttpResponse
     */
    public function put($uri, array $data = [], array $headers = [])
    {
        $server = $this->transformHeadersToServerVars($headers);

        return $this->call('PUT', $uri, $data, [], [], $server);
    }

    /**
     *
     * @param $uri
     * @param array $data
     * @param array $headers
     * @return HttpResponse
     */
    public function delete($uri, array $data = [], array $headers = [])
    {
        $server = $this->transformHeadersToServerVars($headers);

        return $this->call('DELETE', $uri, $data, [], [], $server);
    }

    /**
     * @param $method
     * @param $uri
     * @param array $parameters
     * @param array $cookies
     * @param array $files
     * @param array $server
     * @param null $content
     * @return HttpResponse
     */
    public function call($method, $uri, $parameters = [], $cookies = [], $files = [], $server = [], $content = null)
    {
        $this->currentUri = $this->prepareUrlForRequest($uri);

        $request = Request::create(
            $this->currentUri, $method, $parameters,
            $cookies, $files, array_replace($this->serverVariables, $server)
        );

        try {
            $response = App::run($request);
        } catch (Exception $e) {
            $response = Error::getExceptionHandler()->render($e);
        } catch (\Throwable $e) {
            $response = Error::getExceptionHandler()->render($e);
        }

        return new HttpResponse($response);
    }

    protected function withServerVariables(array $server)
    {
        $this->serverVariables = $server;

        return $this;
    }

    protected function transformHeadersToServerVars(array $headers)
    {
        $server = [];
        $prefix = 'HTTP_';

        foreach ($headers as $name => $value) {
            $name = strtr(strtoupper($name), '-', '_');

            if (!Str::startsWith($name, $prefix) && $name != 'CONTENT_TYPE') {
                $name = $prefix . $name;
            }

            $server[$name] = $value;
        }

        return $server;
    }

    protected function prepareUrlForRequest($uri)
    {
        if (Str::startsWith($uri, '/')) {
            $uri = substr($uri, 1);
        }

        if (!Str::startsWith($uri, 'http')) {
            $uri = $this->baseUrl . '/' . $uri;
        }

        return trim($uri, '/');
    }
}
