<?php

namespace tests;

use PHPUnit\Framework\TestCase;
use tests\traits\ApplicationTrait;
use tests\traits\HttpRequest;
use tests\traits\HttpResponse;
use think\Validate;
use think\Env;

/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/9/4
 * Time: 13:06
 */
class BaseTestCase extends TestCase
{
    use ApplicationTrait, HttpRequest;

    protected $domain;

    public function setUp()
    {
    }

    /**
     * 请求方法
     *
     * @param string $method
     * @param string $uri
     * @param array $data
     * @param array $headers
     * @return HttpResponse $response
     */
    public function sendRequest(string $method, string $uri, array $data = [], array $headers = [])
    {
        if (in_array(strtolower($method), ['get', 'post', 'put', 'delete'])) {
            $resp = $this->$method($uri, $data, $headers);
            // if (Env::get('APP_DEBUG', false) && $resp->getCode() == 500) {
            //     echo $resp->getData();
            // }
            $resp->seeStatusCode(200)->seeJson();

            return $resp;
        }
    }

    /**
     * 检查是否是有效Url
     * @param $url
     * @param string $message
     */
    public function assertUrl($url, $message = '不是有效的Url')
    {
        $this->assertTrue(filter_var($url, FILTER_VALIDATE_URL) !== false, $message);
    }

    public function assertString($string, $message = '必须是字符串')
    {
        $this->assertTrue(is_string($string), $message);
    }

    public function assertInt($int, $message = '必须是整形')
    {
        $this->assertTrue(is_integer($int), $message);
    }

    public function assertArray($array, $message = '必须是数组')
    {
        $this->assertTrue(is_array($array), $message);
    }

    public function assertNumber($number, $message = '必须是数值')
    {
        $this->assertTrue(is_numeric($number), $message);
    }

    public function assertEmail($email, $message = '必须是邮箱')
    {
        $this->assertTrue(filter_var($email, FILTER_VALIDATE_EMAIL), $message);
    }

    public function assertTimestamp($timestamp, $message = '必须是时间戳！')
    {
        $this->assertTrue(1000000000 <= $timestamp && $timestamp <= 9999999999, $message);
    }

    public function assertDatetime($datetime, $message = '必须是日期时间格式')
    {
        $result = format_time(strtotime($datetime)) == $datetime;
        $this->assertTrue($result, $message);
    }
}
