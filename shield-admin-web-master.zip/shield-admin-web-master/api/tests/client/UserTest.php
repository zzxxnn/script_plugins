<?php

namespace tests\client;

class UserTest extends ClientTest
{

    /**
     * 注册成功
     */
    public function testRegisterSuccess()
    {
        $data = [
            'email'    => 'test'.date('ymdHis').'@veda.com',
            'password' => 'veda2017',
            'mobile'   => '18638121735',
            'captcha'  => '5278'
        ];

        $rep = $this->post('/v1/users', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $result = $rep->getData();
        $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    }

    /**
     * 注册失败 - 参数不合法
     */
    public function testRegisterInvalidParamsFailure()
    {
        $data = [
            'email'    => '哈哈',
            'password' => 'veda2017',
            'mobile'   => '18638121735',
            'captcha'  => '5278'
        ];
        $rep  = $this->post('/v1/users', $data);

        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_PARAMS_INVALID);
    }

    /**
     * 注册失败 - 邮箱已注册
     */
    public function testRegisterEmailExistFailure()
    {
        $data = [
            'email'    => 'test@veda.com',
            'password' => 'veda2017',
            'mobile'   => '18638121735',
            'captcha'  => '5278'
        ];

        $rep = $this->post('/v1/users', $data);

        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_EMAIL_REGISTER);
    }

}
