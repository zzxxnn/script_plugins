<?php

namespace tests\client;

class SessionTest extends ClientTest
{

    /**
     * 获取用户信息失败
     *
     */
    public function testLogInfoFailure()
    {
        $this->logout();

        $uri = '/v1/loginfo';
        $rep = $this->get($uri);

        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(12001);
    }

    /**
     * 注销登录成功
     */
    public function testLogoutSuccess()
    {
        $uri    = '/v1/logout';
        $rep    = $this->delete($uri);
        $this->assertJson($rep->getContent(), '返回数据必须是JSON格式！');

        $this->assertEquals(200, $rep->getCode(), 'API请求异常！');

        $result = $rep->getData();
        $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    }


    public function testLoginFailure()
    {
        $data = [
            'email'    => 'ono1231222com',
            'password' => 'veda2017',
            'captcha'  => '5278'
        ];

        $rep = $this->post('/v1/login', $data);
//        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrorCode([11000, 10003, 13001, 14001, 11032]); // 参数不合法
//        $rep->seeErrorCode(10003); // 验证码不正确
//        $rep->seeErrorCode(13001); // 账户不存在
//        $rep->seeErrorCode(14001); // 非法操作
//        $rep->seeErrorCode(11032); // 需刷新重试

    }

}
