<?php

namespace tests\client;

class PortTest extends ClientTest
{

    /**
     * 获取应用防护列表成功
     *
     */
    //public function testListSuccess()
    //{
    //    $data = [];
    //
    //    $rep = $this->get('/v1/port', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $result = $rep->getData();
    //
    //    $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    //
    //    $rep->seeList([ 'id', 'app_id', 'server_ip' ]);
    //}

    /**
     * 获取应用防护列表失败
     *
     */
    public function testListFailure()
    {
        $data = [];

        $rep = $this->get('/v1/port', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    }

    ///**
    // * 获取高仿IP成功
    // */
    //public function testGetDDosIpsSuccess()
    //{
    //    $data = [];
    //
    //    $rep = $this->get('/v1/ddos/ips', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $result = $rep->getData();
    //
    //    $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    //
    //    $rep->seeList([ 'ddos_id', 'area', 'area_text', 'ips' ]);
    //}

    ///**
    // * 添加应用防护成功
    // */
    //public function testAddPortSuccess()
    //{
    //    $data = [
    //        "server_ips" => "192.168.78.85",
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-a87fnqz",
    //                "ip"      => "1.2.3.4",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "proxy_port" => 0,
    //        "protocol"   => "TCP",
    //        "type"       => 3
    //    ];
    //    $rep  = $this->post('/v1/port', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $result = $rep->getData();
    //
    //    $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    //}

    /**
     * 添加域名失败 - 参数不合法
     */
    public function testAddPortInvalidParamsFailure()
    {
        $data = [
            "server_ips" => "192.168.78.1185",
            "proxy_ips"  => [
                [
                    "ddos_id" => "ddos-a87fnqz",
                    "ip"      => "1.2.3.4",
                    "line"    => "2"
                ]
            ],
            "proxy_port" => 0,
            "protocol"   => "TCP",
            "type"       => 3
        ];
        $rep  = $this->post('/v1/port', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_PORT_ADD_PARAMS_INVALID);
    }

    /**
     * 添加域名失败 - 超过代理端口允许范围或端口超出10个
     */
    public function testAddPortProxyPortOutOfRangeFailure()
    {
        $data = [
            "server_ips" => "192.168.99.77",
            "proxy_ips"  => [
                [
                    "ddos_id" => "ddos-a87fnqz",
                    "ip"      => "1.2.3.4",
                    "line"    => "2"
                ]
            ],
            "proxy_port" => "1,2,3,4,5,6,7,8,9,10,11,12,13",
            "protocol"   => "TCP",
            "type"       => 3
        ];
        $rep  = $this->post('/v1/port', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_PORT_ADD_PARAMS_INVALID);
    }

    ///**
    // * 添加域名失败 - 转发端口已存在，不能选择全部 / 端口已存在，不能重复添加
    // */
    //public function testAddPortProxyPortExistFailure()
    //{
    //    $data = [
    //        "server_ips" => "192.168.9.71",
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-a87fnqz",
    //                "ip"      => "192.168.9.71",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "proxy_port" => "1",
    //        "protocol"   => "TCP",
    //        "type"       => 3
    //    ];
    //    $rep  = $this->post('/v1/port', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_ADD_PROXY_PORT_EXIST);
    //}

    /**
     * 添加域名失败 - 新应用配置保存失败
     */
    //public function testAddPortAddSaveConfigFailure()
    //{
    //    $data = [
    //        "server_ips" => "192.168.78.85",
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-a87fnqz",
    //                "ip"      => "1.2.3.4",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "proxy_port" => 0,
    //        "protocol"   => "TCP",
    //        "type"       => 3
    //    ];
    //    $rep  = $this->post('/v1/port', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_ADD_SAVE_CONFIG_FAIL);
    //}

    /**
     * 添加域名失败 - 更新实例接入信息失败
     */
    //public function testAddPortUpdatePortCountFailure()
    //{
    //    $data = [
    //        "server_ips" => "192.168.78.85",
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-a87fnqz",
    //                "ip"      => "1.2.3.4",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "proxy_port" => 0,
    //        "protocol"   => "TCP",
    //        "type"       => 3
    //    ];
    //    $rep  = $this->post('/v1/port', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_UPDATE_PORT_COUNT_FAIL);
    //}

    /**
     * 添加域名失败 - HD Conf配置保存失败
     */
    //public function testAddPortSetEsProxyConfFailure()
    //{
    //    $data = [
    //        "server_ips" => "192.168.78.85",
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-a87fnqz",
    //                "ip"      => "1.2.3.4",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "proxy_port" => 0,
    //        "protocol"   => "TCP",
    //        "type"       => 3
    //    ];
    //    $rep  = $this->post('/v1/port', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_SET_ES_PROXY_CONF_FAIL);
    //}

    /**
     * 添加域名失败 - 新转发配置写入ZK失败
     */
    //public function testAddPortSetZkProxyConfFailure()
    //{
    //    $data = [
    //        "server_ips" => "192.168.78.85",
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-a87fnqz",
    //                "ip"      => "1.2.3.4",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "proxy_port" => 0,
    //        "protocol"   => "TCP",
    //        "type"       => 3
    //    ];
    //    $rep  = $this->post('/v1/port', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_SET_ZK_PROXY_CONF_FAIL);
    //}

    /**
     * 添加域名失败 - 更新域名状态失败
     */
    //public function testAddPortUpdateNormalStatusFailure()
    //{
    //    $data = [
    //        "server_ips" => "192.168.78.85",
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-a87fnqz",
    //                "ip"      => "1.2.3.4",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "proxy_port" => 0,
    //        "protocol"   => "TCP",
    //        "type"       => 3
    //    ];
    //    $rep  = $this->post('/v1/port', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_UPDATE_FAIL);
    //}

    /**
     * 添加域名失败 - 应用创建失败
     */
    public function testAddPortFailure()
    {
        $data = [
            "server_ips" => "192.168.78.85",
            "proxy_ips"  => [
                [
                    "ddos_id" => "ddos-a87fnqz",
                    "ip"      => "1.2.3.4",
                    "line"    => "2"
                ]
            ],
            "proxy_port" => [ 0 ],
            "protocol"   => "TCP",
            "type"       => 3
        ];

        $rep = $this->post('/v1/port', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_PORT_ADD_FAIL);
    }

    /**
     * 编辑应用防护基础配置信息 - 成功
     */
    //public function testUpdateBasicPortConfSuccess()
    //{
    //    $data = [
    //        "server_ips"  => "192.168.99.177",
    //        "server_port" => null
    //    ];
    //
    //    $rep = $this->post('/v1/port/app-ddos-X3cGcOk/conf-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $result = $rep->getData();
    //
    //    $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    //}

    /**
     * 编辑应用防护基础配置信息 - 参数不合法
     */
    public function testUpdateBasicPortConfInvalidParamsFailure()
    {
        $data = [
            "server_ips"  => "192.168.99.77.1",
            "server_port" => null
        ];
        $rep  = $this->post('/v1/port/app-ddos-X3cGcOk/conf-update', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_PORT_UPDATE_PARAMS_INVALID);
    }

    /**
     * 编辑应用防护基础配置信息 - 未找到该应用防护
     */
    //public function testUpdateBasicPortConfNotFoundPortFailure()
    //{
    //    $data = [
    //        "server_ips"  => "192.168.99.77",
    //        "server_port" => null
    //    ];
    //    $rep  = $this->post('/v1/port/app-ddos-X3cGcOk1/conf-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_NOT_EXIST);
    //}

    /**
     * 编辑应用防护基础配置信息 - 更新该应用防护的基本配置信息
     */
    //public function testUpdateBasicPortConfUpdatePortFailure()
    //{
    //    $data = [
    //        "server_ips"  => "192.168.99.77",
    //        "server_port" => null
    //    ];
    //    $rep  = $this->post('/v1/port/app-ddos-X3cGcOk/conf-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_UPDATE_PORT_CONFIG_FAIL);
    //}

    /**
     * 编辑应用防护基础配置信息 - HD Conf配置保存失败
     */
    //public function testUpdateBasicPortConfSetEsProxyConfFailure()
    //{
    //    $data = [
    //        "server_ips"  => "192.168.99.77",
    //        "server_port" => null
    //    ];
    //    $rep  = $this->post('/v1/port/app-ddos-X3cGcOk/conf-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_SET_ES_PROXY_CONF_FAIL);
    //}

    /**
     * 编辑应用防护基础配置信息 - ZK Proxy Conf写入失败
     */
    //public function testUpdateBasicPortConfSetZkProxyConfFailure()
    //{
    //    $data = [
    //        "server_ips"  => "192.168.99.77",
    //        "server_port" => null
    //    ];
    //    $rep  = $this->post('/v1/port/app-ddos-X3cGcOk/conf-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_SET_ZK_PROXY_CONF_FAIL);
    //}

    /**
     * 编辑应用防护基础配置信息 - 更新该应用防护信息失败
     */
    public function testUpdateBasicPortConfFailure()
    {
        $data = [
            "server_ips"  => "2.2.2.3",
            "server_port" => null
        ];
        $rep  = $this->post('/v1/port/app-ddos-RH6HVWd/conf-update', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_PORT_UPDATE_FAIL);
    }

    /**
     * 编辑应用防护配置信息 - 更新该应用防护配置信息成功
     */
    //public function testUpdatePortConfSuccess()
    //{
    //    $data = [
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-2v255px",
    //                "ip"      => "1.2.3.10",
    //                "line"    => "哈哈"
    //            ],
    //            [
    //                "ddos_id" => "ddos-a87fnqz",
    //                "ip"      => "1.2.3.4",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "protocol"   => "TCP",
    //        "proxy_port" => "1,2"
    //    ];
    //
    //    $rep = $this->post('/v1/port/app-ddos-X3cGcOk/linkup-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $result = $rep->getData();
    //
    //    $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    //}

    /**
     * 编辑应用防护配置信息 - 参数不合法
     */
    public function testUpdatePortConfInvalidParamsFailure()
    {
        $data = [
            "proxy_ips"  => [
                [
                    "ddos_id" => "ddos-2v255px",
                    "ip"      => "1.2.3.10",
                    "line"    => "哈哈"
                ],
                [
                    "ddos_id" => "ddos-a87fnqz",
                    "ip"      => "1.2.3.4",
                    "line"    => "2"
                ]
            ],
            "protocol"   => "TCPC",
            "proxy_port" => "1,2"
        ];
        $rep = $this->post('/v1/port/app-ddos-X3cGcOk/linkup-update', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_PORT_UPDATE_PARAMS_INVALID);
    }

    /**
     * 编辑应用防护配置信息 - 未找到该应用防护
     */
    //public function testUpdatePortConfNotFoundPortFailure()
    //{
    //    $data = [
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-2v255px",
    //                "ip"      => "1.2.3.10",
    //                "line"    => "哈哈"
    //            ],
    //            [
    //                "ddos_id" => "ddos-a87fnqz",
    //                "ip"      => "1.2.3.4",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "protocol"   => "TCP",
    //        "proxy_port" => "1,2"
    //    ];
    //    $rep = $this->post('/v1/port/app-ddos-X3cGcOk1/linkup-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_NOT_EXIST);
    //}

    /**
     * 编辑应用防护配置信息 - 超过代理端口允许范围
     */
    //public function testUpdatePortConfAddProxyPortOutOfRangeFailure()
    //{
    //    $data = [
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-2v255px",
    //                "ip"      => "1.2.3.10",
    //                "line"    => "哈哈"
    //            ],
    //            [
    //                "ddos_id" => "ddos-a87fnqz",
    //                "ip"      => "1.2.3.4",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "protocol"   => "TCP",
    //        "proxy_port" => "1,2,3,4,5,6,7,8,9,10,11,12,13"
    //    ];
    //    $rep = $this->post('/v1/port/app-ddos-X3cGcOk/linkup-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_ADD_PROXY_PORT_OUT_OF_RANGE);
    //}

    /**
     * 编辑应用防护配置信息 - 转发端口输入非法
     */
    //public function testUpdatePortConfAddForwardInvalidFailure()
    //{
    //    $data = [
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-2v255px",
    //                "ip"      => "1.2.3.10",
    //                "line"    => "哈哈"
    //            ],
    //            [
    //                "ddos_id" => "ddos-a87fnqz",
    //                "ip"      => "1.2.3.4",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "protocol"   => "TCP",
    //        "proxy_port" => "0,1,2"
    //    ];
    //    $rep = $this->post('/v1/port/app-ddos-X3cGcOk/linkup-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_ADD_FORWARD_INVALID);
    //}

    /**
     * 编辑应用防护配置信息 - 端口已存在
     */
    //public function testUpdatePortConfAddProxyPortExistFailure()
    //{
    //    $data = [
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-ygd7lo2",
    //                "ip"      => "196.168.1.1",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "protocol"   => "TCP",
    //        "proxy_port" => "11"
    //    ];
    //
    //    $rep = $this->post('/v1/port/app-ddos-LWfkdMj/linkup-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_ADD_PROXY_PORT_EXIST);
    //}

    /**
     * 编辑应用防护配置信息 - 移除ZK Proxy Conf信息失败
     */
    //public function testUpdatePortConfRmZkProxyConfFailure()
    //{
    //    $data = [
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-tvqkbib",
    //                "ip"      => "123.133.84.209",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "protocol"   => "UDP",
    //        "proxy_port" => "7072"
    //    ];
    //
    //    $rep = $this->post('/v1/port/app-ddos-LWfkdMj/linkup-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_RM_ZK_PROXY_CONF);
    //}

    /**
     * 编辑应用防护配置信息 - Proxy Conf配置更新失败
     */
    //public function testUpdatePortConfRmEsProxyConfFailure()
    //{
    //    $data = [
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-tvqkbib",
    //                "ip"      => "123.133.84.209",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "protocol"   => "UDP",
    //        "proxy_port" => "7072"
    //    ];
    //
    //    $rep = $this->post('/v1/port/app-ddos-LWfkdMj/linkup-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_RM_ES_PROXY_CONF);
    //}

    /**
     * 编辑应用防护配置信息 - 用户实例接入信息更新失败
     */
    //public function testUpdatePortConfReducePortCountFailure()
    //{
    //    $data = [
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-tvqkbib",
    //                "ip"      => "123.133.84.209",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "protocol"   => "UDP",
    //        "proxy_port" => "7072"
    //    ];
    //
    //    $rep = $this->post('/v1/port/app-ddos-LWfkdMj/linkup-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_REDUCE_PORT_COUNT);
    //}

    /**
     * 编辑应用防护配置信息 - 更新应用接入配置失败
     */
    //public function testUpdatePortConfUpdatePortConfigFailure()
    //{
    //    $data = [
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-tvqkbib",
    //                "ip"      => "123.133.84.209",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "protocol"   => "UDP",
    //        "proxy_port" => "7072"
    //    ];
    //
    //    $rep = $this->post('/v1/port/app-ddos-LWfkdMj/linkup-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_UPDATE_PORT_CONFIG_FAIL);
    //}

    /**
     * 编辑应用防护配置信息 - 更新实例接入信息失败
     */
    //public function testUpdatePortConfUpdatePortCountFailure()
    //{
    //    $data = [
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-tvqkbib",
    //                "ip"      => "123.133.84.209",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "protocol"   => "UDP",
    //        "proxy_port" => "7072"
    //    ];
    //
    //    $rep = $this->post('/v1/port/app-ddos-LWfkdMj/linkup-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_UPDATE_PORT_COUNT_FAIL);
    //}

    /**
     * 编辑应用防护配置信息 - HD Conf配置保存失败
     */
    //public function testUpdatePortConfSetEsProxyConfFailure()
    //{
    //    $data = [
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-tvqkbib",
    //                "ip"      => "123.133.84.209",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "protocol"   => "UDP",
    //        "proxy_port" => "7072"
    //    ];
    //
    //    $rep = $this->post('/v1/port/app-ddos-LWfkdMj/linkup-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_SET_ES_PROXY_CONF_FAIL);
    //}

    /**
     * 编辑应用防护配置信息 - ZK Proxy Conf写入失败
     */
    //public function testUpdatePortConfSetZkProxyConfFailure()
    //{
    //    $data = [
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-tvqkbib",
    //                "ip"      => "123.133.84.209",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "protocol"   => "UDP",
    //        "proxy_port" => "7072"
    //    ];
    //
    //    $rep = $this->post('/v1/port/app-ddos-LWfkdMj/linkup-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_SET_ZK_PROXY_CONF_FAIL);
    //}

    /**
     * 编辑应用防护配置信息 - ZK DNS Conf写入失败
     */
    //public function testUpdatePortConfSetZkDnsConfFailure()
    //{
    //    $data = [
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-tvqkbib",
    //                "ip"      => "123.133.84.209",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "protocol"   => "UDP",
    //        "proxy_port" => "7072"
    //    ];
    //
    //    $rep = $this->post('/v1/port/app-ddos-LWfkdMj/linkup-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_SET_ZK_DNS_CONF_FAIL);
    //}

    /**
     * 编辑应用防护配置信息 - 应用接入信息更新失败
     */
    //public function testUpdatePortConfFailure()
    //{
    //    $data = [
    //        "proxy_ips"  => [
    //            [
    //                "ddos_id" => "ddos-tvqkbib",
    //                "ip"      => "123.133.84.209",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "protocol"   => "UDP",
    //        "proxy_port" => "7072"
    //    ];
    //
    //    $rep = $this->post('/v1/port/app-ddos-LWfkdMj/linkup-update', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_UPDATE_FAIL);
    //}

    /**
     * 删除应用防护成功
     */
    //public function testRmPortSuccess()
    //{
    //    $data = [
    //        'ids' => [
    //            'app-ddos-RH6HVWd'
    //        ]
    //    ];
    //
    //    $rep = $this->delete('/v1/port/bundle/delete', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $result = $rep->getData();
    //
    //    $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    //}

    /**
     * 删除应用防护 - 参数不合法
     */
    public function testRmPortInvalidParamsFailure()
    {
        $data = [
            'idss' => [
                'app-ddos-RH6HVWd'
            ]
        ];

        $rep = $this->delete('/v1/port/bundle/delete', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_PARAMS_INVALID);
    }

    /**
     * 删除应用防护 - 删除应用失败
     */
    //public function testRmPortNotExistFailure()
    //{
    //    $data = [
    //        'ids' => [
    //            'app-ddos-RH6HVWd1'
    //        ]
    //    ];
    //
    //    $rep = $this->delete('/v1/port/bundle/delete', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_NOT_EXIST);
    //}

    /**
     * 删除应用防护 - 移除ZK Proxy Conf信息失败
     */
    //public function testRmPortRmZkProxyConfFailure()
    //{
    //    $data = [
    //        'ids' => [
    //            'app-ddos-RH6HVWd1'
    //        ]
    //    ];
    //
    //    $rep = $this->delete('/v1/port/bundle/delete', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_RM_ZK_PROXY_CONF);
    //}

    /**
     * 删除应用防护 - Proxy Conf配置更新失败
     */
    //public function testRmPortRmEsProxyConfFailure()
    //{
    //    $data = [
    //        'ids' => [
    //            'app-ddos-RH6HVWd1'
    //        ]
    //    ];
    //
    //    $rep = $this->delete('/v1/port/bundle/delete', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_RM_ES_PROXY_CONF);
    //}

    /**
     * 删除应用防护 - 用户实例接入信息更新失败
     */
    //public function testRmPortReducePortCountFailure()
    //{
    //    $data = [
    //        'ids' => [
    //            'app-ddos-RH6HVWd1'
    //        ]
    //    ];
    //
    //    $rep = $this->delete('/v1/port/bundle/delete', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PORT_REDUCE_PORT_COUNT);
    //}

    /**
     * 删除应用防护 - 应用删除失败
     */
    public function testRmPortStatusErrorFailure()
    {
        $data = [
            'ids' => [
                'app-ddos-TakOg8E'
            ]
        ];

        $rep = $this->delete('/v1/port/bundle/delete', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_PORT_DELETE_FAIL);
    }

    /**
     * 获取高仿实例IP成功
     */
    //public function testGetProxyIpsSuccess()
    //{
    //    $data = [];
    //
    //    $rep = $this->get('/v1//port/app-ddos-RH6HVWd/proxy-ips', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $result = $rep->getData();
    //
    //    $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    //}

    /**
     * 获取用户高仿IP成功
     */
    //public function testGetInstancesSuccess()
    //{
    //    $data = [];
    //
    //    $rep = $this->get('/v1/port/app-ddos-RH6HVWd/instances?_from=0&_size=5', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $result = $rep->getData();
    //
    //    $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    //}

    /**
     * 获取用户高仿IP失败 - 应用不存在
     */
    //public function testGetInstancesNotExistFailure()
    //{
    //    $data = [];
    //
    //    $rep = $this->get('/v1/port/app-ddos-RH6HVWd1/instances?_from=0&_size=5', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_SOURCE_NOT_FOUND);
    //}

}
