<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/9/6
 * Time: 17:26
 */

namespace client;


use app\common\model\OrderModel;
use tests\client\ClientTest;

class PayTest extends ClientTest
{

    const ORDER_UNPAID = '11809062120697';

    const ORDER_PAID = '11809031805993';

    const ORDER_CANCELLED = '11809031719375';

    const ORDER_404 = 'test_123456';

    const ORDER_AMOUNT_BIG = '11809062036354';

    /**
     * 测试获取订单支付链接成功
     */
    public function testPayUrlSuccess()
    {
        $order = $this->createOrder();
        $data = ['orderId' => $order['order_id']];
        $resp = $this->sendRequest('post', '/v1/pay/url', $data);

        $this->assertEquals(
            REP_CODE_SUCCESS,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_SUCCESS
        );

        $data = $resp->getData();
        $this->assertUrl($data['url'], '支付链接必须是有效URL!');
    }

    /**
     * 测试获取订单支付链接失败：参数异常
     */
    public function testPayUrlFailureWithParamsError()
    {
        $resp = $this->sendRequest('post', '/v1/pay/url');
        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );
    }

    /**
     * 测试获取订单支付链接失败：未找到订单
     */
    public function testPayUrlFailureWithOrder404()
    {
        $data = ['orderId' => self::ORDER_404];
        $resp = $this->sendRequest('post', '/v1/pay/url', $data);

        $this->assertEquals(
            REP_CODE_SOURCE_NOT_FOUND,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_SOURCE_NOT_FOUND
        );
    }

    /**
     * 测试获取订单支付链接失败：订单已支付
     */
    public function testPayUrlFailureWithOrderPaid()
    {
        $data = ['orderId' => self::ORDER_PAID];
        $resp = $this->sendRequest('post', '/v1/pay/url', $data);

        $this->assertEquals(
            REP_CODE_ILLEGAL_OPERATION,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_ILLEGAL_OPERATION
        );
    }

    /**
     * 测试获取订单支付链接失败：订单已取消
     */
    public function testPayUrlFailureWithOrderCancelled()
    {
        $data = ['orderId' => self::ORDER_CANCELLED];
        $resp = $this->sendRequest('post', '/v1/pay/url', $data);

        $this->assertEquals(
            REP_CODE_ILLEGAL_OPERATION,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_ILLEGAL_OPERATION
        );
    }

    /**
     * 测试获取订单支付信息成功
     */
    public function testPayInfoSuccess()
    {
        $data = ['orderId' => self::ORDER_PAID];
        $resp = $this->sendRequest('POST', '/v1/pay/info', $data);

        $this->assertEquals(
            REP_CODE_SUCCESS,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_SUCCESS
        );

        $data = $resp->getData();
        $this->assertString($data['orderInfo']['appid'], 'appid必须是字符串！');
        $this->assertString($data['orderInfo']['err_code'], 'err_code必须是字符串！');
        $this->assertString($data['orderInfo']['err_code_des'], 'err_code_des必须是字符串！');
        $this->assertNumber($data['orderInfo']['mch_id'], 'mch_id必须是字符串！');
        $this->assertString($data['orderInfo']['nonce_str'], 'nonce_str必须是字符串！');
        $this->assertString($data['orderInfo']['result_code'], 'result_code必须是字符串！');
        $this->assertString($data['orderInfo']['return_code'], 'return_code必须是字符串！');
        $this->assertString($data['orderInfo']['return_msg'], 'return_msg必须是字符串！');
        $this->assertString($data['orderInfo']['sign'], 'sign必须是字符串！');
    }

    /**
     * 测试获取订单支付信息失败：未找到订单
     */
    public function testPayInfoFailureWithOrder404()
    {
        $data = ['orderId' => self::ORDER_404];
        $resp = $this->sendRequest('POST', '/v1/pay/info', $data);

        $this->assertEquals(
            REP_CODE_SOURCE_NOT_FOUND,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_SOURCE_NOT_FOUND
        );
    }

    /**
     * 测试获取订单支付信息失败：参数异常
     */
    public function testPayInfoFailureWithParamError()
    {
        $resp = $this->sendRequest('POST', '/v1/pay/info');

        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );
    }

    /**
     * 测试获取订单支付状态
     */
    public function testPayStatusSuccess()
    {
        $data = ['orderId' => self::ORDER_PAID];
        $resp = $this->sendRequest('POST', '/v1/pay/status', $data);

        $this->assertEquals(
            REP_CODE_SUCCESS,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_SUCCESS
        );

        $data = $resp->getData();
        $this->assertTrue(isset($data['status']) || $data['status'] === null, 'status必须是字符串！');
    }

    /**
     * 测试获取订单支付状态失败：参数异常
     */
    public function testPayStatusFailureWithParamError()
    {
        $resp = $this->sendRequest('POST', '/v1/pay/status');

        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );
    }

    /**
     * 测试获取订单支付状态失败：订单未找到
     */
    public function testPayStatusFailureWithOrder404()
    {
        $data = ['orderId' => self::ORDER_404];
        $resp = $this->sendRequest('POST', '/v1/pay/status', $data);

        $this->assertEquals(
            REP_CODE_SOURCE_NOT_FOUND,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_SOURCE_NOT_FOUND
        );
    }

    /**
     * 测试余额支付成功
     */
    public function testPayRemainingSuccess()
    {
        $order = $this->createOrder();
        $data = ['orderId' => $order['order_id']];

        $resp = $this->sendRequest('post', '/v1/pay/remaining', $data);

        $this->assertEquals(
            REP_CODE_SUCCESS,
            $resp->getErrCode(),
            REP_CODE_SUCCESS
        );

        $result = $resp->getData();
        $this->assertString($result['order']['uid'], 'uid必须是字符串！');
        $this->assertNumber($result['order']['type'], 'type必须是数值！');
        $this->assertNumber($result['order']['fee'], 'fee必须是数值！');
        $this->assertNumber($result['order']['final_fee'], 'final_fee必须是数值！');
        $this->assertNumber($result['order']['status'], 'status必须是数值！');
        $this->assertNumber($result['order']['invoice_status'], 'invoice_status必须是数值！');
        $this->assertDatetime($result['order']['create_time'], 'create_time必须是数值！');
        $this->assertString($result['order']['oid'], 'oid必须是数值！');
    }

    /**
     * 测试订单余额支付失败：参数异常
     */
    public function testPayRemainingFailureWithParamError()
    {
        $resp = $this->sendRequest('post', '/v1/pay/remaining');
        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );
    }

    /**
     * 测试订单余额支付失败：参数异常
     */
    public function testPayRemainingFailureWithOrder404()
    {
        $data = ['orderId' => self::ORDER_404];
        $resp = $this->sendRequest('POST', '/v1/pay/remaining', $data);

        $this->assertEquals(
            REP_CODE_SOURCE_NOT_FOUND,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_SOURCE_NOT_FOUND
        );
    }

    /**
     * 测试订单余额支付失败：参数异常
     */
    public function testPayRemainingFailureWithOrderPaid()
    {
        $data = ['orderId' => self::ORDER_PAID];
        $resp = $this->sendRequest('post', '/v1/pay/remaining', $data);

        $this->assertEquals(
            REP_CODE_ORDER_ALREADY_PAY,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_ORDER_ALREADY_PAY
        );
    }

    /**
     * 测试订单余额支付失败：余额不足
     */
    public function testPayRemainingFailureWithBalanceError()
    {
        $data = ['orderId' => self::ORDER_AMOUNT_BIG, 'payType' => OrderModel::ORDER_PAY_TYPE_REMAINNING];
        $resp = $this->sendRequest('post', '/v1/pay/remaining', $data);

        $this->assertEquals(
            REP_CODE_ORDER_REMAINING_FEE_NOT_ENOUGH,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_ORDER_REMAINING_FEE_NOT_ENOUGH
        );
    }

}