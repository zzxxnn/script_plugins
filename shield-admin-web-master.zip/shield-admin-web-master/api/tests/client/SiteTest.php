<?php

namespace tests\client;

class SiteTest extends ClientTest
{

    /**
     * 获取网站防护列表成功
     *
     */
    public function testListSuccess()
    {
        $data = [];

        $rep = $this->get('/v1/site', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $result = $rep->getData();

        $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');

        $rep->seeList([ 'id', 'app_id', 'upstream' ]);
    }

    /**
     * 获取网站防护列表失败
     *
     */
    public function testListFailure()
    {
        $data = [];

        $rep = $this->get('/v1/site', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    }

    /**
     * 添加网站 - 参数不合法
     */
    public function testAddSiteInvalidParamsFailure()
    {
        $data = [
            "name"        => "yexxcom",
            "http"        => 1,
            "https"       => 0,
            "upstream"    => "192.168.89.86",
            "src_host"    => "",
            "server_port" => 80
        ];
        $rep  = $this->post('/v1/site', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_PARAMS_INVALID);
    }

    /**
     * 添加网站 - 站点已存在
     */
    public function testAddSiteExistFailure()
    {
        $data = [
            "name"        => "c.com",
            "http"        => 1,
            "https"       => 0,
            "upstream"    => "192.168.89.86",
            "src_host"    => "",
            "server_port" => 80
        ];
        $rep  = $this->post('/v1/site', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_SITE_ALREADY_EXIST);
    }

    /**
     * 添加网站 - 获取txt类型记录值
     */
    public function testAddSiteGetTxtCodeSuccess()
    {
        $data = [];

        $rep = $this->get('/v1/site/web-ddos-hbXh45O/txtcode', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $result = $rep->getData();

        $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    }

    /**
     * 添加网站 - 获取txt类型记录值 - 域名不存在
     */
    public function testAddSiteGetTxtCodeSiteNotExistFailure()
    {
        $data = [];

        $rep = $this->get('/v1/site/web-ddos-J5yC0N15/txtcode', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_SITE_TXT_CODE_SITE_NOT_EXIST);
    }

    /**
     * 添加网站 - 审核此站点txt记录值是否符合
     */
    public function testAddSiteVerifyTxtCodeSuccess()
    {
        $data = [
            "domain" => "e.com"
        ];

        $rep = $this->post('/v1/site/web-ddos-hbXh45O/txtcode-verify', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $result = $rep->getData();

        $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    }

    /**
     * 添加网站 - 审核此站点txt记录值是否符合 - 参数不合法
     */
    public function testAddSiteVerifyTxtCodeInvalidParamsFailure()
    {
        $data = [
            "domain" => "e.com"
        ];
        $rep  = $this->post('/v1/site/web-ddos-hbXh45O1/txtcode-verify', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_SITE_TXT_CODE_VERIFY_SITE_NOT_EXIST);
    }

    /**
     * 添加网站 - 用户接入站点
     */
    //public function testAddSiteLinkUpSuccess()
    //{
    //    $data = [
    //        "linked_ips" => [
    //            [
    //                "ddos_id" => "ddos-nlwwwjt",
    //                "ip"      => "192.168.2.11",
    //                "line"    => "2"
    //            ]
    //        ],
    //        "type"       => 1,
    //        "proxy_port" => 80
    //    ];
    //
    //    $rep = $this->post('/v1/site/web-ddos-J5yC0N5/linkup', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $result = $rep->getData();
    //
    //    $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    //}

    /**
     * 添加网站 - 用户接入站点 - 参数不合法
     */
    public function testAddSiteLinkUpInvalidParamsFailure()
    {
        $data = [
            "linked_ipss" => [
                [
                    "ddos_id" => "ddos-nlwwwjt",
                    "ip"      => "192.168.2.11",
                    "line"    => "2"
                ]
            ],
            "type"        => 1,
            "proxy_port"  => 80
        ];

        $rep = $this->post('/v1/site/web-ddos-hbXh45O/linkup', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_SITE_LINK_PARAMS_INVALID);
    }

    /**
     * 添加网站 - 用户接入站点 - 域名不存在
     */
    public function testAddSiteLinkUpNotExistFailure()
    {
        $data = [
            "linked_ips" => [
                [
                    "ddos_id" => "ddos-nlwwwjt",
                    "ip"      => "192.168.2.11",
                    "line"    => "2"
                ]
            ],
            "type"       => 1,
            "proxy_port" => 80
        ];

        $rep = $this->post('/v1/site/web-ddos-hbXh45O1/linkup', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_SITE_LINK_SITE_NOT_EXIST);
    }

    /**
     * 添加网站 - 用户接入站点 - 域名不存在
     */
    public function testAddSiteLinkUpCountNotEnoughFailure()
    {
        $data = [
            "linked_ips" => [
                [
                    "ddos_id" => "ddos-nlwwwjt",
                    "ip"      => "192.168.2.11",
                    "line"    => "2"
                ]
            ],
            "type"       => 1,
            "proxy_port" => 80
        ];

        $rep = $this->post('/v1/site/web-ddos-hbXh45O/linkup', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_SITE_LINK_COUNT_NOT_ENOUGH);
    }

    /**
     * 添加网站 - 更新接入信息 - 参数不合法
     */
    public function testAddSiteUpdateLinkUpInvalidParamsFailure()
    {
        $data = [
            "linked_ipss" => [
                [
                    "ddos_id" => "ddos-nlwwwjt",
                    "ip"      => "192.168.2.11",
                    "line"    => "2"
                ]
            ],
            "type"        => 1,
            "proxy_port"  => 80
        ];

        $rep = $this->post('/v1/site/web-ddos-hbXh45O/linkup-update', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_SITE_UPDATE_LINK_PARAMS_INVALID);
    }

    /**
     * 添加网站 - 更新接入信息 - 参数不合法
     */
    public function testAddSiteUpdateLinkUpNotExistFailure()
    {
        $data = [
            "linked_ips" => [
                [
                    "ddos_id" => "ddos-nlwwwjt",
                    "ip"      => "192.168.2.11",
                    "line"    => "2"
                ]
            ],
            "type"       => 1,
            "proxy_port" => 80
        ];

        $rep = $this->post('/v1/site/web-ddos-hbXh45O1/linkup-update', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_SITE_UPDATE_LINK_SITE_NOT_EXIST);
    }

    /**
     * 添加网站 - 更新接入信息 - 防护域名不够
     */
    public function testAddSiteUpdateLinkUpCountNotEnoughFailure()
    {
        $data = [
            "linked_ips" => [
                [
                    "ddos_id" => "ddos-nlwwwjt",
                    "ip"      => "192.168.2.11",
                    "line"    => "2"
                ]
            ],
            "type"       => 1,
            "proxy_port" => 80
        ];

        $rep = $this->post('/v1/site/web-ddos-hbXh45O/linkup-update', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_SITE_UPDATE_LINK_SITE_COUNT_NOT_ENOUGH);
    }

    /**
     * 删除网站 - 参数不合法
     */
    public function testDeleteSiteInvalidParamsFailure()
    {
        $data = [
            "idss" => [
                "web-ddos-3YkPBFW"
            ]
        ];

        $rep = $this->delete('/v1/site/bundle/delete', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_PARAMS_INVALID);
    }

    /**
     * 更新网站 - 更新网站信息成功
     */
    public function testUpdateSiteSuccess()
    {
        $data = [
            "http"        => 1,
            "https"       => 1,
            "upstream"    => "123.1.2.3",
            "src_host"    => "33.com",
            "server_port" => 80
        ];

        $rep = $this->put('/v1/site/web-ddos-6zuCvMQ', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $result = $rep->getData();

        $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    }

    /**
     * 更新网站 - 参数不合法
     */
    public function testUpdateSiteInvalidParamsFailure()
    {
        $data = [
            "http"        => 1,
            "https"       => 2,
            "upstream"    => "123.1.2.3",
            "src_host"    => "33.com",
            "server_port" => 80
        ];

        $rep = $this->put('/v1/site/web-ddos-J5yC0N5', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_PARAMS_INVALID);
    }

    /**
     * 更新网站 - 参数不合法
     */
    public function testUpdateSiteNotExistFailure()
    {
        $data = [
            "http"        => 1,
            "https"       => 1,
            "upstream"    => "123.1.2.3",
            "src_host"    => "33.com",
            "server_port" => 80
        ];

        $rep = $this->put('/v1/site/web-ddos-J5yC0N51', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_SOURCE_NOT_FOUND);
    }

    /**
     * HTTPS证书 - 参数不合法
     */
    public function testUploadHttpsCertInvalidParamsFailure()
    {
        $data = [
            "certificates"    => "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tDQpDRVJUSUZJQ0FURQ0KLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLQ==",
            "certificate_key" => "LS0tLS1CRUdJTiBSU0EgUFJJVkFURSBLRVktLS0tLQ0KS0VZDQotLS0tLUVORCBSU0EgUFJJVkFURSBLRVktLS0tLQ=="
        ];

        $rep = $this->post('/v1/site/web-ddos-J5yC0N5/https-cert/upload', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_PARAMS_INVALID);
    }

    /**
     * HTTPS证书 - 站点不存在
     */
    public function testUploadHttpsCertNotExistFailure()
    {
        $data = [
            "certificate"     => "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tDQpDRVJUSUZJQ0FURQ0KLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLQ==",
            "certificate_key" => "LS0tLS1CRUdJTiBSU0EgUFJJVkFURSBLRVktLS0tLQ0KS0VZDQotLS0tLUVORCBSU0EgUFJJVkFURSBLRVktLS0tLQ=="
        ];

        $rep = $this->post('/v1/site/web-ddos-J5yC0N15/https-cert/upload', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_SOURCE_NOT_FOUND);
    }

    /**
     * 获取站点上传的HTTPS证书 - 站点不存在
     */
    public function testGetHttpsCertSuccess()
    {
        $data = [];

        $rep = $this->post('/v1/site/web-ddos-6zuCvMQ/https-cert', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $result = $rep->getData();

        $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    }

    /**
     * 获取站点上传的HTTPS证书 - 站点不存在
     */
    public function testGetHttpsCertNotExistFailure()
    {
        $data = [];

        $rep = $this->post('/v1/site/web-ddos-J5yC0N51/https-cert', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_SOURCE_NOT_FOUND);
    }

    /**
     * 黑白名单设置 - 添加成功
     */
    public function testAddBlackWhiteIpSuccess()
    {

    }

    /**
     * 黑白名单设置 - 参数不合法
     */
    //public function testAddBlackWhiteIpInvalidParamsFailure()
    //{
    //    $data = [
    //        "type1"        => "white",
    //        "ipWhiteList" => "192"
    //    ];
    //
    //    $rep = $this->post('/v1/site/web-ddos-jeohLVJ/ip-list', $data);
    //    $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
    //
    //    $rep->seeErrCode(REP_CODE_PARAMS_INVALID);
    //}

    /**
     * 获取网站防护详情成功
     */
    public function testGetSiteDetailSuccess()
    {
        $data = [];

        $rep = $this->get('/v1/site/web-ddos-6zuCvMQ', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');
        $result = $rep->getData();

        $this->assertEquals(0, $result['errcode'], 'API错误码必须是0！');
    }

    /**
     * 获取用户高仿IP失败 - 应用不存在
     */
    public function testGetSiteDetailNotExistFailure()
    {
        $data = [];

        $rep = $this->get('/v1/site/app-ddos-RH6HVWd1', $data);
        $this->assertJson($rep->getContent(), 'API返回数据必须是JSON格式！');

        $rep->seeErrCode(REP_CODE_SOURCE_NOT_FOUND);
    }

}
