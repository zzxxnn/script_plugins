<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/9/7
 * Time: 18:30
 */

namespace client;


use app\common\model\OrderModel;
use tests\client\ClientTest;

class OrderTest extends ClientTest
{
    /**
     * 测试订单列表
     */
    public function testOrderListSuccess()
    {
        $resp = $this->sendRequest('get', '/v1/order');

        $this->assertEquals(
            REP_CODE_SUCCESS,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_SUCCESS
        );

        $data = $resp->getData();
        $this->assertNumber($data['total'], '列表总数必须是数值！');
        $this->assertTrue($data['total'] >= 0, '列表总数必须大于0！');

        foreach ($data['data'] as $item) {
            $this->assertString($item['uid'], '用户名必须是字符串！');
            $this->assertNumber($item['oid'], '订单编号必须是数值！');
            $this->assertNumber($item['type'], '订单类型必须是数值！');
            $this->assertString($item['type_attr'], '订单类型文本必须是字符串！');
            $this->assertDatetime($item['create_time'], '订单创建时间必须是日期时间格式！');
            $this->assertNumber($item['status'], '订单状态必须是数值！');
            $this->assertString($item['status_attr'], '订单状态文本必须是字符串！');
            $this->assertString($item['status_attr'], '订单状态文本必须是字符串！');
            $this->assertNumber($item['fee'], '订单费用必须是数字！');
            $this->assertNumber($item['final_fee'], '订单实际金额必须是数字！');
            !empty($item['invoice_id']) && $this->assertNumber($item['invoice_id'], '订单实际金额必须是数字！');
            !empty($item['invoice_status']) && $this->assertString($item['invoice_status'], '订单状态文本必须是数字！');
            $this->assertString($item['invoice_display_status'], '订单状态文本必须是字符串！');
            $this->assertString($item['invoice_content'], '发票内容必须是字符串！');
        }
    }

    /**
     * 测试创建充值订单
     */
//    public function testOrderCreateSuccess()
//    {
//        $resp = $this->sendRequest('post', '/v1/order');
//
//        $this->assertEquals(
//            REP_CODE_SUCCESS,
//            $resp->getErrCode(),
//            __METHOD__ . '错误码必须是' . REP_CODE_SUCCESS
//        );
//
//    }

    /**
     * 测试生成充值订单
     *
     * @return mixed
     */
    public function testCreateRechargeOrderSuccess()
    {
        $fee = 0.01;
        $data = [
            'type'   => OrderModel::ORDER_TYPE_RECHARGE,
            'fee'    => $fee,
            'detail' => [
                'product_id' => 0
            ]
        ];

        $resp = $this->sendRequest('post', '/v1/order', $data);
        $this->assertEquals(
            REP_CODE_SUCCESS,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_SUCCESS
        );

        $result = $resp->getData();
        $this->assertEquals(OrderModel::ORDER_TYPE_RECHARGE, $result['data']['type']);
        $this->assertEquals($fee, $result['data']['fee']);
        $this->assertEquals(OrderModel::ORDER_STATUS_CREATED, $result['data']['status']);
        $this->assertNumber($result['data']['order_id'], '订单编号必须是数字！');

        return $result['data']['order_id'];
    }

    /**
     * 测试创建订单失败：参数异常
     */
    public function testCreateOrderParamsError()
    {
        // 参数不能为空
        $resp = $this->sendRequest('post', '/v1/order');
        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );

        // 订单类型不合法
        $data = ['type' => 100];
        $resp = $this->sendRequest('post', '/v1/order', $data);
        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );

    }

    /**
     * 测试重置订单创建失败：参数异常
     */
    public function testCreateRechargeOrderFailureWithParamsError()
    {
        // 缺少参数
        $resp = $this->sendRequest('post', '/v1/order');
        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );

        // 缺少fee参数
        $data = ['type' => OrderModel::ORDER_TYPE_RECHARGE];
        $resp = $this->sendRequest('post', '/v1/order', $data);
        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );

        // 订单类型不能为空
        $data = ['fee' => 0.01];
        $resp = $this->sendRequest('post', '/v1/order', $data);
        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );

        // 订单金额非法
        $data = ['fee' => 0, 'type' => OrderModel::ORDER_TYPE_RECHARGE, 'detail' => ['product_id' => 0]];
        $resp = $this->sendRequest('post', '/v1/order', $data);
        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );

        // product_id错误
        $data = ['fee' => 1, 'type' => OrderModel::ORDER_TYPE_RECHARGE, 'detail' => ['product_id' => 1]];
        $resp = $this->sendRequest('post', '/v1/order', $data);
        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );

    }

    /**
     * 测试获取充值订单详情
     *
     * @param string $orderId
     */
    public function testGetRechargeOrderDetail($orderId = '11809081616705')
    {
        $resp = $this->sendRequest('get', '/v1/order/' . $orderId);
        $this->assertEquals(
            REP_CODE_SUCCESS,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_SUCCESS
        );

        $result = $resp->getData();
        $this->assertString($result['data']['uid'], '用户Id必须是字符串!');
        $this->assertInt($result['data']['type'], '类型必须是整形!');
        $this->assertNumber($result['data']['fee'], '金额必须是数值!');
        $this->assertInt($result['data']['status'], '状态必须是整形!');
        $this->assertInt($result['data']['invoice_status'], '开票状态必须是整形!');
        $this->assertDatetime($result['data']['create_time'], '创建时间格式必须是日期时间!');
        $this->assertInt($result['data']['order_id'], 'Id必须是整形!');
        $this->assertString($result['data']['type_attr'], '状态文本必须是字符串!');
    }

//    public function testCreatePaidOrderSuccess()
//    {
//        $data = [
//
//        ];
//        $resp = $this->sendRequest('post', '/v1/order', $data);
//        $this->assertEquals(
//            REP_CODE_SUCCESS,
//            $resp->getErrCode(),
//            REP_CODE_SUCCESS
//        );
//
//    }

    /**
     * 测试创建消费订单失败：参数异常
     */
    public function testCreatePaidOrderFailureWithParamError()
    {
        // 缺少参数
        $resp = $this->sendRequest('post', '/v1/order');
        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );

        // 缺少fee参数
        $data = ['type' => OrderModel::ORDER_TYPE_PAID];
        $resp = $this->sendRequest('post', '/v1/order', $data);
        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );

        // 订单类型不能为空
        $data = ['fee' => 0.01];
        $resp = $this->sendRequest('post', '/v1/order', $data);
        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );

        // 订单详情参数是必须的
        $data = ['fee' => 0.01, 'type' => OrderModel::ORDER_TYPE_PAID];
        $resp = $this->sendRequest('post', '/v1/order', $data);
        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );

        // 订单详情参数是必须的
        $data = ['fee' => 0.01, 'type' => OrderModel::ORDER_TYPE_PAID, 'detail' => ''];
        $resp = $this->sendRequest('post', '/v1/order', $data);
        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );

        // 订单金额非法
        $data = ['fee' => 0, 'type' => OrderModel::ORDER_TYPE_PAID, 'detail' => ['product_id' => 1]];
        $resp = $this->sendRequest('post', '/v1/order', $data);
        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );

        // product_id错误
        $data = ['fee' => 1, 'type' => OrderModel::ORDER_TYPE_RECHARGE, 'detail' => ['product_id' => 1000]];
        $resp = $this->sendRequest('post', '/v1/order', $data);
        $this->assertEquals(
            REP_CODE_PARAMS_INVALID,
            $resp->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_PARAMS_INVALID
        );
    }

    /**
     * 测试获取订单详情成功
     *
     * @depends testCreateRechargeOrderSuccess
     * @param $orderId
     */
    public function testGetOrderInfoSuccess($orderId)
    {
        $resp = $this->sendRequest('get', '/v1/order/' . $orderId);
        $this->assertEquals(
            REP_CODE_SUCCESS,
            $resp->getErrCode(),
            REP_CODE_SUCCESS
        );

        $result = $resp->getData();
        $this->assertEquals('0.01', $result['data']['fee'], '订单金额必须相等！');
        $this->assertString($result['data']['uid'], '用户名必须是字符串！');
        $this->assertNumber($result['data']['type'], '订单类型必须是字符串！');
        $this->assertNumber($result['data']['fee'], '订单金额必须是数字！');
        $this->assertNumber($result['data']['final_fee'], '订单金额必须是数字！');
        $this->assertNumber($result['data']['status'], '订单状态必须是数字！');
        $this->assertNumber($result['data']['invoice_status'], '订单开票状态必须是数字！');
        $this->assertDatetime($result['data']['create_time'], '订单创建时间必须是日期时间格式！');
        $this->assertString($result['data']['type_attr'], '订单状态文本必须是字符串！');
    }

    /**
     * 测试获取订单详情失败：未找到该订单
     */
    public function testGetOrderInfoFailureWith404()
    {
        $resp = $this->sendRequest('get', '/v1/order/test_123456');
        $this->assertEquals(
            REP_CODE_SOURCE_NOT_FOUND,
            $resp->getErrCode(),
            REP_CODE_SOURCE_NOT_FOUND
        );
    }

    /**
     * 测试订单作废成功
     *
     * @depends testCreateRechargeOrderSuccess
     * @param string $orderId
     * @return string
     */
    public function testOrderDestroySuccess($orderId = '11809081616705')
    {
        $resp = $this->sendRequest('delete', '/v1/order/' . $orderId);
        $this->assertEquals(
            REP_CODE_SUCCESS,
            $resp->getErrCode(),
            REP_CODE_SUCCESS
        );

        return $orderId;
    }

    /**
     * 测试订单作废失败：未找到订单
     */
    public function testOrderDestroyFailureWith404()
    {
        $resp = $this->sendRequest('delete', '/v1/order/' . 'test_123456');
        $this->assertEquals(
            REP_CODE_SOURCE_NOT_FOUND,
            $resp->getErrCode(),
            REP_CODE_SOURCE_NOT_FOUND
        );
    }

    /**
     * 测试订单作废失败：订单状态异常
     * @param string $orderId
     *
     * @depends testOrderDestroySuccess
     */
    public function testOrderDestroyFailureWithDestroyed($orderId = '11809081616705')
    {
        $resp = $this->sendRequest('delete', '/v1/order/' . $orderId);
        $this->assertEquals(
            REP_CODE_ILLEGAL_OPERATION,
            $resp->getErrCode(),
            REP_CODE_ILLEGAL_OPERATION
        );
    }

}