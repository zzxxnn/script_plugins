<?php

namespace client;

use app\common\model\UserInstanceModel;
use tests\client\ClientTest;

class DDoSTest extends ClientTest
{
    protected $api;

    const ddosTypeArray = [
        UserInstanceModel::INSTANCE_TYPE_SINGLE, UserInstanceModel::INSTANCE_TYPE_SHARED
    ];

    public function __construct()
    {
        parent::__construct();
        $this->api = '/v1/ddos/';
    }

    /**
     * 测试获取高防实例列表
     */
    public function testGetDDoSListSuccess()
    {
        $resp = $this->sendRequest('get', $this->api);

        $data = $resp->getData();
        $this->assertNumber($data['total'], '列表总数必须是数值！');
        $this->assertTrue($data['total'] >= 0, '列表总数必须大于0！');

        foreach ($data['list'] as $item) {
            $this->assertString($item['id'], '实例ID字符串！');
            $this->assertNumber($item['area'], '实例地区必须是数字！');
            $this->assertString($item['line'], '实例线路必须是字符串！');
            //todo: 存在sp_time为string 还有sp_time为undefined
            if (isset($item['sp_time'])) {
                $this->assertNumber($item['sp_time'], '购买时长必须是数字！');
            }
            $this->assertString($item['instance_id'], '实例ID必须是字符串！');
            $this->assertString($item['uid'], '用户名是字符串！');
            $this->assertInt($item['type'], '实例类型必须是整型！');
            $this->assertString($item['type_attr'], '实例类型文本必须是整型！');
            $this->assertInt($item['status'], '实例状态必须是整型！');
            $this->assertString($item['status_attr'], '实例状态文本必须是整型！');

            ! empty($item['base_bandwidth']) && $this->assertString($item['base_bandwidth'], '基础带宽必须是字符串！');
            ! empty($item['normal_bandwidth']) && $this->assertString($item['normal_bandwidth'], '业务带宽必须是字符串！');
            ! empty($item['bandwidth']) && $this->assertString($item['bandwidth'], '弹性带宽必须是字符串！');
            ! empty($item['sp_num']) && $this->assertNumber($item['sp_num'], '购买数量必须是整型！');
            ! empty($item['sp_num']) && $this->assertTrue($item['sp_num'] >= 1, '购买数量不能小于1！');

            ! empty($item['start_date']) && $this->assertDatetime($item['start_date'], '实例开始时间必须是日期时间格式！');
            ! empty($item['end_date']) && $this->assertDatetime($item['end_date'], '实例结束时间必须是日期时间格式！');
            ! empty($item['instance_line']) && $this->assertInt($item['instance_line'], '实例线路必须是整型！');
            ! empty($item['node_id']) && $this->assertString($item['node_id'], '高防节点ID必须是字符串！');

            // 应用型
            if ($item['type'] == UserInstanceModel::INSTANCE_TYPE_PORT) {
                $this->assertInt($item['port_count'], '实例端口数量必须是整型！');
            }

            // 网站型
            if (\in_array($item['type'], self::ddosTypeArray)) {
                ! empty($item['site_count']) && $this->assertInt($item['site_count'], '实例网站数量必须是整型！');
            }
        }
        //如果列表不为空
        if (isset($data['list'][0])) {
            return $ddos = $data['list'][0];
        }
    }

    /**
     * 测试获取高防实例详情
     *
     * @param string $ddosId
     */
    public function testGetDDoSDetailSuccess($ddosId = 'ddos-uayppvg')
    {
        $resp = $this->sendRequest('get', $this->api.$ddosId);
        $this->assertEquals(
            REP_CODE_SUCCESS,
            $resp->getErrCode(),
            REP_CODE_SUCCESS
        );

        $data = $resp->getData();
        $this->assertString($data['uid'], '用户名必须是字符串！');
        $this->assertNumber($data['type'], '类型必须是整型！');
        $this->assertNumber($data['status'], '状态必须是整型！');
        $this->assertNumber($data['instance_line'], '实例线路必须是整型！');
        $this->assertString($data['normal_bandwidth'], '业务带宽必须是整型！');
        $this->assertString($data['bandwidth'], '弹性带宽必须是整型！');
        $this->assertString($data['base_bandwidth'], '基础带宽必须是整型！');
        $this->assertTimestamp($data['start_date'], '开始时间必须是时间戳！');
        $this->assertTimestamp($data['end_date'], '结束时间必须是时间戳！');
        $this->assertNumber($data['area'], '地域必须是字符串！');
        $this->assertArray($data['hd_ip'], '高防IP必须是数组！');
    }

    /**
     * 测试获取高防实例详情失败：找不到高防实例
     *
     * @param string $ddosId
     */
    public function testGetDDoSDetailFailureWith404($ddosId = 'test-01')
    {
        $resp = $this->sendRequest('get', $this->api.$ddosId);

        $this->assertEquals(
            REP_CODE_SOURCE_NOT_FOUND,
            $resp->getErrCode(),
            REP_CODE_SOURCE_NOT_FOUND
        );
    }

    /**
     * 测试获取用户高仿ips
     */
    public function testGetDdosIpSuccess()
    {
        $response = $this->sendRequest('get', $this->api.'ips');
        $this->assertEquals(
            REP_CODE_SUCCESS,
            $response->getErrCode(),
            __METHOD__ . '错误码必须是' . REP_CODE_SUCCESS
        );

        $data = $response->getData();
        $this->assertNumber($data['total'], '列表总数必须是数值！');
        $this->assertTrue($data['total'] >= 0, '列表总数必须大于0！');

        foreach ($data['list'] as $item) {
            $this->assertNumber($item['type'], 'ip类型必须是数值');
            $this->assertNumber($item['area'], '区域area类型必须为数值');
            $this->assertString($item['area_text'], '区域area_text类型必须为字符串');
            $this->assertString($item['ddos_id'], '实例id类型必须为字符串');
            $this->assertArray($item['ips'], 'ips必须为数组');
        }
    }

    /**
     * 获取高防实例地域列表测试
     */
    public function testGetDdosAreas()
    {
        $response = $this->sendRequest('get', $this->api.'areas');
        $this->assertEquals(REP_CODE_SUCCESS, $response->getErrCode(), REP_CODE_SUCCESS);

        $data = $response->getData();

        foreach ($data['list'] as $item) {
            $this->assertNumber($item['value'], 'value类型必须是数值');
            $this->assertString($item['label'], 'label标签类型必须为字符串');
            //省份下面有直属市县
            if (isset($item['children'])) {
                $this->assertArray($item['children'], 'children必须为数组');
            }
        }
    }

    /**
     * 删除高防实例测试
     * @depends testGetDDoSListSuccess
     */
    public function testDeleteDdosSuccess($ddos)
    {
        \think\Log::write(['要被删除的ddos' => $ddos]);
        $ids = [
            'ids' => [$ddos['id']],
        ];
        $response = $this->sendRequest('delete', $this->api . 'bundle/delete', $ids);
        $this->assertJson($response->getContent(), 'API返回数据必须为JSON格式!');
        $result = $response->getData();
        $this->assertEquals(0, $result['errcode'], 'API错误码必须为0!');
    }
}