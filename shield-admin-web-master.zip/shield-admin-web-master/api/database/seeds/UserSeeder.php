<?php

use think\migration\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        //添加一个代理商
        $rows = [];
        for ($i = 0; $i < 1; $i++) {
            $rows[] = [
                'user_name'        => '',
                'user_email'       => 'agent'.mt_rand(1, 10000).'@veda.com',
                'user_pass'        => password_hash('veda2017', PASSWORD_DEFAULT),
                'id_number'        => '',
                'id_verify_status' => 0,
                'company'          => '北京卫达',
                'avatar'           => 'avatar/support-user1.png',
                'user_invite_code' => '',
                'last_login_ip'    => '',
                'mobile'           => '18610875205',
                'phone'            => ''
            ];
        }
        $rows[] = [
            'user_name'        => 'agent',
            'user_email'       => 'agent@veda.com',
            'user_pass'        => password_hash('veda2017', PASSWORD_DEFAULT),
            'id_number'        => '',
            'id_verify_status' => 0,
            'company'          => '北京卫达',
            'user_status'      => 1,
            'avatar'           => 'avatar/support-user1.png',
            'user_invite_code' => '',
            'last_login_ip'    => '',
            'mobile'           => '17089497810',
            'phone'            => ''
        ];

        //插入agents
        $this->table('agents')->insert($rows)->save();

        $rows2 = [];
        for ($i = 0; $i < 10; $i++) {
            $rows2[] = [
                'username'      => '',
                'real_name'     => '',
                'id_number'     => '',
                'role'          => 1,
                'last_login_ip' => '',
                'mobile'        => '',
                'email'         => 'test'.mt_rand(1, 99999).'@veda.com',
                'password'      => password_hash('veda2017', PASSWORD_DEFAULT),
                'avatar'        => 'avatar/support-user0.png',
                'agent_id'      => 1,
            ];
        }

        $rows2[] = [
            'role'          => 1,
            'username'      => 'client',
            'real_name'     => 'client@veda.com',
            'id_number'     => '',
            'mobile'        => '',
            'email'         => 'client@veda.com',
            'last_login_ip' => '',
            'password'      => password_hash('veda2017', PASSWORD_DEFAULT),
            'avatar'        => 'avatar/support-user0.png',
            'agent_id'      => 1,
        ];

        $rows2[] = [
            'role'          => 1,
            'username'      => 'test',
            'real_name'     => 'test@veda.com',
            'id_number'     => '',
            'mobile'        => '',
            'email'         => 'test@veda.com',
            'last_login_ip' => '',
            'password'      => password_hash('veda2017', PASSWORD_DEFAULT),
            'avatar'        => 'avatar/support-user0.png',
            'agent_id'      => 1,
        ];

        //超级管理员数据迁移文件
        $rows2[] = [
            'role'          => 0,
            'username'      => 'admin',
            'real_name'     => 'admin',
            'id_number'     => '',
            'mobile'        => '',
            'email'         => 'admin@veda.com',
            'last_login_ip' => '',
            'password'      => password_hash('veda2017', PASSWORD_DEFAULT),
            'avatar'        => 'avatar/support-user0.png',
            'agent_id'      => 1,
        ];

        $this->table('users')->insert($rows2)->save();
    }
}