<?php

use app\agent\model\CashOutModel;
use think\migration\Seeder;

class CashOut extends Seeder
{
    public function run()
    {
        //状态数组
        $statusArr = [CashOutModel::CASH_CREATED, CashOutModel::CASH_SUCCESS, CashOutModel::CASH_FAILURE];
        $k         = array_rand($statusArr);
        //快递
        $expressCompanyArray = ['顺丰快递', '申通快递', '圆通快递', '韵达快递', '邮政快递'];
        $expressK            = array_rand($expressCompanyArray);

        $rows = [];
        for ($i = 0; $i < 1000; $i++) {
            $rows[] = [
                'express_company' => $expressCompanyArray[$expressK],
                'express_number'  => rand(1000000, 9999999),
                'proof'           => 1,
                'invoice_number'  => rand(1000000, 9999999),
                'amount'          => rand(100, 10000),
                'status'          => $statusArr[$k],
                'agent_id'        => 2,
            ];
        }

        model('app\agent\model\CashOutModel')->add($rows);
    }
}