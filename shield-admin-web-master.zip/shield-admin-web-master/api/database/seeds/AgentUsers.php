<?php

use think\migration\Seeder;

class AgentUsers extends Seeder
{
    public function run()
    {
        $rows = [];
        for ($i = 0; $i < 100; $i++) {
            $rows[] = [
                'username'      => '',
                'real_name'     => '',
                'id_number'     => '',
                'role'          => 1,
                'last_login_ip' => '',
                'mobile'        => '',
                'email'         => '2'.mt_rand(1, 10000).'@veda.com',
                'password'      => password_hash('veda2017', PASSWORD_DEFAULT),
                'avatar'        => 'avatar/support-user0.png',
                'agent_id'      => 2,
            ];
        }

        //model('app\common\model\UserModel')->add($rows);
        $this->table('users')->insert($rows)->save();
    }
}