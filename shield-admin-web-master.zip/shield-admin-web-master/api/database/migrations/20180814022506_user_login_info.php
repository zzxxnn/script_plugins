<?php

use think\migration\Migrator;

/**
 * Class UserLoginInfo 用户登录日志记录
 *
 * @author Teddy Sun <sgsheg@163.com>
 */
class UserLoginInfo extends Migrator
{
    public function change()
    {
        $table = $this->table('user_login_info');

        $table->addColumn('user_id', 'integer', ['comment' => '登录用户id'])
            ->addColumn('login_ip', 'string', ['limit' => 15, 'comment' => '登录ip地址'])
            ->addColumn('pass_wrong_time_status', 'integer', [
                'limit'   => 1,
                'default' => 0,
                'comment' => '0:登录正确,2:登录失败'
            ])
            ->addColumn('model', 'string', ['comment' => '登录模型,例如"app\common\model\UserModel",代表当前用户从C端登录'])
            ->addColumn('login_time', 'timestamp', array(
                'default' => 'CURRENT_TIMESTAMP',
                'update' => ''
            ))
            ->create();
    }
}
