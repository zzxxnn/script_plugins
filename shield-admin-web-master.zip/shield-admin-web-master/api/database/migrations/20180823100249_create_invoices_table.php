<?php

use think\migration\Migrator;
use think\migration\db\Column;

class CreateInvoicesTable extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('invoices');

        $table->addColumn('user_id', 'integer', ['limit' => 11, 'default' => null, 'comment' => '用户id'])
            ->addColumn('user_email', 'string', ['limit' => 50, 'default' => null, 'comment' => '用户邮箱'])
            ->addColumn('system', 'string', ['limit' => 10, 'default' => null, 'comment' => '系统: index为B端，client为C端，agent为A端'])
            ->addColumn('status', 'integer', ['limit' => 1, 'default' => 0, 'comment' => '审批状态: 0为待审批(已提交)，1为开票中，2为快递中，3为已完成(收到发票), 4为已拒绝'])
            ->addColumn('ivc_type', 'integer', ['limit' => 1, 'default' => 0, 'comment' => '发票类型：0为普通发票; 1为专用发票'])
            ->addColumn('ivc_numbers', 'text', ['comment' => '发票号'])
            ->addColumn('ivc_title', 'string', ['limit' => 255, 'default' => null, 'comment' => '发票抬头'])
            ->addColumn('ivc_tax_id', 'string', ['limit' => 255, 'comment' => '纳税人识别码'])
            ->addColumn('ivc_address', 'string', ['limit' => 255, 'comment' => '注册地址'])
            ->addColumn('ivc_mobile', 'string', ['limit' => 20, 'comment' => '注册电话'])
            ->addColumn('ivc_bank', 'string', ['limit' => 100, 'comment' => '开户银行'])
            ->addColumn('ivc_account', 'string', ['limit' => 100, 'comment' => '银行账户'])
            ->addColumn('consignee_name', 'string', ['limit' => 20, 'default' => null, 'comment' => '收件人'])
            ->addColumn('consignee_address', 'string', ['limit' => 100, 'default' => null, 'comment' => '收件地址'])
            ->addColumn('consignee_mobile', 'string', ['limit' => 100, 'default' => null, 'comment' => '收件人电话'])
            ->addColumn('track_ship_id', 'string', ['limit' => 100, 'comment' => '快递单号'])
            ->addColumn('track_company', 'string', ['limit' => 100, 'comment' => '快递公司'])
            ->addColumn('description', 'text', ['comment' => '开票备注, 拒绝备注'])
            ->addTimestamps()
            ->addColumn('delete_time', 'timestamp', ['null'=>true, 'default'=>null])
            ->create();

        $table->changeColumn(Column::text('ivc_numbers')->setNull(true)->setComment('发票号'));
        $table->changeColumn(Column::string('ivc_tax_id')->setNull(true)->setComment('纳税人识别码'));
        $table->changeColumn(Column::string('ivc_address')->setNull(true)->setComment('注册地址'));
        $table->changeColumn(Column::string('ivc_mobile')->setNull(true)->setComment('注册电话'));
        $table->changeColumn(Column::string('ivc_bank')->setNull(true)->setComment('开户银行'));
        $table->changeColumn(Column::string('ivc_account')->setNull(true)->setComment('银行账户'));
        $table->changeColumn(Column::string('track_ship_id')->setNull(true)->setComment('快递单号'));
        $table->changeColumn(Column::string('track_company')->setNull(true)->setComment('快递公司'));
        $table->changeColumn(Column::string('description')->setNull(true)->setComment('开票备注, 拒绝备注'));
    }
}
