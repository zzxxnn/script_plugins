<?php

use think\migration\Migrator;
use think\migration\db\Column;

class AgentPhotos extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {

        $table = $this->table('agent_photos');

        $table->addColumn('agent_id', 'integer', ['limit' => 32, 'default' => null, 'comment' => '代理商id'])
            ->addColumn('agent_type', 'integer', ['limit' => 3, 'default' => 1, 'comment' => '用户类型,1:个人,2:机构,'])
            ->addColumn('photo_type', 'integer', ['limit' => 3, 'default' => 1, 'comment' => '图片类型,1:身份证正面,2:身份证反面,3:手持身份证,4:营业执照'])
            ->addColumn('url', 'string', ['limit'=>255, 'default'=>null, 'comment' => '图片'])
            ->addTimestamps()
            ->addColumn('delete_time', 'timestamp', ['null'=>true, 'default'=>null])
            ->create();
    }
}
