<?php

use think\migration\Migrator;
use think\migration\db\Column;

class CreateInvoiceOrdersTable extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('invoice_orders');

        $table->addColumn('user_id', 'integer', ['limit' => 11, 'default' => null, 'comment' => '用户id'])
            ->addColumn('user_email', 'string', ['limit' => 50, 'default' => null, 'comment' => '用户邮箱'])
            ->addColumn('invoice_id', 'integer', ['limit' => 32, 'default' => null, 'comment' => '申请单id'])
            ->addColumn('order_id', 'string', ['limit' => 40, 'default' => null, 'comment' => '订单ID'])
            ->addColumn('order_type', 'integer', ['limit' => 1, 'default' => null, 'comment' => '订单类型: 1为充值，2为消费'])
            ->addColumn('invoice_log_id', 'integer', ['limit' => 40, 'default' => null, 'comment' => '审批节点日志'])
            ->addColumn('status', 'integer', ['limit' => 1, 'default' => 0, 'comment' => '审批状态: 0为待审批(已提交)，1为开票中，2为快递中，3为已完成(收到发票), 4为已拒绝'])
            ->addColumn('system', 'string', ['limit' => 10, 'default' => null, 'comment' => '系统: index为B端，client为C端，agent为A端'])
            ->addColumn('fee', 'string', ['limit' => 40, 'default' => null, 'comment' => '订单原价'])
            ->addColumn('final_fee', 'string', ['limit' => 40, 'default' => null, 'comment' => '订单改价后价格'])
            ->addColumn('content', 'text', ['default' => null, 'comment' => '开票内容'])
            ->addTimestamps()
            ->addColumn('delete_time', 'timestamp', ['null' => true, 'default' => null])
            ->create();
    }
}
