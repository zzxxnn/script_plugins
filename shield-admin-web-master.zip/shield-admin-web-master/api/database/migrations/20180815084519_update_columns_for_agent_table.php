<?php

use think\Db;
use think\migration\Migrator;
use think\migration\db\Column;

class UpdateColumnsForAgentTable extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {

        $table = $this->table('agents');

        if ($table->hasColumn('id_number')) {
            Db::execute("ALTER TABLE agents DROP `id_number`");
            $table->addColumn('id_number', 'string',
                [ 'null' => true, 'default' => null, 'comment' => '身份证号码' ])->save();
        }
        if ($table->hasColumn('phone')) {
            Db::execute("ALTER TABLE agents DROP `phone`");
            $table->addColumn('phone', 'string',
                [ 'null' => true, 'default' => null, 'comment' => '固定电话' ])->save();
        }
        if ($table->hasColumn('company')) {
            Db::execute("ALTER TABLE agents DROP `company`");
            $table->addColumn('company', 'string',
                ['limit' => 255,  'null' => true, 'default' => null, 'comment' => '公司信息' ])->save();
        }
        if ($table->hasColumn('qq')) {
            Db::execute("ALTER TABLE agents DROP `qq`");
            $table->addColumn('qq', 'string',
                ['limit' => 20,  'null' => true, 'default' => null, 'comment' => 'qq' ])->save();
        }
        if ($table->hasColumn('bank')) {
            Db::execute("ALTER TABLE agents DROP `bank`");
            $table->addColumn('bank', 'string',
                ['limit' => 100,  'null' => true, 'default' => null, 'comment' => '开户行' ])->save();
        }
        if ($table->hasColumn('bank_account')) {
            Db::execute("ALTER TABLE agents DROP `bank_account`");
            $table->addColumn('bank_account', 'string',
                ['limit' => 100,  'null' => true, 'default' => null, 'comment' => '开户名' ])->save();
        }
        if ($table->hasColumn('bank_card')) {
            Db::execute("ALTER TABLE agents DROP `bank_card`");
            $table->addColumn('bank_card', 'string',
                ['limit' => 100,  'null' => true, 'default' => null, 'comment' => '开户账号' ])->save();
        }
    }
}
