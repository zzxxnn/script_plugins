<?php

use think\migration\Migrator;

/**
 * Class Users 用户表
 *
 * @author Teddy Sun <sgsheg@163.com>
 */
class Users extends Migrator
{
    public function change()
    {
        $table = $this->table('users');

        $table->addColumn('role', 'integer', ['limit' => 1, 'default' => 1, 'comment' => '用户类型,1:普通用户,0:超级管理员'])
            ->addColumn('last_login_time', 'integer', ['limit' => 11, 'default' => 0, 'comment' => '最后登录时间'])
            ->addColumn('account', 'decimal', ['precision' => 10, 'scale' => 2, 'default' => '0.00', 'comment' => '余额'])
            ->addColumn('real_name', 'string', ['limit' => 60, 'default' => null, 'comment' => '真实姓名'])
            ->addColumn('id_number', 'string', ['limit' => 100, 'default' => null, 'comment' => '身份证信息'])
            ->addColumn('id_verify_status', 'integer', ['limit' => 1, 'default' => 0, 'comment' => '身份证信息是否通验证,0:未通过;1通过'])
            ->addColumn('username', 'string', ['limit' => 100, 'comment' => '用户登录名称'])
            ->addColumn('password', 'string', ['limit' => 64, 'default' => 0, 'comment' => '用户密码'])
            ->addColumn('email', 'string', ['limit' => 100, 'default' => '', 'comment' => '用户登录邮箱'])
            ->addColumn('safe_email', 'string', ['limit' => 100, 'default' => '', 'comment' => '安全邮箱'])
            ->addColumn('email_verify_status', 'integer', ['limit' => 1, 'default' => 0, 'comment' => '用户邮箱是否验证'])
            ->addColumn('avatar', 'string', ['limit' => 255, 'default' => null, 'comment' => '头像'])
            ->addColumn('last_login_ip', 'string', ['limit' => 15, 'default' => null, 'comment' => '最后登录ip'])
            ->addColumn('mobile', 'string', ['limit' => 20, 'default' => null, 'comment' => '用户手机号'])
            ->addColumn('mobile_verify_status', 'integer', ['limit' => 1, 'default' => 0, 'comment' => '手机号码是否验证'])
            ->addColumn('agent_id', 'integer', ['limit' => 32, 'default' => null, 'comment' => '代理商id'])
            ->addTimestamps()
            ->addIndex(['email', 'mobile'], ['unique' => true])
            //->addForeignKey('agent_id', 'agents')
            ->create();
    }
}
