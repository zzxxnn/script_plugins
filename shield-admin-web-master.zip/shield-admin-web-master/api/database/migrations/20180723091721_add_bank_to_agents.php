<?php

use think\migration\Migrator;

/**
 * Class AddBankToAgents 添加银行信息
 *
 * @author Teddy Sun <sgsheg@163.com>
 */
class AddBankToAgents extends Migrator
{
    public function change()
    {
        $table = $this->table('agents');
        $table->addColumn('bank', 'string', ['limit' => 100, 'default' => null, 'comment' => '开户行'])
            ->addColumn('bank_account', 'string', ['limit' => 100, 'default' => null, 'comment' => '开户名'])
            ->addColumn('bank_card', 'string', ['limit' => 100, 'default' => null, 'comment' => '开户账号'])
            ->update();
    }
}
