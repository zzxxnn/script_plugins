<?php

use think\migration\Migrator;

/**
 * Class SystemLogs 系统日志
 *
 * @author Teddy Sun <sgsheg@163.com>
 */
class SystemLogs extends Migrator
{
    public function change()
    {
        $table = $this->table('system_logs');
        $table->addColumn('ip', 'string', ['comment' => 'ip'])
            ->addColumn('node', 'string', ['comment' => '节点'])
            ->addColumn('action', 'string', ['comment' => '动作'])
            ->addColumn('content', 'string', ['comment' => '内容'])
            ->addColumn('email', 'string', ['comment' => '邮箱'])
            ->addTimestamps()
            ->create();
    }
}
