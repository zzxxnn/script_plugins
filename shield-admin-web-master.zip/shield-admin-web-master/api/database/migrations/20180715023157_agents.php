<?php

use think\migration\Migrator;
use think\migration\db\Column;

class Agents extends Migrator
{
    public function change()
    {
        $table = $this->table('agents');

        $table->addColumn('user_type', 'integer', ['limit' => 3, 'default' => 1, 'comment' => '用户类型,1:个人代理商,2:机构代理商,'])
            ->addColumn('sex', 'integer', ['limit' => 2, 'default' => 0, 'comment' => '性别;0:保密,1:男,2:女'])
            ->addColumn('birthday', 'integer', ['limit' => 11, 'default' => 0, 'comment' => '生日'])
            ->addColumn('last_login_time', 'integer', ['limit' => 11, 'default' => 0, 'comment' => '最后登录时间'])
            ->addColumn('score', 'integer', ['limit' => 11, 'default' => 0, 'comment' => '积分'])
            ->addColumn('balance', 'decimal', ['precision' => 10, 'scale' => 2,'default' => '0.00', 'comment' => '余额'])
            ->addColumn('user_status', 'integer', ['limit'=>3,'default'=>0, 'comment' => '用户状态;0:禁用,1:正常,2:未验证'])
            ->addColumn('user_name', 'string', ['limit'=>60,'default'=>null, 'comment' => '用户名'])
            ->addColumn('user_nickname', 'string', ['limit'=>50,'default'=>'', 'comment' => ''])
            ->addColumn('user_pass', 'string', ['limit'=>64,'default'=>0, 'comment' => '用户状态;0:禁用,1:正常,2:未验证'])
            ->addColumn('user_email', 'string', ['limit'=>100,'default'=>'', 'comment' => '用户登录邮箱'])
            ->addColumn('user_url', 'string', ['limit'=>100, 'default'=>'', 'comment' => '用户网址'])
            ->addColumn('avatar', 'string', ['limit'=>255, 'default'=>null, 'comment' => '头像'])
            ->addColumn('user_invite_code', 'string', ['limit'=>20, 'default'=>null, 'comment' => '邀请码'])
            ->addColumn('last_login_ip', 'string', ['limit'=>15, 'default'=>null, 'comment' => '最后登录ip'])
            ->addColumn('mobile', 'string', ['limit'=>20, 'default'=>null, 'comment' => '用户手机号'])
            ->addColumn('phone', 'string', ['limit'=>20, 'default'=>null, 'comment' => '固定电话'])
            ->addColumn('id_number', 'string', ['limit'=>100, 'default'=>null, 'comment' => '身份证号码'])
            ->addColumn('id_verify_status', 'integer', ['limit' => 1, 'default' => 0, 'comment' => '身份证信息是否通验证,0:未通过;1通过'])
            ->addColumn('company', 'string', ['limit' => 100, 'default'=>null, 'comment'=>'公司信息'])
            ->addTimestamps()
            ->addColumn('delete_time', 'timestamp', ['null'=>true, 'default'=>null])
            ->addIndex(['user_email', 'user_nickname', 'mobile'], ['unique'=>true])
            ->create();
    }
}
