<?php

use think\migration\Migrator;

/**
 * Class CreateWithDrawTable 提现记录表
 *
 * @author Teddy Sun <sgsheg@163.com>
 */
class CreateWithDrawTable extends Migrator
{
    public function change()
    {
        $table = $this->table('cash_outs', ['engine' => 'Innodb']);
        $table->addColumn('cash_sn', 'string', ['limit' => 100, 'default' => null, 'comment' => '提现编号'])
            ->addColumn('express_company', 'string', ['limit' => 100, 'default' => null, 'comment' => '快递公司'])
            ->addColumn('express_number', 'string', ['limit' => 255, 'default' => null, 'comment' => '快递单号'])
            ->addColumn('invoice_number', 'string', ['limit' => 255, 'default' => null, 'comment' => '发票号码'])
            ->addColumn('proof', 'integer', ['limit' => 1, 'default' => 1, 'comment' => '是否包含完税证明,1:不包含;2:包含'])
            ->addColumn('amount', 'decimal', [
                'precision' => 10, 'scale' => 2, 'default' => '0.00', 'comment' => '提现金额'
            ])
            ->addColumn('status', 'integer', ['limit' => 3, 'default' => 1, 'comment' => '提现状态,1：已创建;2:已提现;3:作废'])
            ->addColumn('agent_id', 'integer', ['limit' => 255, 'null' => true, 'comment' => '代理商id'])
            ->addTimestamps()
            ->addColumn('delete_time', 'timestamp', ['null' => true, 'default' => null])
            ->addIndex(['cash_sn'])
            ->create();
    }
}
