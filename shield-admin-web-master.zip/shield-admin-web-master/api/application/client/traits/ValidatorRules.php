<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/4/26
 * Time: 14:33
 */

namespace app\client\traits;


use think\Validate;

trait ValidatorRules
{

    protected $checkingFieldName = null;

    protected $checkingFieldTitle = null;

    protected function ips($ips)
    {
        foreach ($ips as $ip) {
            $_ips = explode('-', $ip);
            foreach ($_ips as $_ip) {
                if (!Validate::ip($_ip, 'ipv4')) {
                    return $this->checkingFieldTitle . '规则错误！';
                }
            }
        }

        return true;
    }

    protected function domains($domains)
    {
        foreach ($domains as $domain) {
            if ($this->domain($domain) !== true) {
                return $this->checkingFieldTitle . '规则错误！';
            }
        }

        return true;
    }

    protected function domain($value)
    {
        //验证域名
        $pattern = '\b([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}\b';
        if (!Validate::regex($value, $pattern)) {
            return "域名不符合规范！";
        }

        if (count(explode('.', $value)) < 2) {
            return "域名不符合规范！";
        }

        return true;
    }

    /**
     * 自定义验证规则
     *
     * 请求必须包含此参数
     */
    protected function has($value)
    {
        return !is_null($value);
    }

    /**
     * 对IP或IP段进行校验
     * @param $value
     * @return bool|string
     */
    protected function ipWhiteBlackList($value)
    {
        foreach ($value as $item) {
            if (strpos($item, '-') !== false) {    // IP 段
                list($ipStart, $ipEnd) = explode('-', $item);
                $ipStart = ip2long($ipStart);
                $ipEnd = ip2long($ipEnd);

                // 如果IP的开始和结尾不能正确转换为ip2long，或者开始大于等于结尾。则该IP段不合法
                if ($ipStart === false || $ipEnd === false || $ipStart >= $ipEnd) {
                    return 'IP段格式错误！';
                }

                // 黑、白名单，IP段所包含数量不能超过255个！
                if ($ipEnd - $ipStart > 255) {
                    return 'IP段包含IP数量不能超过255个！';
                }
            } else if (strpos($item, '/')) {      // 掩码
                list($ip, $bits) = explode('/', $item);
                if (ip2long($ip) === false) {
                    return 'IP掩码格式错误！';
                }
                // 掩码位只能在24~31范围内
                if ($bits <= 23 || $bits >= 32) {
                    return '掩码位只能在24~31范围内！';
                }
            } else {                                        // IP
                $item = ip2long($item);
                if ($item === false) {
                    return '不是合法的IP地址！';
                }
            }
        }

        return true;
    }

    /**
     * 正则校验端是否合法,规则 [1~65535]
     *
     * @param $value
     * @return bool|string
     */
    protected function port($value)
    {
        $pattern = "/^((([0-9]|[1-9]\d{1,3}|[1-5]\d{4}|6[0-5]{2}[0-3][0-5]))(\-([1-9]|[1-9]\d{1,3}|[1-5]\d{4}|6[0-5]{2}[0-3][0-5])){0,1})$/";

        if (preg_match($pattern, $value)) {
            return true;
        }

        return '端口不符合规范';
    }

}