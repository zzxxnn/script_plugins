<?php

namespace app\client\model;

class HdConfigModel extends BaseModel
{
    protected $esIndex = 'hd_conf';

    protected $esType = 'type';
}