<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/4/11
 * Time: 16:25
 */

namespace app\client\model;


class ProxyConfModel extends BaseModel
{
    protected $esIndex = 'proxy_conf';

    protected $esType = 'type';

}