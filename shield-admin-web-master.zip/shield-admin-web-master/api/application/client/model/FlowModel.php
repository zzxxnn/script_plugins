<?php

namespace app\client\model;

/**
 * Class FlowModel 攻击日志
 *
 * @package app\client\model
 * @author Teddy Sun <sgsheg@163.com>
 */
class FlowModel extends BaseModel
{
    protected $esIndex = 'hd-raw-ad-flow-*';

    protected $esType = 'type';
}
