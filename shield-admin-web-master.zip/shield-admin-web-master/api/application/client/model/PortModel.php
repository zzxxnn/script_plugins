<?php

namespace app\client\model;

/**
 * Class PortModel 应用防护
 *
 * @package app\client\model
 * @author Teddy Sun <sgsheg@163.com>
 */
class PortModel extends BaseModel
{
    protected $esIndex = 'user_app';

    protected $esType = 'type';

    # Port状态
    const PORT_STATUS_LINING     = 1;   // 接入中
    const PORT_STATUS_NORMAL     = 2;   // 正常
    const PORT_STATUS_LINK_ERR   = 3;   // 接入失败
    const PORT_STATUS_DELETE_ERR = 4;   // 删除失败
    # 类型
    const USER_APP_TYPE_PORT = 3; // 非网站防护
    # 转发协议
    const PROTOCOL_TYPE_TCP = 'TCP';
    const PROTOCOL_TYPE_UDP = 'UDP';
    # 前缀
    const PORT_ID_PREFIX = 'app-ddos-';
}