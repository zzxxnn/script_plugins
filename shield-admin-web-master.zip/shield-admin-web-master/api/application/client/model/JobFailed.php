<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/4/8
 * Time: 12:10
 */

namespace app\client\model;


class JobFailed extends BaseModel
{
    protected $table = 'job_failed';

}