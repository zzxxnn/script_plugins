<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/5/26
 * Time: 18:00
 */

namespace app\client\model;


class HDFlowLogModel extends BaseModel
{
    protected $esIndex = 'hd-raw-proxy-app-*';
    protected $esType = 'type';
}