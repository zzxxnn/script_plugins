<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/4/9
 * Time: 11:01
 */

namespace app\client\model\mock;


interface MockDataInterface
{
    public function data();
}