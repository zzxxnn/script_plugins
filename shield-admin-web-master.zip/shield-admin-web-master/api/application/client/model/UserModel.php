<?php

namespace app\client\model;

class UserModel extends BaseModel
{
    protected $table = 'users';

    protected $hidden = [
        'password',
        'update_time'
    ];

    protected $append = ['agent_name'];

    public function getCreateTimeAttr($time)
    {
        return $time;
    }

    public function getUpdateTimeAttr($time)
    {
        return $time;
    }

    //数据关系
    public function agent()
    {
        return $this->belongsTo('AgentModel', 'agent_id');
    }

    public function getAgentNameAttr($value, $data)
    {
        return $this->agent->user_email ?? '';
    }
}
