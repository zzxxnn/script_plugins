<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/3/29
 * Time: 15:45
 */

namespace app\client\model;


class PhyConfModel extends BaseModel
{
    protected $esIndex = 'phy_conf';

    protected $esType = 'type';

}