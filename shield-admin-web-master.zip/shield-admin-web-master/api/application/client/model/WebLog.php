<?php
/*
* This file  is a part of  Veda- Platform
* Copyright (c) 2015 - 2018. Veda Software Inc. (http://www.veda.com)
*
* @file             WebLog.php
* @author           Teddy Sun
*/

namespace app\client\model;

/**
 * Class WebLog 访问日志
 *
 * @package app\client\model
 * @author Teddy Sun <sgsheg@163.com>
 */
class WebLog extends BaseModel
{
    protected $esIndex = 'hd-raw-proxy-web-*';

    protected $esType = 'type';
}
