<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/4/10
 * Time: 18:07
 */

namespace app\client\model;


class ProxyNodeInfoModel extends BaseModel
{
    protected $esIndex = 'proxy_node_info';

    protected $esType = 'type';

    //----------------高防节点类型-------------------。

    const PROXY_NODE_TYPE_SHARED = 1; // 共享型

    const PROXY_NODE_TYPE_SINGLE = 2; // 独享型

    const PROXY_NODE_TYPE_PORT = 3;   // 应用型

}