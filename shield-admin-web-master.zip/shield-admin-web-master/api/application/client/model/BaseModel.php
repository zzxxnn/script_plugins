<?php

namespace app\client\model;

use app\client\traits\ESQuery;
use app\client\traits\ZKQuery;
use think\Model;

class BaseModel extends Model
{
    use ESQuery, ZKQuery;

    //------------------------- ZK -------------------------------

    const HD_ZK_ACTION_CREATE = 'update';
    const HD_ZK_ACTION_DELETE = 'delete';
    const ZK_TYPE_WEB = 'web';
    const ZK_TYPE_APP = 'app';

    //------------------------- ZK -------------------------------

    public function __construct($data = [])
    {
        parent::__construct($data);
    }
}