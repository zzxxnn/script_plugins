<?php
namespace app\client\command;

use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Env;

class SyncFlowLog extends Command
{

    private $esHost = '';
    private $esIndex = 'hd-flow-log-';
    private $esType = 'type';
    private $nodes = ['123.133.84.204','123.133.84.205','123.133.84.206'];
    private $ports = [22018, 8080, 80, 8000, 8088, 1000, 443, 3000];

    protected function configure()
    {
        $this->setName('sync:node-flow-log')->setDescription('Fake node network flow logs');
    }

    protected function execute(Input $input, Output $output)
    {
        $this->esHost = Env::get('SYNC_ES_HOST', '123.133.84.201:9200');
        do {
            $logData = $this->buildBulkParam($this->nodes);
            $this->sendByPost("http://" . $this->esHost . "/_bulk", $logData);
            sleep(10);
        } while (true);
    }

    /**
     * 处理日志内容格式转为ES存储
     *
     * @param array $data
     * @return string $paramStr
     */
    private function buildBulkParam(array $data)
    {
        $params = [];
        $indexOper = ["index" => ["_index" => $this->esIndex . date("Y-m-d"), "_type" => $this->esType, "_id" => null]];
        foreach ($data as $ip) {
            $tmp['proxy_ip'] = $ip;
            $tmp['port'] = $this->ports[array_rand($this->ports)];
            $tmp['in_bps'] = rand(0, 100000000);
            $tmp['out_bps'] = rand(0,10000000);
            $tmp['conns'] = rand(0, 65535);
            $tmp['timestamp'] = gmt_withTZ(time());

            $params[] = json_encode($indexOper);
            $params[] = json_encode($tmp);
        }
        $paramStr = implode("\n", $params) . "\n";

        return $paramStr;
    }

    /**
     * 发送请求
     *
     * @param string $url
     * @param $post_data
     * @return string|null  $responses
     */
    private function sendByPost(string $url, $post_data)
    {
        try {
            is_array($post_data) && $post_data = json_encode($post_data);

            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL            => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 30,
                CURLOPT_CUSTOMREQUEST  => "POST",
                CURLOPT_HTTPHEADER     => ["content-type: application/json"],
                CURLOPT_POSTFIELDS     => $post_data,
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);

            if ($err || is_null($response) || empty($response)) {
                return null;
            }

            echo 'Response:' . json_encode($response) . "\n";

            return $response;
        } catch (\Exception $e) {
            echo $e->getMessage() . "\n";

            return null;
        }
    }
}