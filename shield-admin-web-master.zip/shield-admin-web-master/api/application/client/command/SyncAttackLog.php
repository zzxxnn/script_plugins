<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/5/25
 * Time: 16:01
 */

namespace app\client\command;


use think\console\input\Argument as InputArgument;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Env;
use think\Validate;

class SyncAttackLog extends Command
{

    private $token = 'weida';
    private $endPoint = '103.44.147.57:5544/api/getAttackLogByIP';
    private $esHost = '';
    private $esIndex = 'hd-attack-log-';
    private $esType = 'type';
    private $watchingIp = null;

    protected function configure()
    {
        $this->setName('sync:ip-attack-log')
            ->setDescription('Sync attack log by IP.')
            ->addArgument('ip', InputArgument::REQUIRED, 'Watching IP.');
    }

    protected function execute(Input $input, Output $output)
    {
        $this->esHost = Env::get('SYNC_ES_HOST', '123.133.84.201:9200');
        if (empty($this->esHost)) {
            $output->error('Set the ES host first!');

            return;
        }

        $watchIp = $input->getArgument('ip');
        if (!Validate::is($watchIp, 'ip')) {
            $output->error('IP is invalid.');

            return;
        }

        $this->watchingIp = $watchIp;
        $output->writeln('Start sync logs for ' . $watchIp);
        $end_time = $end_time ?? time();
        $start_time = $end_time - 30;
        do {
            // 记录运行开始的时间
            $runStart = time();
            $this->work($start_time, $end_time);
            // 记录运行结束的时间
            $runEnd = time();
            // 每30秒获取一次
            sleep(30 - ($runEnd - $runStart));
            $start_time = $end_time;
            $end_time = time();
        } while (true);

        $output->writeln('Sync has been down.');
    }


    private function work($start_time, $end_time)
    {
        $postData = [
            "strAuthorityPork" => $this->token,
            "ip"               => $this->watchingIp,
            "start_time"       => date('Y-m-d H:i:s', $start_time),
            "end_time"         => date('Y-m-d H:i:s', $end_time),
        ];
        $responses = $this->sendByPost("http://" . $this->endPoint, $postData);
        echo "[" . date('Y-m-d H:i:s', $start_time) . ' - ' . date('Y-m-d H:i:s', $end_time) . "]" . $responses . "\n";
        if (!is_null($responses)) {
            $result = json_decode(json_decode($responses), true);
            if ($result['code'] === "0" && $result['err'] === "Success!" && !empty($result['data'])) {
                $logData = $this->buildBulkParam($result['data']);
                echo "[" . date('Y-m-d H:i:s', $start_time) . ' - ' . date('Y-m-d H:i:s', $end_time) . "]" . $logData . "\n";
                $this->sendByPost("http://" . $this->esHost . "/_bulk", $logData);
            }
        }
    }


    /**
     * 处理日志内容格式转为ES存储
     *
     * @param array $data
     * @return string $paramStr
     */
    private function buildBulkParam(array $data)
    {
        $params = [];
        $indexOper = ["index" => ["_index" => $this->esIndex . date("Y-m-d"), "_type" => $this->esType, "_id" => null]];
        foreach ($data as $tmp) {
            $tmp['start_time'] = gmt_withTZ(strtotime($tmp['start_time']));
            $tmp['end_time'] = gmt_withTZ(strtotime($tmp['end_time']));
            $tmp['last_update'] = gmt_withTZ(strtotime("now"));
            $tmp['status'] = (int)$tmp["status"];
            $tmp['count'] = (int)$tmp["count"];
            $tmp['drop_count'] = (int)$tmp["drop_count"];
            $tmp['size'] = (int)$tmp["size"];
            $tmp['drop_size'] = (int)$tmp["drop_size"];

            $params[] = json_encode($indexOper);
            $params[] = json_encode($tmp);
        }
        $paramStr = implode("\n", $params) . "\n";

        return $paramStr;
    }


    /**
     * 发送请求
     *
     * @param string $url
     * @param $post_data
     * @return string|null  $responses
     */
    private function sendByPost(string $url, $post_data)
    {
        try {
            is_array($post_data) && $post_data = json_encode($post_data);

            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL            => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 30,
                CURLOPT_CUSTOMREQUEST  => "POST",
                CURLOPT_HTTPHEADER     => ["content-type: application/json"],
                CURLOPT_POSTFIELDS     => $post_data,
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);

            if ($err || is_null($response) || empty($response)) {
                return null;
            }

            echo 'Response:' . json_encode($response) . "\n";

            return $response;
        } catch (\Exception $e) {
            echo $e->getMessage() . "\n";

            return null;
        }
    }

}