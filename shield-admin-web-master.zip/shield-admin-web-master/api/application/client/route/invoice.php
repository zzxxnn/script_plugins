<?php

use think\Route;

// 申请开票
Route::post('invoice', 'client/Invoice/create');
// 获取最近的发票信息
Route::get('invoice/latest', 'client/Invoice/showLatest');
// 获取发票申请号
Route::get('invoice/uuid', 'client/Invoice/showUUID');
// 开票详情
Route::get('invoice/:id', 'client/Invoice/show');
// 收到发票
Route::put('invoice/:id/finish', 'client/Invoice/finish');
