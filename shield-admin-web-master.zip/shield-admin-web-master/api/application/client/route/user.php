<?php

use think\Route;

Route::resource('users', 'client/user.Users', ['except' => ['read']]);

Route::get([
    'users/profile' => 'client/user.Users/profile',
    'manage'        => 'client/Manage/get',
]);
Route::post([
    'password/send'  => 'client/user.Password/send',
    'safemail/send'  => 'client/user.Safemail/send',
    'safephone/send' => 'client/user.Safephone/send',
    'user/avatar'    => 'client/user.Avatar/save',
    'users/:code'    => 'client/user.Users/createByAgentCode'
]);
Route::put([
    'password'    => 'client/user.Password/update',
    'safemail'    => 'client/user.Safemail/update',
    'safephone'   => 'client/user.Safephone/update',
    'realname'    => 'client/user.Realname/update',
    'user/avatar' => 'client/user.Avatar/update',
]);
