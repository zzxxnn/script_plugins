<?php

use think\Route;

Route::resource('order','client/Order');