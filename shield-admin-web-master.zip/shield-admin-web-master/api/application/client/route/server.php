<?php

use think\Route;

// Server 实例价格计算
Route::post('server/price', 'client/Servers/serverPrice');
Route::post('server/price/renew', 'client/Servers/renewPrice');

// Server 的基础信息
Route::get('server/config', 'client/Servers/serverConfig');

// 计算购买实例数量是否足够
Route::get('server/quantity', 'client/Servers/computeQuantity');

// 获取实例可接入的地域
Route::get('server/:id/areas', 'client/Servers/serverAreas');

// 获取实例可接入线路
Route::get('server/lines', 'client/Servers/serverLines');

Route::resource('server', 'client/Servers');