<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/3/30
 * Time: 9:29
 */

use think\Route;


//Route::get('test-pay', 'client/Pay/testPay');

Route::post('pay/notify', 'client/Pay/notify');

Route::post('pay/info', 'client/Pay/info');

Route::post('pay/url', 'client/Pay/url');

Route::post('pay/status', 'client/Pay/status');

// 余额支付
Route::post('pay/remaining', 'client/Pay/remaining');

//Route::resource('pay', 'client/Pay');