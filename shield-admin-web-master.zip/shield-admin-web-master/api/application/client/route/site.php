<?php

use think\Route;

// 获取TextCode
Route::get('site/:id/txtcode/', 'client/Site/txtCode');

// 域名接入
Route::post('site/:id/linkup', 'client/Site/linkup');
// 更新域名接入信息
Route::post('site/:id/linkup-update', 'client/Site/updateLinkUp');

// 域名审核
Route::post('site/:id/txtcode-verify', 'client/Site/txtcodeVerify');
// DNS 解析校验
Route::post('site/:id/cname-verify', 'client/Site/cNameVerify');

// 站点https证书上传
Route::post('site/:id/https-cert/upload', 'client/Site/httpsCertUpload');

// 获取站点的证书
Route::post('site/:site/https-cert', 'client/Site/GetHttpsCert');

// 获取站点可接入实例
Route::get('site/:id/instances', 'client/Site/instances');

//------------------------- 缓存加速 START -------------------------------

// 设置站点缓存有效期配置
Route::post('site/:id/cache-expire', 'client/site.Cache/setSiteCacheExpire');

// 获取站点缓存有效期配置
Route::get('site/:id/cache-expire', 'client/site.Cache/getSiteCacheExpire');

// 添加站点缓存白名单
Route::post('site/:id/cache-whitelist', 'client/site.Cache/addSiteCacheWhiteList');

// 获取站点缓存白名单配置
Route::get('site/:id/cache-whitelist', 'client/site.Cache/getSiteCacheWhiteList');

// 移除缓存白名单关键字
Route::delete('site/:id/cache-whitelist', 'client/site.Cache/delSiteCacheWhiteList');

// 获取缓存黑名单
Route::get('site/:id/cache-blacklist', 'client/site.Cache/getSiteCacheBlackList');

// 添加缓存黑名单
Route::post('site/:id/cache-blacklist', 'client/site.Cache/addSiteCacheBlackList');

// 移除站点缓存黑名单关键字
Route::delete('site/:id/cache-blacklist', 'client/site.Cache/delSiteCacheBlackList');


Route::get('site/:id/cache-list', 'client/site.Cache/index');

//------------------------- 缓存加速 END -------------------------------

//------------------------- 黑白名单配置 START -------------------------------
Route::get('site/:id/ip-list', 'client/site.Ip/index');
Route::post('site/:id/ip-list', 'client/site.Ip/save');

//------------------------- 黑白名单配置 END -------------------------------

//------------------------- 报表 START -------------------------------

//网站访问统计
Route::get('site/:id/report/index', 'client/site.Report/index');
//攻击日志
Route::get('site/:id/report/attacks', 'client/site.Report/attacks');

//Route::get('site/:id/report/bandwidth', 'client/site.Report/banWidth');

//------------------------- 报表 END -------------------------------

Route::get('site/:id/proxy-ips', 'client/Site/proxyIps');

// 站点批量删除
Route::delete('site/bundle/delete', 'client/Site/bundleDelete');

// 资源路由
Route::resource('site', 'client/Site');

