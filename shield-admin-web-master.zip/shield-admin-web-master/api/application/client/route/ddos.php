<?php

use think\Route;

Route::post('ddos/:id/active', 'client/DDoS/active');

Route::get('ddos/ips', 'client/DDoS/ips');
//续费
Route::get('ddos/:id/renew/info', 'client/DDoS/renewinfo');

Route::get('ddos/areas', 'client/DDoS/areas');

Route::get('ddos/:id/available-areas', 'client/DDoS/availableAreas');

// 站点批量删除
Route::delete('ddos/bundle/delete', 'client/DDoS/bundleDelete');

//------------------------- 报表 START -------------------------------

Route::get('ddos/:id/report/attacks', 'client/ddos.Report/attacks');

Route::get('ddos/:id/report/bandwidth', 'client/ddos.Report/banWidth');

Route::get('ddos/:id/proxy-ips', 'client/DDoS/proxyIps');

//------------------------- 报表 END -------------------------------

Route::resource('ddos', 'client/DDoS');