<?php

use think\Route;

Route::get([
    'loginfo'       =>  'client/Sessions/index',
]);
Route::post([
    'login'         =>  'client/Sessions/create',
]);
Route::delete([
    'logout'        =>  'client/Sessions/destroy'
]);
