<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/3/28
 * Time: 17:59
 */

use think\Route;

// 生成CName自动调度的CNAME值
Route::post('port/:id/cname-generate', 'client/Port/cnameGenerate');
// 启用CNAME自动调度
Route::post('port/:id/cname-active', 'client/Port/cnameActive');

// 修改应用接入信息
Route::post('port/:id/linkup-update', 'client/Port/updateLinkUp');
// 修改应用信息
Route::post('port/:id/conf-update', 'client/Port/updateConf');

// 获取应用黑白名单
Route::get('port/:id/ip-list', 'client/port.Ip/index');
Route::post('port/:id/ip-list', 'client/port.Ip/save');

// 设置应用黑白名单
Route::post('port/:id/ip-black-list', 'client/Port/setIpBlacklist');
Route::post('port/:id/ip-white-list', 'client/Port/setIpWhitelist');

Route::get('port/:id/proxy-ips', 'client/Port/proxyIps');

// 获取站点可接入实例
Route::get('port/:id/instances', 'client/Port/instances');

// 站点批量删除
Route::delete('port/bundle/delete', 'client/Port/bundleDelete');

//------------------------- 报表 START -------------------------------

Route::get('port/:id/report/attacks', 'client/port.Report/attacks');

Route::get('port/:id/report/bandwidth', 'client/port.Report/banWidth');

//------------------------- 报表 END -------------------------------

// 资源路由
Route::resource('port', 'client/Port');