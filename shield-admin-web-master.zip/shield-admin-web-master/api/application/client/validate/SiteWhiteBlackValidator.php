<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/5/21
 * Time: 10:24
 */

namespace app\client\validate;


class SiteWhiteBlackValidator extends BaseValidator
{
    protected $rule = [
        'urlWhitelist' => 'has|array',                  // URL 白名单
        'urlBlacklist' => 'has|array',                  // URL 黑名单
        'ipBlacklist'  => 'has|array|ipWhiteBlackList', // IP 黑名单
        'ipWhitelist'  => 'has|array|ipWhiteBlackList', // IP 白名单
    ];

    public function messages()
    {
        return [];
    }

    protected $scene = [
        'set_url_whitelist' => ['urlWhitelist'], // 站点URL白名单
        'set_url_blacklist' => ['urlBlacklist'], // 站点URL黑名单
        'set_ip_blacklist'  => ['ipBlacklist'], //  站点IP黑名单
        'set_ip_whitelist'  => ['ipWhitelist'], //  站点IP白名单
    ];

    protected $field = [
        'urlWhitelist' => 'URL白名单',
        'urlBlacklist' => 'URL黑名单',
        'ipWhitelist'  => 'IP白名单',
        'ipBlacklist'  => 'IP黑名单',
    ];

}