<?php

namespace app\client\validate;

use think\Validate;

/**
 * Class ServerPrice 价格生成验证
 *
 * @package app\client\validate
 * @author Teddy Sun <sgsheg@163.com>
 */
class ServerPrice extends Validate
{
    protected $rule = [
        'type'       => 'require|in:1,2,3',
        'sp_num'     => 'require|regex:/^\+?[1-9][0-9]*$/', //todo: 购买数量需要有一个最大值,小于B端添加的总数量
        'sp_time'    => 'require|regex:/^\+?[1-9][0-9]*$/',
        'site_count' => 'regex:/^\+?[1-9][0-9]*$/',
        'instance_id'=> 'require|min:1'
    ];

    protected $field = [
        'type'       => '产品类型',
        'sp_num'     => '购买数量',
        'sp_time'    => '购买时长',
        'site_count' => '防护域名数',
        'instance_id'=> '用户实例的ID'
    ];

    protected $message = [
        'type.require'       => '产品类型必须',
        'type.in'            => '产品类型只能是网站共享、网站独享、应用的一种',
        'sp_num.require'     => '购买数量必须',
        'sp_num.regex'       => '购买数量必须是大于1的正整数',
        'sp_time.require'    => '购买时长必须',
        'sp_time.regex'      => '购买时长必须为大于1的正整数',
        'site_count.require' => '防护域名数必须',
        'site_count.regex'   => '防护域名数必须是大于等于1的正整数',
        'instance_id.require'=> '用户实例的ID必须',
        'instance_id.min'    => '用户实例的ID必须'
    ];

    protected $scene = [
        'search' => ['type', 'sp_num', 'sp_time', 'site_count'],
        'renew'  => ['instance_id', 'sp_time'],
        'upgrade' => ['instance_id'],
    ];
}