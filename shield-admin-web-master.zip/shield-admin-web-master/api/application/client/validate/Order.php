<?php

namespace app\client\validate;

use think\Validate;
use app\common\model\OrderModel;

class Order extends Validate
{
    protected $field = [
        'type'                    => '订单类型',
        'fee'                     => '订单金额',
        'detail'                  => '订单详情',
        'detail.line'             => '实例线路',
        'detail.base_bandwidth'   => '保底防护带宽',
        'detail.bandwidth'        => '弹性防护贷款',
        'detail.sp_time'          => '实例时长',
        'detail.port_count'       => '防护端口数',
        'detail.site_count'       => '防护域名数',
        'detail.sp_num'           => '购买数量',
        'detail.normal_bandwidth' => '业务带宽',
        'id'                      => '订单编号',
        'instance_id'             => '实例ID'
    ];

    protected $rule = [
        'type'                    => 'require|in:' . OrderModel::ORDER_TYPE_RECHARGE . ',' . OrderModel::ORDER_TYPE_PAID . ','
            . OrderModel::ORDER_TYPE_RENEWAL . ',' . OrderModel::ORDER_TYPE_UPGRADE,
        'fee'                     => 'require|gt:0',
        'detail'                  => 'require',
        'detail.product_id'       => 'require|in:0,1,2,3',
        'detail.line'             => 'require|min:1',
        'detail.base_bandwidth'   => 'require',
        'detail.bandwidth'        => 'require',
        'detail.sp_time'          => 'require|min:1',
        'detail.port_count'       => 'require|>=:1',
        'detail.site_count'       => 'require|>=:1',
        'detail.sp_num'           => 'require|integer|min:1',
        'detail.normal_bandwidth' => 'require|integer|min:1',
        'id'                      => 'require',
        'instance_id'             => 'require'
    ];

    protected $scene = [
        'site_paid_order' => ['type', 'fee', 'detail', 'detail.product_id'],
        'port_paid_order' => ['type', 'fee', 'detail', 'detail.product_id'],
        'recharge_order'  => ['type', 'fee', 'detail', 'detail.product_id'],
        'delete_order'    => ['id'],
        'show_order'      => ['id'],
        'order_type'      => ['type'],
        'create_order'    => ['type', 'fee'],
        'renew_order'     => ['instance_id', 'sp_time', 'fee'],
        'instance_order'  => ['type', 'fee', 'detail', 'detail.product_id'],
    ];
}
