<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/3/29
 * Time: 17:14
 */

namespace app\client\validate;


use app\common\model\OrderModel;
use think\Validate;

class Pay extends Validate
{

    protected $rule = [
        'order_id' => 'require|min:10',
        'orderId' => 'require|min:10',
        'payType' => 'require|in:' . OrderModel::ORDER_PAY_TYPE_ALIPAY . ',' . OrderModel::ORDER_PAY_TYPE_WX . ','
            . OrderModel::ORDER_PAY_TYPE_REMAINNING
    ];

    protected $message = [];

    protected $field = [
        'order_id' => '订单编号',
        'orderId' => '订单编号',
    ];

    protected $scene = [
        'pay' => ['order_id'],
        'status' => ['orderId'],
        'info' => ['orderId'],
        'url' => ['orderId'],
        'remaining' => ['orderId'],
    ];

    public function orderExist($value, $rule, $data)
    {
        try {
            $order = (new OrderModel)->esGetById($value);

            return $order ? true : '订单' . $value . '不存在';
        } catch (\Exception $e) {
            return '订单' . $value . '不存在';
        }

    }

}