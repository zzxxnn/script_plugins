<?php

namespace app\client\validate;

use think\Validate;

class User extends Validate
{

    protected $rule = [
        'email'     => 'require|email',
        'password'  => 'require',
        'captcha'   => 'require',
        'mobile'    => 'require|mobile',
        'token'     => 'require',
        'old_pwd'   => 'require',
        'new_pwd'   => 'require|password',
        'real_name' => 'require',
        'id_number' => 'require',
        'safemail'  => 'require|email',
        'safephone' => 'require|mobile',

    ];

    protected $message = [
        'email.require'     => '11000|邮箱不能为空',
        'email.email'       => '11000|邮箱格式错误',
        'password.require'  => '11000|密码不能为空',
        'captcha.require'   => '11000|验证码不能为空',
        'mobile.require'    => '11000|手机号不能为空',
        'mobile.mobile'     => '11003|手机号格式错误',
        'token.require'     => '11000|token不能为空',
        'old_pwd.require'   => '11000|原密码不能为空',
        'new_pwd.require'   => '11000|新密码不能为空',
        'new_pwd.password'  => '11002|新密码强度不够',
        'real_name.require' => '11000|真实姓名不能为空',
        'id_number.require' => '11000|身份证号不能为空',
        'safemail.require'  => '11000|安全邮箱不能为空',
        'safemail.email'    => '11001|安全邮箱格式错误',
        'safephone.require' => '11000|安全电话不能为空',
        'safephone.mobile'  => '11003|安全电话格式错误',
    ];

    protected $scene = [
        'login'                 => [ 'email', 'password', 'captcha' ],
        'register'              => [ 'email', 'password', 'mobile', 'captcha' ],
        'password_send'         => [ 'email', 'captcha' ],
        'password_token_update' => [ 'email', 'token', 'new_pwd' ],
        'password_update'       => [ 'old_pwd', 'new_pwd' ],
        'realname'              => [ 'real_name', 'id_number', 'captcha' ],
        'safemail_send'         => [ 'safemail' ],
        'safemail_update'       => [ 'safemail', 'token' ],
        'safephone_send'        => [ 'safephone' ],
        'safephone_update'      => [ 'safephone', 'token' ],
    ];

    protected function mobile($value)
    {
        return is_cellphone_number($value);
    }

    protected function password($value)
    {
        return is_correct_password($value);
    }
}
