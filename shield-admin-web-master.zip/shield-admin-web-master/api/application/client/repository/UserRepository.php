<?php

namespace app\client\repository;

use app\client\model\UserModel;

class UserRepository extends BaseRepository
{
    public function __construct()
    {
        $this->model = new UserModel();
    }

    /**
     * 根据用户邮箱查找用户
     *
     * @param $email
     * @return null|string
     * @throws \Exception
     */
    public function selectUserById($email)
    {
        return $this->model->esGetById($email);
    }

    /**
     * 创建用户
     *
     * @param $user_info
     * @return bool
     * @throws \Exception
     */
    public function insertUser($user_info): bool
    {
        $id   = $user_info['email'];
        $data = $this->model->esAdd($user_info, $id);
        if ($data === false) {
            return false;
        }

        return 'created' === $data['result'];
    }

    /**
     * 更新用户信息
     *
     * @param array $user_info
     * @param $id
     * @return Boolean
     * @throws \Exception
     */
    public function updateUser($user_info, $id): bool
    {
        $data = $this->model->esUpdateById($user_info, $id);
        if ($data === false) {
            return false;
        }

        return 'updated' === $data['result'];
    }

    /**
     * 根据某列搜索用户信息
     *
     * @param $filter
     * @return array
     * @throws \Exception
     */
    public function searchByFilter($filter): array
    {
        $filter = [
            'query' => [
                'match' => $filter
            ]
        ];

        return $this->model->esSearch($filter);
    }
}
