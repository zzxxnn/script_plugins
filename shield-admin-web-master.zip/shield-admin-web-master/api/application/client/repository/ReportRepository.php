<?php

namespace app\client\repository;


use app\client\model\AttackLog;
use app\client\model\FlowModel;
use app\client\model\HDFlowLogModel;
use app\client\model\WebLog;
use Carbon\Carbon;

class ReportRepository extends BaseRepository
{
    protected $attackLogModel;

    protected $webLogModel;

    public function __construct()
    {
        $this->attackLogModel = new AttackLog();
        $this->webLogModel = new WebLog();
    }

    /**
     * @param null $startTime
     * @param null $endTime
     * @return array
     */
    public function getWebAggs($startTime = null, $endTime = null, $count=200)
    {
        !$endTime && $endTime = time();
        // 根据查询的开始时间和结束时间，确定聚合的Interval
        $quickTime = $this->caclAggsIntervalByTime($startTime, $endTime, $count);

        $aggs = [
            'group_by_state' => [
                'date_histogram' => [
                    'field'         => 'timestamp',
                    'interval'      => $quickTime,
                    'format'        => 'yyyy-MM-dd HH:mm:ss',
                    'min_doc_count' => 0,
                    'extended_bounds' => [
                        'min' => date('Y-m-d H:i:s', $startTime),
                        'max' => date('Y-m-d H:i:s', $endTime)
                    ],
                    'time_zone' => '+08:00'
                ],
                'aggs'           => [
                    'total_flow'         => [
                        'sum' => [
                            'field' => 'bytes_sent',            //流量
                        ]
                    ],
                    'total_requests'     => [
                        'value_count' => [
                            'field' => 'request_time',           //访问时间
                        ]
                    ],
                    'distinct_client_ip' => [                   // 网站浏览人数
                        'cardinality' => [
                            'field' => 'client_ip.keyword',     //访问ip
                        ]
                    ]
                ]
            ],
            'total_flow'         => [                   // 总流量
                'sum' => [
                    'field' => 'bytes_sent',            //流量
                ]
            ],
            'total_requests'     => [                   // 总请求次数
                'value_count' => [
                    'field' => 'request_time',          //访问时间
                ]
            ],
            'distinct_client_ip' => [                   // 网站浏览人数
                'cardinality' => [
                    'field' => 'client_ip.keyword',     //访问ip
                ]
            ]
        ];

        return ['agg' => $aggs, 'interval' => $quickTime];
    }

    /**
     * 获取攻击次数和攻击总数
     *
     * @return array
     */
    public function getAttackType()
    {
        $aggs = [
            'distinct_attract_type'  => [
                'cardinality' => ['field' => 'attack-type'],
            ],
            'distinct_attract_count' => [
                'cardinality' => ['field' => '_id'],
            ]
        ];

        return $aggs;
    }

    /**
     * 制作flow数据表中的聚合
     *
     * @param null $startTime
     * @param null $endTime
     * @param integer $count
     * @return array
     */
    public function getAttackFlow($startTime = null, $endTime = null, $count = 200): array
    {
        !$endTime && $endTime = time();
        // 根据查询的开始时间和结束时间，确定聚合的Interval
        $interval = $this->caclAggsIntervalByTime($startTime, $endTime, $count);

        $aggs = [
            'size_detail'            => [
                'date_histogram' => [
                    'field'           => 'timestamp',
                    'interval'        => $interval,
                    'format'          => 'yyyy-MM-dd HH:mm:ss',
                    'min_doc_count'   => 0,
                    'extended_bounds' => [
                        'min' => date('Y-m-d H:i:s', $startTime),
                        'max' => date('Y-m-d H:i:s', $endTime)
                    ],
                    'time_zone'       => '+08:00'
                ],
                'aggs'           => [
                    'in_every_10s' => [
                        'date_histogram' => [
                            'field' => 'timestamp',
                            'interval' => '5s',
                        ],
                        'aggs' => [
                            'max_bps_sum' => [
                                'sum' => ['field' => 'max-bps',]
                            ],
                            'max_bps_after_sum' => [
                                'sum' => ['field' => 'max-bps-after']
                            ],
                            'max_pps_sum' => [
                                'sum' => ['field' => 'max-pps']
                            ],
                            'max_pps_after_sum' => [
                                'sum' => ['field' => 'max-pps-after']
                            ],
                        ]
                    ],
                    'max_bps' => [
                        'max_bucket' => ['buckets_path' =>'in_every_10s>max_bps_sum']
                    ],
                    'max_bps_after' => [
                        'max_bucket' => ['buckets_path' =>'in_every_10s>max_bps_after_sum']
                    ],
                    'max_pps' => [
                        'max_bucket' => ['buckets_path' =>'in_every_10s>max_pps_sum']
                    ],
                    'max_pps_after' => [
                        'max_bucket' => ['buckets_path' =>'in_every_10s>max_pps_after_sum']
                    ]
                ]
            ],
            'avg_max_bps' => [
                'avg_bucket' => [
                    'buckets_path' => 'size_detail>max_bps'
                ]
            ],
            'avg_max_bps_after' => [
                'avg_bucket' => [
                    'buckets_path' => 'size_detail>max_bps_after'
                ]
            ],
            'avg_max_pps' => [
                'avg_bucket' => [
                    'buckets_path' => 'size_detail>max_pps'
                ]
            ],
            'avg_max_pps_after' => [
                'avg_bucket' => [
                    'buckets_path' => 'size_detail>max_pps_after'
                ]
            ],
            'max_bps' => [
                'max_bucket' => [
                    'buckets_path' => 'size_detail>max_bps'
                ]
            ]
        ];

        return $aggs;
    }

    /**
     * 获取攻击次数和攻击种类
     *
     * @param $filter
     * @return array
     * @throws \Exception
     */
    public function getAttackRecord($filter): array
    {
        $attackRecord = (new AttackLog())->esAggsSearch($filter, 0, 20);
        //\think\log::record(['attack' => $attackRecord], 'info');
        $attack = $attackRecord['aggs'] ?? [];
        $attackRecords = $attackRecord['hits'] ?? [];
        if ($attackRecords) {
            foreach ($attackRecords as &$attackRecord) {
                $attackRecord['attack-type'] = AttackLog::attackType[$attackRecord['attack-type']];
                $attackRecord['time'] = format_time(strtotime($attackRecord['time']));
            }
            unset($attackRecord);
        }
        // 攻击类型和攻击次数
        $attackCount = $attack['distinct_attract_count']['value'] ?? 0;
        $attackTypeCount = $attack['distinct_attract_type']['value'] ?? 0;

        return compact('attackCount', 'attackTypeCount','attackRecords');
    }

    /**
     * @param $filter
     * @return array
     * @throws \Exception
     */
    public function getAttackFlowRecord($filter): array
    {
        $attackRecord = (new FlowModel())->esAggsSearch($filter, 0, 0);
        $attack = $attackRecord['aggs'] ?? [];
        //调整数据
        $attacks = $this->processSizeDetailNewAggs($attackRecord['aggs']['size_detail'] ?? []);
        $gjTotal = $attack['avg_max_bps']['value'] ?? 0;             // 攻击流量
        $lhTotal = $attack['avg_max_bps_after']['value'] ?? 0;        // 滤后流量
        $glTotal = ($gjTotal - $lhTotal) ?? 0;
        $sjbTotal = $attack['avg_max_pps']['value'] ?? 0;             // 数据包总计
        $glsjbTotal = $attack['avg_max_pps_after']['value'] ?? 0;     // 过滤数据包总计
        $maxBps = $attack['max_bps']['value'] ?? 0;

        return compact('attacks', 'gjTotal', 'glTotal', 'lhTotal', 'sjbTotal', 'glsjbTotal', 'maxBps');
    }

    /**
     * 获取网站访问流量
     *
     * @param $filter
     * @param string $interval 3m
     * @return array
     * @throws \Exception
     */
    public function getWebLogTrend($filter, $interval = '3m')
    {
        // 聚合查询所有攻击日志
        $webLogs = $this->webLogModel->esAggsSearch($filter, 0, 0);

        $webLogsAggs = $webLogs['aggs'];
        // 传入平均峰值interval
        $webs = $this->webLogAggs(($webLogsAggs['group_by_state'] ?? []), $interval);

        $totalFlow = 0;
        if (isset($webLogsAggs['total_flow'])) {
           $totalFlow  = format_bytes($webLogsAggs['total_flow']['value']) ?? 0; 
        }
        
        $totalReq   = $webLogsAggs['total_requests']['value'] ?? 0;
        $totalVisit = $webLogsAggs['distinct_client_ip']['value'] ?? 0;

        // 对聚合字段进行过滤
        return compact('webs', 'totalFlow', 'totalReq', 'totalVisit');
    }

    /**
     * 将QuickTime格式（1:min|1:hour）解析为：
     * [
     *  'startTime' => 1234567890
     *  'endTime' => 1234567890
     * ]
     * @param null $quickTime
     * @return array
     */
    public function parseQuickTime($quickTime = null)
    {
        $endTime = $startTime = null;

        if ($quickTime) {
            $endTime = Carbon::now();
            list($num, $unit) = explode(':', $quickTime);
            switch ($unit) {
                case 'hour':
                    $startTime = $endTime->subHours($num)->timestamp;
                    break;
                case 'min':
                    $startTime = $endTime->subMinutes($num)->timestamp;
                    break;
                default:
                    $startTime = $endTime->subMinutes($num)->timestamp;
                    break;
            }
        }
        // 转化为时间戳
        $endTime = $endTime->timestamp;

        return compact('startTime', 'endTime');
    }

    /**
     * @param null $startTime
     * @param null $endTime
     * @return array
     */
    public function getBWFilterAggs($startTime = null, $endTime = null, $count=200)
    {
        !$endTime && $endTime = time();
        // 根据查询的开始时间和结束时间，确定聚合的Interval
        $interval = $this->caclAggsIntervalByTime($startTime, $endTime, $count);

        $aggs = [
            'bandwidth' => [
                'date_histogram' => [
                    'field'           => 'timestamp',
                    'interval'        => $interval,
                    'format'          => 'yyyy-MM-dd HH:mm:ss',
                    'min_doc_count'   => 0,
                    'extended_bounds' => [
                        'min' => date('Y-m-d H:i:s', $startTime),
                        'max' => date('Y-m-d H:i:s', $endTime)
                    ],
                    'time_zone' => '+08:00'
                ],
                'aggs'           => [
                    'in_every_10s' => [
                        'date_histogram' => [
                            'field' => 'timestamp',
                            'interval' => '5s',
                        ],
                        'aggs' => [
                            'up_sum' => [
                                'sum' => ['field' => 'max-up',]
                            ],
                            'down_sum' => [
                                'sum' => ['field' => 'max-down']
                            ],
                            'session_sum' => [
                                'sum' => ['field' => 'session']
                            ]
                        ]
                    ],
                    'max_up' => [
                        'max_bucket' => ['buckets_path' =>'in_every_10s>up_sum']
                    ],
                    'max_down' => [
                        'max_bucket' => ['buckets_path' =>'in_every_10s>down_sum']
                    ],
                    'max_session' => [
                        'max_bucket' => ['buckets_path' =>'in_every_10s>session_sum']
                    ]
                ]
            ],
        ];

        return $aggs;
    }

    /**
     * @param $filter
     * @return array
     * @throws \Exception
     */
    public function getBWTrend($filter)
    {
        $bwTrend = (new HDFlowLogModel())->esAggsSearch($filter, 0, 0);
        $logs = $this->processBandWidth($bwTrend['aggs']['bandwidth'] ?? []);
        $maxData = $this->getMaxBandWidth($bwTrend['aggs']['bandwidth'] ?? []);

        $maxIn = $maxData['maxIn'] ?? 0;
        $maxOut = $maxData['maxOut'] ?? 0;

        return compact('logs', 'maxIn', 'maxOut');
    }

    /**
     * 过滤网站访问日志
     *
     * @param $aggs
     * @return array
     */
    private function webLogAggs($aggs = [], $interval)
    {
        $result = [];

        foreach ($aggs['buckets'] ?? [] as $sizeDetail) {
            $result[] = [
                'time'           => $sizeDetail['key_as_string'],
                'total_flow'     => $sizeDetail['total_flow']['value'] ?? 0,                //流量峰值
                'total_requests' => $sizeDetail['total_requests']['value'] ?? 0,            //总请求数
                'total_ip'       => $sizeDetail['distinct_client_ip']['value'] ?? 0,        //ip数字
            ];
        }

        return $result;
    }

    /**
     * @param array $sizeDetailAggs
     * @return array
     */
    private function processSizeDetailNewAggs($sizeDetailAggs = [])
    {
        $result = [];
        foreach ($sizeDetailAggs['buckets'] ?? [] as $sizeDetail) {
            $result[] = [
                'time'  => $sizeDetail['key_as_string'],
                'gjMax' => $sizeDetail['max_bps']['value'] ?? 0,
                'lhMax' => $sizeDetail['max_bps_after']['value'] ?? 0,
            ];
        }

        return $result;
    }

    /**
     * 根据开始时间和结束时间，获取需要聚合的时间间隔
     * [规则: 24小时2m,其他10s]
     *
     * @param $startTime
     * @param $endTime
     * @param $count
     * @return string
     */
    private function caclAggsIntervalByTime($startTime, $endTime, $count)
    {
        $endTime     = Carbon::createFromTimestamp($endTime);
        $startTime   = Carbon::createFromTimestamp($startTime);
        $diffSeconds = $endTime->diffInSeconds($startTime);

        $interval = (int) ($diffSeconds / $count / 10) * 10;

        return $interval > 10 ? $interval.'s' : '10s';
    }

    /**
     * 处理每10s中最大的连接数、流入流量、流出流量
     *
     * @param array $logs
     * @return array
     */
    private function processBandWidth($logs = [])
    {
        $result = [];
        foreach ($logs['buckets'] ?? [] as $sizeDetail) {
            $result[] = [
                'time'     => $sizeDetail['key_as_string'],
                'inMax'    => $sizeDetail['max_up']['value'] ?? 0,              // IN峰值
                'outMax'   => $sizeDetail['max_down']['value'] ?? 0,            // OUT峰值
                'connsMax' => $sizeDetail['max_session']['value'] ?? 0,         // 总连接数
            ];
        }

        return $result;
    }

    /**
     * @param array $logs
     * @return array
     */
    private function getMaxBandWidth($logs = [])
    {
        $maxUpArray = $maxDownArray = [];

        foreach ($logs['buckets'] ?? []  as $bucket) {
            //10s内最大流入和最大流出
            $maxUpArray[] = $bucket['max_up']['value'];
            $maxDownArray[] = $bucket['max_down']['value'];
        }

        $maxIn = max($maxUpArray);
        $maxOut = max($maxDownArray);

        return ['maxIn' => $maxIn, 'maxOut' => $maxOut];
    }
}