<?php

namespace app\client\repository;

use app\client\model\ProxyNodeInfoModel;
use app\client\model\ServerModel;
use app\client\model\UserInstanceModel;
use app\client\service\Auth;
use app\common\model\OrderModel;
use app\common\model\ProductModel;
use app\common\model\ProductSkuModel;
use app\common\model\SiteModel;
use Carbon\Carbon;

class ServerRepository extends BaseRepository
{
    protected $orderModel;

    protected $instanceModel;

    protected $proxyNodeInfoModel;

    protected $productModel;

    protected $productSkuModel;

    public function __construct()
    {
        $this->model = new ServerModel();

        $this->orderModel = new OrderModel();

        $this->proxyNodeInfoModel = new ProxyNodeInfoModel();

        $this->instanceModel = new UserInstanceModel();

        $this->productModel = new ProductModel();

        $this->productSkuModel = new ProductSkuModel();
    }

    /*** 计算价格
     *
     * @param $serverInfo
     * @return float|int
     */
    public function calcSiteServerPrice($serverInfo)
    {
        $amount      = 0;
        try {
            $product                         = $this->productModel->esGetById($serverInfo['product_id']);
            $filter['query']['bool']['must'] = [ 'term' => [ 'price_id' => $serverInfo['product_sku_id'] ] ];
            $product_skus                    = $this->productSkuModel->esSearch($filter, 0, 1);
            $product_sku                     = [];
            if ($product_skus) {
                $product_sku = $product_skus[0];
            }
            $product_attributes = [];
            if ($product && isset($product['attributes']) && !empty($product['attributes'])) {
                // 循环属性，拿出需计费的属性，分叠加计费和倍率计费的属性
                $typeArray = [ProductModel::PRODUCT_ATTRIBUTE_TYPE_DISCRETE, ProductModel::PRODUCT_ATTRIBUTE_TYPE_AFTER_USE_CHARGE];
                foreach ($product['attributes'] as $attribute) {
                    if (!\in_array($attribute['type'], $typeArray)) {
                        // 离散属性和用后计费属性不需计算费用
                        $product_attributes[] = array_merge($attribute, ['value' => $serverInfo[$attribute['name']]]);
                    }
                }
            }

            if ($product_attributes && $product_sku) {
                $amount = $this->getProductPrice($product_attributes, $product_sku);
            }

            return $amount;
        } catch (\Exception $e) {
            return $amount;
        }
    }

    /**
     * 计算实例续费价格
     *
     * @param array $data 表单数据
     * @param array $instance 实例数据
     * @param string $type renew续费|upgrade升级
     * @return float|boolean|int
     * @throws \Exception
     */
    public function calcRenewServerPrice($data, $type = 'renew', $instance = null)
    {
        //实例id
        $instanceId = $data['instance_id'];
        if (empty($instance)) {
            $instance = $this->instanceModel->esGetById($instanceId);
        }
        // 查找实例来源订单
        // todo: 当一个实例先购买，然后在升级，然后再续费时，getFreshestOrderByInstanceId将获取的是最新的升级的订单。这样计算出来的价格是不对的,请注意修改！
        $userOrder = (new OrderRepository())->getFreshestOrderByInstanceId($instanceId);
        if (! $userOrder) {
            return false;
        }
        //续费
        if ('renew' === $type) {
            //实例时长
            $renewSpTime = $data['sp_time'] ?? 1;
            if ($this->checkInstanceAllowRenew((int)$renewSpTime, $instance)) {
                $unitPrice = $this->getPriceFromOldOrder($userOrder);
                //todo:对单价进行处理
                $unitPrice = number_format((float)$unitPrice, 2, '.', '');
                if ($unitPrice) {
                    return $unitPrice * $renewSpTime;
                }
            } else {
                return false;
            }
        } else {
            //检查升级日期
            if (isset($data['detail']['sp_time'])) {
                $renewSpTime = $data['detail']['sp_time'] - $instance['sp_time'];
                if (! $this->checkInstanceAllowRenew((int)$renewSpTime, $instance)) {
                    return false;
                }
            }

            //找到按商品
            if (isset($userOrder['product_id'])) {
                $product = $this->productModel->esGetById($userOrder['product_id']);
                if (! $product) {
                    return false;
                }
                if (!isset($userOrder['product_sku_id'])) {
                    return false;
                }
                $filter['query']['bool']['must'] = [ 'term' => [ 'price_id' => $userOrder['product_sku_id'] ] ];
                //找到sku
                $productSkus  = $this->productSkuModel->esSearch($filter, 0, 1);
                if ($productSkus) {
                    $product_sku = $productSkus[0];
                }

                //todo: 根据当前实例计算当前价格:
                $fee = $this->getCurrentInstance($userOrder, $product_sku, $instanceId);
                if (!$fee) {
                    return false;
                }
                $attributes = $userOrder['detail']['attributes'] ?? null;
                if ($attributes) {
                    //todo:处理site_count 临时允许只操作数量为1
                    if (isset($data['detail']['site_count'])) {
                        $data['detail']['site_count'] = 1;
                    }
                    //根据目前的属性计算出来对应的价格按照目前的倍率.
                    $attributes = $this->checkAttributes($attributes, $data);
                    if ($attributes) {
                        $oldAmount  = $this->getUpgradeAmount($attributes, $product_sku, $data);
                        //差价返回
                        $diff = $oldAmount - $fee;
                        if  ($diff && $diff > 0) {
                            return $diff;
                        } else {
                            return '0.00';
                        }
                    }
                    return false;
                }
            }
            return false;
        }
    }

    /**
     * 获取用户实例
     * @param null $line
     * @param null $type
     * @return array
     * @throws \Exception
     */
    public function getUserServer($line = null, $type = null)
    {
        $filter = [
            'query' => [
                'bool' => [
                    'must' => [
                        [
                            'term' => [ //需要是当前用户
                                'uid.keyword' => Auth::id()
                            ]
                        ],
                        [
                            'term' => [ // 订单需要是消费订单
                                'type' => OrderModel::ORDER_TYPE_PAID,
                            ],
                        ],
                        [
                            'term' => [ // 订单需要是已支付状态
                                'status' => OrderModel::ORDER_STATUS_PAID,
                            ]
                        ],
                        [
                            'term' => [ // 实例的有效期需要大于当前时间
                                'status' => OrderModel::ORDER_STATUS_PAID,
                            ]
                        ]
                    ],
                    'must_not' => [
                        'term' => [ // 已分配高防IP
                            'detail.hd_ip.keyword' => ''
                        ]
                    ]
                ]
            ]
        ];

        if ($line != null && $line != '') {
            $filter['query']['bool']['must'][] = ['term' => ['detail.line' => $line]];
        }

        if ($type != null && $type != '') {
            $filter['query']['bool']['must'][] = ['term' => ['detail.product_id' => $type]];
        }

        $_result = $this->orderModel->esSearch($filter);

        $result = [];
        foreach ($_result as $key => $order) {
            if (empty($order['detail'])) {
                continue;
            }

            $result[] = [
                'type' => $order['detail']['product_id'],
                'hd_ip' => $order['detail']['hd_ip'],
                'line' => $order['detail']['line']
            ];
        }

        return $result;
    }

    /**
     * 获取系统可分配实例
     * @param $type 1 独享型，2 共享型，3 非站点型
     * @param $line
     * @param null $count
     * @return array
     * @throws \Exception
     */
    public function getAvailableServerList($type = null, $line = null, $count = null)
    {
        if ($type == SiteModel::DOMAIN_TYPE_SINGLE) {
            // 独享型
            $list = $this->getSignalServerList($line, $count);
        } elseif ($type == SiteModel::DOMAIN_TYPE_SHARED) {
            // 共享型
            $list = $this->getSharedServerList($line, $count);
        } elseif ($type == SiteModel::DOMAIN_TYPE_PORT) {
            // 非网站类型
            $list = $this->getPortServerList($line, $count);
        } else {
            // 所有类型
            $list = $this->getServerList($line);
        }

        return $list;
    }

    /**
     * 获取所有类型的可分配实例
     *
     * @param null $line
     * @param $count
     * @return array
     * @throws \Exception
     */
    public function getServerList($line = null, $count)
    {
        $filter = [
            'query' => [
                'bool' => [
                    'must' => []
                ]
            ]
        ];


        if ($line) {
            $filter['query']['bool']['must'][] = ['term' => ['line' => $line]];
        }

        return $this->model->esSearch($filter, 0, $count);
    }

    /**
     * 获取独享型可用实例列表
     * @param null $line
     * @param $count
     * @return array
     * @throws \Exception
     */
    public function getSignalServerList($line = null, $count)
    {
        $filter = [
            'query' => [
                'bool' => [
                    'must' => [
                        [
                            'term' => [
                                'user_count' => '0',
                            ],
                        ],
                        [
                            'term' => [
                                'type' => SiteModel::DOMAIN_TYPE_SINGLE,
                            ],
                        ],
                    ]
                ]
            ]
        ];

        if ($line) {
            $filter['query']['bool']['must'][] = ['term' => ['line' => $line]];
        }

        return $this->model->esSearch($filter, 0, $count);
    }

    /**
     * 获取共享型实力列表
     * @param null $line
     * @param $count
     * @return array
     * @throws \Exception
     */
    public function getSharedServerList($line = null, $count)
    {
        $filter = [
            'query' => [
                'bool' => [
                    'must' => [
                        [
                            'term' => [
                                'type' => SiteModel::DOMAIN_TYPE_SHARED,
                            ],
                        ],
                    ]
                ]
            ]
        ];

        if ($line) {
            $filter['query']['bool']['must'][] = ['term' => ['line' => $line]];
        }

        return $this->model->esSearch($filter, 0, $count);
    }

    /**
     * 获取非网站类型实例列表
     *
     * @param null $line
     * @param $count
     * @return array
     * @throws \Exception
     */
    public function getPortServerList($line = null, $count)
    {
        $filter = [
            'query' => [
                'bool' => [
                    'must' => [
                        [
                            'term' => [
                                'type' => SiteModel::DOMAIN_TYPE_PORT,
                            ],
                        ],
                    ]
                ]
            ]
        ];
        if ($line) {
            $filter['query']['bool']['must'][] = ['term' => ['line' => $line]];
        }

        return $this->model->esSearch($filter, 0, $count);
    }

    /**
     * 更新高仿节点的介入信息
     * @param $id
     * @param int $count
     * @return bool
     * @throws \Exception
     */
    public function updateServerUserCount($id, $count = 1)
    {
        $server = $this->model->esGetById($id);
        if (!$server) {
            return false;
        }

        // 高仿节点介入用户数增加
        $userCount = (int)(isset($server['user_count']) ? $server['user_count'] : 0);
        $data = ['user_count' => $userCount + $count];

        // 高仿节点接入站点数增加
        if (in_array($server['type'], [ServerModel::SERVER_TYPE_WEB_ALONE, ServerModel::SERVER_TYPE_WEB_SHARED])) {
            $siteCount = (int)(isset($server['site_count']) ? $server['site_count'] : 0);
            $data['site_count'] = $siteCount + $count;
        }

        // 高仿节点接入端口数增加
        if ($server['type'] == ServerModel::SERVER_TYPE_WEB_PORT) {
            $portCount = (int)(isset($server['port_count']) ? $server['port_count'] : 0);
            $data['port_count'] = $portCount + $count;
        }

        $result = $this->model->esUpdateById($data, $id);

        return $result ? true : false;
    }

    /**
     * 获取实例可接入的地域
     * @param $line
     * @param $type
     * @return array
     */
    public function getServerAvailableAreas($line, $type)
    {
        try {
            $must = [
                ['term' => ['line_type' => $line]],
                ['term' => ['node_type' => $type]],

            ];
            $filter = ['query' => ['bool' => ['must' => $must]]];
            $nodes = $this->proxyNodeInfoModel->esSearch($filter);

            $areas = [];
            $instanceAreas = UserInstanceModel::$instanceAreas;
            foreach ($nodes as $key => $node) {
                $areas[] = ['value' => $node['area'], 'text' => $instanceAreas[$node['area']]];
            }

            return $areas;
        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * 获取实例接入线路
     * @return array
     */
    public function getServerLines()
    {
        $lines = [];
        $_lines = UserInstanceModel::$instanceLines;
        foreach ($_lines as $key => $line) {
            $lines[] = ['value' => $key, 'text' => $line];
        }

        return $lines;
    }

    /**
     * 获取 未被购买 的网站独享节点、应用类节点，和未达到网站上限的共享网站类高防节点
     *
     * @return array
     */
    public function getProxyNodesInfo()
    {
        // try {
        $filter = [
                'query'=>[
                    'bool'=>[
                        'should'=>[
                            [
                                'bool'=>[
                                    'must'=>[
                                        'term' =>[
                                            'node_type' => ProxyNodeInfoModel::PROXY_NODE_TYPE_SINGLE // 用户数为0的独享高防节点
                                        ],
                                        'term' =>[
                                            'user_count' => 0
                                        ],
                                    ]
                                ]
                            ],
                            [
                                'bool'=>[
                                    'must'=>[
                                        'term' =>[
                                            'node_type' => ProxyNodeInfoModel::PROXY_NODE_TYPE_SINGLE // 用户数为0的应用高防节点
                                        ],
                                        'term' =>[
                                            'user_count' => 0
                                        ],
                                    ]
                                ]
                            ],
                            [
                                'bool'=>[
                                    'must'=>[
                                        'term'=>[
                                            'node_type' => ProxyNodeInfoModel::PROXY_NODE_TYPE_SHARED // 共享高防节点
                                        ]
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            ];
        $from = 0;
        $size = 10000;

        $proxy_info = $this->proxyNodeInfoModel->esSearch($filter, $from, $size);
        if (empty($proxy_info)) {
            return [];
        }

        // 过滤掉已经到达网站接入上限的高防节点
        foreach ($proxy_info as $key => &$info) {
            if ($info['node_type'] === ProxyNodeInfoModel::PROXY_NODE_TYPE_SHARED) {
                $site_count_limit = $info['site_limit'];
                $site_count_used = $this->getUserInstanceSiteCount($info['node_id']);
                if ($site_count_limit > $site_count_used) {
                    $info['site_left'] = $site_count_limit - $site_count_used;
                } else {
                    unset($proxy_info[$key]);
                }
            }
        }
        unset($info);

        $proxy_info = array_map(function ($info) {
            $tmp = [
                'line_type' => $info['line_type'],
                'node_type' => $info['node_type']
            ];
            if (isset($info['site_left'])) {
                $tmp['site_left'] = $info['site_left'];
            }
            return $tmp;
        }, $proxy_info);

        return array_values($proxy_info);
        // } catch (\Exception $e) {
        //     return [];
        // }
    }

    public function getUserInstanceSiteCount($proxy_id)
    {
        // try {
        $from = 0;
        $size = 10000;
        $filter = ['query'=>['bool'=>['filter'=>['term'=>['node_id.keyword'=>$proxy_id]]]]];
        $site_count = 0;

        $instances = $this->instanceModel->esSearch($filter, $from, $size);
        if (empty($instances)) {
            return $site_count;
        }

        foreach ($instances as $each) {
            $site_count += $each['site_count'];
        }

        return $site_count;

        // } catch (Exception $e) {
        //     return 0;
        // }
    }

    /**
     * 获取所有的商品
     *
     * @param array $filter
     * @param int   $from
     * @param null  $size
     *
     * @return array
     * @throws \Exception
     */
    public function getProductList($filter = [], $from = 0, $size = null)
    {
        $products = $this->productModel->esAggsSearch($filter, $from, $size);
        if ($products) {
            return $products;
        }
        return [];
    }

    /**
     * 获取在售商品
     *
     * @param array $filter
     * @param int   $from
     * @param null  $size
     *
     * @return array
     * @throws \Exception
     */
    public function getSaleProductList($filter = [], $from = 0, $size = null)
    {
        $filter      = [
            "query" => [
                "bool" => [
                    "must" => [
                        [
                            "term" => [
                                "on_sale" => ProductModel::PRODUCT_ON_SALE
                            ]
                        ]
                    ]
                ]
            ],
            "sort" => [
                "product_id" => ["order" => "asc"]
            ]
        ];
        $products = $this->productModel->esSearch($filter, $from, $size);
        if ($products) {
            return $products;
        }
        return [];
    }


    /**
     * 根据商品ID(product_id)查找商品定价
     *
     * @param $id
     *
     * @return array
     * @throws \Exception
     */
    public function getProductSkuByProductId($id)
    {
        $filter['query']['bool']['must'][] = ['term' => ['product_id' => $id]];

        return $this->model->esSearch($filter, 0, 1);
    }

    private function getPriceFromOldOrder($userOrder)
    {
        $spTimeValue = 0; // 时长
        $spTimePrice = 0; // 时长费率
        $spNumValue = 0; // 购买数量
        if (isset($userOrder['detail']['attributes'])) {
            foreach ($userOrder['detail']['attributes'] as $tmp) {
                if ($tmp['name'] === 'sp_time') {
                    $spTimeValue = $tmp['value'];
                    if (isset($tmp['price'])) {
                        $spTimePrice = $tmp['price'];
                    }
                }
                if ($tmp['name'] === 'sp_num') {
                    $spNumValue = $tmp['value'];
                }
            }
        }

        // 如果订单中不存在费率的字段，则从product_sku查询
        if (!$spTimePrice) {
            $productSku = (new \app\client\repository\ProductSkuRepository)->getProductSkuById($userOrder['product_sku_id']);
            if (!$productSku) {
                return false;
            }

            if(isset($productSku['sp_time'])){
                foreach($productSku['sp_time'] as $tmp){
                    if($spTimeValue >= $tmp['min'] && $spTimeValue <= $tmp['max']){
                        $spTimePrice = $tmp['price'];
                        break;
                    }
                }
            }else{
                return false;
            }
        }
        // 单价 todo: $spTimeValue存在为0情况
        /**
         * $spTimeValue（时长）为0的原因为：升级时sp_time传值为0
         * 当用户选择升级时无法选择时长，此时sp_time（时长）传值为0。因此在此处计算续费老订单时会出现$spTimeValue=0的情况。【建议：无论续费和升级，前端可传值与老订单相同的时长，这样将来不至于出现其他的问题】
         */
        $_price = $spTimePrice * $spNumValue;
        if($spTimeValue) {
            $_price *= $spTimeValue;
        }
        return $_price > 0 ? $userOrder['fee'] / $_price: 0;
    }

    /**
     * 依据之前订单记录的价格对实例的参数进行计算
     *
     * @param $product_attributes
     * @param $data
     * @throws \Exception
     * @return int
     */
    private function getUpgradeAmount($product_attributes, $product_sku, $data, $type='upgrade')
    {
        $result = [];
        //这是现在的计算方式
        $typeArray = [ProductModel::PRODUCT_ATTRIBUTE_TYPE_DISCRETE, ProductModel::PRODUCT_ATTRIBUTE_TYPE_AFTER_USE_CHARGE];
        foreach ($product_attributes  as $attribute) {
            if (!in_array($attribute['type'], $typeArray)) {
                // 离散属性和用后计费属性不需计算费用
                if (isset($data['detail'][$attribute['name']])) {
                    $result[] = array_merge($attribute, ['value' => $data['detail'][$attribute['name']]]);
                }
            }
        }
        //计算升级amount
        return $this->getProductPrice($result, $product_sku,$type);
    }

    /**
     * 比对新提交的数据和升级老数据
     * @param $attributes
     * @param $data
     * @return bool
     */
    private function checkAttributes($attributes, $data)
    {
        foreach ($attributes as $attribute) {
            if ($attribute['name'] == 'bandwidth') {
                if (isset($data['bandwidth'])) {
                    $bandWidth = $data['bandwidth'] + 0;
                    //比较新老值
                    $bandWidthValue = $attribute['value'] + 0;

                    if ($bandWidthValue > $bandWidth) {
                        return false;
                    }
                }
            }
            if ($attribute['name'] == 'base_bandwidth') {
                if (isset($data['base_bandwidth'])) {
                    $baseBandWidth = $data['base_bandwidth'] + 0;
                    //比较新老值
                    $baseBandWidthValue = $attribute['value'] + 0;

                    if ($baseBandWidthValue > $baseBandWidth) {
                        return false;
                    }
                }
            }
            if ($attribute['name'] == 'normal_bandwidth') {
                if (isset($data['normal_bandwidth'])) {
                    $normalBandWidth = $data['normal_bandwidth'] + 0;
                    //比较新老值
                    $normalBandWidthValue = $attribute['value'] + 0;

                    if ($normalBandWidthValue > $normalBandWidth) {
                        return false;
                    }
                }
            }
            //if ($attribute['name'] == 'site_count') {
            //    if (isset($data['site_count'])) {
            //        $siteCount = $data['site_count'] + 0;
            //        //比较新老值
            //        $siteCountValue = $attribute['value'] + 0;
            //        if ($siteCountValue > $siteCount) {
            //            return false;
            //        }
            //    }
            //}
            if ($attribute['name'] == 'sp_num') {
                if (isset($data['sp_num'])) {
                    $spNum = $data['sp_num'] + 0;
                    //比较新老值
                    $spNumValue = $attribute['value'] + 0;

                    if ($spNumValue > $spNum) {
                        return false;
                    }
                }
            }
            if ($attribute['name'] == 'sp_time') {
                if (isset($data['sp_time'])) {
                    $spTime = $data['sp_time'] + 0;
                    //比较新老值
                    $spTimeValue = $attribute['value'] + 0;
                    if ($spTimeValue > $spTime) {
                        return false;
                    }
                }
            }
        }

        return $attributes;
    }

    /**
     * @param $product_attributes
     * @param $product_sku
     * @return int
     */
    private function getProductPrice($product_attributes, $product_sku, $type='current')
    {
        $result = [];
        $amount = 0;
        foreach ($product_attributes as $product_attribute) {
            if (isset($product_sku[$product_attribute['name']])) {
                $user_buy_value = $product_attribute['value'];
                if ($product_attribute['type'] == ProductModel::PRODUCT_ATTRIBUTE_TYPE_DISCRETE_CHARGE) {
                    // 离散计费属性 - 只需叠加即可
                    foreach ($product_sku[$product_attribute['name']] as $sku_key => $sku_value) {
                        if ($sku_value['bandwidth'] == $user_buy_value) {
                            if ($type === 'upgrade' && isset($product_attribute['price'])) {
                                if ($product_attribute['price'] < $sku_value['price']) {
                                    $amount   += $sku_value['price'];
                                } else {
                                    $amount  += $product_attribute['price'];
                                }
                            } else {
                                $amount   += $sku_value['price'];
                            }
                            $result[] = $product_attribute['name'];
                        }
                    }
                } elseif ($product_attribute['type'] == ProductModel::PRODUCT_ATTRIBUTE_TYPE_CONTINUOUS_CHARGE) {
                    // 连续计费属性 - 需叠加，需判断区间
                    foreach ($product_sku[$product_attribute['name']] as $sku_key => $sku_value) {
                        if ($user_buy_value >= $sku_value['min'] && $user_buy_value <= $sku_value['max']) {
                            $result[] = $product_sku[$product_attribute['name']];
                            if ($type === 'upgrade' && isset($product_attribute['price'])) {
                                if ($product_attribute['price'] < $sku_value['price']) {
                                    $amount   += ($user_buy_value - $sku_value['min'] + 1) * $sku_value['price'];
                                } else {
                                    $amount   += ($user_buy_value - $sku_value['min'] + 1) * $product_attribute['price'];
                                }
                            } else {
                                $amount   += ($user_buy_value - $sku_value['min'] + 1) * $sku_value['price'];
                            }
                        } elseif ($user_buy_value > $sku_value['max']) {
                            if ($type === 'upgrade' && isset($product_attribute['price'])) {
                                if ($product_attribute['price'] < $sku_value['price']) {
                                    $amount += ($sku_value['max'] - $sku_value['min'] + 1) * $sku_value['price'];
                                } else {
                                    $amount += ($sku_value['max'] - $sku_value['min'] + 1) * $product_attribute['price'];
                                }
                            } else {
                                $amount += ($sku_value['max'] - $sku_value['min'] + 1) * $sku_value['price'];
                            }
                        }
                    }
                } elseif ($product_attribute['type'] == ProductModel::PRODUCT_ATTRIBUTE_TYPE_RATIO_CHARGE) {
                    // 倍率计费属性 - 成倍数增加，需判断区间
                    $ratio_amount = 0;
                    foreach ($product_sku[$product_attribute['name']] as $sku_key => $sku_value) {
                        if ($user_buy_value >= $sku_value['min'] && $user_buy_value <= $sku_value['max']) {
                            $result[]     = $product_sku[$product_attribute['name']];
                            if ($type === 'upgrade' && isset($product_attribute['price'])) {
                                if ($product_attribute['price'] < $sku_value['price']) {
                                    $ratio_amount += ($user_buy_value - $sku_value['min'] + 1) * $sku_value['price'];
                                } else {
                                    $ratio_amount += ($user_buy_value - $sku_value['min'] + 1) * $product_attribute['price'];
                                }
                            } else {
                                $ratio_amount += ($user_buy_value - $sku_value['min'] + 1) * $sku_value['price'];
                            }
                        } elseif ($user_buy_value > $sku_value['max']) {
                            if ($type === 'upgrade' && isset($product_attribute['price'])) {
                                if ($product_attribute['price'] < $sku_value['price']) {
                                    $ratio_amount += ($sku_value['max'] - $sku_value['min'] + 1) * $sku_value['price'];
                                } else {
                                    $ratio_amount += ($sku_value['max'] - $sku_value['min'] + 1) * $product_attribute['price'];
                                }
                            } else {
                                $ratio_amount += ($sku_value['max'] - $sku_value['min'] + 1) * $sku_value['price'];
                            }
                        }
                    }

                    // 升级时sp_time传值为0，会导致整个计算价格为0,所以此处需判空处理
                    if($ratio_amount) {
                        $amount *= $ratio_amount;
                    }
                }
            }
        }
        return $amount;
    }

    /**
     * @param $order
     * @param $sku
     * @param $instanceId
     * @return bool|int
     * @throws \Exception
     */
    private function getCurrentInstance($order, $sku, $instanceId)
    {
        //获取当前实例配置
        //根据实例中的属性和price进行价格计算
        $instance = $this->instanceModel->esGetById($instanceId);
        $data['detail'] = [
            'base_bandwidth' => $instance['base_bandwidth'] ?? null,
            'normal_bandwidth' => $instance['normal_bandwidth'] ?? null,
            'sp_num' => $instance['sp_num'] ?? 0,
            'sp_time' => $instance['sp_time'] ?? 0,
            'bandwidth' => $instance['bandwidth'] ?? 0,
        ];
        $attributes = $order['detail']['attributes'];

        if (isset($attributes)) {
            //上一次支付订单的价格记录
            return  $this->getUpgradeAmount($attributes, $sku, $data, 'local');
        }

        return false;
    }

    /**
     * @param integer $month 月份
     * @param array $instance 实例
     * @return integer
     */
    private function checkInstanceAllowRenew($month, $instance)
    {
        $startDate = Carbon::parse(format_time(strtotime($instance['start_date'])));
        $endTime   = Carbon::parse(format_time(strtotime($instance['end_date'])));
        $spEndTime = $endTime->addMonths($month);

        if ($spEndTime->diffInYears($startDate) <= 3) {
            return 1;
        }

        return 0;
    }
}

