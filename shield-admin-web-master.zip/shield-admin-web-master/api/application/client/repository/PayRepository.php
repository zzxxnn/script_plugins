<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/3/29
 * Time: 17:11
 */

namespace app\client\repository;


use app\client\service\WxPay;

class PayRepository extends BaseRepository
{
    protected $orderRepository;

    public function __construct()
    {
        $this->orderRepository = new OrderRepository();
    }

    /**
     * 执行支付成功后的操作
     *
     * @param       $data
     * @param null  $payType  支付方式（支付宝、微信、余额）
     */
    public function emitPaySuccessEvent($data, $payType = null)
    {
        // 处理支付成功的订单
        $this->orderRepository->processPaidOrder($data['oid'], $payType);
    }

    /**
     * 获取微信支付二维码链接
     *
     * @param $goodsInfo
     * @param $orderId
     * @param $totalFee
     * @param $goodsId
     * @return mixed
     * @throws \app\common\exception\client\Pay\WxPayException
     * @throws \WxPayException
     */
    public function getWxPayQrCodeUrl($goodsInfo, $orderId, $totalFee, $goodsId)
    {
        $coreUrl = (new WxPay())->getPayUrl($goodsInfo, $orderId, $totalFee, $goodsId);

        return 'http://paysdk.weixin.qq.com/qrcode.php?data=' . urlencode($coreUrl);
    }

    public function getOrderPayInfo($orderId)
    {
        $result = (new WxPay())->getOrderInfo($orderId);
        if (!isset($result['return_code'], $result['trade_state']) || $result['return_code'] !== 'SUCCESS') {
            return null;
        }

        return $result;
    }

    public function getOrderPayStatus($orderId)
    {
        $orderInfo = $this->getOrderPayInfo($orderId);

        return $orderInfo['trade_state'] ?? null;
    }

    public function payNotify($orderInfo)
    {
        $orderId = $orderInfo['out_trade_no'];
        $orderFee = $orderInfo['total_fee'];

        // 查询是否存在该订单

        $this->emitPaySuccessEvent(['order_id' => $orderId]);

    }
}