<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/3/28
 * Time: 17:29
 */

namespace app\client\repository;


use app\common\exception\client\ElasticSearchException;
use app\common\exception\client\PermissionDenyException;
use app\common\exception\client\ZookeeperException;
use app\client\model\BaseModel;
use app\client\model\DnsConfModel;
use app\client\model\HdConfigModel;
use app\client\model\PortModel;
use app\client\model\ProxyConfModel;
use app\client\model\UserInstanceModel;
use app\client\service\Auth;
use think\Log;
use app\client\validate\Port as PortValidator;

class PortRepository extends BaseRepository
{

    protected $hdConfModel = null;

    protected $instanceModel = null;

    protected $proxyConfModel = null;

    protected $dnsConfModel = null;

    public function __construct()
    {
        $this->model = new PortModel();

        $this->hdConfModel = new HdConfigModel();

        $this->instanceModel = new UserInstanceModel();

        $this->proxyConfModel = new ProxyConfModel();

        $this->dnsConfModel = new DnsConfModel();
    }

    /**
     * 生成应用型ID
     *
     * @return string
     * @throws \Exception
     */
    public function generatePortId()
    {
        do {
            $id = PortModel::PORT_ID_PREFIX . str_rand(7);
            $userApp = $this->model->esGetById($id);
        } while ($userApp);

        return $id;
    }

    /**
     * 代理端口已经存在的个数
     *
     * @param $proxyIps
     * @return int
     * @throws \Exception
     */
    public function portHasExists($appId, $proxyIps)
    {
        $ipArray = [];
        foreach ($proxyIps as $proxyIp) {
            $ipArray[] = $proxyIp['ip'];
        }
        $filter = [
            'query' => [
                'bool' => [
                    'must' => [
                        ['term' => ['_id' => $appId]],
                        ['terms' => ['proxy_ip.ip' => $ipArray]],
                    ]
                ]
            ],
            'aggs'  => [
                "state_ip" => [
                    "stats" => [
                        "field" => 'proxy_port'
                    ]
                ]
            ]
        ];

        $aggs = $this->model->esAggsSearch($filter);

        return $aggs['aggs']['state_ip']['count'] ?? 0;
    }


    /**
     * 检查非网站信息是否存在
     *
     * @param $proxyIps
     * @param $port
     * @param $exclude array 要排除的实例ID组
     * @return bool
     * @throws \Exception
     */
    public function portIsExist($proxyIps, $port, $exclude = [])
    {
        //多个端口
        if (!is_array($port)) {
            $port = explode(',', $port);
        }

        try {
            foreach ($proxyIps as $proxyIp) {
                //如果这个里面包含了0
                if (in_array(0, $port)) {
                    $filter = [
                        'query' => [
                            'bool' => [
                                'must' => [
                                    ['term' => ['proxy_ip.ip' => $proxyIp['ip']]],
                                ]
                            ]
                        ]
                    ];
                } else {
                    $filter = [
                        'query' => [
                            'bool' => [
                                'must' => [
                                    ['term' => ['proxy_ip.ip' => $proxyIp['ip']]],
                                    [
                                        'bool' => [
                                            'should' => [
                                                ['term' => ['proxy_port' => 0]],
                                                ['terms' => ['proxy_port' => $port]]
                                            ]
                                        ]
                                    ]
                                ]
                            ]
                        ]
                    ];
                }

                if (!empty($filter)) {
                    $filter['query']['bool']['must_not'] = [
                        ['terms' => ['_id' => $exclude]]
                    ];
                }

                $userApp = $this->getUserApp($filter);
                if (count($userApp) > 0) {
                    return true;
                }
            }

            return false;
        } catch (\Exception $e) {
            return true;
        }
    }

    public function getUserApp($filter = [])
    {
        try {
            return $this->model->esSearch($filter);
        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * 根据IP获取非网站信息
     *
     * @param $ip
     * @param null $port
     * @return array
     * @throws \Exception
     */
    public function getPortByIp($ip, $port = null)
    {
        $filter = ['source_ip' => $ip];

        if ($port) {
            $filter['source_port'] = $port;
        }

        return $this->model->esSearch($filter);
    }

    /**
     * 添加非网站防护
     *
     * @param $attributes
     * @return bool
     * @throws \Exception
     */
    public function addPort($attributes)
    {

        $proxyIps = [];
        foreach ($attributes['proxy_ips'] as $proxyIp) {
            if (!$userInstance = $this->instanceModel->esGetById($proxyIp['ddos_id'])) {
                throw new ElasticSearchException('为找到该用户实例！');
            }

            // 检查该实例是否属于当前用户
            if ($userInstance['uid'] != Auth::id()) {
                throw new PermissionDenyException('没有权限接入此实例！');
            }

            $proxyIps[] = [
                'instance_id'   => $proxyIp['ddos_id'],
                'instance_line' => $userInstance['instance_line'],
                'area'          => $userInstance['area'],
                'line'          => $proxyIp['line'],
                'ip'            => $proxyIp['ip'],
            ];
        }

        $id = $this->generatePortId();

        $proxyPort = array_map('intval', explode(',', $attributes['proxy_port'] ?? 0));
        $data = [
            'status'      => PortModel::PORT_STATUS_LINING,
            'uid'         => Auth::id(),
            'app_id'      => $id,
            'type'        => PortModel::USER_APP_TYPE_PORT,
            'proxy_ip'    => $proxyIps,
            'protocol'    => $attributes['protocol'],
            'proxy_port'  => $proxyPort,
            'server_ip'   => explode(',', $attributes['server_ips']),
            'name'        => null,     // CNAME自动调度域名
            'cname'       => null,    // CNAME自动调度CNAME
            'filter'      => null,   // 黑白名单
            'last_update' => gmt_withTZ()
        ];

        return $this->model->esAdd($data, $id);
    }

    /**
     * 获取非网站防护列表
     * @param $filter
     * @param $from
     * @param $size
     * @return array
     * @throws \Exception
     */
    public function portList($filter, $from, $size)
    {
        $ports = $this->model->esSearch($filter, $from, $size);
        $ddosIds = [];
        foreach ($ports as $port) {
            $ddosIds = array_merge($ddosIds, array_column($port['proxy_ip'] ?? [], 'instance_id'));
        }

        // 获取实例列表
        $filter = [['terms' => ['instance_id.keyword' => array_values(array_unique($ddosIds))]]];
        $instances = $this->instanceModel->esFilter($filter);

        foreach ($ports as $key => &$port) {
            $port['last_update'] = strtotime($port['last_update']);
            $port['name'] = $port['name'] ?? null;
            $port['cname'] = $port['cname'] ?? null;
            // 源站IP
            $port['server_ip'] = implode(',', $port['server_ip'] ?? []);

            foreach ($port['proxy_ip'] as &$proxyIp) {
                // 根据高防实例的ID，获取高防实例详情
                $instance = array_filter($instances, function ($instance) use ($proxyIp) {
                    return $proxyIp['instance_id'] == $instance['instance_id'];
                });
                $instance = !empty($instance) ? array_pop($instance) : null;
                $instanceEndTime = !empty($instance) ? strtotime($instance['end_date']) : null;
                $proxyIp['endTime'] = format_time($instanceEndTime);  // 实例的过期时间
                $proxyIp['expired'] = (bool)($instanceEndTime <= time());       // 该实例是否过期：true 已过期, false 未过期
            }

            $port['proxy_port'] = implode(',', (array)$port['proxy_port']);
        }

        return $ports;
    }

    /**
     * @param $id
     * @return null|string
     * @throws \Exception
     */
    public function getPortById($id)
    {
        $port = $this->model->esGetById($id);
        if ($port && $port['type'] != PortModel::USER_APP_TYPE_PORT) {   // 如果查询结果不是应用型，返回空
            return null;
        }

        return $port;
    }

    /**
     * 删除应用防护
     *
     * @param $id
     * @return bool
     * @throws \Exception
     */
    public function delPortById($id)
    {
        try {
            return (bool)$this->model->esDeleteById($id);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    /**
     * 设置Zookeeper Proxy Conf
     *
     * @param $port
     * @param array $except
     * @return bool
     * @throws ZookeeperException
     */
    public function setZKProxyConf($port, $except = [])
    {
        is_string($port) && $port = $this->getPortById($port);

        $data = [
            'type'   => BaseModel::ZK_TYPE_APP,
            'action' => BaseModel::HD_ZK_ACTION_CREATE,
            'data'   => [
                'id'           => $port['app_id'],
                'protocol'     => strtolower($port['protocol']),
                'proxy_port'   => implode(',', (array)$port['proxy_port']),
                'server_ip'    => $port['server_ip'],
                'ip_whitelist' => $port['filter']['ip_whitelist'] ?? [],    // IP白名单
                'ip_blacklist' => $port['filter']['ip_blacklist'] ?? []     // IP黑名单
            ]
        ];

        $ipSetRecord = [];
        foreach ($port['proxy_ip'] as $proxyIp) {
            // 对于已经写入过的高防IP不进行重复写入
            if (in_array($proxyIp['ip'], $ipSetRecord)) {
                continue;
            }
            $instanceId = $proxyIp['instance_id'];
            // 对于改变前后同时存在的高防IP不进行重复写入
            if (!empty($except[$instanceId]) && in_array($proxyIp['ip'], $except[$instanceId])) {
                continue;
            }
            $path = '/hd/proxy/' . $proxyIp['ip'] . '/' . micro_timestamp();

            Log::info('Set port proxy with data:' . json_encode(compact('path', 'data')));
            $result = $this->model->zkSetData($path, $data);
            if (!$result) {
                throw new ZookeeperException('将Proxy信息写入ZK时，为PORT：' . $port['domain'] . '设置Proxy配置失败！');
            }
        }

        return true;
    }

    public function updatePort($attributes, $port)
    {
        is_string($port) && $port = $this->getPortById($port);

        $proxyPort = $attributes['proxy_port'] ?? $port['proxy_port'];
        if (!is_array($proxyPort)) {
            $proxyPort = array_map('intval', explode(',', $proxyPort));
        }

        $data = [
            'protocol'    => $attributes['protocol'] ?? $port['protocol'],
            'proxy_port'  => $proxyPort,
            'server_ip'   => $attributes['server_ip'] ?? $port['server_ip'],
            'name'        => $attributes['domain'] ?? ($port['name'] ?? null),
            'cname'       => $attributes['cname'] ?? ($port['cname'] ?? null),
            'status'      => $attributes['status'] ?? ($port['status'] ?? null),
            'last_update' => gmt_withTZ()
        ];

        // 如果存在proxy_ips，需要对proxy_ips 进行处理
        if (isset($attributes['proxy_ips'])) {
            $proxyIps = [];
            foreach ($attributes['proxy_ips'] as $proxyIp) {
                if (!$userInstance = $this->instanceModel->esGetById($proxyIp['ddos_id'])) {
                    throw new ElasticSearchException('未找到该用户实例！');
                }
                // 检查该实例是否属于当前用户
                if ($userInstance['uid'] != Auth::id()) {
                    throw new PermissionDenyException('没有权限接入此实例！');
                }

                $proxyIps[] = [
                    'instance_id'   => $proxyIp['ddos_id'],
                    'instance_line' => $userInstance['instance_line'],
                    'area'          => $userInstance['area'],
                    'line'          => $proxyIp['line'],
                    'ip'            => $proxyIp['ip'],
                ];
            }
            $data['proxy_ip'] = $proxyIps;
        }

        if (isset($attributes['filter'])) {
            $data['filter'] = [
                'ip_blacklist' => $attributes['filter']['ip_blacklist'] ?? ($port['filter']['ip_blacklist'] ?? []),
                'ip_whitelist' => $attributes['filter']['ip_whitelist'] ?? ($port['filter']['ip_whitelist'] ?? []),
            ];
        }

        return $this->model->esUpdateById($data, $port['app_id']);
    }

    /**
     * 删除应用型防护的Proxy Conf配置信息
     *
     * @param $port
     * @return bool
     * @throws ElasticSearchException
     */
    public function rmESProxyConf($port)
    {
        foreach ($port['proxy_ip'] as $proxyIp) {
            if (!$proxyConfig = $this->proxyConfModel->esGetById($proxyIp['ip'])) {
                continue; // 未找到改高防节点的Proxy Conf信息时，不进行移除操作
            }

            foreach ($proxyConfig['forwarding'] as $index => $forwarding) {
                if ($forwarding['uid'] == Auth::id() && $this->isEqualPortProxy($port['proxy_port'], $forwarding['proxy_port'])) {
                    unset($proxyConfig['forwarding'][$index]);
                }
            }

            if (!$this->proxyConfModel->esUpdateById(['forwarding' => array_values($proxyConfig['forwarding'])], $proxyIp['ip'])) {
                throw new ElasticSearchException("删除PORT：" . $port['proxy_ip'] . " Proxy Config配置信息失败");
            }
        }

        return true;
    }

    /**
     * 移除Zookeeper中Proxy Conf 配置信息
     *
     * @param $port
     * @param array $except
     * @return bool
     * @throws ZookeeperException
     */
    public function rmZKProxyConf($port, $except = [])
    {
        $data = [
            'type'   => BaseModel::ZK_TYPE_APP,
            'action' => BaseModel::HD_ZK_ACTION_DELETE,
            'data'   => [
                'id'         => $port['app_id'],
                'proxy_port' => implode(',', (array)$port['proxy_port']),
                'proxy_ip'   => array_column($port['proxy_ip'], 'ip'),
                'protocol'   => strtolower($port['protocol'])
            ]
        ];
        $ipRmRecord = [];
        foreach ($port['proxy_ip'] as $proxyIp) {
            // 对于同一个高防IP不进行重复移除
            if (in_array($proxyIp['ip'], $ipRmRecord)) {
                continue;
            }
            $instanceId = $proxyIp['instance_id'];
            // 对于更新前没有改变的高防IP不进行移除
            if (!empty($except[$instanceId]) && in_array($proxyIp['ip'], $except[$instanceId])) {
                continue;
            }

            $ipRmRecord[] = $proxyIp['ip'];
            $path = '/hd/proxy/' . $proxyIp['ip'] . '/' . micro_timestamp();
            if (!$this->model->zkSetData($path, $data)) {
                throw new ZookeeperException('将Proxy：' . $port['proxy_ip'] . '删除信息写入ZK时失败！');
            }
        }

        return true;
    }

    /**
     * 更新Proxy Conf forwarding 转发规则
     *
     * @param $port
     * @return bool
     * @throws \Exception
     */
    public function setESProxyConf($port)
    {
        is_string($port) && $port = $this->getPortById($port);

        // ProxyPort 为整数数组
        $proxyPort = is_array($port['proxy_port']) ? $port['proxy_port'] : explode(',', $port['proxy_port']);
        $proxyPort = array_map('intval', $proxyPort);

        $data = [
            'uid'        => Auth::id(),
            'server_ip'  => $port['server_ip'],
            'proxy_port' => $proxyPort,
            'filter'     => [
                'ip_blacklist' => $port['filter']['ip_blacklist'] ?? [],
                'ip_whitelist' => $port['filter']['ip_whitelist'] ?? [],
            ]
        ];

        foreach ($port['proxy_ip'] as $proxyIp) {
            if (!$proxyConf = $this->proxyConfModel->esGetById($proxyIp['ip'])) {
                // 当前高防节点记录不存在时，进行创建
                $proxyConf = ['ip' => $proxyIp['ip'], 'forwarding' => [$data], 'last_update' => gmt_withTZ()];
                if (!$this->proxyConfModel->esAdd($proxyConf, $proxyIp['ip'])) {
                    throw new \Exception('更新Proxy Conf转发规则失败！');
                }
            } else {
                // 已经存在的，更新相关信息,将转发端口转化成字符串进行比较
                $forwardingPorts = array_map(function ($item) {
                    $itemProxyPort = (array)$item['proxy_port'];
                    sort($itemProxyPort);

                    return implode(',', $itemProxyPort);
                }, $proxyConf['forwarding'] ?? []);

                // 对当前应用的端口进行
                sort($proxyPort);

                // 查找当前端口是否存在
                $key = array_search(implode(',', $proxyPort), $forwardingPorts);
                if ($key != false) {    // 当前配置已经写入，更新已经写入的配置
                    $proxyConf['forwarding'][$key] = $data;
                } else {      // 当前配置尚未写入，写入配置
                    $proxyConf['forwarding'][] = $data;
                }
                $proxyConf['last_update'] = gmt_withTZ();
                if (!$this->proxyConfModel->esUpdateById($proxyConf, $proxyIp['ip'])) {
                    throw new \Exception('更新Proxy Conf转发规则失败！');
                }
            }
        }

        return true;
    }

    /**
     * 增加用户实例的接入数量
     * @param $port
     * @return bool
     * @throws ElasticSearchException
     * @throws PermissionDenyException
     */
    public function addUserInstancePortCount($port)
    {
        is_string($port) && $port = $this->getPortById($port);
        foreach ($port['proxy_ip'] as $proxyIp) {
            if (!$userInstance = $this->instanceModel->esGetById($proxyIp['instance_id'])) {
                throw new ElasticSearchException('用户接入实例不存在！');
            }

            // 验证该实例是否属于该用户
            if ($userInstance['uid'] != Auth::id()) {
                throw new PermissionDenyException('没有权限接入此实例！');
            }

            // 将对应的实例端口接入数增加
            // foreach ($userInstance['hd_ip'] as $index => $hdIp) {
            //     if ($hdIp['ip'] == $proxyIp['ip'] && $hdIp['line'] == $proxyIp['line']) {
            //         $userInstance['hd_ip'][$index]['port_count'] = ($hdIp['port_count'] ?? 0) + 1;
            //     }
            // }
            $userInstance['port_count'] = ($userInstance['port_count'] ?? 0) + 1;

            if (!$this->instanceModel->esUpdateById(['port_count' => $userInstance['port_count']], $proxyIp['instance_id'])) {
                throw new ElasticSearchException('更新实例接入数量失败！');
            }
        }

        return true;
    }

    /**
     * 削减用户实例接入数
     *
     * @param $port
     * @return bool
     * @throws ElasticSearchException
     */
    public function cutUserInstancePortCount($port)
    {
        foreach ($port['proxy_ip'] as $proxyIp) {
            if (!$userInstance = $this->instanceModel->esGetById($proxyIp['instance_id'])) {
                continue;
            }
            // foreach ($userInstance['hd_ip'] as $index => $hdIp) {
            //     if ($hdIp['line'] == $proxyIp['line'] && $hdIp['ip'] == $proxyIp['ip']) {
            //         $userInstance['hd_ip'][$index]['port_count'] = ($hdIp['port_count'] ?? 0) > 0 ? $hdIp['port_count'] - 1 : 0;
            //     }
            // }
            $userInstance['port_count'] = ($userInstance['port_count'] ?? 0) > 0 ? $userInstance['port_count'] - 1 : 0;

            if (!$this->instanceModel->esUpdateById([
                'port_count' => $userInstance['port_count'], 'last_update' => gmt_withTZ()
            ], $proxyIp['instance_id']
            )) {
                throw new ElasticSearchException('更新用户实例接入数失败！');
            }
        }

        return true;
    }

    public function checkIsUpdatePortInfo($data, $port)
    {
        try {
            is_string($port) && $port = $this->getPortById($port);
            // 检查源站IP是否更新
            if (isset($data['server_ips']) && $data['server_ips'] != implode(',', $port['server_ip'])) {
                return true;
            }
            // 检查转发协议是否更新
            if (isset($data['protocol']) && $data['protocol'] != $port['protocol']) {
                return true;
            }
            // 检查代理端口是否更新
            if (isset($data['proxy_port']) && $data['proxy_port'] != $port['proxy_port']) {
                return true;
            }
            // 检查代理IP是否更新
            if (isset($data['proxy_ips'])) {
                // 如果所选高防IP数量与原数量不一致，需要更新当前Port信息
                if (count($data['proxy_ips']) != count($port['proxy_ip'])) {
                    return true;
                }
                // 如果所选高防IP数量和原数量一致，比较所有高仿IP和实例是否一致，不一致时更新当前Port信息
                foreach ($data['proxy_ips'] as $proxyIp) {
                    $exist = false;
                    foreach ($port['proxy_ip'] as $v) {
                        if ($exist) {
                            continue;
                        }
                        // 实例ID，线路和端口完全相同，标识该接入线路已选择（未修改）
                        if ($proxyIp['ddos_id'] == $v['instance_id'] && $proxyIp['ip'] == $v['ip'] && $proxyIp['line'] == $v['line']) {
                            $exist = true;
                        }
                    }

                    if (!$exist) {
                        return true;
                    }
                }
            }

            return false;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * 设置应用的访问黑白名单
     * @param $data
     * @param $port
     * @return bool
     */
    public function setPortWhiteBlackList($data, $port): bool
    {
        try {
            is_string($port) && $port = $this->getPortById($port);
            $whitelist = explode("\n", trim($data['whitelist'] ?? ''));
            $blacklist = explode("\n", trim($data['blacklist'] ?? ''));

            return (bool)$this->updatePort(compact('whitelist', 'blacklist'), $port);
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     *
     * @param $domain
     * @param $port
     * @return string
     * @throws \Exception
     */
    public function generatePortCname($domain, $port)
    {
        is_string($port) && $port = $this->getPortById($port);
        $cname = $domain != ($port['name'] ?? '') ? SiteRepository::generateDomainCName() : $port['cname'];

        return $cname;
    }

    /**
     * 设置CNAME自动调度的DNS配置信息
     *
     * @param $attributes
     * @param $port
     * @return array|bool
     * @throws ElasticSearchException
     */
    public function setESDNSConf($attributes, $port)
    {
        is_string($port) && $port = $this->getPortById($port);
        $dnsConf = [
            'conf_id'     => SiteRepository::generateDynamicDomain($port['name']),    // dns_conf Id为站点动态域名
            'name'        => $port['cname'],                                     // 站点CNAME
            'type'        => DnsConfModel::TYPE_DYNAMIC,                                // 配置类型 Dynamic - 动态; Static - 静态
            'response'    => [],                                                    // DNS响应列表
            'last_update' => gmt_withTZ()
        ];

        foreach ($attributes['proxy_ip'] as $index => $proxyIp) {
            if (!$ddosInstance = $this->instanceModel->esGetById($proxyIp['instance_id'])) {
                throw new ElasticSearchException('未找到该用户实例' . $proxyIp['instance_id'] . '!');
            }

            $dnsConf['response'][$proxyIp['line']] = [
                'line' => $proxyIp['line'],
                'ip'   => $proxyIp['ip'],
                'area' => $ddosInstance['area'],
            ];
            $dnsConf['response'] = array_values($dnsConf['response']);
        }

        return $this->dnsConfModel->esAdd($dnsConf, $dnsConf['conf_id']);
    }

    /**
     * 写入ZK DNS配置信息
     * @param $port
     * @return bool
     * @throws ElasticSearchException
     * @throws ZookeeperException
     */
    public function setZKDNSConf($port)
    {
        is_string($port) && $port = $this->getPortById($port);
        $data = ['action' => BaseModel::HD_ZK_ACTION_CREATE, 'name' => $port['cname'], 'response' => []];
        foreach ($port['proxy_ip'] as $_ip) {
            // 获取实例的接入区域
            if ($ddosInstance = $this->instanceModel->esGetById($_ip['instance_id'])) {
                // 一个线路选择一个IP进行接入
                $data['response'][$_ip['line']] = ['line' => $_ip['line'], 'ip' => $_ip['ip'], 'area' => $ddosInstance['area']];
            }
        }

        // 重建IP的索引
        $data['response'] = array_values($data['response']);

        // 获取所有可用的DNS服务器，并将DNS配置信息写入每台机器的ZK配置上
        $dnsNodeList = (new SiteRepository)->getDNSNodeList();
        if (empty($dnsNodeList)) {
            throw new ElasticSearchException('无可用DNS服务器！');
        }

        $dnsIps = [];
        array_map(function ($item) use (&$dnsIps) {
            foreach ($item['node_ip'] as $nodeIp) {
                $dnsIps[] = $nodeIp['ip'];
            }
        }, $dnsNodeList);

        // 将站点DNS信息写到所有的DNS节点上
        foreach (array_unique($dnsIps) as $ip) {
            $path = '/hd/dns/' . $ip . '/' . micro_timestamp();
            Log::info('Set site DNS with data:' . json_encode(compact('path', 'data')));
            $result = $this->model->zkSetData($path, $data);
            if (!$result) {
                throw new ZookeeperException('写入应用：' . $port['app_id'] . 'ZK DNS配置失败！');
            }
        }

        return true;
    }

    /**
     * 移除ZK DNS配置信息
     * @param $port
     * @return bool
     * @throws ZookeeperException
     */
    public function rmZKDNSConf($port)
    {
        is_string($port) && $port = $this->getPortById($port);
        $data = ['action' => BaseModel::HD_ZK_ACTION_DELETE, 'name' => $port['cname']];

        // 获取DNS信息
        $dnsNodeList = (new SiteRepository)->getDNSNodeList();
        $dnsIps = [];
        array_map(function ($item) use (&$dnsIps) {
            foreach ($item['node_ip'] as $nodeIp) {
                $dnsIps[] = $nodeIp['ip'];
            }
        }, $dnsNodeList);

        foreach (array_unique($dnsIps) as $ip) {
            $path = '/hd/dns/' . $ip . '/' . micro_timestamp();
            if (!$this->model->zkSetData($path, $data)) {
                throw new ZookeeperException('移除应用：' . $port['app_id'] . 'ZK DNS配置失败！');
            }
        }

        return true;
    }

    /**
     * 移除应用ES DNS配置信息
     * @param $port
     * @return bool
     * @throws ElasticSearchException
     */
    public function rmESDNSConf($port)
    {
        is_string($port) && $port = $this->getPortById($port);
        // DNS Conf ID为域名生成的Dynamic域名
        $dnsConfId = SiteRepository::generateDynamicDomain($port['name']);
        if (!$dnsConf = $this->dnsConfModel->esGetById($dnsConfId)) {
            return true;
        }

        if (!$dnsConf = $this->dnsConfModel->esDeleteById($dnsConfId)) {
            throw  new ElasticSearchException('移除应用:' . $port['app_id'] . 'ES DNS 配置信息失败！');
        }

        return true;
    }

    /**
     * 将高防节点信息包装为
     * [
     *      'ddos-3gvpwae' => [
     *            '192.14.15.1',
     *            '192.14.15.2'
     *      ],
     *      'ddos-zg5yaer' => [
     *            '192.20.8.1',
     *            '192.20.8.2'
     *      ]
     * ]
     * @param array $source
     * @param string $instanceKey
     * @return array
     */
    public function processExceptProxyIp($source = [], $instanceKey = 'ddos_id')
    {
        $result = [];
        foreach ($source as $item) {
            $instanceId = $item[$instanceKey];
            !isset($result[$instanceId]) && $result[$instanceId] = [];
            $result[$instanceId][] = $item['ip'];
        }

        return $result;
    }

    /**
     * 获取用户已经选择的高防实例列表
     *
     * @param $selectInstanceIds
     * @param $from
     * @param $size
     * @return array
     * @throws \Exception
     */
    public function getPortSelectInstance($selectInstanceIds, $from, $size)
    {
        $filter = [
            'query' => [
                'bool' => [
                    'filter' => [
                        ['terms' => ['instance_id.keyword' => array_wrap($selectInstanceIds)]],
                        ['term' => ['uid.keyword' => Auth::id()]],
                        ['term' => ['status' => UserInstanceModel::STATUS_ACTIVATED]],
                        ['term' => ['type' => UserInstanceModel::INSTANCE_TYPE_PORT]]
                    ]
                ]
            ],
            'sort'  => ['last_update' => 'desc']
        ];

        return (new DDoSRepository())->getDDoSList($filter, $from, $size);
    }

    /**
     * 获取用户未选择的高防实例列表
     *
     * @param $selectInstanceIds
     * @param int $from
     * @param int $size
     * @return array
     * @throws \Exception
     */
    public function getPortUnSelectInstance($selectInstanceIds, int $from, int $size)
    {
        $filter = [
            'query' => [
                'bool' => [
                    'must'     => [
                        ['term' => ['uid.keyword' => Auth::id()]],
                        ['term' => ['status' => UserInstanceModel::STATUS_ACTIVATED]],
                        ['terms' => ['type' => [UserInstanceModel::INSTANCE_TYPE_PORT]]]
                    ],
                    'must_not' => [
                        ['terms' => ['instance_id.keyword' => $selectInstanceIds]]
                    ]
                ]
            ],
            'sort'  => ['last_update' => 'desc']
        ];

        return (new DDoSRepository())->getDDoSList($filter, $from, $size);
    }

    /**
     * 根据高仿实例ID获取应用防护列表
     * @param $id
     *
     * @return array
     */
    public function getPortByDDosId($id)
    {
        try {
            $filter = [
                'query' => [
                    'bool' => [
                        'must' => [
                            ['term' => ['uid.keyword' => Auth::id()]],
                            ['terms' => ['type' => [UserInstanceModel::INSTANCE_TYPE_PORT]]],
                            ['term' => ['proxy_ip.instance_id.keyword' => $id]]
                        ]
                    ]
                ]
            ];

            return $this->model->esSearch($filter);
        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * 删除应用防护（批量）
     *
     * @param $ports
     * @param $validator
     *
     * @return string
     * @throws ElasticSearchException
     */
    public function rmPortList($ports, $validator)
    {
        foreach ($ports as $port) {
            // 依次移除对应站点的ES和ZK配置
            $this->rmSinglePort($port, $validator);
        }

        return true;
    }

    /**
     * 删除应用防护（单个）
     *
     * @param               $port
     * @param PortValidator $validator
     *
     * @return string
     * @throws ElasticSearchException
     */
    public function rmSinglePort($port, PortValidator $validator)
    {
        try {
            if ($validator->scene('del_port')->check($port)) {
                throw new ElasticSearchException($validator->getError(), REP_CODE_PARAMS_INVALID);
            }

            if ($port['status'] == PortModel::PORT_STATUS_NORMAL) { // 未正常接入的域名，不进行移除
                // 将新转发配置写入ZK
                if (!$this->rmZKProxyConf($port)) {
                    throw new ZookeeperException('ZK error.', REP_CODE_DB_ERROR);
                }

                // 移除Proxy Conf中的配置信息
                if (!$this->rmESProxyConf($port)) {
                    throw new ElasticSearchException('Proxy Conf配置更新失败！', REP_CODE_ES_ERROR);
                }

                if (!$this->cutUserInstancePortCount($port)) {
                    throw new ElasticSearchException('用户实例接入信息更新失败！', REP_CODE_ES_ERROR);
                }
            }

            $delResult = $this->delPortById($port['app_id']);
            if (!$delResult) {
                $this->updatePort(['status' => PortModel::PORT_STATUS_DELETE_ERR], $port['app_id']);

                throw new ElasticSearchException('DB error', REP_CODE_DB_ERROR);
            }

            return true;
        } catch (\Exception $e) {

            throw new ElasticSearchException('应用删除失败！', REP_CODE_FAILED_OPERATION);
        }
    }

    /**
     * 比较转发端口前后是否一致
     *
     * @param $proxyPort1
     * @param $proxyPort2
     * @return bool
     */
    private function isEqualPortProxy($proxyPort1, $proxyPort2)
    {
        // 全部强制转化为数组
        $proxyPort1 = (array)$proxyPort1;
        $proxyPort2 = (array)$proxyPort2;

        sort($proxyPort1);
        sort($proxyPort2);

        // 转化为字符串进行比较
        if (implode(',', $proxyPort1) == implode(',', $proxyPort2)) {
            return true;
        }

        return false;
    }
}
