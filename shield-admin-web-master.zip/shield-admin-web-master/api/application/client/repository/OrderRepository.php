<?php

namespace app\client\repository;

use app\common\model\UserInstanceModel;
use app\client\model\UserModel;
use app\client\service\Auth;
use app\client\validate\Order;
use app\common\exception\client\Pay\AccountPayException;
use app\common\exception\client\Pay\WxPayException;
use app\common\model\InvoiceModel;
use app\common\model\OrderModel;
use app\common\model\ProductModel;
use app\common\model\ProductSkuModel;
use think\Log;
use Carbon\Carbon;

class OrderRepository extends BaseRepository
{
    protected $productModel;

    protected $productSkuModel;

    public function __construct()
    {
        $this->model = new OrderModel();

        $this->productModel = new ProductModel();

        $this->productSkuModel = new ProductSkuModel();
    }

    /**
     * 生成订单号,长度
     *
     */
    public function generateOrderId()
    {
        do {
            // 标识 + （年 + 日 + 月 + 时 + 分） + 随机码
            $orderId = OrderModel::ORDER_HD . date('ymdHi') . rand(100, 999);
            $result = $this->model->esGetById($orderId);
        } while ($result);

        return $orderId;
    }

    /**
     * 创建订单
     *
     * @param $data
     *
     * @return array|bool|string
     * @throws \Exception
     */
    public function createOrder($data)
    {
        // 处理订单信息数据结构
        $orderInfo = $this->processOrderInfo($data);
        $result = $this->model->esAdd($orderInfo, self::generateOrderId());

        if ($result['result'] === 'created') {
            return array_merge(['order_id' => $result['_id']], $orderInfo);
        }

        return false;
    }

    /**
     * 创建订单，处理充值订单和消费订单的数据结构
     *
     * @param array $orderInfo
     *
     * @return array
     * @throws \Exception
     */
    public function processOrderInfo(array $orderInfo = [])
    {
        $order = [];
        // 充值
        if ($orderInfo['type'] == OrderModel::ORDER_TYPE_RECHARGE) {
            $order = [
                'uid'            => Auth::id(),
                'type'           => $orderInfo['type'],
                'fee'            => $orderInfo['fee'],
                'final_fee'      => $orderInfo['fee'],                 // 初始优惠价和订单总价相等
                'status'         => OrderModel::ORDER_STATUS_CREATED,
                'invoice_status' => InvoiceModel::INVOICE_STATUS_READY,
                'create_time'    => gmt_withTZ(),
                'pay_time'       => null, // 支付时间,
                'detail'         => []
            ];
        }

        // 消费
        if ($orderInfo['type'] == OrderModel::ORDER_TYPE_PAID) {
            $order = $this->generatePaidOrder($orderInfo);
        }

        // 续费
        if ($orderInfo['type'] == OrderModel::ORDER_TYPE_RENEWAL) {
            $order = $this->generateRenewalUpgradeOrder($orderInfo);
        }

        //升级
        if (OrderModel::ORDER_TYPE_UPGRADE == $orderInfo['type']) {
            $order = $this->generateRenewalUpgradeOrder($orderInfo, 'upgrade');
        }

        return $order;
    }

    /**
     * 生成消费订单的数据格式
     *
     * @param $orderInfo
     *
     * @return array
     * @throws \Exception
     */
    private function generatePaidOrder($orderInfo)
    {
        $order_detail = $orderInfo['detail'];
        if (!empty($order_detail['product_id']) && !empty($order_detail['product_sku_id'])) {
            $product = $this->productModel->esGetById($order_detail['product_id']) ?? [];
            $filter['query']['bool']['must'][] = ['term' => ['price_id' => $order_detail['product_sku_id']]];
            $product_sku = $this->productSkuModel->esSearch($filter, 0, 1)[0] ?? [];
            if ($product && $product) {
                // 按照商品中的属性进行组装数据结构
                foreach ($product['attributes'] as $key => &$attribute) {
                    if (isset($product_sku[$attribute['name']]) && isset($order_detail[$attribute['name']])) {
                        if (is_array($product_sku[$attribute['name']])) {
                            foreach ($product_sku[$attribute['name']] as $sku_key => $sku_value) {
                                if (isset($sku_value["bandwidth"])) {
                                    if ($sku_value["bandwidth"] == $order_detail[$attribute['name']]) {
                                        $attribute['value'] = (string)$order_detail[$attribute['name']];

                                        // 记录属性原始价格，续费使用
                                        $attribute['price'] = $sku_value['price'] ?? 0;
                                        $product['attributes'][$key] = $attribute;
                                        continue;
                                    }
                                } elseif (isset($sku_value["min"]) && isset($sku_value['max'])) {
                                    // 区间值
                                    if ($order_detail[$attribute['name']] >= $sku_value["min"] && $order_detail[$attribute['name']] <= $sku_value["max"]) {
                                        $attribute['value'] = (string)$order_detail[$attribute['name']];

                                        // 记录属性原始价格，续费使用
                                        $attribute['price'] = $sku_value['price'] ?? 0;
                                        $product['attributes'][$key] = $attribute;
                                        continue;
                                    }
                                }
                            }
                        } elseif (is_string($product_sku[$attribute['name']])) {
                            $attribute['value'] = (string)$order_detail[$attribute['name']];
                            $product['attributes'][$key] = $attribute;
                        }
                    }
                    // 去除没有sku的属性（特殊情况）
                    if (!isset($attribute['value'])) {
                        unset($product['attributes'][$key]);
                        $product['attributes'] = array_values($product['attributes']);
                    }
                }
                unset($attribute);
            }

            // 计算订单截止时间
            $create_time = gmt_withTZ();
            $dt = \Carbon\Carbon::parse($create_time);
            $period = $order_detail['sp_time'];
            $dt = $dt->addMonths($period);
            $order = [
                'type'           => $orderInfo['type'],
                'fee'            => $orderInfo['fee'],
                'final_fee'      => $orderInfo['fee'],
                'uid'            => Auth::id(),
                'product_id'     => $order_detail['product_id'],
                'product_sku_id' => $order_detail['product_sku_id'],
                'create_time'    => $create_time,
                'pay_time'       => null,
                'status'         => OrderModel::ORDER_STATUS_CREATED,
                'invoice_status' => InvoiceModel::INVOICE_STATUS_READY,
                'start_date'     => $create_time,
                'end_date'       => gmt_withTZ($dt->timestamp),
                'detail'         => array_merge($product, ['instance_id' => []])
            ];

            return $order;
        }

        return [];
    }

    /**
     * 根据订单ID获取订单详情
     *
     * @param $id
     *
     * @return null|string
     * @throws \Exception
     */
    public function getOrderById($id)
    {
        $order = $this->model->esGetById($id);
        if ($order) {
            $order['oid'] = $id;
            $order['create_time'] = date('Y-m-d H:i:s', strtotime($order['create_time']));
        }

        return $order;
    }

    /**
     * 作废订单
     *
     * @param $id
     *
     * @return array|bool
     * @throws \Exception
     */
    public function deleteOrder($id): bool
    {
        return (bool)$this->model->esUpdateById(['status' => OrderModel::ORDER_STATUS_TRASHED], $id);
    }

    public function processPaidOrder($id, $payType = null)
    {
        try {
            if ($order = $this->model->esGetById($id)) {
                if ($order['type'] == OrderModel::ORDER_TYPE_RECHARGE) {            // 充值订单
                    // 充值订单添加用户余额
                    $this->processRechargeOrder($order);
                } else {                                                            // 支付订单
                    // 如果为余额支付，需从用户余额中减去订单金额
                    if ($payType == OrderModel::ORDER_PAY_TYPE_REMAINNING) {
                        $this->processRechargeOrder($order, false);
                    }

                    // 购买实例的订单分配高防实例
                    if ($order['type'] == OrderModel::ORDER_TYPE_PAID) {
                        // 生成高防实例，且分配实例
                        $orderInstancesIds = (new DDoSRepository())->dispatchOrderInstance($id);

                        // 更新订单中分配的实例ID
                        $this->model->esUpdateById(['detail' => ['instance_id' => $orderInstancesIds]], $id);

                        // 支付成功后库存处理
                        $filter['query']['bool']['must'][] = ['term' => ['price_id' => $order['product_sku_id']]];
                        $product_sku = $this->productSkuModel->esSearch($filter, 0, 1)[0] ?? [];
                        if ($product_sku && !empty($product_sku['stock'])) {
                            (new ProductSkuModel())->esUpdateById(
                                ['stock' => $product_sku['stock'] - 1],
                                $product_sku['id']
                            );
                        }
                    }

                    // 实例续费，更改实例到期时间
                    if ($order['type'] == OrderModel::ORDER_TYPE_RENEWAL) {
                        $data = [
                            'start_date' => $order['start_date'],
                            'end_date'   => $order['end_date']
                        ];
                        foreach ($order['detail']['instance_id'] as $instanceId) {
                            $ddos = (new UserInstanceModel)->esGetById($instanceId);
                            if ($ddos) {
                                if ($ddos['status'] == UserInstanceModel::STATUS_OVERDUE) {
                                    $data['status'] = UserInstanceModel::STATUS_ACTIVATED;
                                }

                                (new DDoSRepository())->updateDDoS($data, $instanceId);
                            }
                        }
                    }

                    // 实例升级，更新实例配置
                    if ($order['type'] == OrderModel::ORDER_TYPE_UPGRADE) {
                        $this->processUpgradeOrder($order);
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('Update Order HD IP Error with id:' . $id . ', message:' . $e->getMessage());

            return Finalfail(REP_CODE_ORDER_UPDATE_ERROR, '更新订单失败，ID为' . $id . ', 错误信息为:' . $e->getMessage());
        }
    }

    /**
     * 获取可用DNS服务器列表
     *
     * @param null $type 类型
     * @param null $line 线路
     * @param null $count 获取数量
     *
     * @return array
     * @throws \Exception
     */
    public function fetchAvailableServers($type = null, $line = null, $count = null)
    {
        $serverList = (new ServerRepository())->getAvailableServerList($type, $line, $count);

        return $serverList;
    }

    public function updateOrderHdIp($id, $hdIp)
    {
        $data = ['detail' => ['hd_ip' => $hdIp]];

        return $this->model->esUpdateById($data, $id);
    }

    public function updateOrderStatus($status, $orderId)
    {
        $data = [
            'status'      => $status,
            'last_update' => gmt_withTZ(),
        ];

        // 更新支付时间
        if ($status == OrderModel::ORDER_STATUS_PAID) {
            $data['pay_time'] = gmt_withTZ();
        }

        return $this->model->esUpdateById($data, $orderId);
    }

    private function processRechargeOrder($order, $if_plus = true)
    {
        $orderUser = (new UserModel)->where('email', $order['uid'])->find();
        if (!$orderUser) {
            throw  new WxPayException('未找到订单用户！');
        }

        // 更新用户余额
        if ($if_plus) {
            $account = $orderUser['account'] + $order['fee'];
        } else {
            // 检查当前账户余额是否充足
            if ($orderUser['account'] < $order['fee']) {
                throw new AccountPayException('订单' . $order['id'] . '余额不足，无法扣款！');
            }

            $account = $orderUser['account'] - $order['fee'];
        }

        $updateRslt = $orderUser->save(compact('account'));
        if (!$updateRslt) {
            throw new WxPayException('更新用户余额失败！');
        }

        return true;
    }


    /**
     * 处理已支付的实例升级订单
     * 1. 更新实例配置
     * 2. 更新实例有效期
     *
     * @param $order
     * @return bool
     * @throws \Exception
     */
    private function processUpgradeOrder($order)
    {
        if (!isset($order['detail'], $order['detail']['instance_id'])) {
            return false;
        }

        // 升级订单中，只有一个实例Id
        $instanId = $order['detail']['instance_id'][0] ?? null;
        $instance = (new DDoSRepository())->getDDoSById($instanId);
        if (!$instance) {   // 找不到实例时，无法进行升级
            throw new \RuntimeException('高防实例升级失败，未找到该实例！');
        }

        // 获取该升级订单生成的新实例配置
        $newConfs = [];
        $orderAttributes = $order['detail']['attributes'] ?? [];
        foreach ($orderAttributes as $attribute) {
            $newConfs[$attribute['name']] = $attribute['value'];
        }

        $newConfs['instance_id'] = $instanId;            // 实例ID
        $newConfs['uid'] = $instance['uid'];             // 用户ID
        $newConfs['type'] = $instance['type'];           // 实例类型
        $newConfs['status'] = $instance['status'];       // 实例状态
        $newConfs['start_date'] = $order['start_date'];  // 开始时间
        $newConfs['end_date'] = $order['end_date'];      // 结束时间
        $newConfs['last_update'] = gmt_withTZ();         // 最后更新时间
        $newConfs['area'] = $instance['area'];           // 实例地区
        $newConfs['line'] = $instance['line'];           // 实例线路
        $newConfs['instance_line'] = $instance['instance_line']; // 实例线路
        $newConfs['sp_num'] = $instance['sp_num'];       // 购买时长

        isset($instance['node_id']) && $newConfs['node_id'] = $instance['node_id'];    // 高防节点ID
        isset($instance['hd_ip']) && $newConfs['hd_ip'] = $instance['hd_ip'];    // 高防IP（数组）

        // 网站防护需要保留site_count
        isset($instance['site_count']) && $newConfs['site_count'] = $instance['site_count'];
        // 应用防护需要保留port_count
        isset($instance['port_count']) && $newConfs['port_count'] = $instance['port_count'];

        // 更新实例的配置信息
        $updateRslt = (new UserInstanceModel())->esAdd($newConfs, $instanId);
        if (!$updateRslt) {
            throw new \RuntimeException('高防实例升级失败，配置更新失败！');
        }

        return true;
    }


    /**
     * 根据用户实例ID，获取实例消费的最新订单
     *
     * @param string $instanceId
     * @return array|int
     * @throws \Exception
     */
    public function getFreshestOrderByInstanceId($instanceId)
    {
        $filter = [
            'query' => [
                'bool' => [
                    'filter' => [
                        ['term' => ['detail.instance_id.keyword' => $instanceId]],
                        [
                            'terms' => [
                                'type' => [
                                    OrderModel::ORDER_TYPE_PAID,
                                    OrderModel::ORDER_TYPE_RENEWAL,
                                    OrderModel::ORDER_TYPE_UPGRADE
                                ]
                            ]
                        ],
                        ['term' => ['status' => OrderModel::ORDER_STATUS_PAID]]
                    ]
                ]
            ],
            'sort'  => [
                [
                    'create_time' => [
                        'order' => 'desc'
                    ]
                ]
            ]
        ];

        $data = $this->model->esSearch($filter);

        return $data ? $data[0] : false;
    }

    /**
     * 续费、升级订单创建
     *
     * @param $orderInfo array
     * @param $type string
     * @return array
     */
    private function generateRenewalUpgradeOrder($orderInfo, $type = 'renewal')
    {
        // 初始化订单状态 时间等
        $create_time = gmt_withTZ();
        $orderInfo['create_time'] = $create_time;
        $orderInfo['last_update'] = $create_time;
        $orderInfo['pay_time'] = null;
        $orderInfo['status'] = OrderModel::ORDER_STATUS_CREATED;
        $orderInfo['final_fee'] = $orderInfo['fee'];

        if (strtotime($orderInfo['end_date']) < time()) {
            // 实例过期续费
            $dt = Carbon::parse($create_time);
            $dt = $dt->addMonths($orderInfo['sp_time']);
            $orderInfo['start_date'] = $create_time;
            $orderInfo['end_date'] = gmt_withTZ($dt->timestamp);
        } else {
            // 非过期续费
            $dt = Carbon::parse($orderInfo['end_date']);
            $dt = $dt->addMonths($orderInfo['sp_time']);
            $orderInfo['end_date'] = gmt_withTZ($dt->timestamp);
        }

        if ('renewal' === $type) {
            // 修改订单实例开始结束时间
            foreach ($orderInfo['detail']['attributes'] as &$tmp) {
                //是续费的话.
                if ($tmp['name'] === 'sp_time') {
                    $tmp['value'] = $orderInfo['sp_time']; // 购买时长更新
                    $tmp['price'] = $orderInfo['sp_time_price']; // 费率更新
                    break;
                }
            }
            unset($tmp, $orderInfo['id'], $orderInfo['sp_time'], $orderInfo['sp_time_price']);
        } else {
            //todo:对升级订单进行操作
            unset($orderInfo['id'], $orderInfo['sp_time']);
        }

        return $orderInfo;
    }
}
