<?php

namespace app\client\repository;

use app\client\model\PhyConfModel;
use app\client\model\PortModel;
use app\client\model\ProxyNodeInfoModel;
use app\client\service\Auth;
use app\client\service\MockData;
use app\common\model\OrderModel;
use app\common\model\UserInstanceModel;
use app\index\repository\UserappRepository;
use Carbon\Carbon;

class DDoSRepository extends BaseRepository
{
    protected $orderModel;

    protected $phyConfModel;

    protected $instanceModel;

    protected $proxyNodeInfoModel;

    protected $report;


    public function __construct()
    {
        $this->model = new UserInstanceModel();

        $this->orderModel = new OrderModel();

        $this->phyConfModel = new PhyConfModel();

        $this->instanceModel = new UserInstanceModel();

        $this->proxyNodeInfoModel = new ProxyNodeInfoModel();

        $this->report = new ReportRepository();
    }

    public function generateInstanceId()
    {
        do {
            $id = 'ddos-' . strtolower(str_rand(7));
            $result = $this->instanceModel->esGetById($id);
        } while ($result);

        return $id;
    }

    /**
     * 构造高防IP查询的基础查询
     * @return array
     */
    public static function DDoSFilter()
    {
        $filter = [
            'query' => [
                'bool' => [
                    'must'     => [
                        [
                            'term' => [ //需要是当前用户
                                'uid.keyword' => Auth::id()
                            ]
                        ],
                        [
                            'term' => [ // 订单需要是消费订单
                                'type' => OrderModel::ORDER_TYPE_PAID,
                            ],
                        ],
                        [
                            'term' => [ // 订单需要是已支付状态
                                'status' => OrderModel::ORDER_STATUS_PAID,
                            ]
                        ],
                        [
                            'range' => [ // 实例的有效期需要大于当前时间
                                'detail.end_date' => [
                                    'gt' => gmt_withTZ()
                                ],
                            ]
                        ]
                    ],
                    'must_not' => [
                        'term' => [ // 已分配高防IP
                            'detail.hd_ip.keyword' => ''
                        ]
                    ]
                ]
            ]
        ];

        return $filter;
    }

    /**
     * 获取高防IP列表
     * @param array $filter
     * @param int $from
     * @param null $size
     * @return array
     * @throws \Exception
     */
    public function getDDoSList($filter = [], $from = 0, $size = null)
    {
        $ddosList = $this->instanceModel->esSearch($filter, $from, $size);
        // 过滤所有项的start_date 和 end_date
        foreach ($ddosList as $key => &$item) {
            $item['start_date'] = format_time(strtotime($item['start_date']));
            $item['end_date'] = format_time(strtotime($item['end_date']));
            $item['last_update'] = format_time(strtotime($item['last_update']));
            //是否允许续费或者升级
            //当前时间到实例结束时间小于3年
            $item['near_end_time'] = $this->getNearEndTime($item);

            // 高防实例可接入域名数
            if (isset($item['site_count'])) {
                $item['site_count'] *= (UserInstanceModel::$instanceLineCounts[$item['instance_line']] ?? 1);
            }

            $attack = $this->getAttack($item);
            $item['number'] = $attack['number'];
            $item['total'] = $attack['total'];
            $item['type'] += 0;
            //自定义状态解释字段
            $item['status_attr'] = UserInstanceModel::statusArray[$item['status']] ?? '未知';
            $item['type_attr'] = UserInstanceModel::typeArray[$item['type']] ?? '未知';
        }

        return $ddosList;
    }

    /**
     * 获取用户实例信息
     * @param $ip
     * @return array
     * @throws \Exception
     */
    public function getIPPhyConf($ip)
    {
        $phyConf = $this->phyConfModel->esGetById($ip);

        return $phyConf ?: [];
    }

    /**
     * 为用户分发订单实例
     * @param $orderId
     * @return array|bool
     * @throws \Exception
     */
    public function dispatchOrderInstance($orderId)
    {
        $order = (new OrderRepository())->getOrderById($orderId);
        if (!$order && !empty($order['detail'])) {
            return false;
        }

        // 解析订单数据
        $count = 0;
        $attributes = [];
        foreach ($order['detail']['attributes'] as $attribute) {
            if (isset($attribute['value']) && !empty($attribute['value'])) {
                $attributes[$attribute['name']] = $attribute['value'];
            }
            if ($attribute['name'] == 'area') {
                $attributes[$attribute['name']] = array_search($attribute['value'], UserInstanceModel::$instanceAreas);
            } elseif ($attribute['name'] == 'line') {
                $attributes['instance_line'] = array_search($attribute['value'], UserInstanceModel::$instanceLines);
            } elseif ($attribute['name'] == 'sp_num') {
                $count = $attribute['value'];
            }
        }

        // 排除自身已经拥有的高防节点
        $filter['query']['bool']['must'] = [
            ['term' => ['uid.keyword' => Auth::id()]],
            ['term' => ['area' => $attributes['area']]],
            ['term' => ['instance_line' => $attributes['instance_line']]],
            ['term' => ['type' => $order['product_id']]]
        ];
        $exclude = $this->model->esSearch($filter);
        $exclude = array_column($exclude, 'node_id');

        // 查询可用的高防节点
        $filter['query']['bool'] = [
            'must_not' => ['terms' => ['node_id.keyword' => $exclude]],
            'must'     => [
                ['term' => ['area' => $attributes['area']]],
                ['term' => ['line_type' => $attributes['instance_line']]],
                ['term' => ['node_type' => $order['product_id']]]
            ]
        ];

        if ($order['product_id'] != UserInstanceModel::INSTANCE_TYPE_SHARED) {  // 独享型高防实例，高防节点接入用户数必须是0
            $filter['query']['bool']['must'][] = ['term' => ['user_count' => 0]];
        } else {    // 共享型高防实例，高仿节点用户接入数不作限制
            $filter['sort'] = [['user_count' => ['order' => 'asc']]];
        }

        // 查询与订单购买数量相符的高防节点数量
        $proxyNodes = $this->proxyNodeInfoModel->esSearch($filter, 0, $count);

        // 如果订单配置存在site_count，且product_id属于共享或独享，存储site_count
        // 不存在site_count字段，标识当前不进行限制
        // 如果product_id是应用型，只限制端口，不限制接入数量
        if (isset($order['detail'], $order['detail']['site_count']) &&
            in_array($order['product_id'], [UserInstanceModel::INSTANCE_TYPE_SINGLE, UserInstanceModel::INSTANCE_TYPE_SHARED])) {
            $attributes['site_count'] = $order['detail']['site_count'];
        }

        $orderInstanceIds = []; // 订单分配到的高防实例Id列表
        //如果符合购买数量，进行分配。否则标记为未分配
        if ($count == count($proxyNodes)) {
            foreach ($proxyNodes as $index => $proxyNode) {
                $instanceId = $this->generateInstanceId();
                if ($order['product_id'] != UserInstanceModel::INSTANCE_TYPE_PORT) {
                    // 网站类型, 实例下各地址site_count初始化
                    $proxyNode['node_ip'] = array_map(function ($item) {
                        return ['line' => $item['line'], 'ip' => $item['ip'], 'site_count' => 0];
                    }, $proxyNode['node_ip']);
                }
                $data = [
                    'instance_id' => $instanceId,
                    'uid'         => Auth::id(),
                    'type'        => $order['product_id'],
                    'status'      => UserInstanceModel::STATUS_ACTIVATED,
                    'start_date'  => $order['start_date'],
                    'end_date'    => $order['end_date'],
                    'node_id'     => $proxyNode['node_id'],
                    'hd_ip'       => $proxyNode['node_ip'],
                    'last_update' => gmt_withTZ()
                ];
                $data = array_merge($data, $attributes);

                // 写入用户实例信息并将高防节点user_count加1
                if ($this->instanceModel->esAdd($data, $instanceId)) {
                    $this->updateProxyNodeUserCount($proxyNode);
                    $orderInstanceIds[] = $instanceId;
                } else {
                    throw new \Exception('写入已分配实例失败！');
                }
            }
        } else {
            throw new \Exception('分配实例失败，高防节点资源不足！');
        }

        return $orderInstanceIds;
    }

    /**
     * 回收高防实例的高防IP
     * @param  string $id 高防实例ID
     * @return boolean
     */
    public function recycle($id)
    {
        try {
            $ddos = $this->getDDoSById($id);
            $proxyNode = $this->proxyNodeInfoModel->esGetById($ddos['node_id']);

            return $this->proxyNodeInfoModel->esUpdateById(['user_count' => $proxyNode['user_count'] - 1], $ddos['node_id']);
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * 获取用户的高防实例
     * @param $filter
     * @return array
     */
    public function getUserDDoSList($filter)
    {
        try {
            $filter['query']['bool']['must'][] = ['term' => ['uid.keyword' => Auth::id()]];
            $ddosList = $this->instanceModel->esSearch($filter);
            // 过滤所有项的Start_date 和 end_date
            foreach ($ddosList as $key => $item) {
                $ddosList[$key]['start_date'] = strtotime($item['start_date']);
                $ddosList[$key]['end_date'] = strtotime($item['end_date']);
            }

            return $ddosList;
        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * 根据ID获取高防实例 信息
     *
     * @param $id
     * @return null|string
     * @throws \Exception
     */
    public function getDDoSById($id)
    {
        try {
            $ddos = $this->instanceModel->esGetById($id);
            if ($ddos) {
                $ddos['start_date'] = strtotime($ddos['start_date']);
                $ddos['end_date'] = strtotime($ddos['end_date']);
            }

            return $ddos;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * 删除高仿实例
     *
     * @param $id
     * @return bool
     * @throws \Exception
     */
    public function delDDoSById($id)
    {
        try {
            $this->recycle($id);

            return (bool)$this->instanceModel->esDeleteById($id);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    /**
     * 获取可用的高防节点信息
     *
     * @param $ddosLine
     * @param $ddosType
     * @param $ddosArea
     * @return mixed|null
     */
    public function getAvailableProxyNodeInfo($ddosLine, $ddosType, $ddosArea)
    {
        try {
            //筛选获取当前用户已启用的高防节点IP
            $finder['query']['bool']['filter'][] = [
                ['term' => ['instance_line' => $ddosLine]],
                ['term' => ['type' => $ddosType]],
                ['term' => ['area' => $ddosArea]],
                ['term' => ['status' => UserInstanceModel::STATUS_ACTIVATED]],
                ['term' => ['uid.keyword' => Auth::id()]]
            ];

            $existsInstances = $this->instanceModel->esSearch($finder);

            if ($existsInstances) {
                $existsProxyIps = [];
                foreach ($existsInstances as $instance) {
                    foreach ($instance['hd_ip'] as $tmp) {
                        $existsProxyIps[] = $tmp['ip'];
                    }
                }
                //去重
                $existsProxyIps = array_unique($existsProxyIps);

                foreach ($existsProxyIps as $ip) {
                    $must_not[] = ["term" => ['node_ip.ip.keyword' => $ip]];
                }
                $filter['query']['bool']['must_not'] = $must_not;
            }

            $filter['query']['bool']['must'] = [
                ['term' => ['line_type' => $ddosLine]],
                ['term' => ['area' => $ddosArea]],
                ['term' => ['node_type' => $ddosType]]
            ];

            // 独享型实例
            if ($ddosType == UserInstanceModel::INSTANCE_TYPE_SINGLE) {
                $filter['query']['bool']['must'][] = ['term' => ['user_count' => 0]];
            }

            // 获取一个可用的高防节点信息
            $proxyNodeInfo = $this->proxyNodeInfoModel->esSearch($filter, 0, 1);
            if (!empty($proxyNodeInfo)) {
                return array_shift($proxyNodeInfo);
            }

            return null;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * 根据实例ID，更新实例状态为已更新
     * 1.根据实例的线路、类型、接入区域获取
     * @param $ddosInstanceId
     * @param $proxyNodeInfo
     * @return array|bool
     */
    public function ddosActive($ddosInstanceId, $proxyNodeInfo)
    {
        try {
            $hdIps = $proxyNodeInfo['node_ip'];

            if (in_array($proxyNodeInfo['node_type'], [UserInstanceModel::INSTANCE_TYPE_SINGLE, UserInstanceModel::INSTANCE_TYPE_SHARED])) {
                array_walk($hdIps, [$this, 'processSiteInstanceHdIps']);
            } else {
                array_walk($hdIps, [$this, 'processPortInstanceHdIps']);
            }

            $filter['query']['bool']['must'] = [
                ['term' => ['proxy_ip.instance_id.keyword' => $ddosInstanceId]],
                ['term' => ['status' => PortModel::PORT_STATUS_NORMAL]],
                ['term' => ['type' => PortModel::USER_APP_TYPE_PORT]]
            ];
            $port_count = (int)(new UserappRepository())->countApps($filter);

            $instanceData = [
                'hd_ip'      => $hdIps,
                'node_id'    => $proxyNodeInfo['node_id'],
                'area'       => $proxyNodeInfo['area'],
                'status'     => UserInstanceModel::STATUS_ACTIVATED,
                'port_count' => $port_count,
            ];

            return $this->instanceModel->esUpdateById($instanceData, $ddosInstanceId);
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * 更新当前高防节点的用户接入数
     *
     * @param $proxyNodeInfo
     * @return bool
     */
    public function updateProxyNodeUserCount($proxyNodeInfo)
    {
        try {
            $newCount = (int)(($proxyNodeInfo['user_count'] ?? 0) + 1);

            return $this->proxyNodeInfoModel->esUpdateById(['user_count' => $newCount], $proxyNodeInfo['node_id']);
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * 获取用户的高防IP
     *
     * @param null $line
     * @param null $type
     * @param int $from
     * @param null $size
     * @return array
     * @throws \Exception
     */
    public function getUserDDoSIps($line = null, $type = null, $from = 0, $size = null)
    {
        $filter = [
            'query' => [
                'bool' => [
                    'must' => [
                        ['term' => ['uid.keyword' => Auth::id()]],
                        ['term' => ['status' => UserInstanceModel::STATUS_ACTIVATED]],
                    ]
                ]
            ]
        ];

        $line !== null && $filter['query']['bool']['must'][] = ['term' => ['hd_ip.line' => $line]];
        $type !== null && $filter['query']['bool']['must'][] = ['term' => ['type' => $type]];

        // 获取列表
        $instances = $this->instanceModel->esSearch($filter, $from, $size);
        $total = $this->instanceModel->esCount($filter);
        // 对实例列表进行处理：1、添加地域、线路中文显示；2、添加网站接入数量限制
        $ips = $this->processInstanceList($instances);

        return ['list' => array_values($ips), 'total' => $total];
    }

    /**
     * 获取实例可接入
     * @param $line
     * @param $type
     * @return array
     */
    public function getAvailableArea($line, $type, $site_count_needs)
    {
        try {
            //筛选获取当前用户已启用的高防节点IP
            $finder['query']['bool']['filter'][] = [
                ['term' => ['instance_line' => $line]],
                ['term' => ['type' => $type]],
                ['term' => ['status' => $this->instanceModel::STATUS_ACTIVATED]],
                ['term' => ['uid.keyword' => Auth::id()]]
            ];
            $exsitsInstance = $this->instanceModel->esSearch($finder);

            if (!empty($exsitsInstance)) {
                $exsits_proxyIp = [];
                foreach ($exsitsInstance as $instance) {
                    foreach ($instance['hd_ip'] as $tmp) {
                        $exsits_proxyIp[] = $tmp['ip'];
                    }
                }

                $exsits_proxyIp = array_unique($exsits_proxyIp);
                foreach ($exsits_proxyIp as $ip) {
                    $must_not[] = ["term" => ['node_ip.ip.keyword' => $ip]];
                }
                $filter['query']['bool']['must_not'] = $must_not;
            }

            // 获得当前实例可接入的所有高防节点
            $must = [
                ['term' => ['line_type' => $line]],
                ['term' => ['node_type' => $type]],
            ];

            // 如果是独享型实例，只能获取尚未有用户接入的高防节点
            $type == UserInstanceModel::INSTANCE_TYPE_SINGLE && $must[] = ['term' => ['user_count' => 0]];

            $filter['query']['bool']['must'] = $must;

            $nodes = $this->proxyNodeInfoModel->esSearch($filter);
            // 如果是网站类实例, 需要验证此高防节点中所有IP剩余网站数是否足够
            if ($type == UserInstanceModel::INSTANCE_TYPE_SHARED || $type == UserInstanceModel::INSTANCE_TYPE_SINGLE) {
                $nodes = array_filter($nodes, function ($node) use ($site_count_needs) {
                    $site_limit = $node['site_limit'];
                    $already_used_count = $this->getAlreadyUsedSiteCount($node['node_id']);

                    return $site_limit - $already_used_count >= $site_count_needs;
                });
            }

            $availableAreas = array_column($nodes, 'area');

            // 获取所有地域列表
            $areas = MockData::value('AreaList');
            foreach ($areas as $key => &$area) {
                if (isset($area['children'])) {
                    // 如果有子地域，根据自地域判断当前地域是否可用，并移除不可用的地域
                    foreach ($area['children'] as $_k => $_area) {
                        if (!in_array($_area['value'], $availableAreas)) {
                            unset($areas[$key]['children'][$_k]);
                        }
                    }
                    // 如果该节点下所有子地域都被移除，说明当前地域无可接入的地域，移除地域
                    if (empty($areas[$key]['children'])) {
                        unset($areas[$key]);
                    } else {
                        $areas[$key]['children'] = array_values($areas[$key]['children']);
                    }
                } else {
                    // 如果没有子地域，直接判断当前地域是否可用，移除不可用的
                    if (!in_array($area['value'], $availableAreas)) {
                        unset($areas[$key]);
                    }
                }
            }

            return array_values($areas);
        } catch (\Exception $e) {
            return [];
        }
    }

    public function getRelationAreaIds($areaId)
    {
        $relationIds = [];
        $start = 10 * $areaId;
        $end = $start + 9;

        for ($i = $start; $i <= $end; $i++) {
            $relationIds[] = $i;
        }

        return $relationIds;
    }

    /**
     * 对实例列表进行过滤：
     * 1、添加实例地域和线路中文显示
     * 2、添加IP可接入数量
     *
     * @param array $ddosInstances
     * @return array
     */
    public function processInstanceList($ddosInstances = [])
    {
        $ddos = [];
        foreach ($ddosInstances as $instance) {
            if ($instance['type'] == UserInstanceModel::INSTANCE_TYPE_PORT) {
                array_walk($instance['hd_ip'], function (&$item) {
                    $item['line_text'] = UserInstanceModel::$instanceLines[$item['line']];
                });
            } else {
                $site_limit = $instance['site_count'] ?? -1;
                array_walk($instance['hd_ip'], function (&$item) use ($site_limit) {
                    $item['line_text'] = UserInstanceModel::$instanceLines[$item['line']];
                    $item['usable'] = 1;

                    // 如果实例限制了域名数量，且当前接入数量达到site_limit，不能继续接入
                    if (isset($item['site_count']) && $site_limit != -1) {
                        $item['usable'] = $item['site_count'] >= $site_limit ? 0 : 1;
                        unset($item['site_count']);
                    }
                });
            }

            $ddos[$instance['id']] = [
                'type'      => $instance['type'] + 0,
                'area'      => $instance['area'],
                'area_text' => UserInstanceModel::$instanceAreas[$instance['area']],
                'ddos_id'   => $instance['id'],
                'ips'       => $instance['hd_ip']
            ];
        }

        return $ddos;
    }

    // 获得某个高防节点已经被用户购入的防护域名数
    private function getAlreadyUsedSiteCount($id)
    {
        $site_count = 0;

        $filter['query']['bool']['filter'][] = ['term' => ['node_id.keyword' => $id]];
        $instance = $this->instanceModel->esSearch($filter);
        if (empty($instance)) {
            return $site_count;
        }

        foreach ($instance as $tmp) {
            $site_count += $tmp['site_count'];
        }

        return $site_count;
    }

    /**
     * 获取24小内的攻击峰值和流量
     *
     * @param $item
     * @return array
     * @throws \Exception
     */
    private function getAttack($item): array
    {
        $data = ['number' => 0, 'total' => 0];

        //激活实例才有攻击峰值和攻击次数
        if (UserInstanceModel::STATUS_ACTIVATED === $item['status']) {
            $filter = $filter2 = [];

            $endTime = Carbon::now()->timestamp;
            $startTime = Carbon::now()->subDay(1)->timestamp;

            if ($startTime < $item['start_date']) {
                $startTime = $item['start_date'];
            }

            $serverIp = array_column($item['hd_ip'], 'ip');

            $filter[] = [
                'terms' => ['server-ip' => $serverIp],
            ];
            $filter2[] = ['terms' => ['server-ip' => $serverIp]];

            $filter[] = ['range' => ['start-time' => ['gte' => gmt_withTZ($startTime)]]];
            $filter[] = ['range' => ['start-time' => ['lt' => gmt_withTZ($endTime)]]];

            $filter2[] = ['range' => ['timestamp' => ['gte' => gmt_withTZ($startTime)]]];
            $filter2[] = ['range' => ['timestamp' => ['lt' => gmt_withTZ($endTime)]]];

            // 查询条件
            $filter = ['query' => ['bool' => compact('filter')]];
            $filter2 = ['query' => ['bool' => ['filter' => $filter2]]];

            //获取攻击类型和攻击次数
            $filter['aggs'] = $this->report->getAttackType();
            $attackType = $this->report->getAttackRecord($filter);

            //获取攻击流量
            $filter2['aggs'] = $this->report->getAttackFlow($startTime, $endTime);
            $attackFlow = $this->report->getAttackFlowRecord($filter2);

            return [
                'number' => $attackType['attackCount'],
                'total'  => $attackFlow['maxBps'],
            ];
        }

        return $data;
    }

    public function updateDDoS($attributes, $ddos)
    {
        is_string($ddos) && $ddos = $this->getDDoSById($ddos);

        $attributes['last_update'] = gmt_withTZ();

        return $this->model->esUpdateById($attributes, $ddos['instance_id']);
    }

    /**
     * 获取用户已拥有的高防实例（B端使用）
     *
     * @param $id   用户id
     *
     * @return int
     */
    public function getUserDDoSTotal($id)
    {
        $filter['query']['bool']['must'][] = ['term' => ['uid.keyword' => $id]];

        return (int)$this->model->esCount($filter);
    }

    /**
     * 实例是否可以继续进行[续费][升级]
     *
     * @param $item
     * @param bool $convert
     * @return bool
     */
    public function getNearEndTime($item, $convert = false)
    {
        //$now = Carbon::now();
        if ($convert) {
            $startDate = Carbon::createFromTimestamp($item['start_date']);
            $endDate = Carbon::createFromTimestamp($item['end_date']);
        } else {
            $startDate = new Carbon($item['start_date']);
            $endDate = new Carbon($item['end_date']);
        }

        if ($endDate->diffInYears($startDate) < 3) {
            return 1;
        }

        return 0;
    }
}
