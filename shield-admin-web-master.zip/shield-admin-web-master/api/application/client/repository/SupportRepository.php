<?php

namespace app\client\repository;

use app\common\model\SupportModel;

/**
 * Class SupportRepository 支持人员
 *
 * @package app\client\repository
 * @author Teddy Sun <sgsheg@163.com>
 */
class SupportRepository extends BaseRepository
{
    public function __construct()
    {
        $this->model = new SupportModel();
    }

    /**
     * 新增支持人员
     *
     * @param $support
     * @return bool
     * @throws \Exception
     */
    public function create($support): bool
    {
        $result = $this->model->esAdd($support);

        return isset($result['result']) && $result['result'] === 'created';
    }

    /**
     * 获取支持人员列表
     *
     * @param array $filter
     * @param int $from
     * @param null $size
     * @return array
     * @throws \Exception
     */
    public function supportList($filter = [], $from = 0, $size = null)
    {
        return $this->model->esSearch($filter, $from, $size);
    }

    /**
     * 获取总数
     *
     * @param array $filter
     * @return null|string
     * @throws \Exception
     */
    public function getSupportTotal($filter = [])
    {
        return $this->model->esCountDocs($filter);
    }

    /**
     * 根据邮箱查找代理商
     *
     * @param $id
     *
     * @return null|string
     * @throws \Exception
     */
    public function selectSupportById($id)
    {
        return $this->model->esGetById($id);
    }

    /**
     * 获取支持人员
     *
     * @return array
     * @throws \Exception
     */
    public function getSupport()
    {
        $filter     = [
            '_source' => ['name', 'qq', 'mobile', 'avatar', 'email'],
            'query'   => [
                'bool' => [
                    'filter' => [
                        ['term' => ['type' => 2]],
                    ]
                ]
            ]
        ];
        $technicals = self::supportList($filter);

        $filter = [
            '_source' => ['name', 'qq', 'mobile', 'avatar', 'email'],
            'query'   => [
                'bool' => [
                    'filter' => [
                        ['term' => ['type' => 1]],
                    ]
                ]
            ]
        ];
        $sales  = self::supportList($filter);

        $technical = [];
        if ($technicals) {
            $technical[] = $technicals[0];
        }
        $sale = null;
        if ($sales) {
            $sale = $sales[0];
        }

        return [$technical, $sale];
    }
}