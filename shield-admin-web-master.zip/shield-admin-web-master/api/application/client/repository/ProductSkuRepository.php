<?php
/**
 * Created by PhpStorm.
 * User: 叶肖肖
 * Date: 2018/07/06
 * Time: 14:02
 */

namespace app\client\repository;

use app\common\model\ProductSkuModel;

class ProductSkuRepository extends BaseRepository
{

    public function __construct()
    {
        $this->model = new ProductSkuModel();
    }

    /**
     * 根据商品ID获取商品属性
     *
     * @param $productId
     *
     * @return array
     * @throws \Exception
     */
    public function getProductSkuListByProductId($productId)
    {
        $filter = [
            'query' => [
                'bool' => [
                    'must' => [
                        ['term' => ['product_id' => $productId]]
                    ]
                ]
            ],
            'sort' => [
                'price_id' => ['order' => 'asc']
            ]
        ];
        $product_skus = $this->model->esSearch($filter);

        if ($product_skus) {
            return $product_skus;
        }

        return [];
    }

    /**
     * 获取sku
     *
     * @param $skuId
     * @return array|int
     * @throws \Exception
     */
    public function getProductSkuById($skuId)
    {
        $filter = [
            'query' => [
                'bool' => [
                    'filter' => [
                        [
                            'term' => [
                                'price_id' => $skuId
                            ]
                        ]
                    ]
                ]
            ]
        ];

        $data = $this->model->esSearch($filter);

        return $data ? $data[0] : false;
    }

}
