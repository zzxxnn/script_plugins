<?php

use think\Route;

Route::group('v1', function () {

    // 版本号
    Route::get('app-version', function () {
        $version = env('APP_VERSION', '未知版本');
        return Finalsuccess($version);
    });

    // 引入Login 模块路由
    require APP_PATH.'client/route/auth.php';
    // 引入User 模块路由
    require APP_PATH.'client/route/user.php';
    // 引入Site模块路由
    require APP_PATH.'client/route/site.php';
    // 引入Order模块路由
    require APP_PATH.'client/route/order.php';
    // 引入Server模块路由
    require APP_PATH.'client/route/server.php';

    // 引入Port模块路由
    require APP_PATH.'client/route/port.php';

    // 引入DDoS模块路由
    require APP_PATH.'client/route/ddos.php';

    // 引入Pay模块路由
    require APP_PATH.'client/route/pay.php';

    // 引入Invoice模块路由
    require APP_PATH.'client/route/invoice.php';
});

Route::rule([
    'login'                 => 'client/index/login',
    'register'              => 'client/index/register',
    'register/:code'        => 'client/index/register',
    'password_find'         => 'client/index/password_find',
    'password_reset/:token' => 'client/index/password_reset'
]);

Route::miss('client/Index/index');
