<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/6/22
 * Time: 13:54
 */

namespace app\client\service;

use app\common\exception\client\Pay\WxPayException;
use WxPayApi;
use WxPayOrderQuery;
use WxPayUnifiedOrder;

class WxPay
{
    /**
     * 调用微信支付 统一下单API
     * 生成微信支付平台订单
     * @param string $goodsInfo
     * @param $orderId
     * @param $totalFee
     * @param $goodsId
     * @param string $type
     * @return \成功时返回，其他抛异常
     * @throws \WxPayException
     */
    public function getUnifiedOrder($goodsInfo = '', $orderId, $totalFee, $goodsId, $type = 'NATIVE')
    {
        $curTime = time();
        $expire = config('wx_pay.url_expire');
        $totalFee = config('app_debug') ? 1 : $totalFee;
        $wxPayOrder = new WxPayUnifiedOrder();
        $wxPayOrder->SetBody($goodsInfo);    // 商品描述
        $wxPayOrder->SetAttach('HD 测试订单');   // 附加数据
        $wxPayOrder->SetOut_trade_no($orderId);   // 商户订单号
        $wxPayOrder->SetTotal_fee($totalFee);  // 订单总金额
        $wxPayOrder->SetTime_start(date('YmdHis', $curTime));     // 交易起止时间
        $wxPayOrder->SetTime_expire(date('YmdHis', $curTime + $expire));   // 交易结束时间
        $wxPayOrder->SetTrade_type($type);
        $wxPayOrder->SetProduct_id('product_' . $goodsId);
        $notifyUrl = config('wx_pay.notify_url');
        $wxPayOrder->SetNotify_url($notifyUrl);

        return WxPayApi::unifiedOrder($wxPayOrder);
    }

    /**
     * 获取 支付链接
     *
     * @param $goodsInfo
     * @param $orderId
     * @param $totalFee
     * @param $goodsId
     * @return mixed
     * @throws WxPayException
     * @throws \WxPayException
     */
    public function getPayUrl($goodsInfo, $orderId, $totalFee, $goodsId)
    {
        $unifiedOrder = $this->getUnifiedOrder($goodsInfo, $orderId, $totalFee, $goodsId, $type = 'NATIVE');
        if (!isset($unifiedOrder['result_code'], $unifiedOrder['return_msg']) || $unifiedOrder['result_code'] !== 'SUCCESS') {
            throw new WxPayException($unifiedOrder['return_msg']);
        }

        return $unifiedOrder['code_url'];

    }

    /**
     * 获取订单详情
     *
     * @param $orderId
     * @return \成功时返回，其他抛异常
     * @throws \WxPayException
     */
    public function getOrderInfo($orderId)
    {
        $orderQuery = new WxPayOrderQuery();
        $orderQuery->SetOut_trade_no($orderId);

        return WxPayApi::orderQuery($orderQuery);
    }
}