<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/3/13
 * Time: 17:52
 */

namespace app\client\controller\swagger;

/**
 * @SWG\Definition()
 */
class Site
{
    /**
     * @SWG\Definition(
     *     definition="SiteList",
     *     type="object",
     *     @SWG\Property(
     *          property="list",
     *          type="object",
     *          example={"errcode":0,"errmsg":"ok","list":{{"app_id":"test.com","uid":"test@veda.com","name":"test.com",
     *     "type":1,"http":1,"https":0,"https_cert":0,"https_cert_key":0,"upstream":"192.168.2.1","status":4,
     *     "text_code":"mf0ZVN3fN3idvK3b","src_host":"","server_port":80,"proxy_ip":{{"area":41,"instance_id":"ddos-zg5yaer",
     *     "line":"8","ip":"192.20.8.1","instance_line":"8","endTime":1529582953,"expired":false},{"area":23,
     *     "instance_id":"ddos-2nidcsg","line":"8","ip":"192.20.50.1","instance_line":"8","endTime":1534855859,
     *     "expired":false}},"cache":null,"filter":null,"last_update":1527234615,"cname":"uh3jzy346h.hd.vedasec.cn",
     *     "proxy_port":80,"id":"test.com"}},"total":3}
     *      ),
     *      @SWG\Property(
     *          property="total",
     *          type="string",
     *          example="5"
     *      ),
     *     @SWG\Property(
     *          property="errcode",
     *          type="integer",
     *          example=0
     *      ),
     *     @SWG\Property(
     *          property="errmsg",
     *          type="string",
     *          example="ok"
     *      ),
     * )
     */

    /**
     * @SWG\Definition(
     *    definition="SiteBwList",
     *    type="object",
     *    @SWG\Property(property="url_white_list", type="object", example={"test","host"}, description="网址白名单"),
     *    @SWG\Property(property="url_black_list", type="object", example={"veda","haha"}, description="网址黑名单"),
     *    @SWG\Property(property="ip_white_list", type="object", example={"1.1.1.1","2.2.22.2"}, description="IP白名单"),
     *    @SWG\Property(property="ip_black_list", type="object", example={"3.32.3.3","44.4.4.4"}, description="IP黑名单")
     * )
     *
     */

    /**
     * @SWG\Definition(
     *     definition="Site Status",
     *      type="object",
     *      @SWG\Property(property=" 0 ", type="用户已提交，待审核"),
     *      @SWG\Property(property="1", type="已审核，待接入"),
     *      @SWG\Property(property="2", type="正在接入"),
     *      @SWG\Property(property="3", type="已接入，未修改DNS解析"),
     *      @SWG\Property(property="4", type="正常"),
     *      @SWG\Property(property="5", type="接入错误"),
     *      @SWG\Property(property="6", type="正在删除"),
     *      @SWG\Property(property="7", type="删除异常"),
     *
     *  )
     */

    /**
     * @SWG\Definition(
     *     definition="Site Cache",
     *      type="object",
     *      @SWG\Property(property="static_expire", type="静态资源缓存有效期"),
     *      @SWG\Property(property="html_expire", type="静态页面缓存有效期"),
     *      @SWG\Property(property="index_expire", type="首页缓存有效期"),
     *      @SWG\Property(property="directory_expire", type="目录缓存有效期")
     *  )
     */

    /**
     * @SWG\Definition(
     *     definition="Site 域名攻击信息",
     *      type="object",
     *      @SWG\Property(property="attacks.time", type="integer", example="1525356000", description="攻击时间"),
     *      @SWG\Property(property="attacks.gjMax", type="integer", example="1525", description="攻击流量峰值"),
     *      @SWG\Property(property="attacks.lhMax", type="integer", example="152", description="滤后流量峰值"),
     *      @SWG\Property(property="gjTotal", type="integer", example="15212312", description="攻击流量总计"),
     *      @SWG\Property(property="glTotal", type="integer", example="15212312", description="过虑流量总计"),
     *      @SWG\Property(property="lhTotal", type="integer", example="15212312", description="过滤后流量总计"),
     *      @SWG\Property(property="sjbTotal", type="integer", example="15212312", description="攻击数据包总计"),
     *      @SWG\Property(property="glsjbTotal", type="integer", example="15212312", description="过滤后数据包总计"),
     *      @SWG\Property(property="attackTypeCount", type="integer", example="5", description="攻击种类数"),
     *      @SWG\Property(property="attackCount", type="integer", example="64", description="总攻击次数"),
     *  )
     */

}