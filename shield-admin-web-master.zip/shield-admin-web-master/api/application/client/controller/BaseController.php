<?php

namespace app\client\controller;

use app\client\service\Auth;
use app\client\traits\CheckLogin;
use think\Controller;
use think\Log;

class BaseController extends Controller
{
    use CheckLogin;

    protected $validator;

    protected $repository;

    // 日志文件
    protected $logPath = RUNTIME_PATH . 'error-log';

    public function checkOriginIp()
    {
        //TODO 添加源站IP校验
    }

    /**
     * 添加日志异常记录
     * @param int $msg
     * @param string $lvl
     */
    public function saveLog($msg = null, $lvl = 'error')
    {
        try {
            $logFile = $this->logPath . DS . date('Ymd') . '.log';

            // 检查日志目录是否存在
            if (!is_dir(dirname($logFile))) {
                mkdir(dirname($logFile), 0755, true);
            }

            $url = request()->method() . " " . request()->url();
            $content = sprintf('[' . date('Y-m-d H:i:s') . ']' . '[%s] [%s]:' . PHP_EOL, strtoupper($lvl), $url);
            $content .= 'AUTH_INFO: ' . var_export(Auth::user(), true) . PHP_EOL;
            $content .= 'REQUEST: ' . var_export($this->getLogRequest(), true) . PHP_EOL;
            $content .= 'ERROR_MSG: ' . var_export($msg, true) . PHP_EOL;
            $content .= '---------------------------------------------------------------' . PHP_EOL;

            file_put_contents($logFile, $content, FILE_APPEND);
        } catch (\Exception $e) {
            Log::error($e->getMessage());
        }
    }

    private function getLogRequest()
    {
        return ['URL' => request()->url(), 'HEADER' => request()->header(), 'PARAM' => request()->param()];
    }

    /**
     * 控制器异常处理
     *
     * @param \Exception $e
     */
    public function errorHandle(\Exception $e)
    {
        $this->saveLog(['file' => $e->getFile(), 'code' => $e->getCode(), 'msg' => $e->getMessage(), 'line' => $e->getLine()]);
    }
}