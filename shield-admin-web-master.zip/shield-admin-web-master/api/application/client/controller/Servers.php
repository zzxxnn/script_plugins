<?php

namespace app\client\controller;

use app\client\model\ProxyNodeInfoModel;
use app\client\model\ServerModel;
use app\client\repository\DDoSRepository;
use app\client\repository\ProductSkuRepository;
use app\client\repository\ServerRepository;
use app\client\traits\CheckLogin;
use app\client\validate\ServerPrice as PriceValidate;
use app\client\validate\Servers as ServersValidator;
use app\common\model\UserInstanceModel;
use Carbon\Carbon;
use think\Request;

class Servers extends BaseController
{
    use CheckLogin;

    private $server;

    protected $validator;

    protected $beforeActionList = [
        'checkLogin' => [ 'only' => 'get,add,setthr,serverPrice,serverConfig,serverAreas,serverLines' ]
    ];

    protected $repository;

    public function __construct(Request $request)
    {
        $this->repository = new ServerRepository();

        $this->validator = new ServersValidator();

        parent::__construct($request);
    }

    public function _initialize()
    {
        $this->server = new ServerModel;
    }

    /**
     *
     * @SWG\GET(
     *      path="/server",
     *      tags={"Server 用户实例"},
     *      summary="获取用户实例列表",
     *      @SWG\Parameter(
     *          name="type",
     *          in="query",
     *          description="类型:1-独享型;2-共享型;3-非网站",
     *          type="integer"
     *      ),
     *      @SWG\Parameter(
     *          name="line",
     *          in="query",
     *          description="线路,example: 11_1",
     *          type="integer"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          ref="#/definitions/ServerList"
     *      )
     * )
     *
     * @return float|int|string
     * @throws \Exception
     */
    public function index()
    {
        $line = input('line', null);
        $type = input('type', null);

        $servers = $this->repository->getUserServer($line, $type);

        return Finalsuccess([ 'list' => $servers ]);
    }

    /**
     *
     * @SWG\Post(
     *      path="/server/price",
     *      tags={"Server 用户实例"},
     *      summary="计算当前选购实例的价格",
     *     @SWG\Parameter(
     *         name="type=1|2",
     *         in="body",
     *         description="网站类价格计算参数",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"base_bandwidth":"10","normal_bandwidth":"10","bandwidth":"10","site_count":"6","sp_num":"10","sp_time":"8","type":"1","line":"8","count":"1","period":"2:month","product_sku_id":"BHjpgmQBkdRoYao17uVv","product_id":"BHjpgmQBkdRoYao17uVv"},
     *              description="站点"
     *          )
     *     ),
     *     @SWG\Parameter(
     *         name="type=3",
     *         in="body",
     *         description="非网站类价格计算参数",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"type": 3,"line": "1_1","base_bandwidth": 10,"bandwidth": 100,"count": 1,"period":
     *              "2:month","port_count": 50}, description="站点"
     *          )
     *     ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok", "amount": 100}
     *          )
     *      )
     * )
     *
     * @param PriceValidate $validate
     *
     * @return float|int|string
     */
    public function serverPrice(PriceValidate $validate)
    {
        $data = input();

        if (! $validate->scene('search')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $validate->getError());
        }

        $amount = $this->repository->calcSiteServerPrice($data);

        return Finalsuccess(compact('amount'));
    }

    /**
     *
     * @SWG\Post(
     *      path="/server/price/renew",
     *      tags={"Server 用户实例"},
     *      summary="计算当前续费实例的价格",
     *      @SWG\Parameter(name="instance_id", in="body", required=true, type="string", description="用户实例ID",
     *          @SWG\Schema(
     *              @SWG\Property(property="instance_id", type="string", example="ddos_asdaw2d"),
     *          )),
     *      @SWG\Parameter(name="sp_time", in="body", required=false, type="integer", description="购买时长",
     *          @SWG\Schema(
     *              @SWG\Property(property="sp_time", type="string", example=10),
     *          )),
     *      @SWG\Parameter(name="action", in="body", required=false, type="string",
     *          description="价格计算类型,upgrade:升级,renewal:续费",
     *          @SWG\Schema(
     *              @SWG\Property(property="action", type="string", example="upgrade"),
     *          )),
     *      @SWG\Parameter(name="detail", in="body", required=false, type="array",
     *          description="续费详情",
     *          @SWG\Schema(
     *              @SWG\Property(property="sp_time", type="string", example=3),
     *              @SWG\Property(property="sp_num", type="string", example=3),
     *              @SWG\Property(property="site_count", type="string", example=1),
     *              @SWG\Property(property="base_bandwidth", type="string", example="10G"),
     *              @SWG\Property(property="normal_bandwidth", type="string", example="10M"),
     *              @SWG\Property(property="bandwidth", type="string", example="20G"),
     *          )),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常, amount: 金额, end_date: 到期时间, max_month:最多可以续费升级月份",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok", "data": {"amount": "4.00", "end_date": "2019-10-09 21:43:43", "max_month": 35}}
     *          )
     *      )
     * )
     * 获取续费|升级价格
     *
     * @param PriceValidate $validate
     * @param \app\client\repository\ServerRepository $repository
     * @return float|int|string
     * @throws \Exception
     */
    public function renewPrice(PriceValidate $validate, ServerRepository $repository, DDoSRepository $DDoSRepository)
    {
        $data = input();
        $maxMonth = 36; //最大购买时间为36个月即3年

        $instanceId = input('post.instance_id');
        if (! $instanceId) {
            return Finalfail(REP_CODE_PARAMS_INVALID, '实例ID不能为空');
        }
        $userInstanceModel = new UserInstanceModel();
        $instance = $userInstanceModel->esGetById($instanceId);
        $startDate = Carbon::createFromTimestamp(strtotime($instance['start_date']));
        $endDate = Carbon::createFromTimestamp(strtotime($instance['end_date']));
        $instanceMonth = $endDate->diffInMonths($startDate);

        if (empty($data['action']) || 'renew' === $data['action']) {
            if (! $validate->scene('renew')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validate->getError());
            }
            //实例续费升级最长时间为3年
            if (0 == $DDoSRepository->getNearEndTime($instance)) {
                return Finalfail(REP_CODE_ABNORMAL_OPERATION, '实例暂时无法续费');
            }
            $amount = $repository->calcRenewServerPrice($data, 'renew', $instance);
            //实例结束时间
            $newEndDate = $endDate->addMonths($data['sp_time'])->toDateTimeString();
        } elseif ('upgrade' === $data['action']) {
            if (! $validate->scene('upgrade')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validate->getError());
            }
            //实例续费升级最长时间为3年
            if (0 == $DDoSRepository->getNearEndTime($instance)) {
                return Finalfail(REP_CODE_ABNORMAL_OPERATION, '实例暂时无法升级');
            }
            //升级了
            $amount = $repository->calcRenewServerPrice($data, 'upgrade', $instance);
            //实例结束时间
            $instanceMonth = $endDate->diffInMonths($startDate);
            $diffMonth = $data['detail']['sp_time'] - $instanceMonth;
            $newEndDate = $endDate->addMonths($diffMonth)->toDateTimeString();
        } else {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '暂无价格！');
        }
        //处理价钱
        $amount = number_format((float)$amount, 2, '.', '');
        //实例最大续费和升级月份
        $maxMonth = $maxMonth - $instanceMonth;
        if ($maxMonth < 0) {
            $maxMonth = 0;
        }

        return Finalsuccess(['data' => ['amount' => $amount, 'end_date' => $newEndDate, 'max_month' => $maxMonth]]);
    }

    /**
     *
     * @SWG\Get(
     *      path="/server/config",
     *      tags={"Server 用户实例"},
     *      summary="获取可购买实例数据",
     *      @SWG\Parameter(name="type", in="query", required=true, type="integer", description="防护类型,默认为共享网站类"),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example=
     *              {"errcode":0,"errmsg":"ok","data":{{"product_id":"F3hoiGQBkdRoYao1A-WV","product_name":"网站共享","product_num":1,"area":{"label":"地区","type":"离散属性","GXhviGQBkdRoYao1suUq":"河南","FHhmiGQBkdRoYao1YuWu":"北京"},"line":{"label":"线路","type":"离散属性","GXhviGQBkdRoYao1suUq":"电信","FHhmiGQBkdRoYao1YuWu":"联通"},"base_bandwidth":{"label":"保底带宽","type":"离散计费属性","GXhviGQBkdRoYao1suUq":{{"bandwidth":"10G","price":"10"},{"bandwidth":"20G","price":"20"}},"FHhmiGQBkdRoYao1YuWu":{{"bandwidth":"10G","price":10},{"bandwidth":"20G","price":20},{"bandwidth":"30G","price":25}}},"normal_bandwidth":{"label":"业务宽带","type":"离散计费属性","GXhviGQBkdRoYao1suUq":{{"bandwidth":"10M","price":"5"},{"bandwidth":"20M","price":"6"}},"FHhmiGQBkdRoYao1YuWu":{{"bandwidth":"10M","price":5},{"bandwidth":"20M","price":10},{"bandwidth":"30M","price":30}}},"bandwidth":{"label":"弹性宽带","type":"用后计费属性","GXhviGQBkdRoYao1suUq":{{"bandwidth":"10","price":"10"},{"bandwidth":"20","price":"15"}},"FHhmiGQBkdRoYao1YuWu":{{"bandwidth":"10G","price":110},{"bandwidth":"30G","price":200}}},"site_count":{"label":"防护域名数","type":"连续计费属性","GXhviGQBkdRoYao1suUq":{{"min":"1","max":"10","price":"1"},{"min":"11","max":"50","price":"10"},{"min":"51","max":"60","price":"100"}},"FHhmiGQBkdRoYao1YuWu":{{"min":1,"max":50,"price":10},{"min":51,"max":100,"price":8}}},"sp_num":{"label":"购买数量","type":"倍率计费属性","GXhviGQBkdRoYao1suUq":{{"min":"1","max":"10","price":"1"},{"min":"11","max":"20","price":"0.8"},{"min":"21","max":"30","price":"0.7"}},"FHhmiGQBkdRoYao1YuWu":{{"min":1,"max":10,"price":1},{"min":11,"max":20,"price":0.8}}},"sp_time":{"label":"购买时长","type":"倍率计费属性","GXhviGQBkdRoYao1suUq":{{"min":"1","max":"6","price":"1"},{"min":"7","max":"12","price":"0.95"},{"min":"13","max":"18","price":"0.85"}},"FHhmiGQBkdRoYao1YuWu":{{"min":1,"max":6,"price":1},{"min":7,"max":12,"price":0.95}}}},{"product_id":"HHjlrGQBkdRoYao1sOWf","product_name":"应用类","product_num":1},{"product_id":"HXglrWQBkdRoYao1BOWG","product_name":"网站独享","product_num":1,"area":{"label":"地区","type":"离散属性","HngnrWQBkdRoYao1meVY":"天津"},"line":{"label":"线路","type":"离散属性","HngnrWQBkdRoYao1meVY":"移动"},"base_bandwidth":{"label":"保底带宽","type":"离散计费属性","HngnrWQBkdRoYao1meVY":{{"bandwidth":"10G","price":"10","type":"离散计费属性"},{"bandwidth":"20G","price":"20"}}},"bandwidth":{"label":"弹性带宽","type":"离散计费属性","HngnrWQBkdRoYao1meVY":{{"bandwidth":"10M","price":"5","type":"离散计费属性"},{"bandwidth":"20M","price":"10"},{"bandwidth":"30M","price":"30"}}},"normal_bandwidth":{"label":"业务带宽","type":"离散计费属性","HngnrWQBkdRoYao1meVY":{{"bandwidth":"10G","price":"10","type":"离散计费属性"},{"bandwidth":"15G","price":"15"},{"bandwidth":"20G","price":"20"}}},"site_count":{"label":"防护域名数","type":"连续计费属性","HngnrWQBkdRoYao1meVY":{{"min":"1","max":"20","price":"10"},{"min":"21","max":"50","price":"8"}}},"sp_num":{"label":"购买数量","type":"倍率计费属性","HngnrWQBkdRoYao1meVY":{{"min":"1","max":"50","price":"10"},{"min":"51","max":"100","price":"8"}}},"sp_time":{"label":"购买时长","type":"倍率计费属性","HngnrWQBkdRoYao1meVY":{{"min":"1","max":"6","price":"10"},{"min":"7","max":"12","price":"8"}}}}}}
     *          )
     *      )
     * )
     *
     * 获取可购买实例数据
     *
     * @return string
     * @throws \Exception
     */
    public function serverConfig()
    {
        $productList = $this->repository->getSaleProductList();
        // 检查当前商品是否存在
        if (! $productList) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该商品定价！');
        }
        $products = [];
        if ($productList) {
            foreach ($productList as $product) {
                $product_skus = ( new ProductSkuRepository() )->getProductSkuListByProductId($product['product_id']);
                if ($product_skus) {
                    $products[$product['product_id']] = [
                        'product_id' => $product['product_id'],
                        'product_name' => $product['product_name'],
                        'attributes' => $product['attributes']
                    ];
                    foreach ($product_skus as $sku) {
                        $products[$product['product_id']]['sku'][$sku['price_id']] = $sku;
                    }
                }
            }
        }
        return Finalsuccess(['data' => $products]);
    }

    /**
     *
     * @SWG\Get(
     *      path="/server/quantity",
     *      tags={"Server 用户实例"},
     *      summary="计算实例可购买最大数量",
     *      @SWG\Parameter(name="proxy_type", in="query", required=true, type="integer", description="防护类型"),
     *      @SWG\Parameter(name="line_type", in="query", required=true, type="integer", description="线路类型"),
     *      @SWG\Parameter(name="site_qty", in="query", required=true, type="integer", description="防护域名数, 无则填0"),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","max_quantity":2}
     *          )
     *      )
     * )
     *
     */
    public function computeQuantity()
    {
        $invalid = $this->validate(
            input(),
            [ 'proxy_type' => 'require|integer', 'line_type' => 'require|integer', 'site_qty' => 'require|integer' ]
        );
        if ($invalid !== true) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $invalid);
        }

        $line_type  = input('line_type');
        $proxy_type = input('proxy_type');
        $site_qty   = input('site_qty');

        // 获取数据库现有的高防节点
        $proxy_nodes = $this->repository->getProxyNodesInfo();
        $proxy_nodes = array_filter($proxy_nodes, function ($node) use ($line_type, $proxy_type) {
            return $node['line_type'] == $line_type && $node['node_type'] == $proxy_type;
        });

        if (ProxyNodeInfoModel::PROXY_NODE_TYPE_PORT == $proxy_type || ProxyNodeInfoModel::PROXY_NODE_TYPE_SINGLE == $proxy_type) {
            return Finalsuccess([ 'max_quantity' => [ "min" => 1, "max" => count($proxy_nodes), "step" => 1 ] ]);
        } elseif (ProxyNodeInfoModel::PROXY_NODE_TYPE_SHARED == $proxy_type) {
            $site_count_arr = array_column($proxy_nodes, 'site_left');
            $site_count_arr = array_filter($site_count_arr, function ($tmp) use ($site_qty) {
                return $site_qty <= $tmp;
            });

            return Finalsuccess([ 'max_quantity' => [ "min" => 1, "max" => count($site_count_arr), "step" => 1 ] ]);
        }
    }

    /**
     *
     * @SWG\Get(
     *      path="/server/{id}/areas",
     *      tags={"Server 用户实例"},
     *      summary="获取实例可接入地域",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="用户实例Id",
     *          type="integer",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","list":{{"text":"北京","value":11},{"text":"天津","value":12}}}
     *          )
     *      )
     * )
     *
     * 获取用户实例可接入的地域列表
     *
     * @param $id
     *
     * @return string
     * @throws \Exception
     */
    public function serverAreas($id)
    {
        $data = input();
        if (! $this->validator->scene('server_area')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        if (! $instance = ( new DDoSRepository() )->getDDoSById($id)) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该实例信息！');
        }
        $areas = $this->repository->getServerAvailableAreas($instance['instance_line'], $instance['type']);

        return Finalsuccess([ 'list' => $areas ]);
    }

    /**
     *
     * @SWG\Get(
     *      path="/server/lines",
     *      tags={"Server 用户实例"},
     *      summary="获取实例可接入线路",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","list":{{"value":0,"text":"海外"},{"value":1,"text":"电信"},
     *     {"value":2,"text":"联通"},{"value":3,"text":"电信、联通"},{"value":4,"text":"移动"},{"value":5,"text":"电信、移动"},
     *     {"value":6,"text":"移动、联通"},{"value":7,"text":"移动、联通和电信"},{"value":8,"text":"BGP"}}}
     *          )
     *      )
     * )
     *
     * 获取所有实例可接入线路
     *
     * @return string
     */
    public function serverLines()
    {
        $lines = $this->repository->getServerLines();

        return Finalsuccess([ 'list' => $lines ]);
    }
}
