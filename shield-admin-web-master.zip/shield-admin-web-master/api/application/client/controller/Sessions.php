<?php

namespace app\client\controller;

use app\client\service\Auth as AuthService;
use app\common\model\UserModel;
use app\common\repository\UserRepository;
use think\Controller;
use think\Loader;
use think\Log;

class Sessions extends Controller
{

    protected $validate;

    protected $repository;

    public function _initialize()
    {
        $this->validate   = Loader::validate('User');
        $this->repository = new UserRepository();
    }

    /**
     * @SWG\Get(
     *      path="/loginfo",
     *      tags={"session 登录管理"},
     *      summary="【获取】登录状态",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","is_login":true,"user_id":1,"user_email":"test@veda.com","user_account":"9485.00"}
     *          )
     *      )
     * )
     */
    public function index()
    {
        $auth = AuthService::user();
        if ($auth) {
            $user = UserModel::where('email', $auth['id'])->find();
            if ($user) {
                return Finalsuccess([
                    'is_login'     => true,
                    'user_id'      => $user->id,
                    'user_email'   => $user->email,
                    'user_account' => $user->account,
                ]);
            }
        }

        return Finalfail(REP_CODE_NEED_LOGIN, [ 'is_login' => false, 'user_email' => '', 'user_account' => 0, ]);
    }

    /**
     * @SWG\Post(
     *      path="/login",
     *      tags={"session 登录管理"},
     *      summary="【登陆】管理员登录",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="登录post信息：",
     *          @SWG\Schema(
     *              @SWG\Property(property="username", type="string", example="root"),
     *              @SWG\Property(property="password", type="string", example="veda2017"),
     *              @SWG\Property(property="captcha", type="string", example="9716"),
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     * @param UserRepository $repository
     *
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function create(UserRepository $repository)
    {
        $auth = input();

        // PHPUnit 发来的请求不进行解密
        if (!is_phpunit_testing()) {
            $auth['email']    = rsa_decrypt($auth['email']);
            $auth['password'] = rsa_decrypt($auth['password']);
        }

        if ( ! $this->validate->scene('login')->check($auth)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validate->getError());
        }

        // PHPUnit 发来的请求不进行校验码校验
        if (!is_phpunit_testing() && ! captcha_check($auth['captcha'])) {
            return Finalfail(REP_CODE_CAPTCHA_INVALID, '验证码错误');
        }

        $log = $repository->doEmail($auth);

        switch ($log) {
            case 0:
                //写入session
                AuthService::login($auth);
                // 加密前的邮箱，用作记录日志使用
                request()->bind('decrypt_email', $auth['email']);

                return Finalsuccess();
                break;
            case 1:
                return Finalfail(REP_CODE_PASSWORD_ERROR, '密码不正确');
                break;
            case 2:
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '账户不存在');
                break;
            case 3:
                $loginTimeLimit = \think\Env::get('Login_Time_Limit') ?? 30;

                request()->bind('minutes', $loginTimeLimit);

                return Finalfail(REP_CODE_ILLEGAL_OPERATION, '错误次数过多,请'.$loginTimeLimit.'分钟后重试.');
                break;
            case 4:
                return Finalfail(REP_CODE_LOGIN_NEED_REFRESH, '请刷新重试');
                break;
            default :
                return Finalfail(REP_CODE_ILLEGAL_OPERATION, '非法操作');
        }
    }

    /**
     * @SWG\Delete(
     *      path="/logout",
     *      tags={"session 登录管理"},
     *      summary="【注销】用户注销",
     *      operationId="logoutUser",
     *      parameters={},
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     */
    public function destroy()
    {
        AuthService::logout();

        return Finalsuccess();
    }
}
