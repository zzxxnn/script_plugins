<?php
/*
* This file  is a part of  Veda- Platform
* Copyright (c) 2015 - 2018. Veda Software Inc. (http://www.veda.com)
*
* @file             Base.php
* @author           Teddy Sun
*/

namespace app\client\controller\port;

use app\client\controller\BaseController;
use app\client\repository\PortRepository;
use think\db\exception\ModelNotFoundException;
use think\Request;

/**
 * Class Base
 *
 * @package app\client\controller\port
 * @author Teddy Sun <sgsheg@163.com>
 */
class Base extends BaseController
{
    const WHITE = 'white';
    const BLACK = 'black';

    protected $port;

    /**
     * Base constructor.
     *
     * @param $id
     * @param \app\client\repository\PortRepository $portRepository
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \Exception
     */
    public function __construct(PortRepository $portRepository, Request $request, $id)
    {
        $this->port = $portRepository->getPortById($id);
        if (null === $this->port) {
            throw new ModelNotFoundException('未找到应用');
        }
        parent::__construct($request);
    }
}