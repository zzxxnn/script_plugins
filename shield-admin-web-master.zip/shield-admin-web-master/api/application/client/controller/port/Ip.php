<?php
/*
* This file  is a part of  Veda- Platform
* Copyright (c) 2015 - 2018. Veda Software Inc. (http://www.veda.com)
*
* @file             Ip.php
* @author           Teddy Sun
*/

namespace app\client\controller\port;

use app\client\repository\PortRepository;
use app\client\validate\Port;
use think\db\exception\ModelNotFoundException;
use think\Request;

/**
 * Class Ip
 *
 * @package app\client\controller\port
 * @author Teddy Sun <sgsheg@163.com>
 */
class Ip extends Base
{
    /**
     * @SWG\Get(
     *      path="/port/{id}/ip-list",
     *      tags={"Port 非网站防护黑白名单"},
     *      summary="获取用户的应用防护黑白名单",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"ipBlacklist":{"127.0.0.1"},"ipWhitelist":{"127.0.0.1","127.0.0.2"}}}
     *          )
     *      )
     * )
     *
     * 获取应用该黑白名单
     *
     * @return \think\Response
     */
    public function index()
    {
        $port = $this->port;

        $ipBlacklist = $port['filter']['ip_blacklist'] ?? [];
        $ipWhitelist = $port['filter']['ip_whitelist'] ?? [];

        return Finalsuccess(['data' => compact('ipBlacklist', 'ipWhitelist')]);
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * @SWG\Post(
     *      path="/port/{id}/ip-list",
     *      tags={"Port 非网站防护黑白名单"},
     *      summary="更新应用IP名单",
     *     @SWG\Parameter(
     *         name="",
     *         in="body",
     *         description="应用IP名单",
     *         required=true,
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"type":"white", "ipBlacklist":{"192.168.1.1","192.168.1.2"}}
     *          )
     *     ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 设置成功| !=0 设置失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     * 设置应用黑白名单
     *
     * @param \app\client\repository\PortRepository $repository
     * @param \app\client\validate\Port $validator
     * @return \think\Response
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function save(PortRepository $repository, Port $validator)
    {
        // 白名单
        $type = $this->request->post('type');

        if (empty($type) || ! in_array($type, [self::WHITE, self::BLACK])) {
            //无type或者type不在允许范围内抛出异常
            throw new ModelNotFoundException('操作非法');
        }

        $whitelist = $this->request->post('ipWhitelist/a');
        $blackList = $this->request->post('ipBlacklist/a');
        $filter    = [];

        if (self::WHITE == $type) {
            //白色更新
            if (! $validator->scene('ip_white_list')->check($whitelist)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }

            $filter = ['filter' => ['ip_whitelist' => $whitelist]];
        }

        if (self::BLACK == $type) {
            //黑ip
            $filter = ['filter' => ['ip_blacklist' => $blackList]];

            if (! $validator->scene('ip_black_list')->check($blackList)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }
        }

        try {
            if ($this->updatePortElastic($repository, $this->port, $filter)) {
                return Finalsuccess();
            }
        } catch (\Exception $e) {
            return Finalfail(REP_CODE_FAILED_OPERATION, '操作失败,请重试');
        }
    }

    /**
     * 显示指定的资源
     *
     * @param  int
     * @return \think\Response
     */
    public function read($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request
     * @param  int
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * 删除指定资源
     *
     * @param  int
     * @return \think\Response
     */
    public function delete($id)
    {
        //
    }

    /**
     * 更新ES和ZK
     *
     * @param \app\client\repository\PortRepository $repository
     * @return bool|string
     * @throws \Exception
     * @throws \app\common\exception\client\ElasticSearchException
     * @throws \app\common\exception\client\PermissionDenyException
     * @throws \app\common\exception\client\ZookeeperException
     */
    private function updatePortElastic(PortRepository $repository, $port, $filter)
    {
        if (! $repository->updatePort($filter, $port)) {
            return Finalfail(REP_CODE_ES_ERROR, 'IP名单设置失败！');
        }

        // 更新Proxy Conf中的记录
        if (! $repository->setESProxyConf($port)) {
            return Finalfail(REP_CODE_ES_ERROR, 'Proxy Conf更新失败！');
        }

        // 配置ZK IP黑白名单
        if (! $repository->setZKProxyConf($port)) {
            return Finalfail(REP_CODE_ZK_ERROR, 'ZK Proxy Conf更新失败！');
        }

        return true;
    }
}