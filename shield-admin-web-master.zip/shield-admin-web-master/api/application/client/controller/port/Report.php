<?php

namespace app\client\controller\port;


use app\client\controller\BaseController;
use app\client\repository\PortRepository;
use app\client\repository\ReportRepository;
use think\Request;

class Report extends BaseController
{
    protected $reportRepository;

    public function __construct(Request $request)
    {
        $this->repository = new PortRepository();
        $this->reportRepository = new ReportRepository();

        parent::__construct($request);
    }

    /**
     * @SWG\Get(
     *      path="/port/{id}/report/attacks",
     *      tags={"Port 应用防护报表信息"},
     *      summary="获取应用攻击信息",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="应用 Id",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="ip",
     *          in="query",
     *          description="高防IP",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="start_date",
     *          in="query",
     *          description="开始时间(时间戳)",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="end_date",
     *          in="query",
     *          description="结束时间(时间戳)",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="quick_time",
     *          in="query",
     *          description="快速查询的时间，Example: 15:min,30:min,1:hour,24:hour",
     *          type="string",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"attacks":{{"time":"2018-05-26 17:21:00","gjMax":0,"lhMax":0},
     *     {"time":"2018-05-26 17:24:00","gjMax":0,"lhMax":0},{"time":"2018-05-26 17:27:00","gjMax":0,"lhMax":0},{"time":"2018-05-26 17:30:00",
     *     "gjMax":0,"lhMax":0},{"time":"2018-05-26 17:33:00","gjMax":0,"lhMax":0},{"time":"2018-05-26 17:36:00","gjMax":0,"lhMax":0}},
     *     "gjTotal":3847453146,"glTotal":142370332,"lhTotal":3705082814,"sjbTotal":3009929,"glsjbTotal":142370262,"attackTypeCount":4,
     *     "attackCount":1076,"attackRecords":{"time":"2018-06-26 10:53:24","attack-ip":{"192.168.100.13","192.168.100.1","192.168.100.13","192.168.100.3","192.168.100.11","192.168.100.17","192.168.100.5","192.168.100.17","192.168.100.9","192.168.100.7"},"target-ip":"192.168.1.1","attack-type":"UDP Flood","max-bps":2480992,"target-port":{10017,10013,10005,10007,10007,10017,10005,10013,10013,10019}}}}
     *          )
     *      )
     * )
     *
     * @param $id
     * @return string
     */
    public function attacks($id)
    {
        try {
            $data = $this->request->only(['ip', 'start_date', 'end_date', 'quick_time']);

            if (!$port = $this->repository->getPortById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该应用！');
            }

            $filter = [];
            $filter2 = [];
            // 高防IP flow中server-ip
            $serverIp = (array)(!empty($data['ip']) ? $data['ip']: array_column($port['proxy_ip'], 'ip'));
            config('app_debug') && $serverIp = null; // 测试环境默认返回所有IP的报表
            !empty($serverIp) && $filter[] = ['terms' => ['target-ip' => $serverIp]];
            !empty($serverIp) && $filter2[] = ['terms' => ['server-ip' => $serverIp]];

            // 没有开始时间，默认15分钟
            $startTime = $data['start_date'] ?? time() - 15 * 60;
            $endTime = $data['end_date'] ?? null;
            // 快速查询
            if (!empty($data['quick_time'])) {
                $timeParsed = $this->reportRepository->parseQuickTime($data['quick_time']);
                $startTime = $timeParsed['startTime'];
                $endTime = $timeParsed['endTime'];
            }

            !empty($startTime) && $filter2[] = ['range' => ['timestamp' => ['gte' => gmt_withTZ($startTime)]]];
            !empty($endTime) && $filter2[] = ['range' => ['timestamp' => ['lt' => gmt_withTZ($endTime)]]];

            // 查询条件
            $filter  = ['query' => ['bool' => compact('filter')]];
            $filter2  = ['query' => ['bool' => ['filter' => $filter2]]];

            //获取攻击类型和攻击次数
            $filter['aggs'] = $this->reportRepository->getAttackType();
            $filter['sort'] = ['time' => 'desc'];
            $filter['_source'] = ['time','attack-ip','target-ip','target-port','attack-type','max-bps'];
            $attackType     = $this->reportRepository->getAttackRecord($filter);
            //获取攻击流量
            $filter2['aggs'] = $this->reportRepository->getAttackFlow($startTime, $endTime);
            $attackFlow     = $this->reportRepository->getAttackFlowRecord($filter2);

            return Finalsuccess(['data' => array_merge($attackType, $attackFlow)]);
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_ES_ERROR, '获取应用流量趋势失败！');
        }
    }

    /**
     *
     * @SWG\Get(
     *      path="/ddos/{id}/report/bandwidth",
     *      tags={"DDoS 应用防护报表信息"},
     *      summary="获取应用防护 IN/OUT 带宽趋势",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="高防实例 Id",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="ip",
     *          in="query",
     *          description="高防IP",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="start_date",
     *          in="query",
     *          description="开始时间(时间戳)",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="end_date",
     *          in="query",
     *          description="结束时间(时间戳)",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="quick_time",
     *          in="query",
     *          description="快速查询的时间，Example: 15:min,30:min,1:hour,24:hour",
     *          type="string",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","logs":{{"time":"2018-05-26 18:57:00","inMax":95637547,"outMax":9458637,
     *     "connsMax":0},{"time":"2018-05-26 19:00:00","inMax":97481137,"outMax":9972130,"connsMax":0},{"time":"2018-05-26 19:03:00",
     *     "inMax":95233859,"outMax":9803399,"connsMax":0},{"time":"2018-05-26 19:06:00","inMax":99691233,"outMax":9929844,
     *     "connsMax":0},{"time":"2018-05-26 19:09:00","inMax":99523116,"outMax":9742200,"connsMax":0},{"time":"2018-05-26 19:12:00",
     *     "inMax":94714624,"outMax":9735875,"connsMax":0}},"maxIn":99691233,"maxOut":9972130}
     *          )
     *      )
     * )
     * @param $id
     * @return string
     */
    public function banWidth($id)
    {
        try {
            $data = $this->request->only(['ip', 'start_date', 'end_date', 'quick_time']);
            if (!$port = $this->repository->getPortById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该应用！');
            }

            $filter = [];
            $must = [['match' => ['app' => $port['app_id']]]];
            // 高防IP
            $id = (array)(!empty($data['ip']) ? $data['ip']: array_column($port['proxy_ip'], 'ip'));
            config('app_debug') && $id = null;      // 测试环境默认返回所有IP的报表
            !empty($id) && $filter[] = ['terms' => compact('id')];
            //端口过滤
            $proxyPorts = $port['proxy_port'] ?? [];
            if ($proxyPorts) {
                $ports = [];
                foreach ($proxyPorts as $proxyPort) {
                    //字符串变为数字
                    $ports[] = (int) $proxyPort;
                }

                $filter[] = ['terms' => ['proxy-port' => $ports]];
            }
            //协议过滤 TCP:6 UDP:17
            $httpProtocol = $port['protocol'] ?? [];
            if ($httpProtocol) {
                $http = 6;
                //notice: 默认为TCP 6 如果为udp则为17 传递给es过滤
                if ('UDP' === $httpProtocol) {
                    $http = 17;
                }

                $filter[] = ['term' => ['proto' => $http]];
            }

            $startTime = $data['start_date'] ?? time() - 15 * 60;
            $endTime = $data['end_date'] ?? null;
            // 快速查询
            if (!empty($data['quick_time'])) {   // 如果有快速查询时间，需要使用快速查询的时间作为最终查询时间范围
                $timeParsed = $this->reportRepository->parseQuickTime($data['quick_time']);
                $startTime = $timeParsed['startTime'];
                $endTime = $timeParsed['endTime'];
            }
            !empty($startTime) && $filter[] = ['range' => ['timestamp' => ['gte' => gmt_withTZ($startTime)]]];
            !empty($endTime) && $filter[] = ['range' => ['timestamp' => ['lt' => gmt_withTZ($endTime)]]];

            // 查询条件
            $filter = ['query' => ['bool' => compact('must', 'filter')]];
            // 聚合方式
            $filter['aggs'] = $this->reportRepository->getBWFilterAggs($startTime, $endTime);
            $bwTrend = $this->reportRepository->getBWTrend($filter);

            return Finalsuccess($bwTrend);
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail('IN/Out带宽获取失败！');
        }
    }
}