<?php

namespace app\client\controller;

use app\client\model\PortModel;
use app\common\model\SiteModel;
use app\common\model\UserInstanceModel;
use app\client\repository\DDoSRepository;
use app\client\repository\SiteRepository;
use app\client\service\Auth;
use app\client\traits\ControllerGuard;
use app\client\validate\Site as SiteValidator;
use think\Request;

class Site extends BaseController
{

    use ControllerGuard;

    protected $site;

    public function __construct(Request $request)
    {
        parent::__construct($request);
    }

    protected $beforeActionList = [
        'checkLogin' => ['except' => 'GetHttpsCert'],
        'IsDDoSIps'  => ['only' => 'GetHttpsCert']
    ];

    /**
     * @SWG\Get(
     *      path="/site",
     *      tags={"Site 网站防护"},
     *      summary="获取用户的域名",
     *      @SWG\Parameter(
     *          name="type",
     *          in="query",
     *          description="类型:0 未设置; 1 独享型; 2 共享型",
     *          type="integer"
     *      ),
     *      @SWG\Parameter(
     *          name="name",
     *          in="query",
     *          description="域名",
     *          type="string"
     *      ),
     *      @SWG\Parameter(
     *          name="ip",
     *          in="query",
     *          description="ip",
     *          type="string"
     *      ),
     *      @SWG\Parameter(
     *          name="_from",
     *          in="query",
     *          description="查询范围开始",
     *          type="integer"
     *      ),
     *      @SWG\Parameter(
     *          name="_size",
     *          in="query",
     *          description="查询数量",
     *          type="integer"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          ref="#/definitions/SiteList"
     *      )
     * )
     *
     * 域名状态码：
     * 0：待审核 1：待接入 2：正在接入 3：正常
     * 4：接入错误 5：正在删除 6：删除异常
     * @param SiteRepository $repository
     * @return array     $domainList 返回结果数组
     */
    public function index(SiteRepository $repository)
    {
        $from = input('_from', 0);
        $size = input('_size', 5);

        $must = [];
        // 根据类型进行筛选
        $type = input('type', null);
        if ($type) {
            $must[] = ['term' => ['type' => $type]];
        }

        // 根据域名进行筛选
        $name = input('name', null);
        if ($name) {
            $must[] = ['regexp' => ['name.keyword' => ".*$name.*"]];
        }

        // 根据高防IP进行筛选
        $ip = input('ip', null);
        if ($ip) {
            $must[] = ['regexp' => ['proxy_ip.ip.keyword' => ".*$ip.*"]];
        }

        // 根据当前用户查询
        $must[] = ['term' => ['uid.keyword' => Auth::id()]];
        $filter = [
            'query' => [
                'bool' => [
                    'must'     => $must,
                    'must_not' => [
                        'term' => [
                            'type' => PortModel::USER_APP_TYPE_PORT
                        ]
                    ]
                ]
            ],
            'sort'  => [
                [
                    'last_update' => [
                        'order' => 'desc'
                    ]
                ]
            ],
        ];
        $domainList = $repository->domainList($filter, $from, $size);
        $count = $repository->getSiteCount($filter);

        return Finalsuccess(['list' => $domainList, 'total' => $count]);
    }

    /**
     *
     * @SWG\Post(
     *      path="/site",
     *      tags={"Site 网站防护"},
     *      summary="用户添加站点",
     *     @SWG\Parameter(
     *         name="",
     *         in="body",
     *         description="站点信息",
     *         required=true,
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"name": "test.com", "http": 0, "https": 1, "upstream": "127.0.0.1,127.0.0.2", "src_host": "src-host.com"}
     *          )
     *     ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 添加成功| !=0 添加失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     *
     * 用户添加域名
     *
     * @param SiteValidator  $validator
     * @param SiteRepository $repository
     *
     * @return string    json     返回结果
     */
    public function create(SiteValidator $validator, SiteRepository $repository)
    {
        try {
            // 参数校验
            if (!$validator->scene('site_add')->check(input())) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }

            $data = $this->request->only(['name', 'http', 'https', 'upstream', 'src_host', 'server_port']);
            // 检查当前域名是否存在
            if ($result = $repository->domainIsExist($data['name'])) {
                return Finalfail(REP_CODE_SITE_ALREADY_EXIST, '站点已经存在，不能重复添加！');
            }

            // 添加新域名
            $domain = $repository->addDomain($data);
            if (!$domain) {
                return Finalfail(REP_CODE_SITE_SAVE_CONFIG_FAIL, '站点配置保存失败！');
            }
            request()->bind('email', Auth::id());

            return Finalsuccess(['data' => $domain]);
        } catch (\Exception $e) {
            // 日志记录当前错误信息
            $this->errorHandle($e);

            return Finalfail(REP_CODE_DB_ERROR, '站点创建失败！');
        }
    }

    /**
     *
     * @SWG\Put(
     *      path="/site/{id}",
     *      tags={"Site 网站防护"},
     *      summary="更新站点配置信息",
     *     @SWG\Parameter(
     *         name="",
     *         in="body",
     *         description="站点信息",
     *         required=true,
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"http": 0, "https": 1, "upstream": "127.0.0.1,127.0.0.2", "src_host": "src-host.com"}
     *          )
     *     ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 更新成功| !=0 更新失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * 更新站点信息
     *
     * @param $id
     * @param SiteRepository $repository
     * @param SiteValidator $validator
     * @return bool|string
     */
    public function update($id, SiteRepository $repository, SiteValidator $validator)
    {
        try {
            $data = request()->only(['upstream', 'http', 'https', 'src_host', 'server_port']);
            if (!$validator->scene('update_site')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }

            if (!$site = $repository->getSiteById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该站点！');
            }

            // 如果取消HTTPS协议，需要将HTTPS配置移除
            $rmHttpsConf = $site['https'] == 1 && $data['https'] != 1;
            if ($rmHttpsConf && !$repository->rmZKProxyConf($site, true)) {
                return Finalfail(REP_CODE_SITE_UPDATE_LINK_RM_ZK_PROXY_CONF_FAIL, '移除HTTPS配置失败！');
            }

            // 如果取消HTTP协议，需要将HTTP配置移除
            $rmHttpConf = $site['http'] == 1 && $data['http'] != 1;
            if ($rmHttpConf && !$repository->rmZKProxyConf($site, false, null, [], false)) {
                return Finalfail(REP_CODE_SITE_UPDATE_LINK_RM_ZK_PROXY_CONF_FAIL, '移除HTTPS配置失败！');
            }

            // 更新域名配置信息
            $data['upstream'] = explode(',', $data['upstream']);
            if (!$repository->updateSiteInfo($data, $id)) {
                return Finalfail(REP_CODE_SITE_UPDATE_SITE_CONFIG_FAIL, '更新站点配置失败！');
            }

            // 如果站点配置有更改，且站点已接入需要移除已经写入的ZK Proxy配置信息
            if ((in_array($site['status'], [SiteModel::DOMAIN_STATUS_LINKED, SiteModel::DOMAIN_STATUS_NORMAL]))) {
                // 更新ES Proxy Conf 配置信息
                if (!$repository->setESProxyConf($id)) {
                    return Finalfail(REP_CODE_SITE_LINK_SET_PROXY_CONF_FAIL, 'Proxy Conf 配置保存失败！');
                }

                // 重新写入站点高防节点ZK配置信息
                if (!$repository->setZKProxyConf($id)) {
                    return Finalfail(REP_CODE_SITE_LINK_SET_ZK_PROXY_CONF_FAIL, 'Proxy信息写入ZK失败！');
                }
            }

            request()->bind('email', Auth::id());
            request()->bind('name', $site['name']);

            return Finalsuccess();
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_SITE_LINK_FAIL, '站点接入失败！');
        }
    }

    /**
     *
     * @SWG\Get(
     *      path="/site/{id}",
     *      tags={"Site 网站防护"},
     *      summary="获取域名详情",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="用户实例 Id",
     *          type="integer",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"app_id":"test.com","uid":"test@veda.com","name":"test.com",
     *     "type":1,"http":1,"https":0,"https_cert":"","https_cert_key":"","upstream":"192.168.2.1","status":4,
     *     "text_code":"mf0ZVN3fN3idvK3b","src_host":"","server_port":80,"proxy_ip":{{"area":41,"instance_id":"ddos-zg5yaer",
     *     "line":"8","ip":"192.20.8.1","instance_line":"8"},{"area":23,"instance_id":"ddos-2nidcsg","line":"8","ip":"192.20.50.1",
     *     "instance_line":"8"}},"cache":null,"filter":null,"last_update":1527234615,"cname":"uh3jzy346h.hd.vedasec.cn",
     *     "proxy_port":80}}
     *          )
     *      )
     * )
     *
     * 获取站点详情
     *
     * @param $id
     * @param SiteRepository $repository
     * @return string
     */
    public function show($id, SiteRepository $repository)
    {
        try {
            if (!$site = $repository->getSiteById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该站点！');
            }
            $site['last_update'] = strtotime($site['last_update']);
            $site['upstream'] = implode(',', $site['upstream'] ?? []);

            return Finalsuccess(['data' => $site]);
        } catch (\Exception $e) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '站点详情获取失败！');
        }
    }

    /**
     * @SWG\Get(
     *      path="/site/{id}/txtcode",
     *      tags={"Site 网站防护"},
     *      summary="获取txt类型记录值",
     *     @SWG\Parameter(
     *         name="domain",
     *         in="path",
     *         required=true,
     *         type="string",
     *         description="用户站点"
     *     ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","vdomain":"hdverify.cncn.com","way":"TXT","utextcode":"f72004acd5a6a9a8", "name":"cncn.com"}
     *          )
     *      )
     * )
     *
     * 获取txt类型记录值
     * @param $id
     * @param SiteRepository $repository
     * @return string    json     返回记录值
     * @throws \Exception
     */
    public function txtCode($id, SiteRepository $repository)
    {
        $site = $repository->getSiteById($id);
        if (!$site) {
            return Finalfail(REP_CODE_SITE_TXT_CODE_SITE_NOT_EXIST, '未找到该站点！');
        }

        // 生成幻盾安全域名
        $HDDomain = SiteRepository::generateHDDomain($site['name']);
        // 获取该域名的textCode值
        $textCode = $repository->getDomainTextCode($id);
        if (!$textCode) {
            return Finalfail(REP_CODE_SITE_TXT_CODE_FAIL, '站点txt类型记录值获取失败！');
        }

        $verifydata = [
            'vdomain'   => $HDDomain,
            'way'       => 'TXT',
            'utextcode' => $textCode,
            'name'      => $site['name']
        ];
        request()->bind('email', Auth::id());
        request()->bind('name', $site['name']);

        return Finalsuccess($verifydata);
    }

    /**
     * @SWG\Post(
     *      path="/site/{id}/txtcode-verify",
     *      tags={"Site 网站防护"},
     *      summary="审核此站点txt记录值是否符合",
     *     @SWG\Parameter(
     *         name="",
     *         in="body",
     *         description="",
     *         required=true,
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"domain": "www.cncn.com"},
     *              description="站点"
     *          )
     *     ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 审核成功| !=0 审核失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * 审核此站点txt记录值是否符合
     * @param $id
     * @param SiteRepository $repository
     * @return string    json     返回结果
     */
    public function txtcodeVerify($id, SiteRepository $repository)
    {
        try {
            // 检查站点是否存在
            $exist = $repository->getSiteById($id);
            if (!$exist) {
                return Finalfail(REP_CODE_SITE_TXT_CODE_VERIFY_SITE_NOT_EXIST, '站点不存在!');
            }

            //生成幻盾安全域名
            $vDomain = SiteRepository::generateHDDomain($exist['name']);
            if (!config('app_debug')) { // 测试环境不进行校验

                // 获取系统生成的TextCode与用户填写的进行比较
                if (!$textCode = $repository->getDomainTextCode($id)) {
                    return Finalfail(REP_CODE_SITE_TEXT_CODE_NOT_FOUND, '未找到该站点TextCode值!');
                }

                //检查域名是否有效
                $result = SiteRepository::domainIsValid($vDomain);
                if (false === $result) {
                    return Finalfail(REP_CODE_SITE_TXT_PARSE_FAIL, '站点TXT记录未正确解析！');
                }

                // 系统生成的TextCode与用户填写的进行比较
                if ($result != $textCode) {
                    return Finalfail(REP_CODE_SITE_TEXT_CODE_ERROR, '站点解析TxTCode值不匹配！');
                }
            }

            // 更新站点状态为已审核
            $result = $repository->updateSiteStatus($id, SiteModel::DOMAIN_STATUS_APPROVED);
            if (!$result) {
                return Finalfail(REP_CODE_SITE_UPDATE_APPROVED_STATUS_FAIL, '站点状态更新为已审核失败');
            }

            request()->bind('email', Auth::id());
            request()->bind('name', $exist['name']);

            return Finalsuccess();
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_SITE_TEXT_CODE_VERIFY_FAIL, '站点TxTCode值校验失败！');
        }
    }

    /**
     * @SWG\Post(
     *      path="/site/{id}/linkup",
     *      tags={"Site 网站防护"},
     *      summary="用户接入站点",
     *      @SWG\Parameter(
     *          name="",
     *          in="body",
     *          description="接入信息",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"app_id":"e.com","uid":"test@veda.com","name":"e.com",
     *     "type":"1","http":"1","https":"0","https_cert":"","https_cert_key":"","upstream":{"192.15.57.1"},"status":3,
     *     "text_code":"N87PW2jOsXpw64YZ","proxy_ip":{{"area":41,"instance_id":"ddos-rbpavgc","line":"2","ip":"192.168.9.22",
     *     "instance_line":"3"}},"last_update":"2018-04-24T07:57:33.000Z","cname":"nekex91bli.hd.vedasec.net"}}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 接入成功| !=0 接入失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":""}
     *          )
     *      )
     * )
     *
     * 用户接入站点
     *
     * @param                $id
     * @param SiteRepository $repository
     * @param SiteValidator  $validator
     *
     * @return string    json     返回结果
     * @throws \Exception
     */
    public function linkup($id, SiteRepository $repository, SiteValidator $validator)
    {
        $data = input();
        if (!$validator->scene('linkup')->check($data)) {
            return Finalfail(REP_CODE_SITE_LINK_PARAMS_INVALID, $validator->getError());
        }

        if ( ! $siteModel = $repository->getSiteById($id)) {    //站点不存在
            return Finalfail(REP_CODE_SITE_LINK_SITE_NOT_EXIST, '域名不存在！');
        }

        // 检查所选高防节点中, 可用的高防IP足够
        if (!$repository->checkProxyConfSiteCountLimit($data)) {
            return Finalfail(REP_CODE_SITE_LINK_COUNT_NOT_ENOUGH, '防护域名数量不足！');
        }

        // 检查当前域名状态
        if ($siteModel['status'] != SiteModel::DOMAIN_STATUS_APPROVED) { //站点未通过审核
            return Finalfail(REP_CODE_SITE_LINK_NOT_APPROVED_STATUS, '站点未通过审核！');
        }
        try {

            // 生成当前站点的CName记录
            $cname = $repository->generateDomainCName();
            // 更新站点状态为接入中
            $attributes = [
                'http'       => $siteModel['http'],
                'https'      => $siteModel['https'],
                'linked_ips' => $data['linked_ips'],
                'proxy_port' => $data['proxy_port'] ?? 80,      //代理端口
                'status'     => SiteModel::DOMAIN_STATUS_LINKING,
                'cname'      => $cname,
                'type'       => $data['type']
            ];
            if (!$repository->updateSiteInfo($attributes, $id)) {
                return Finalfail(REP_CODE_SITE_LINK_UPDATE_LINKING_STATUS_FAIL, '域名配置更新失败！');
            }

            $data['cname'] = $cname;
            // 更新站点状态为接入中，同时将接入信息写入ES
            if (!$repository->updateSiteProxyConf($attributes, $id)) {
                return Finalfail(REP_CODE_SITE_LINK_UPDATE_PROXY_CONF_FAIL, '域名状态更新失败！');
            }

            // 在proxy_conf 中加入新的DNS配置
            if (!$repository->setESProxyConf($id)) {
                return Finalfail(REP_CODE_SITE_LINK_SET_PROXY_CONF_FAIL, 'Proxy Conf 配置保存失败！');
            }

            // 下发配置
            if (!$repository->addESDNSConf($data, $id)) {
                return Finalfail(REP_CODE_SITE_LINK_ADD_DNS_NODE_CONF_FAIL, 'DNS Node Info配置写入失败！');
            }

            // 将DNS配置写入Zookeeper
            if (!$repository->setZKDnsConf($data, $id)) {
                return Finalfail(REP_CODE_SITE_LINK_SET_ZK_DNS_CONF_FAIL, 'DNS配置信息写入失败！');
            }

            // 将转发设置写入Zookeeper
            if (!$repository->setZKProxyConf($id)) {
                return Finalfail(REP_CODE_SITE_LINK_SET_ZK_PROXY_CONF_FAIL, 'Proxy信息写入ZK失败！');
            }

            // 更新站点状态为已接入
            if (!$result = $repository->updateSiteStatus($id, SiteModel::DOMAIN_STATUS_LINKED)) {
                return Finalfail(REP_CODE_SITE_LINK_UPDATE_LINKED_STATUS_FAIL, '域名状态更新失败！');
            }
            $site = $repository->getSiteById($id);

            request()->bind('email', Auth::id());
            request()->bind('name', $site['name']);

            return Finalsuccess(['data' => $site]);
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_SITE_LINK_FAIL, '域名接入失败！');
        }
    }

    /**
     * @SWG\Post(
     *      path="/site/{id}/linkup-update",
     *      tags={"Site 网站防护"},
     *      summary="更新站点接入信息",
     *      @SWG\Parameter(
     *          name="",
     *          in="body",
     *          description="接入信息",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"linked_ips": {{"line": "1", "ip": "192.168.1.0",
     *     "ddos_id":"ddos-ofanbvo"},{"line": "2", "ip": "192.168.1.1", "ddos_id":"ddos-ofanbvo"}}}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 更新成功| !=0 更新失败！",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":""}
     *          )
     *      )
     * )
     * @param $id
     * @param SiteRepository $repository
     * @param SiteValidator $validator
     * @return string
     */
    public function updateLinkUp($id, SiteRepository $repository, SiteValidator $validator)
    {
        try {
            $data = request()->only(['linked_ips', 'proxy_port']);
            if (!$validator->scene('update_linkup')->check($data)) {
                return Finalfail(REP_CODE_SITE_UPDATE_LINK_PARAMS_INVALID, $validator->getError());
            }

            if (!$site = $repository->getSiteById($id)) {
                return Finalfail(REP_CODE_SITE_UPDATE_LINK_SITE_NOT_EXIST, '未找到该站点！');
            }

            // 检查所选高防节点中, 可用的高防IP足够
            if (!$repository->checkProxyConfSiteCountLimit($data, $site)) {
                return Finalfail(REP_CODE_SITE_UPDATE_LINK_SITE_COUNT_NOT_ENOUGH, '防护域名数量不足！');
            }

            //------------------------- 移除旧的配置 START -------------------------------

            if (!$repository->rmESDNSConf($site)) {
                return Finalfail(REP_CODE_SITE_UPDATE_LINK_RM_DNS_CONF_FAIL, '移除DNS Conf 信息失败！');
            }

            if (!$repository->rmESProxyConf($site)) {
                return Finalfail(REP_CODE_SITE_UPDATE_LINK_RM_PROXY_CONF_FAIL, '移除Proxy Conf信息失败！');
            }

            // 修改前和修改后相同的数据不需要移除
            $zkRmExcept = $repository->processExceptProxyIp($data['linked_ips']);
            if (!$repository->rmZKProxyConf($site, false, null, $zkRmExcept)) {
                return Finalfail(REP_CODE_SITE_UPDATE_LINK_RM_ZK_PROXY_CONF_FAIL, 'ZK删除Proxy数据写入失败！');
            }

            if (!$repository->rmZKDNSConf($site)) {
                return Finalfail(REP_CODE_SITE_UPDATE_LINK_RM_ZK_DNS_CONF_FAIL, 'ZK删除DNS数据写入失败！');
            }

            if (!$repository->resetUserInstanceSiteCount($site)) {
                return Finalfail(REP_CODE_SITE_UPDATE_LINK_UPDATE_SITE_COUNT_FAIL, '更新用户实例域名接入数量失败！');
            }

            //------------------------- 移除旧的配置 END -------------------------------
            // 记录旧的未曾ProxyIp，不进行重复添加
            $zkSetExcept = $repository->processExceptProxyIp($site['proxy_ip'], 'instance_id');
            // 更新站点的接入信息
            if (!$repository->updateSiteProxyConf($data, $site)) {
                return Finalfail(REP_CODE_SITE_UPDATE_LINK_UPDATE_SITE_PROXY_CONF_FAIL, '更新站点配置失败！');
            }

            //------------------------- 写入新配置 START -------------------------------
            if (!$repository->setESProxyConf($id)) {
                return Finalfail(REP_CODE_SITE_UPDATE_LINK_SET_PROXY_CONF_FAIL, 'Proxy Conf 配置保存失败！');
            }

            if (!$repository->addESDNSConf($data, $id)) {
                return Finalfail(REP_CODE_SITE_UPDATE_LINK_ADD_DNS_NODE_CONF_FAIL, 'DNS Node Info配置写入失败！');
            }

            if (!$repository->setZKDnsConf($data, $id)) {
                return Finalfail(REP_CODE_SITE_UPDATE_LINK_SET_ZK_DNS_CONF_FAIL, 'DNS配置信息写入失败！');
            }

            if (!$repository->setZKProxyConf($id)) {
                return Finalfail(REP_CODE_SITE_UPDATE_LINK_SET_ZK_PROXY_CONF_FAIL, 'Proxy信息写入ZK失败！');
            }

            //------------------------- 写入新配置 END -------------------------------

            request()->bind('email', Auth::id());
            request()->bind('name', $site['name']);

            return Finalsuccess();
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_SITE_UPDATE_LINK_FAIL, '站点接入信息更新失败！');
        }
    }

    /**
     * @SWG\Delete(
     *      path="/site/{id}",
     *      tags={"Site 网站防护"},
     *      summary="用户删除站点",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="站点Id",
     *          type="integer",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 删除成功| !=0 删除失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * 用户删除站点
     * @param $id
     * @param SiteRepository $repository
     * @param SiteValidator $validator
     * @return string    json     返回结果
     */
    public function destroy($id, SiteRepository $repository, SiteValidator $validator)
    {
        try {
            // 参数校验
            if (!$validator->scene('del_site')->check(compact('id'))) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }

            if (!$site = $repository->getSiteById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该站点！');
            }

            // 已经成功接入的站点需要进行ZK和ES信息移除
            if (in_array($site['status'], [SiteModel::DOMAIN_STATUS_LINKED, SiteModel::DOMAIN_STATUS_NORMAL])) {
                // 移除Proxy Conf配置信息
                if (!$repository->rmESProxyConf($site)) {
                    return Finalfail(REP_CODE_SITE_UPDATE_LINK_RM_PROXY_CONF_FAIL, '移除Proxy Conf信息失败！');
                }

                // 移除ES DNS Conf配置信息
                if (!$repository->rmESDNSConf($site)) {
                    return Finalfail(REP_CODE_SITE_UPDATE_LINK_RM_DNS_CONF_FAIL, '移除DNS Conf 信息失败！');
                }

                // 将删除DNS配置写入Zookeeper
                if (!$repository->rmZKDNSConf($site)) {
                    return Finalfail(REP_CODE_SITE_UPDATE_LINK_RM_ZK_DNS_CONF_FAIL, 'ZK删除DNS数据写入失败！');
                }

                // 将删除DNS配置写入Zookeeper
                if (!$repository->rmZKProxyConf($site)) {
                    return Finalfail(REP_CODE_SITE_UPDATE_LINK_RM_ZK_PROXY_CONF_FAIL, 'ZK删除Proxy数据写入失败！');
                }

                // 更新用户实例中的域名接入数量
                if (!$repository->resetUserInstanceSiteCount($site)) {
                    return Finalfail(REP_CODE_SITE_UPDATE_LINK_UPDATE_SITE_COUNT_FAIL, '更新用户实例域名接入数量失败！');
                }
            }

            // 移除站点
            if (!$repository->removeDomain($id)) {
                // 更新域名状态为删除异常
                $repository->updateSiteStatus($id, SiteModel::DOMAIN_STATUS_DELETE_ERR);

                return Finalfail(REP_CODE_SITE_DELETE_FAIL, '站点删除失败');
            }

            return Finalsuccess();
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_SITE_DELETE_FAIL, '站点删除失败！');
        }
    }

    /**
     *
     * @SWG\Post(
     *      path="/site/{id}/cname-verify",
     *      tags={"Site 网站防护"},
     *      summary="校验CNAME是否正确解析",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="站点Id",
     *          type="integer",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 校验通过| !=0 校验失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * 校验域名DNS解析状态
     *
     * @param $id
     * @param SiteRepository $repository
     * @return string
     */
    public function cNameVerify($id, SiteRepository $repository)
    {
        try {
            if (!$site = $repository->getSiteById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该站点！');
            }

            if (!config('app_debug')) {
                // 校验域名的Cname是否正确解析
                if (!$repository->cNameVerify($site['name'], $site['cname'])) {
                    return Finalfail(REP_CODE_FAILED_OPERATION, 'CNAME未正确解析！');
                }
            }

            // 更新域名状态为正常
            if (!$repository->updateSiteStatus($id, SiteModel::DOMAIN_STATUS_NORMAL)) {
                return Finalfail(REP_CODE_ES_ERROR, '域名状态更新失败！');
            }

            return Finalsuccess();
        } catch (\Exception $e) {
            return Finalfail(REP_CODE_FAILED_OPERATION, 'CNAME验证失败！');
        }
    }

    /**
     * @SWG\Post(
     *      path="/site/{id}/https-cert/upload",
     *      tags={"Site 网站防护"},
     *      summary="站点防护Https 证书上传",
     *      @SWG\Parameter(
     *          name="",
     *          in="body",
     *          description="HTTPS证书信息",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={ "certificate": "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tDQpDRVJUSUZJQ0FURQ0KLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLQ==",
     *              "certificate_key": "LS0tLS1CRUdJTiBSU0EgUFJJVkFURSBLRVktLS0tLQ0KS0VZDQotLS0tLUVORCBSU0EgUFJJVkFURSBLRVktLS0tLQ=="}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 上传成功| !=0 上传失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * @param $id
     * @param SiteValidator $validator
     * @param SiteRepository $repository
     * @return string
     */
    public function httpsCertUpload($id, SiteValidator $validator, SiteRepository $repository)
    {
        try {
            $data = input();
            // 参数校验
            if (!$validator->scene('https_cert_upload')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }

            // 检查站点是否存在
            if (!$site = $repository->getSiteById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该站点！');
            }

            // 更新站点的HTTPS证书
            if (!$repository->updateSiteCertificate($site, base64_decode($data['certificate']), base64_decode($data['certificate_key']))) {
                return Finalfail(REP_CODE_ES_ERROR, '站点HTTPS证书更新失败！');
            }

            //更新ES Proxy ConfHTTP证书信息
            if (!$repository->setESProxyConf($id)) {
                return Finalfail(REP_CODE_ES_ERROR, '更新Proxy Conf证书信息失败！');
            }

            return Finalsuccess();
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_FAILED_OPERATION, 'HTTPS证书上传失败！');
        }
    }

    /**
     * @SWG\post(
     *      path="/site/{id}/https-cert",
     *      tags={"Site 网站防护"},
     *      summary="获取站点上传的HTTPS证书",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="站点Id, example: www.abc.com",
     *          type="string",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","cert":{"site":"www.abc.com",
     *     "certificate":"LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tDQpDRVJUSUZJQ0FURQ0KLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLQ==",
     *     "certificate_key":"LS0tLS1CRUdJTiBSU0EgUFJJVkFURSBLRVktLS0tLQ0KS0VZDQotLS0tLUVORCBSU0EgUFJJVkFURSBLRVktLS0tLQ=="}}
     *          )
     *      )
     * )
     *
     * @param SiteRepository $repository
     * @param SiteValidator $validator
     * @return string
     */
    public function GetHttpsCert(SiteRepository $repository, SiteValidator $validator)
    {
        try {
            $data = input();
            // 参数校验
            // if (!$validator->scene('get_https_cert')->check($data)) {
            //     return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            // }

            // 查找站点
            if (!$site = $repository->getSiteById($data['site'])) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该站点！');
            }

            // 获取该站点的HTTPS证书
            if (!$cert = $repository->getSiteCerts($site)) {
                return Finalfail(REP_CODE_ES_ERROR, '未找到该站点的HTTPS证书信息！');
            }

            return Finalsuccess(compact('cert'));
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_FAILED_OPERATION, '服务端异常，证书获取失败！');
        }
    }

    /**
     * @SWG\Delete(
     *      path="/site/bundle/delete",
     *      tags={"Site 网站防护"},
     *      summary="批量删除站点",
     *      @SWG\Parameter(
     *          name="",
     *          in="body",
     *          description="站点ID数组",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"ids": {"test1.com", "test3.com"}}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 删除成功| !=0 删除失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * @param SiteValidator $validator
     * @param SiteRepository $repository
     * @return string
     */
    public function bundleDelete(SiteValidator $validator, SiteRepository $repository)
    {
        $data = input();
        if (!$validator->scene('bundle_delete')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
        }

        foreach ($data['ids'] as $id) {
            // 依次移除对应站点的ES和ZK配置
            $result = ($this->destroy($id, $repository, $validator))->getData();
            if ($result['errcode'] != 0) {
                return Finalfail($result['errcode'], $result['errmsg']);
            }
        }
        request()->bind('email', Auth::id());

        return Finalsuccess();
    }

    /**
     * @SWG\Get(
     *      path="/site/{id}/proxy-ips",
     *      tags={"Site 网站防护"},
     *      summary="获取站点高仿节点列表",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="站点ID",
     *          type="string"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","proxyIps":{{"area":33,"line":"8","ip":"192.16.19.1","ddos_id":"ddos-dknajde",
     *     "area_text":"浙江","line_text":"BGP"}}}
     *          )
     *      )
     * )
     *
     * @param $id
     * @param SiteRepository $repository
     * @return string
     */
    public function proxyIps($id, SiteRepository $repository)
    {
        try {
            if (!$site = $repository->getSiteById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该站点！');
            }
            $proxyIps = $site['proxy_ip'] ?? [];
            foreach ($proxyIps as &$proxyIp) {
                $proxyIp['ddos_id'] = $proxyIp['instance_id'];
                $proxyIp['area_text'] = UserInstanceModel::$instanceAreas[$proxyIp['area']];
                $proxyIp['line_text'] = UserInstanceModel::$instanceLines[$proxyIp['line']];

                unset($proxyIp['instance_id'], $proxyIp['instance_line']);
            }

            return Finalsuccess(compact('proxyIps'));
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_FAILED_OPERATION, '获取站点高防IP失败！');
        }
    }

    /**
     * @SWG\Get(
     *     path="/site/{id}/instances",
     *     tags={"Site 网站防护"},
     *     summary="获取用户实例高防IP",
     *      @SWG\Response(
     *          response="200",
     *          description="success: true | false ",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","list":{"ddos-fz32vw2":{"type":1,"area":11,"area_text":"北京",
     *     "ddos_id":"ddos-fz32vw2","ips":{{"line":"1","ip":"192.168.55.52","line_text":"电信","usable":1},{"line":"2",
     *     "ip":"192.168.55.53","line_text":"联通","usable":1},{"line":"8","ip":"192.168.55.54","line_text":"BGP","usable":1}}},
     *     "ddos-1x4o1fp":{"type":1,"area":11,"area_text":"北京","ddos_id":"ddos-1x4o1fp","ips":{{"line":"8","ip":"192.168.55.21",
     *     "line_text":"BGP","usable":0}}}},"total":6}
     *          )
     *      )
     * )
     *
     * @param $id
     * @param SiteRepository $repository
     * @param DDoSRepository $DDoSRepository
     * @return string
     */
    public function instances($id, SiteRepository $repository, DDoSRepository $DDoSRepository)
    {
        try {
            $from = input('_from', 0);
            $size = input('_size', 10);

            if (!$site = $repository->getSiteById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该站点！');
            }
            $filter = [
                'sort'  => ['last_update' => 'desc'],
                'query' => [
                    'bool' => [
                        'must' => [
                            ['term' => ['uid.keyword' => Auth::id()]],
                            ['term' => ['status' => UserInstanceModel::STATUS_ACTIVATED]],
                            ['terms' => ['type' => [UserInstanceModel::INSTANCE_TYPE_SHARED, UserInstanceModel::INSTANCE_TYPE_SINGLE]]]
                        ]
                    ]
                ]
            ];
            $total = (new UserInstanceModel())->esCount($filter);

            $unSelectInstances = [];
            $selectInstanceIds = array_column($site['proxy_ip'], 'instance_id');
            // 获取该站点已选择的高防实例
            $selectInstances = $repository->getSiteSelectInstance($selectInstanceIds, $from, $size);
            if (count($selectInstances) < $size) {        // 如果当前已选择的高防实例小于Size，补充部分未选择的高防实例
                // 获取该站点未选择的高防实例
                $unSelectFrom = max($from - count($selectInstanceIds), 0);
                $unSelectSize = $size - count($selectInstances);
                $unSelectInstances = $repository->getSiteUnSelectInstance($selectInstanceIds, $unSelectFrom, $unSelectSize);
            }

            // 对实例列表进行处理：1、添加可接入数量；2、添加实例线路和地域信息
            $instanceList = $DDoSRepository->processInstanceList(array_merge($selectInstances, $unSelectInstances));

            return Finalsuccess(['list' => array_values($instanceList), 'total' => $total]);
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_FAILED_OPERATION, '获取站点高防实例失败！');
        }
    }
}
