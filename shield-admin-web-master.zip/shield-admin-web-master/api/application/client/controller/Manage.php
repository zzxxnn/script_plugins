<?php

namespace app\client\controller;

use app\common\model\SiteModel;
use app\client\repository\SupportRepository;
use app\common\model\UserModel;
use app\client\service\Auth as AuthService;
use app\client\traits\CheckLogin;

class Manage extends BaseController
{

    use CheckLogin;

    protected $beforeActionList = [
        'checkLogin',
    ];

    /**
     * @SWG\Get(
     *      path="/manage",
     *      tags={"manage 用户主页"},
     *      summary="【获取】用户主页",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={{"errcode":0,"errmsg":"ok","data":{"sites":13,"ports":7,"account":0,"email":"test@veda.com","avatar":"static\/img\/support-user1.png","sale":{{"qq":1621125713,"name":"销售1号","mobile":18610875205,"email":"jlin@veda.com","id":"TamCRWQB7YLfiSA_nKqF","avatar":"http://admin.sheld.local/avatar/support-user1.png"}},"technical":{{"qq":1621125713,"name":"技术2号","mobile":18610875205,"email":"sunhl@veda.com","id":"T6mCRWQB7YLfiSA_napC","avatar":"http://admin.sheld.local/avatar/support-user1.png"},{"qq":1621125713,"name":"技术4号","mobile":18610875205,"email":"sunhl@veda.com","id":"UamCRWQB7YLfiSA_napU","avatar":"http://admin.sheld.local/avatar/support-user1.png"},{"qq":1621125714,"name":"技术1号","mobile":18610875206,"email":"sunhaolei@gmail.com","id":"TqmCRWQB7YLfiSA_naos","avatar":"http://admin.sheld.local/avatar/support-user1.png"},{"qq":1621125713,"name":"技术3号","mobile":18610875205,"email":"sunhl@veda.com","id":"UKmCRWQB7YLfiSA_napM","avatar":"http://admin.sheld.local/avatar/support-user1.png"}}}}}
     *          )
     *      )
     * )
     *
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \Exception
     */
    public function get(SupportRepository $supportRepository)
    {
        list($domains, $sites, $ports, $account, $avatar) = $this->getUserInformation();

        list($technicals, $sales) = $supportRepository->getSupport();

        $data = [
            'domains'   => $domains ?: 0,
            'sites'     => $sites ?: 0,
            'ports'     => $ports ?: 0,
            'account'   => $account,
            'email'     => AuthService::id(),
            'avatar'    => $avatar,
            'technical' => $technicals,
            'sale'      => $sales,
        ];

        return Finalsuccess([ 'data' => $data ]);
    }

    /**
     * 获取用户相关信息
     *
     * @return array
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \Exception
     */
    private function getUserInformation()
    {
        $siteModel = new SiteModel();
        $must_not      = [ [ 'term' => [ 'type' => SiteModel::DOMAIN_TYPE_PORT ] ] ];
        $domain_filter = [
            'query' => [
                'bool' => [
                    'must'     => [
                        [ 'term' => [ 'uid.keyword' => AuthService::id() ] ]
                    ],
                    'must_not' => $must_not
                ]
            ]
        ];
        $domains       = $siteModel->esCountDocs($domain_filter);

        $must_not      = [ [ 'term' => [ 'type' => SiteModel::DOMAIN_TYPE_PORT ] ] ];
        $site_filter = [
            'query' => [
                'bool' => [
                    'must'     => [
                        [ 'term' => [ 'status' => SiteModel::DOMAIN_STATUS_NORMAL ] ],
                        [ 'term' => [ 'uid.keyword' => AuthService::id() ] ]
                    ],
                    'must_not' => $must_not
                ]
            ]
        ];
        $sites       = $siteModel->esCountDocs($site_filter);

        $port_filter = [
            'query' => [
                'bool' => [
                    'must' => [
                        [ 'term' => [ 'status' => SiteModel::PORT_STATUS_NORMAL ] ],
                        [ 'term' => [ 'type' => SiteModel::DOMAIN_TYPE_PORT ] ],
                        [ 'term' => [ 'uid.keyword' => AuthService::id() ] ]
                    ]
                ]
            ]
        ];
        $ports       = $siteModel->esCountDocs($port_filter);

        $user = UserModel::where([ 'email' => AuthService::id() ])->find();

        $account  = $user ? $user->account : 0;
        $avatar   = ( $user && $user->avatar ) ? $user->avatar : 'avatar/support-user0.png';

        return [ $domains, $sites, $ports, $account, $avatar];
    }


}
