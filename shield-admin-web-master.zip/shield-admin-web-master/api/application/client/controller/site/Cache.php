<?php

namespace app\client\controller\site;

use app\client\repository\SiteRepository;
use app\client\validate\Site;

class Cache extends Base
{
    /**
     * @SWG\Get(
     *      path="/site/{id}/cache-list",
     *      tags={"Site 网站防护缓存加速"},
     *      summary="获取站点的缓存黑白名单配置",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","whiteList":{{"time":"1:hour","keyword":"test"}}, "blackList":{{"time":"1:hour","keyword":"test"}}}
     *          )
     *      )
     * )
     *
     *
     * @return string
     */
    public function index()
    {
        $site      = $this->site;
        $whiteList = $site['cache']['whitelist'] ?? [];
        $blackList = $site['cache']['blacklist'] ?? [];

        $data = ['whiteList' => $whiteList, 'blackList' => $blackList];

        return Finalsuccess($data);
    }

    /**
     *
     * @SWG\Post(
     *      path="/site/{id}/cache-expire",
     *      tags={"Site 网站防护缓存加速"},
     *      summary="设置站点的缓存有效期",
     *      @SWG\Parameter(
     *          name="",
     *          in="body",
     *          description="缓存有效期配置",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"static_expire":"1:minute","html_expire":"2:minute","index_expire":"5:minute","directory_expire":"10:minute"}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 设置成功| !=0 设置失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * 设置站点的缓存配置
     *
     * @param $id
     * @param SiteRepository $repository
     * @param Site $siteValidator
     * @return string
     */
    public function setSiteCacheExpire($id, SiteRepository $repository, Site $siteValidator)
    {
        try {
            $data = request()->only(['static_expire', 'html_expire', 'index_expire', 'directory_expire']);
            if (! $siteValidator->scene('set_site_cache_expire')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $siteValidator->getError());
            }
            if (! $site = $repository->getSiteById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该站点！');
            }

            // 设置站点缓存有效期
            if (! $repository->setSiteCacheExpire($data, $site)) {
                return Finalfail(REP_CODE_ES_ERROR, '设置站点缓存有效期失败！');
            }

            if (! $repository->setSiteProxyCache($data, $site)) {
                return Finalfail(REP_CODE_ES_ERROR, '更新高防节点缓存配置失败！');
            }

            return Finalsuccess();
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_FAILED_OPERATION, '更新高防节点缓存配置失败！');
        }
    }

    /**
     *
     * @SWG\Get(
     *      path="/site/{id}/cache-expire",
     *      tags={"Site 网站防护缓存加速"},
     *      summary="获取站点的缓存有效期配置",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","cache":{"static_expire":"1:minute","html_expire":"2:minute",
     *     "index_expire":"5:hour","directory_expire":"10:minute"}}
     *          )
     *      )
     * )
     *
     * @param $id
     * @param SiteRepository $repository
     * @return string
     */
    public function getSiteCacheExpire($id, SiteRepository $repository)
    {
        try {
            if (! $site = $repository->getSiteById($id)) {
                return Finalsuccess(REP_CODE_SOURCE_NOT_FOUND, '未找到该站点！');
            }
            // 获取站点的缓存有效期设置
            $cache = $repository->getSiteCacheExpire($site);

            return Finalsuccess(compact('cache'));
        } catch (\Exception $e) {
            return Finalfail(REP_CODE_FAILED_OPERATION, '获取站点缓存配置失败！');
        }
    }

    /**
     *
     *
     * @SWG\Post(
     *      path="/site/{id}/cache-whitelist",
     *      tags={"Site 网站防护缓存加速"},
     *      summary="添加站点缓存白名单",
     *      @SWG\Parameter(
     *          name="",
     *          in="body",
     *          description="缓存白名单关键字",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"keyword":"test","expire":"1:hour"}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 添加成功| !=0 添加失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * 添加站点缓存策略
     *
     * @param $id
     * @param Site $validator
     * @param SiteRepository $repository
     * @return string
     */
    public function addSiteCacheWhiteList($id, Site $validator, SiteRepository $repository)
    {
        try {
            $data = request()->only(['keyword', 'expire']);
            if (! $validator->scene('set_site_cache_keywords')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }

            if (! $site = $repository->getSiteById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该站点！');
            }

            // 检查缓存关键字是否存在
            if ($repository->isWhiteCacheKeywordExist($data['keyword'], $site)) {
                return Finalfail(REP_CODE_ILLEGAL_OPERATION, '关键字已存在，不能重复添加！');
            }

            // 添加站点缓存策略
            if (! $repository->addSiteCacheWhiteList($data, $id)) {
                return Finalfail(REP_CODE_ES_ERROR, '添加站点缓存策略失败！');
            }

            $site = $repository->getSiteById($id);
            if (! $repository->setESProxyConf($site)) {
                return Finalfail(REP_CODE_ES_ERROR, '更新Proxy Conf Cache失败！');
            }

            return Finalsuccess();
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_FAILED_OPERATION, '更新站点缓存白名单失败！');
        }
    }

    /**
     * @SWG\Delete(
     *      path="/site/{id}/cache-whitelist",
     *      tags={"Site 网站防护缓存加速"},
     *      summary="删除站点缓存白名单关键字",
     *      @SWG\Parameter(
     *          name="",
     *          in="body",
     *          description="需要删除的缓存关键字",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"keywords": {"test1"}}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 删除成功| !=0 删除失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     * @param $id
     * @param Site $validator
     * @param SiteRepository $repository
     * @return string
     */
    public function delSiteCacheWhiteList($id, Site $validator, SiteRepository $repository)
    {
        try {
            $data = request()->only('keywords');
            if (! $validator->scene('del_site_cache_keywords')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }

            if (! $site = $repository->getSiteById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该站点！');
            }

            // 移除缓存白名单关键字
            if (! $repository->rmSiteCacheWhiteList($data['keywords'], $id)) {
                return Finalfail(REP_CODE_ES_ERROR, '删除失败！');
            }

            $site = $repository->getSiteById($id);
            if (! $repository->setESProxyConf($site)) {
                return Finalfail(REP_CODE_ES_ERROR, '更新Proxy Conf Cache失败！');
            }

            return Finalsuccess();
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_FAILED_OPERATION, '删除站点缓存白名单失败！');
        }
    }

    /**
     * @SWG\Post(
     *      path="/site/{id}/cache-blacklist",
     *      tags={"Site 网站防护缓存加速"},
     *      summary="添加站点缓存黑名单",
     *      @SWG\Parameter(
     *          name="",
     *          in="body",
     *          description="黑名单关键字",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"keyword":"test"}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 添加成功| !=0 添加失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * 添加站点缓存黑名单
     *
     * @param $id
     * @param Site $validator
     * @param SiteRepository $repository
     * @return string
     */
    public function addSiteCacheBlackList($id, Site $validator, SiteRepository $repository)
    {
        try {
            $data = request()->only(['keyword']);
            if (! $validator->scene('set_site_cache_blackList')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }

            if (! $site = $repository->getSiteById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该站点！');
            }
            // 检查缓存关键字是否存在
            if ($repository->isBlackCacheKeywordExist($data['keyword'], $site)) {
                return Finalfail(REP_CODE_ILLEGAL_OPERATION, '关键字已存在，不能重复添加！');
            }

            if (! $repository->addSiteCacheBlackList($data, $site)) {
                return Finalfail(REP_CODE_ES_ERROR, '添加站点缓存黑名单失败！');
            }
            $site = $repository->getSiteById($id);
            if (! $repository->setESProxyConf($site)) {
                return Finalfail(REP_CODE_ES_ERROR, '更新Proxy Conf Cache失败！');
            }

            return Finalsuccess();
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_FAILED_OPERATION, '设置站点缓存黑名单失败！');
        }
    }

    /**
     * @SWG\Delete(
     *      path="/site/{id}/cache-blacklist",
     *      tags={"Site 网站防护缓存加速"},
     *      summary="删除站点缓存黑名单关键字",
     *      @SWG\Parameter(
     *          name="",
     *          in="body",
     *          description="需要删除的缓存黑名单关键字",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"keywords": {"test1"}}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 删除成功| !=0 删除失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     * @param $id
     * @param Site $validator
     * @param SiteRepository $repository
     * @return string
     */
    public function delSiteCacheBlackList($id, Site $validator, SiteRepository $repository)
    {
        try {
            $data = request()->only('keywords');
            if (! $validator->scene('del_site_cache_blacklist')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }

            if (! $site = $repository->getSiteById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该站点！');
            }

            // 移除缓存白名单关键字
            if (! $repository->rmSiteCacheBlackList($data['keywords'], $id)) {
                return Finalfail(REP_CODE_ES_ERROR, '删除失败！');
            }

            $site = $repository->getSiteById($id);
            if (! $repository->setESProxyConf($site)) {
                return Finalfail(REP_CODE_ES_ERROR, '更新Proxy Conf Cache失败！');
            }

            return Finalsuccess();
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_FAILED_OPERATION, '获取站点缓存黑名单失败！');
        }
    }
}