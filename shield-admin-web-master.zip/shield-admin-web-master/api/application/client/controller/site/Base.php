<?php

namespace app\client\controller\site;

use app\common\exception\client\PermissionDenyException;
use app\client\controller\BaseController;
use app\client\repository\SiteRepository;
use think\db\exception\ModelNotFoundException;
use think\Request;

/**
 * Class Base
 *
 * @package app\client\controller\site
 * @author Teddy Sun <sgsheg@163.com>
 */
class Base extends BaseController
{
    const WHITE = 'white';
    const BLACK = 'black';

    protected $site;

    /**
     * Base constructor.
     *
     * @param \think\Request $request
     * @param \app\client\repository\SiteRepository $siteRepository
     * @param $id
     * @throws \Exception
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function __construct(Request $request, SiteRepository $siteRepository, $id)
    {
        $this->site = $siteRepository->getSiteById($id);

        if (empty($this->site)) {
            throw new ModelNotFoundException('未找到对应站点');
        }
        //没有cname不允许访问控制面板和黑白名单
        if (empty($this->site['cname'])) {
            throw new PermissionDenyException('不允许访问');
        }
        parent::__construct($request);
    }
}