<?php
/*
* This file  is a part of  Veda- Platform
* Copyright (c) 2015 - 2018. Veda Software Inc. (http://www.veda.com)
*
* @file             UrlList.php
* @author           Teddy Sun
*/

namespace app\client\controller\site;

use think\Controller;
use think\Request;

/**
 * Class UrlList 黑白网址
 * @package app\client\controller\site
 * @author Teddy Sun <sgsheg@163.com>
 */
class UrlList extends Controller
{
    /**
     * 显示资源列表
     *
     * @return \think\Response
     */
    public function index()
    {
        //
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
    }

    /**
     * 显示指定的资源
     *
     * @param  int
     * @return \think\Response
     */
    public function read($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request
     * @param  int
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * 删除指定资源
     *
     * @param  int
     * @return \think\Response
     */
    public function delete($id)
    {
        //
    }
}