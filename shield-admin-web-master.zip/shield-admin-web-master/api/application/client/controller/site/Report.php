<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/4/26
 * Time: 19:00
 */

namespace app\client\controller\site;

use app\client\repository\ReportRepository;
use think\Request;

class Report extends Base
{
    /**
     * * @SWG\Get(
     *      path="/site/{id}/report/index",
     *      tags={"Site 网站访问概况"},
     *      summary="网站访问概况",
     *      @SWG\Parameter(
     *          name="start_date",
     *          in="query",
     *          description="开始时间(时间戳)",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="end_date",
     *          in="query",
     *          description="结束时间(时间戳)",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="quick_time",
     *          in="query",
     *          description="快速查询的时间，Example: 15:min,30:min,1:hour,24:hour",
     *          type="string",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"webs":{{"time":"2018-05-26 19:51:00","total_flow":0,"total_requests":0,"total_ip":0},
     *     {"time":"2018-05-26 19:54:00","total_flow":0,"total_requests":0,"total_ip":0},{"time":"2018-05-26 19:57:00","total_flow":0,"total_requests":0,"total_ip":0},{"time":"2018-05-26 20:00:00",
     *     "total_flow":0,"total_requests":0,"total_ip":0},{"time":"2018-05-26 20:03:00","total_flow":0,"total_requests":0,"total_ip":0},{"time":"2018-05-26 20:06:00","total_flow":0,"total_requests":0,"total_ip":0}},"totalFlow":0,
     *     "totalReq":0,"totalVisit":0}}
     *          )
     *      )
     * )
     *
     *
     * 获取时间内的统计数据
     *
     * @param \app\client\repository\ReportRepository $reportRepository
     * @param $id
     * @return string
     */
    public function index(ReportRepository $reportRepository, $id)
    {
        try {
            $data = $this->request->only(['start_date', 'end_date', 'quick_time']);

            $startTime = $data['start_date'] ?? time() - 15 * 60;
            $endTime   = $data['end_date'] ?? null;

            if (! empty($data['quick_time'])) {
                $timeParsed = $reportRepository->parseQuickTime($data['quick_time']);
                $startTime  = $timeParsed['startTime'];
                $endTime    = $timeParsed['endTime'];
            }

            // 条件
            $must = [[
                'match' => [
                    'host' => $id,
                ]
            ]];

            $filter = [];
            $filter[] = [
                'range' => [
                    'timestamp' => [
                        'gte' => gmt_withTZ($startTime),
                        'lte' => gmt_withTZ($endTime),
                    ]
                ]
            ];
            // 查询条件
            $filter = ['query' => ['bool' => compact('must', 'filter')]];
            // 聚合方式
            $aggData = $reportRepository->getWebAggs($startTime, $endTime);
            $filter['aggs'] = $aggData['agg'];
            $logs           = $reportRepository->getWebLogTrend($filter, $aggData['interval']);

            return Finalsuccess(['data' => $logs]);
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_ES_ERROR, '获取网站访问概况失败！');
        }
    }

    /**
     * @SWG\Get(
     *      path="/site/{id}/report/attacks",
     *      tags={"Site 网站防护报表信息"},
     *      summary="获取域名攻击信息",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="站点 Id",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="ip",
     *          in="query",
     *          description="高防IP",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="start_date",
     *          in="query",
     *          description="开始时间(时间戳)",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="end_date",
     *          in="query",
     *          description="结束时间(时间戳)",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="quick_time",
     *          in="query",
     *          description="快速查询的时间，Example: 15:min,30:min,1:hour,24:hour",
     *          type="string",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"attacks":{{"time":"2018-05-26 17:21:00","gjMax":0,"lhMax":0},
     *     {"time":"2018-05-26 17:24:00","gjMax":0,"lhMax":0},{"time":"2018-05-26 17:27:00","gjMax":0,"lhMax":0},{"time":"2018-05-26 17:30:00",
     *     "gjMax":0,"lhMax":0},{"time":"2018-05-26 17:33:00","gjMax":0,"lhMax":0},{"time":"2018-05-26 17:36:00","gjMax":0,"lhMax":0}},
     *     "gjTotal":3847453146,"glTotal":142370332,"lhTotal":3705082814,"sjbTotal":3009929,"glsjbTotal":142370262,"attackTypeCount":4,
     *     "attackCount":1076,"attackRecords":{"time":"2018-06-26 10:53:24","attack-ip":{"192.168.100.13","192.168.100.1","192.168.100.13","192.168.100.3","192.168.100.11","192.168.100.17","192.168.100.5","192.168.100.17","192.168.100.9","192.168.100.7"},"target-ip":"192.168.1.1","attack-type":"UDP Flood","max-bps":2480992,"target-port":{10017,10013,10005,10007,10007,10017,10005,10013,10013,10019}}}}
     *          )
     *      )
     * )
     *
     * @param $id
     * @param \app\client\repository\ReportRepository $reportRepository
     * @return string
     */
    public function attacks($id,ReportRepository $reportRepository)
    {
        try {
            $data = $this->request->only(['ip', 'start_date', 'end_date', 'quick_time']);
            $site = $this->site;

            $filter = $filter2 = [];

            $serverIp = (array)(! empty($data['ip']) ? $data['ip'] : array_column($site['proxy_ip'], 'ip'));
            config('app_debug') && $serverIp = null; // 测试环境默认返回所有IP的报表
            ! empty($serverIp) && $filter[] = ['terms' => ['target-ip' => $serverIp]];
            ! empty($serverIp) && $filter2[] = ['terms' => ['server-ip' => $serverIp]];
            // 没有开始时间，默认15分钟
            $startTime = $data['start_date'] ?? time() - 15 * 60;
            $endTime   = $data['end_date'] ?? null;
            // 快速查询
            if (! empty($data['quick_time'])) {
                // 如果有快速查询时间，需要使用快速查询的时间作为最终查询时间范围
                $timeParsed = $reportRepository->parseQuickTime($data['quick_time']);
                $startTime  = $timeParsed['startTime'];
                $endTime    = $timeParsed['endTime'];
            }

            ! empty($startTime) && $filter2[] = ['range' => ['timestamp' => ['gte' => gmt_withTZ($startTime)]]];
            ! empty($endTime) && $filter2[] = ['range' => ['timestamp' => ['lt' => gmt_withTZ($endTime)]]];

            // 查询条件
            $filter = ['query' => ['bool' => compact('filter')]];
            $filter['sort'] = ['time' => 'desc'];
            $filter['_source'] = ['time','attack-ip','target-ip','target-port','attack-type','max-bps'];
            $filter2 = ['query' => ['bool' => ['filter' => $filter2]]];

            //获取攻击类型和攻击次数
            $filter['aggs'] = $reportRepository->getAttackType();
            $attackType     = $reportRepository->getAttackRecord($filter);
            //攻击流量
            $filter2['aggs'] = $reportRepository->getAttackFlow($startTime, $endTime);
            $attackFlow     = $reportRepository->getAttackFlowRecord($filter2);

            return Finalsuccess(['data' => array_merge($attackType, $attackFlow)]);

        } catch (\Exception $e) {

            $this->errorHandle($e);

            return Finalfail(REP_CODE_ES_ERROR, '获取站点流量趋势失败！');
        }
    }

    /**
     *
     * @SWG\Get(
     *      path="/site/{id}/report/bandwidth",
     *      tags={"Site 网站防护报表信息"},
     *      summary="获取应用防护 IN/OUT 带宽趋势",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="高防实例 Id",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="ip",
     *          in="query",
     *          description="高防IP",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="start_date",
     *          in="query",
     *          description="开始时间(时间戳)",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="end_date",
     *          in="query",
     *          description="结束时间(时间戳)",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="quick_time",
     *          in="query",
     *          description="快速查询的时间，Example: 15:min,30:min,1:hour,24:hour",
     *          type="string",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","logs":{{"time":"2018-05-26 18:57:00","inMax":95637547,"outMax":9458637,
     *     "connsMax":0},{"time":"2018-05-26 19:00:00","inMax":97481137,"outMax":9972130,"connsMax":0},{"time":"2018-05-26 19:03:00",
     *     "inMax":95233859,"outMax":9803399,"connsMax":0},{"time":"2018-05-26 19:06:00","inMax":99691233,"outMax":9929844,
     *     "connsMax":0},{"time":"2018-05-26 19:09:00","inMax":99523116,"outMax":9742200,"connsMax":0},{"time":"2018-05-26 19:12:00",
     *     "inMax":94714624,"outMax":9735875,"connsMax":0}},"maxIn":99691233,"maxOut":9972130}
     *          )
     *      )
     * )
     * @param \app\client\repository\ReportRepository $reportRepository
     * @return string
     */
    public function banWidth(ReportRepository $reportRepository)
    {
        try {
            $data   = $this->request->only(['ip', 'start_date', 'end_date', 'quick_time']);
            $site   = $this->site;
            $filter = [];

            // 高防IP
            $id = (array)(! empty($data['ip']) ? $data['ip'] : array_column($site['proxy_ip'], 'ip'));
            config('app_debug') && $id = null; // 测试环境默认返回所有IP的报表
            ! empty($id) && $filter[] = ['terms' => compact('id')];

            $startTime = $data['start_date'] ?? time() - 15 * 60;
            $endTime   = $data['end_date'] ?? null;
            // 快速查询
            if (! empty($data['quick_time'])) {   // 如果有快速查询时间，需要使用快速查询的时间作为最终查询时间范围
                $timeParsed = $reportRepository->parseQuickTime($data['quick_time']);
                $startTime  = $timeParsed['startTime'];
                $endTime    = $timeParsed['endTime'];
            }
            ! empty($startTime) && $filter[] = ['range' => ['timestamp' => ['gte' => gmt_withTZ($startTime)]]];
            ! empty($endTime) && $filter[] = ['range' => ['timestamp' => ['lt' => gmt_withTZ($endTime)]]];

            // 查询条件
            $filter = ['query' => ['bool' => compact('filter')]];
            // 聚合方式
            $filter['aggs'] = $reportRepository->getBWFilterAggs($startTime, $endTime);
            $bwTrend        = $reportRepository->getBWTrend($filter);

            return Finalsuccess($bwTrend);
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail('IN/Out带宽获取失败！');
        }
    }
}