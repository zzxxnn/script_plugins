<?php

namespace app\client\controller\site;

use app\client\controller\BaseController;
use app\client\repository\SiteRepository;
use app\client\validate\SiteWhiteBlackValidator;

class BlackWhiteList extends BaseController
{

    /**
     * @SWG\Get(
     *      path="/site/{id}/url-whitelist",
     *      tags={"Site 网站防护黑白名单"},
     *      summary="获取站点Url白名单列表",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","urlWhitelist":{"a.com","b.com"}}
     *          )
     *      )
     * )
     *
     * @param $id
     * @param SiteRepository $repository
     * @return string
     */
    public function getUrlWhiteList($id, SiteRepository $repository)
    {
        try {
            if (!$site = $repository->getSiteById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该应用！');
            }

            $urlWhitelist = $site['filter']['url_whitelist'] ?? [];

            return Finalsuccess(compact('urlWhitelist'));
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_FAILED_OPERATION, '获取站点网址白名单失败！');
        }
    }

    /**
     * @SWG\Post(
     *      path="/site/{id}/url-whitelist",
     *      tags={"Site 网站防护黑白名单"},
     *      summary="更新站点Url白名单列表",
     *      @SWG\Parameter(
     *          name="urlWhitelist",
     *          in="body",
     *          description="站点URL白名单",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"urlWhitelist":{"a.com","b.com"}}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * @param $id
     * @param SiteRepository $repository
     * @param SiteWhiteBlackValidator $validator
     * @return string
     */
    public function setUrlWhiteList($id, SiteRepository $repository, SiteWhiteBlackValidator $validator)
    {
        try {
            $urlWhitelist = request()->param('urlWhitelist/a');
            if (!$validator->scene('set_url_whitelist')->check(input())) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }

            if (!$site = $repository->getSiteById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该站点！');
            }

            // 重复的不进行保存
            $urlWhitelist = array_unique($urlWhitelist);
            if (!$repository->updateSiteInfo(['filter' => ['url_whitelist' => $urlWhitelist]], $site)) {
                return Finalfail(REP_CODE_ES_ERROR, '更新站点URL白名单失败！');
            }

            $site = $repository->getSiteById($id);
            if (!$repository->setESProxyConf($site)) {
                return Finalfail(REP_CODE_ES_ERROR, '更新Proxy Conf配置信息失败！');
            }

            if (!$repository->setZKProxyConf($site)) {
                return Finalfail(REP_CODE_ZK_ERROR, '更新ZK Proxy Conf配置信息失败！');
            }

            return Finalsuccess();
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_FAILED_OPERATION, '设置站点网址白名单失败！');
        }
    }

    /**
     * @SWG\Get(
     *      path="/site/{id}/url-blacklist",
     *      tags={"Site 网站防护黑白名单"},
     *      summary="获取站点Url黑名单列表",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","urlBlacklist":{"a.com","b.com"}}
     *          )
     *      )
     * )
     *
     * @param $id
     * @param SiteRepository $repository
     * @return string
     */
    public function getUrlBlackList($id, SiteRepository $repository)
    {
        try {
            if (!$site = $repository->getSiteById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该应用！');
            }
            $urlBlacklist = $site['filter']['url_blacklist'] ?? [];

            return Finalsuccess(compact('urlBlacklist'));
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_FAILED_OPERATION, '获取站点网址黑名单失败！');
        }
    }

    /**
     * @SWG\Post(
     *      path="/site/{id}/url-blacklist",
     *      tags={"Site 网站防护黑白名单"},
     *      summary="更新站点Url黑名单列表",
     *      @SWG\Parameter(
     *          name="urlBlacklist",
     *          in="body",
     *          description="站点URL黑名单",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"urlBlacklist":{"a.com","b.com"}}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * @param $id
     * @param SiteWhiteBlackValidator $validator
     * @param SiteRepository $repository
     * @return string
     */
    public function setUrlBlackList($id, SiteWhiteBlackValidator $validator, SiteRepository $repository)
    {
        try {
            $urlBlacklist = request()->param('urlBlacklist/a');
            if (!$validator->scene('set_url_blacklist')->check(input())) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }
            if (!$site = $repository->getSiteById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该站点！');
            }

            // 重复的不进行保存
            $urlBlacklist = array_unique($urlBlacklist);
            if (!$repository->updateSiteInfo(['filter' => ['url_blacklist' => $urlBlacklist]], $site)) {
                return Finalfail(REP_CODE_ES_ERROR, '更新站点URL白名单失败！');
            }
            $site = $repository->getSiteById($id);
            if (!$repository->setESProxyConf($site)) {
                return Finalfail(REP_CODE_ES_ERROR, '更新Proxy Conf配置信息失败！');
            }

            if (!$repository->setZKProxyConf($site)) {
                return Finalfail(REP_CODE_ZK_ERROR, '更新ZK Proxy Conf配置信息失败！');
            }

            return Finalsuccess();
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_FAILED_OPERATION, '设置站点网址黑名单失败！');
        }
    }
}
