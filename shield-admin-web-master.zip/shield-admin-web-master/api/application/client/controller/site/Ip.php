<?php
/*
* This file  is a part of  Veda- Platform
* Copyright (c) 2015 - 2018. Veda Software Inc. (http://www.veda.com)
*
* @file             Ip.php
* @author           Teddy Sun
*/

namespace app\client\controller\site;

use app\client\repository\SiteRepository;
use app\client\validate\SiteWhiteBlackValidator;
use think\db\exception\ModelNotFoundException;
use think\Request;

/**
 * Class Ip IP黑白列表
 *
 * @package app\client\controller\site
 * @author Teddy Sun <sgsheg@163.com>
 */
class Ip extends Base
{
    /**
     * @SWG\Get(
     *      path="/site/{id}/ip-list",
     *      tags={"Site 网站防护黑白名单"},
     *      summary="获取站点IP黑白名单列表",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","ipWhiteList":{}, "ipBlackList": {}}
     *          )
     *      )
     * )
     * 显示资源列表
     *
     * @return \think\Response
     * @throws \Exception
     */
    public function index()
    {
        $site = $this->site;

        $ipWhiteList = $site['filter']['ip_whitelist'] ?? [];
        $ipBlackList = $site['filter']['ip_blacklist'] ?? [];

        return Finalsuccess(compact('ipWhiteList', 'ipBlackList'));
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * @SWG\Post(
     *      path="/site/{id}/ip-list",
     *      tags={"Site 网站防护黑白名单"},
     *      summary="更新站点ip黑白名单列表",
     *      @SWG\Parameter(
     *          name="ipWhiteList",
     *          in="body",
     *          description="站点ip黑白名单",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"ipWhitelist":{"1.1.1.1"}}
     *          )
     *      ),
     *     @SWG\Parameter(
     *          name="type=white|black",
     *          in="body",
     *          description="站点ip黑白名单",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"type": "white"}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * @param SiteRepository $repository
     * @param SiteWhiteBlackValidator $validator
     * @return string
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function save(SiteWhiteBlackValidator $validator, SiteRepository $repository)
    {
        $site = $this->site;
        $type = $this->request->post('type');

        if (empty($type) || ! in_array($type, [self::WHITE, self::BLACK])) {
            //无type或者type不在允许范围内抛出异常
            throw new ModelNotFoundException('操作非法');
        }

        // 白名单
        $ipWhitelist = $this->request->post('ipWhiteList/a');
        $ipBlacklist = $this->request->post('ipBlackList/a');
        $filter      = [];

        if (self::WHITE == $type) {

            $filter = ['filter' => ['ip_whitelist' => $ipWhitelist]];
            $site['filter']['ip_whitelist'] = $ipWhitelist;
            //白色更新

            if (! $validator->scene('set_ip_whitelist')->check(['ipWhitelist' => $ipWhitelist])) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }
        }

        if (self::BLACK == $type) {
            //黑ip
            $filter = ['filter' => ['ip_blacklist' => $ipBlacklist]];
            $site['filter']['ip_blacklist'] = $ipBlacklist;

            if (! $validator->scene('set_ip_blacklist')->check(['ipBlacklist' => $ipBlacklist])) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }
        }

        try {
            if ($this->saveToElasticSearch($repository, $filter, $site)) {
                return Finalsuccess();
            }
        } catch (\Exception $e) {
            return Finalfail(REP_CODE_FAILED_OPERATION, '操作失败,请重试');
        }
    }

    /**
     * 显示指定的资源
     *
     * @param  int
     * @return \think\Response
     */
    public function read($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request
     * @param  int
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * 删除指定资源
     *
     * @param  int
     * @return \think\Response
     */
    public function delete($id)
    {
        //
    }

    /**
     * @param \app\client\repository\SiteRepository $repository
     * @param $filter
     * @param $site
     * @return boolean | string
     * @throws \Exception
     * @throws \app\common\exception\client\ElasticSearchException
     * @throws \app\common\exception\client\ZookeeperException
     */
    private function saveToElasticSearch(SiteRepository $repository, $filter, $site)
    {
        if (! $repository->updateSiteInfo($filter, $site)) {
            return Finalfail(REP_CODE_ES_ERROR, '更新站点名单失败！');
        }

        if (! $repository->setESProxyConf($site)) {
            return Finalfail(REP_CODE_ES_ERROR, '更新Proxy Conf配置信息失败！');
        }

        if (! $repository->setZKProxyConf($site)) {
            return Finalfail(REP_CODE_ZK_ERROR, '更新ZK Proxy Conf配置信息失败！');
        }

        return true;
    }
}