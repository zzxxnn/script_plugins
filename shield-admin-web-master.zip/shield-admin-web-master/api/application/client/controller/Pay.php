<?php

namespace app\client\controller;

use app\common\model\OrderModel;
use app\client\repository\OrderRepository;
use app\client\repository\PayRepository;
use app\client\service\Auth;
use app\client\service\WxPay;
use app\client\traits\CheckLogin;
use app\client\validate\Pay as PayValidator;
use app\common\exception\client\Pay\WxPayException;
use app\common\model\UserModel;
use NativePay;
use think\Log;
use think\Request;
use WxPayResults;
use WxPayUnifiedOrder;

class Pay extends BaseController
{
    use CheckLogin;

    protected $beforeActionList = [
        'checkLogin' => ['only' => 'index,create']
    ];

    public function __construct(Request $request)
    {
        $this->repository = new PayRepository();

        $this->validator = new PayValidator();

        parent::__construct($request);
    }

    public function testPay(Request $request)
    {
        $wxPayOrder = new WxPayUnifiedOrder();
        $wxPayOrder->SetBody('HD 高防实例');    // 商品描述
        $wxPayOrder->SetAttach('HD 测试订单');   // 附加数据
        $wxPayOrder->SetOut_trade_no(date('YmdHis'));   // 商户订单号
        $wxPayOrder->SetTotal_fee(1);  // 订单总金额
////        $wxPayOrder->SetTime_start();              // 交易起止时间
////        $wxPayOrder->SetTime_expire();              // 交易结束时间
////        $wxPayOrder->SetGoods_tag();                // 订单优惠标记
//        $wxPayOrder->SetNotify_url("http://paysdk.weixin.qq.com/example/notify.php");
        $wxPayOrder->SetTrade_type("NATIVE");
        $wxPayOrder->SetProduct_id("123456789");
        $notifyUrl = 'http://77ced19d.ittun.com/v1/pay/notify';
        $wxPayOrder->SetNotify_url($notifyUrl);

        $notify = new NativePay();
        $result = $notify->GetPayUrl($wxPayOrder);
        if (! isset($result['result_code'], $result['return_msg']) || $result['result_code'] !== 'SUCCESS') {
            return $result['return_msg'];
        }
        $payLink = $result['code_url'];

        return $this->fetch('wx-pay', compact('payLink'));
    }

    /**
     * 支付结果的通知
     *
     * @param OrderRepository $orderRepository
     * @param PayRepository $payRepository
     *
     * @return string
     */
    public function notify(OrderRepository $orderRepository, PayRepository $payRepository)
    {
        try {
            $notifyInfo    = WxPayResults::Init(file_get_contents('php://input'));
            $notifyTradeNo = $notifyInfo['out_trade_no'];
            $notifyFee     = $notifyInfo['total_fee'] / 100;        // 微信返回的订单金额单位为 分
            // 查找订单是否存在
            if (! $order = $orderRepository->getOrderById($notifyTradeNo)) {
                throw new WxPayException('未找到订单，回调参数:'.json_encode($notifyInfo));
            }

            // 如果订单已支付，直接返回成功
            if ($order['status'] == OrderModel::ORDER_STATUS_PAID) {
                echo '<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>';
                exit;
            }

            // 检查当前订单状态
            if (! in_array($order['status'], [OrderModel::ORDER_STATUS_CREATED, OrderModel::ORDER_STATUS_TRASHED])) {
                throw new WxPayException('订单状态异常，回调参数:'.json_encode($notifyInfo));
            }

            // 校验支付金额是否正确
            $orderFee = $order['final_fee'] ?? $order['fee'];
            if (! config('app_debug') && $orderFee != $notifyFee) {
                throw new WxPayException('订单金额异常，回调参数：'.json_encode($notifyInfo));
            }

            // 更新订单状态为 已支付
            $updateResult = $orderRepository->updateOrderStatus(OrderModel::ORDER_STATUS_PAID, $notifyTradeNo);
            if (! $updateResult) {
                throw new WxPayException('订单状态更新失败，回调参数：'.json_encode($notifyInfo));
            }

            // 处理订单支付成功后的逻辑
            $payRepository->emitPaySuccessEvent($order);

            echo '<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>';
            exit;
        } catch (\Exception $e) {
            Log::error($e->getMessage());
        }
    }

    /**
     * @SWG\POST(
     *     path="/v1/pay/url",
     *     tags={"Pay 支付"},
     *     summary="Pay 获取订单支付链接",
     *      @SWG\Parameter(
     *          name="",required=true,in="body",description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="orderId", type="string", example="11806221400509", description="订单编号"),
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="success: true | false ",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","url":"http://paysdk.weixin.qq.com/example/qrcode.php?
 * data=weixin%3A%2F%2Fwxpay%2Fbizpayurl%3Fpr%3D9dCqt6M"}
     *          )
     *      )
     * )
     *
     * @param PayRepository $repository
     * @param OrderRepository $orderRepository
     *
     * @return string
     */
    public function url(PayRepository $repository, OrderRepository $orderRepository)
    {
        try {
            $data = input();
            // 参数校验
            if (! $this->validator->scene('url')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
            }

            $orderId = $data['orderId'];

            if (! $order = $orderRepository->getOrderById($orderId)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该订单！');
            }

            // 已支付订单弹出
            if ($order['status'] == OrderModel::ORDER_STATUS_PAID) {
                return Finalfail(REP_CODE_ILLEGAL_OPERATION, '订单已支付！');
            }

            // 订单已作废，弹出已作废的提示
            if ($order['status'] == OrderModel::ORDER_STATUS_TRASHED) {
                return Finalfail(REP_CODE_ILLEGAL_OPERATION, '订单已作废！');
            }

            $goodsInfo = $order['type'] == OrderModel::ORDER_TYPE_RECHARGE ? '幻盾余额充值' : '幻盾高防实例购买！';
            $orderFee  = ($order['final_fee'] ?? $order['fee']) * 100;
            $goodsId   = $order['detail']['product_id'] ?? 0;

            // 获取支付链接
            $url = $repository->getWxPayQrCodeUrl($goodsInfo, $orderId, $orderFee, $goodsId);

            return Finalsuccess(compact('url'));
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_SERVER_ERROR, '支付链接获取失败！');
        }
    }

    /**
     * @SWG\POST(
     *     path="/v1/pay/info",
     *     tags={"Pay 支付"},
     *     summary="Pay 获取订单支付信息",
     *      @SWG\Parameter(
     *          name="",required=true,in="body",description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="orderId", type="string", example="11806221400509", description="订单编号"),
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="success: true | false ",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","orderInfo":{"appid":"wx4a2cdf4c3bc90cd7","attach":"HD 测试订单",
     *     "bank_type":"CFT","cash_fee":"1","fee_type":"CNY","is_subscribe":"N","mch_id":"1507790591","nonce_str":"hGcXpqv3YGkABv0l",
     *     "openid":"oTuRD0X_S_TaY-jJ3FPkkk18JmJk","out_trade_no":"20180622141816","result_code":"SUCCESS","return_code":"SUCCESS",
     *     "return_msg":"OK","sign":"35113124692A4891E9AB02F1D8C50880","time_end":"20180622141835","total_fee":"1",
     *     "trade_state":"SUCCESS","trade_state_desc":"支付成功","trade_type":"NATIVE","transaction_id":"4200000142201806220415497385"}}
     *          )
     *      )
     * )
     *
     * @param OrderRepository $repository
     *
     * @return string
     */
    public function info(OrderRepository $repository)
    {
        try {
            $data = input();
            // 参数校验
            if (! $this->validator->scene('info')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
            }

            $orderId = $data['orderId'];
            if (! $order = $repository->getOrderById($orderId)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该订单！');
            }

            $orderInfo = (new WxPay())->getOrderInfo($orderId);

            return Finalsuccess(compact('orderInfo'));
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_SERVER_ERROR, '获取订单支付信息失败！');
        }
    }

    /**
     * @SWG\Post(
     *      path="/v1/pay/status",
     *      tags={"Pay 支付"},
     *      summary="Pay 获取订单支付状态",
     *      @SWG\Parameter(
     *          name="",required=true,in="body",description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="orderId", type="string", example="11806221400509", description="订单编号"),
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",description="Success: true",
     *          @SWG\Property(type="object",example={"errcode":0,"errmsg":"ok","status":"SUCCESS"})
     *      ),
     * )
     * @param PayRepository $repository
     * @param OrderRepository $orderRepository
     *
     * @return string
     */
    public function status(PayRepository $repository, OrderRepository $orderRepository)
    {
        try {
            $data = input();
            // 参数校验
            if (! $this->validator->scene('status')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
            }
            $orderId = $data['orderId'];

            if (! $order = $orderRepository->getOrderById($orderId)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该订单！');
            }
            $payInfo = $repository->getOrderPayInfo($orderId);
            $status  = $payInfo['trade_state'] ?? null;

            // 如果支付状态为已支付，更新订单的支付状态
            $updateOrderStatus = $status === 'SUCCESS';
            if ($updateOrderStatus) {
                // 检查当前订单状态
                if ((! in_array($order['status'],
                    [OrderModel::ORDER_STATUS_CREATED, OrderModel::ORDER_STATUS_TRASHED]))) {
                    $updateOrderStatus = false;
                }

                // 校验支付金额是否正确
                $payFee = $payInfo['total_fee'] / 100;

                // 订单的支付价格为优惠价或者原价
                $orderFee = $order['final_fee'] ?? $order['fee'];
                if (! config('app_debug') && $orderFee != $payFee) {
                    $updateOrderStatus = false;
                }

                // 更新订单状态为 已支付
                if ($updateOrderStatus) {
                    $updateResult = $orderRepository->updateOrderStatus(OrderModel::ORDER_STATUS_PAID, $orderId);
                    if (! $updateResult && $updateResult['result'] = ['updated']) {
                        throw new WxPayException('订单状态更新失败，回调参数：'.json_encode($payInfo));
                    }
                    // 处理订单支付成功后的逻辑
                    $repository->emitPaySuccessEvent($order);
                }
            }

            request()->bind('email', Auth::id());
            return Finalsuccess(compact('status'));
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_DB_ERROR, '获取订单支付状态失败！');
        }
    }

    /**
     *
     * @SWG\Post(
     *      path="/v1/pay/remaining",
     *      tags={"Pay 支付"},
     *      summary="Pay 余额支付",
     *     @SWG\Parameter(
     *          name="orderId",
     *          in="query",
     *          description="订单编号",
     *          type="string"
     *      ),
     *      @SWG\Parameter(
     *          name="payType",
     *          in="query",
     *          description="支付方式 - 1: 支付宝; 2: 微信支付; 3. 余额支付",
     *          type="integer"
     *      ),
     *      @SWG\Response(
     *          response="200",description="Success: true",
     *          @SWG\Property(type="object",example={"errcode":0,"errmsg":"ok","status":"SUCCESS"})
     *      ),
     * )
     *
     *
     * @param PayRepository $payRepository
     * @param OrderRepository $orderRepository
     *
     * @return string
     */
    public function remaining(PayRepository $payRepository, OrderRepository $orderRepository)
    {
        try {
            $data = input();
            // 参数校验
            if (! $this->validator->scene('remaining')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
            }

            $orderId = $data['orderId'];

            if (! $order = $orderRepository->getOrderById($orderId)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该订单！');
            }

            if ($order['status'] == OrderModel::ORDER_STATUS_PAID) {
                return Finalfail(REP_CODE_ORDER_ALREADY_PAY, '该订单已经支付过了！');
            }

            $orderFee    = $order['final_fee'] ?? $order['fee'];
            $user        = UserModel::where('email', Auth::id())->find();
            $userAccount = $user ? $user->account : 0;
            if ($userAccount < $orderFee) {
                return Finalfail(REP_CODE_ORDER_REMAINING_FEE_NOT_ENOUGH, '余额不足，请充值后再购买！');
            } else {
                // 更新订单状态为 已支付
                $updateResult = $orderRepository->updateOrderStatus(OrderModel::ORDER_STATUS_PAID, $orderId);
                if (! $updateResult) {
                    return Finalfail(REP_CODE_ORDER_UPDATE_ERROR, '订单状态更新失败，请稍后再试！');
                }

                // 处理订单支付成功后的逻辑
                $payRepository->emitPaySuccessEvent($order, OrderModel::ORDER_PAY_TYPE_REMAINNING);
            }

            request()->bind('order_id', $orderId);
            request()->bind('email', Auth::id());
            return Finalsuccess(compact('order'));
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_DB_ERROR, '余额支付失败！');
        }
    }
}