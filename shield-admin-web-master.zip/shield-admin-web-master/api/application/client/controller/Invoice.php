<?php

namespace app\client\controller;

use app\client\service\Auth;
use app\client\traits\CheckLogin;
use app\common\repository\InvoiceRepository;
use app\common\validate\InvoiceValidator;
use app\common\model\InvoiceModel;
use think\Request;

class Invoice extends BaseController
{

    use CheckLogin;

    public function __construct(Request $request)
    {
        parent::__construct();

        $this->validator  = new InvoiceValidator();
        $this->repository = new InvoiceRepository();
    }

    /**
     * @SWG\Get(
     *      path="/invoice/uuid",
     *      tags={"Invoice 开票"},
     *      summary="【获取】生成开票申请号",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":"1808301016505"}
     *          )
     *      )
     * )
     *
     *
     */
    public function showUUID()
    {
        return Finalsuccess(['data' => InvoiceModel::INVOICE_UUID_PREFIX.date('ymdHi').rand(100, 999)]);
    }

    /**
     * @SWG\Post(
     *      path="/invoice",
     *      tags={"Invoice 开票"},
     *      summary="用户申请开票",
     *     @SWG\Parameter(
     *         name="",
     *         in="body",
     *         description="开票 信息, ivc_type为发票类型；fee:订单原价；final_fee：改价之后的价格",
     *         required=true,
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"invoice":{"uuid":"11808301026978","user_id":
     *              1,"user_email":"test54814@veda.com","ivc_type":0,"ivc_title":"发票抬头","ivc_tax_id":"纳税人识别码","ivc_address":"注册地址","ivc_mobile":"注册电话","ivc_bank":"开户银行","ivc_account":"银行账号","consignee_name":"收件人","consignee_address":"收件地址","consignee_mobile":"收件人电话"},"orders":{{"order_id":"11807031102581","order_type":"3","content":"技术服务费","fee":100,"final_fee":0}}}
     *          )
     *     ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 申请成功| !=0 申请失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"id":9}}
     *          )
     *      )
     * )
     *
     */
    public function create()
    {
        $data = input();
        request()->bind('email', Auth::id());

        if (isset($data['invoice']) && isset($data['invoice']['ivc_type'])) {
            if ($data['invoice']['ivc_type'] == InvoiceModel::INVOICE_TYPE_NORMAL) {
                // 普通发票参数校验
                if ( ! $this->validator->scene('normal_invoice')->check(input())) {
                    return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
                }
            } elseif ($data['invoice']['ivc_type'] == InvoiceModel::INVOICE_TYPE_PRIVATE) {
                // 专用发票参数校验
                if ( ! $this->validator->scene('private_invoice')->check(input())) {
                    return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
                }
            }

            $result = $this->repository->save($data, 'client');
            if ($result) {

                return Finalsuccess(['data' => ['id' => $result->id]]);
            }

            return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败！');

        }

        return Finalfail(REP_CODE_PARAMS_INVALID, '请选择发票类型！');
    }

    /**
     * @SWG\Get(
     *      path="/invoice/{id}",
     *      tags={"Invoice 开票"},
     *      summary="【获取】用户开票详情",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"id":3,"uuid":"11808301026978","user_id":1,"user_email":"test54814@veda.com","system":"client","ivc_type":0,"ivc_numbers":null,"ivc_title":"北京卫达","ivc_tax_id":"123456789","ivc_address":"北京市","ivc_mobile":"18638121735","ivc_bank":"招商银行","ivc_account":"123456789","consignee_name":"叶肖肖","consignee_address":"郑州市大学科技园","consignee_mobile":"18638121735","track_ship_id":null,"track_company":null,"description":null,"create_time":"2018-08-25
     *              15:07:10","update_time":"2018-08-25
     *              15:07:10","delete_time":null,"logs":{{"id":3,"status":0,"create_time":"2018-08-25
     *              15:07:10"}},"orders":{{"id":3,"order_id":"11807031102581","order_type":1,"content":"技术服务费","fee":"100","final_fee":"0"},{"id":4,"order_id":"11805301538535","order_type":2,"content":"技术服务费","fee":"100","final_fee":"0"}}},"order_total_amount": 80}
     *          )
     *      )
     * )
     *
     *
     * @param $id
     *
     * @return string
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function show($id)
    {
        $invoice = $this->repository->getDetail($id);
        if ( ! $invoice) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该订单的开票信息！');
        }

        return Finalsuccess([ 'data' => $invoice ]);
    }

    /**
     * @SWG\Put(
     *      path="/invoice/{id}/finish",
     *      tags={"Invoice 开票"},
     *      summary="【收到发票】收到发票",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 收到发票成功| !=0 收到发票失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     *
     * @return string
     * @throws \app\common\exception\RepositoryException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function finish()
    {
        $data = input();
        request()->bind('email', Auth::id());
        // 普通发票参数校验
        if ( ! $this->validator->scene('finish_invoice')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        $result = $this->repository->finish($data);
        if ($result) {
            return Finalsuccess();
        }

        return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败！');
    }

    /**
     * @SWG\Get(
     *      path="/invoice/latest",
     *      tags={"Invoice 开票"},
     *      summary="【获取】用户最近开票信息",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"normal":{"ivc_type":0,"ivc_title":"北京卫达","consignee_name":"叶肖肖","consignee_address":"郑州市大学科技园","consignee_mobile":"18638121735"},"private":{"ivc_type":1,"ivc_title":"北京卫达","ivc_tax_id":"123456789","ivc_address":"北京市","ivc_mobile":"18638121735","ivc_bank":"招商银行","ivc_account":"123456789","consignee_name":"叶肖肖","consignee_address":"郑州市大学科技园","consignee_mobile":"18638121735"}}}
     *          )
     *      )
     * )
     *
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function showLatest()
    {
        $result = [];
        $normal_invoice = InvoiceModel::where('ivc_type', InvoiceModel::INVOICE_TYPE_NORMAL)->where('user_email', Auth::id())->order('id', 'desc')->find();
        $private_invoice = InvoiceModel::where('ivc_type', InvoiceModel::INVOICE_TYPE_PRIVATE)->where('user_email', Auth::id())->order('id', 'desc')->find();
        if ($normal_invoice){
            $result['normal'] = [
                "ivc_type"          => $normal_invoice->ivc_type,
                "ivc_title"         => $normal_invoice->ivc_title,
                "consignee_name"    => $normal_invoice->consignee_name,
                "consignee_address" => $normal_invoice->consignee_address,
                "consignee_mobile"  => $normal_invoice->consignee_mobile,
            ];
        }
        if ($private_invoice) {
            $result['private'] = [
                "ivc_type"          => $private_invoice->ivc_type,
                "ivc_title"         => $private_invoice->ivc_title,
                "ivc_tax_id"        => $private_invoice->ivc_tax_id,
                "ivc_address"       => $private_invoice->ivc_address,
                "ivc_mobile"        => $private_invoice->ivc_mobile,
                "ivc_bank"          => $private_invoice->ivc_bank,
                "ivc_account"       => $private_invoice->ivc_account,
                "consignee_name"    => $private_invoice->consignee_name,
                "consignee_address" => $private_invoice->consignee_address,
                "consignee_mobile"  => $private_invoice->consignee_mobile,
            ];
        }
        if ($result) {
            return Finalsuccess([ 'data' => $result ]);
        }

        return Finalsuccess();
    }

}
