<?php

namespace app\client\controller\ddos;

use app\common\exception\client\PermissionDenyException;
use app\client\controller\BaseController;
use app\client\model\UserInstanceModel;
use app\client\repository\DDoSRepository;
use think\db\exception\ModelNotFoundException;
use think\Request;

/**
 * Class Base
 *
 * @package app\client\controller\ddos
 * @author Teddy Sun <sgsheg@163.com>
 */
class Base extends BaseController
{
    protected $instance;

    /**
     * Base constructor.
     *
     * @param \app\client\repository\DDoSRepository $repository
     * @param \think\Request $request
     * @param $id
     * @throws \Exception
     */
    public function __construct(DDoSRepository $repository, Request $request, $id)
    {
        $this->instance = $repository->getDDoSById($id);
        if (! $this->instance) {
            throw new ModelNotFoundException('未找到实例');
        }

        //实例未激活 拒绝查看
        if (UserInstanceModel::STATUS_CREATED === $this->instance['status']) {
            throw new PermissionDenyException('实例暂未启用.');
        }
        parent::__construct($request);
    }
}