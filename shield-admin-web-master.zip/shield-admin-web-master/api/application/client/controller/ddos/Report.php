<?php

namespace app\client\controller\ddos;

use app\client\repository\ReportRepository;

/**
 * Class Report 高仿实例报表
 *
 * @package app\client\controller\ddos
 * @author Teddy Sun <sgsheg@163.com>
 */
class Report extends Base
{
    /**
     * @SWG\Get(
     *      path="/ddos/{id}/report/attacks",
     *      tags={"DDoS 高防实例报表信息"},
     *      summary="获取高防实例攻击信息",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="高防实例 Id",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="ip",
     *          in="query",
     *          description="高防IP",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="start_date",
     *          in="query",
     *          description="开始时间(时间戳)",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="end_date",
     *          in="query",
     *          description="结束时间(时间戳)",
     *          type="integer",
     *      ),
     *      @SWG\Parameter(
     *          name="quick_time",
     *          in="query",
     *          description="快速查询的时间，Example: 15:min,30:min,1:hour,24:hour",
     *          type="string",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"attacks":{{"time":"2018-05-26 17:21:00","gjMax":0,"lhMax":0},
     *     {"time":"2018-05-26 17:24:00","gjMax":0,"lhMax":0},{"time":"2018-05-26 17:27:00","gjMax":0,"lhMax":0},{"time":"2018-05-26 17:30:00",
     *     "gjMax":0,"lhMax":0},{"time":"2018-05-26 17:33:00","gjMax":0,"lhMax":0},{"time":"2018-05-26 17:36:00","gjMax":0,"lhMax":0}},
     *     "gjTotal":3847453146,"glTotal":142370332,"lhTotal":3705082814,"sjbTotal":3009929,"glsjbTotal":142370262,"attackTypeCount":4,
     *     "attackCount":1076,"attackRecords":{"time":"2018-06-26 10:53:24","attack-ip":{"192.168.100.13","192.168.100.1","192.168.100.13","192.168.100.3","192.168.100.11","192.168.100.17","192.168.100.5","192.168.100.17","192.168.100.9","192.168.100.7"},"target-ip":"192.168.1.1","attack-type":"UDP Flood","max-bps":2480992,"target-port":{10017,10013,10005,10007,10007,10017,10005,10013,10013,10019}}}}
     *          )
     *      )
     * )
     *
     * 总流量和攻击流量趋势
     *
     * @param \app\client\repository\ReportRepository $reportRepository
     * @param $id
     * @return string
     */
    public function attacks(ReportRepository $reportRepository, $id)
    {
        $instance = $this->instance;
        try {
            $data   = $this->request->only(['ip', 'start_date', 'end_date', 'quick_time']);
            $filter = $filter2 = [];
            // 高防IP notice:注意攻击flow中server-ip
            $serverIp = (array) (! empty($data['ip']) ? $data['ip'] : array_column($instance['hd_ip'], 'ip'));

            $filter[]  = ['terms' => ['target-ip' => $serverIp]];
            $filter2[] = ['terms' => ['server-ip' => $serverIp]];

            $startTime = $data['start_date'] ?? time() - 15 * 60;
            $endTime   = $data['end_date'] ?? null;
            // 快速查询
            if (! empty($data['quick_time'])) {
                // 如果有快速查询时间，需要使用快速查询的时间作为最终查询时间范围
                $timeParsed = $reportRepository->parseQuickTime($data['quick_time']);
                $startTime  = $timeParsed['startTime'];
                $endTime    = $timeParsed['endTime'];
            }

            ! empty($startTime) && $filter2[] = ['range' => ['timestamp' => ['gte' => gmt_withTZ($startTime)]]];
            ! empty($endTime) && $filter2[] = ['range' => ['timestamp' => ['lt' => gmt_withTZ($endTime)]]];

            // 查询条件
            $filter  = ['query' => ['bool' => compact('filter')]];
            $filter2 = ['query' => ['bool' => ['filter' => $filter2]]];

            //获取攻击类型和攻击次数
            $filter['aggs'] = $reportRepository->getAttackType();
            $filter['sort'] = ['time' => 'desc'];
            $filter['_source'] = ['time','attack-ip','target-ip','target-port','attack-type','max-bps'];
            $attackType     = $reportRepository->getAttackRecord($filter);

            //获取攻击流量
            $filter2['aggs'] = $reportRepository->getAttackFlow($startTime, $endTime);
            $attackFlow      = $reportRepository->getAttackFlowRecord($filter2);

            return Finalsuccess(['data' => array_merge($attackType, $attackFlow)]);
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_ES_ERROR, '获取应用流量趋势失败！');
        }
    }

    /**
     * IN/OUT 带宽趋势
     *
     * @param $id
     * @return string
     */
    public function banWidth(ReportRepository $reportRepository)
    {
        $instance = $this->instance;

        try {
            $data = $this->request->only(['ip', 'start_date', 'end_date', 'quick_time']);

            $filter = [];

            // 高防IP
            $id = (array) (! empty($data['ip']) ? $data['ip'] : array_column($instance['hd_ip'], 'ip'));

            if (empty($id)) {
                $data = ['logs' => [], 'maxIn' => 0, 'maxOut' => 0];

                return Finalsuccess($data);
            }
            $filter[] = ['terms' => compact('id')];

            $startTime = $data['start_date'] ?? time() - 15 * 60;
            $endTime   = $data['end_date'] ?? null;
            // 快速查询
            if (! empty($data['quick_time'])) {   // 如果有快速查询时间，需要使用快速查询的时间作为最终查询时间范围
                $timeParsed = $reportRepository->parseQuickTime($data['quick_time']);
                $startTime  = $timeParsed['startTime'];
                $endTime    = $timeParsed['endTime'];
            }
            ! empty($startTime) && $filter[] = ['range' => ['timestamp' => ['gte' => gmt_withTZ($startTime)]]];
            ! empty($endTime) && $filter[] = ['range' => ['timestamp' => ['lt' => gmt_withTZ($endTime)]]];

            // 查询条件
            $filter = ['query' => ['bool' => compact('filter')]];
            // 聚合方式
            $filter['aggs'] = $reportRepository->getBWFilterAggs($startTime, $endTime);
            $bwTrend        = $reportRepository->getBWTrend($filter);

            return Finalsuccess($bwTrend);
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail('IN/Out带宽获取失败！');
        }
    }
}