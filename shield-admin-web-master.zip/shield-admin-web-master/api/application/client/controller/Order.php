<?php

namespace app\client\controller;

use app\common\model\OrderModel;
use app\common\model\ProductModel;
use app\client\repository\OrderRepository;
use app\client\repository\ServerRepository;
use app\client\service\Auth;
use app\client\traits\CheckLogin;
use app\client\validate\Order as OrderValidator;
use app\common\model\ProductSkuModel;
use think\Request;

class Order extends BaseController
{

    use CheckLogin;

    protected $validator;

    protected $repository;

    public function __construct(Request $request = null)
    {
        $this->repository = new OrderRepository();

        $this->validator = new OrderValidator();

        parent::__construct($request);
    }

    protected $beforeActionList = [
        'checkLogin'
    ];

    /**
     * @SWG\Get(
     *      path="/order",
     *      tags={"Order 订单管理"},
     *      summary="获取订单列表",
     *      @SWG\Parameter(
     *          name="type",
     *          in="query",
     *          description="类型:1-充值;2-消费",
     *          type="integer"
     *      ),
     *      @SWG\Parameter(
     *          name="status",
     *          in="query",
     *          description="支付状态:0-未支付；1-已支付；2-已作废",
     *          type="integer"
     *      ),
     *      @SWG\Parameter(
     *          name="start_date",
     *          in="query",
     *          description="开始时间戳",
     *          type="integer"
     *      ),
     *      @SWG\Parameter(
     *          name="end_date",
     *          in="query",
     *          description="结束时间戳",
     *          type="integer"
     *      ),
     *      @SWG\Parameter(
     *          name="invoice_status",
     *          in="query",
     *          description="筛选未开票状态的订单，传值为0",
     *          type="integer"
     *      ),
     *      @SWG\Parameter(
     *          name="invoice_order_id",
     *          in="query",
     *          description="开票订单号",
     *          type="string"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          ref="#/definitions/OrderList"
     *      )
     * )
     *
     * @throws \Exception
     */
    public function index()
    {
        $must     = [];
        $must_not = [];
        $should   = [];

        // 分页相关
        $from = input('_from', 0);
        $size = input('_size', 10);

        // 根据订单类型查询： 1 - 充值,2 - 消费
        $type = input('type', null);
        if ($type) {
            $must[] = [ 'term' => [ 'type' => $type ] ];
        }

        // 订单状态 [0,1,2]
        $status = input('status', null);
        if (isset($status)) {
            $must[] = [ 'term' => [ 'status' => $status ] ];
        }

        // 开始时间
        $start = input('start_date', null);
        if ($start) {
            $must[] = [ 'range' => [ 'create_time' => [ 'gte' => $start ] ] ];
        }

        // 结束时间
        $end = input('end_date', null);
        if ($end) {
            $must[] = [ 'range' => [ 'create_time' => [ 'lte' => $end ] ] ];
        }

        $invoice_order_id = input('invoice_order_id', null);
        if ($invoice_order_id) {
            $must_not[] = [ 'term' => [ '_id' => $invoice_order_id ] ];
        }

        $invoice_status = input('invoice_status', null);
        if (isset($invoice_status)) {
            $must_not[] = [ 'exists' => [ 'field' => 'invoice_status' ] ];
            $should[] = [ 'term' => [ 'invoice_status' => 0 ] ];
        }

        // 过滤未开票订单
        $must[] = [ 'term' => [ 'uid.keyword' => Auth::id() ] ];
        $filter = [
            'query' => [ 'bool' => [ 'must' => $must, 'must_not' => $must_not, 'should' => $should ] ],
            'sort'  => [ [ 'create_time' => [ 'order' => 'desc' ] ] ],
        ];

        $invoice_order    = [];
        if ($invoice_order_id) {
            $invoice_order = ( new \app\common\repository\OrderRepository() )->getInvoiceOrderDetail($invoice_order_id);
        }

        $orders = ( new \app\common\repository\OrderRepository() )->getOrderList($filter, $from, $size);
        $count  = ( new \app\common\repository\OrderRepository() )->count($filter);

        return Finalsuccess([ 'data' => $orders, 'total' => $count, 'invoice_order' => $invoice_order ]);
    }

    /**
     * @SWG\Post(
     *      path="/order",
     *      tags={"Order 订单管理"},
     *      summary="订单生成",
     *      @SWG\Parameter(
     *         name="充值订单",
     *         in="body",
     *         description="",
     *         required=true,
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"type":1,"fee":0.01,"detail":{"product_id":0}}
     *          )
     *      ),
     *      @SWG\Parameter(
     *         name="购买新实例订单",
     *         in="body",
     *         description="",
     *         required=true,
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"type": 2, "fee": 100, "detail": {"product_id":1, "product_sku_id":2, "product_name":
     *              "网站", "line": "联通",
     *              "base_bandwidth": 20, "bandwidth": 20, "normal_bandwidth": 20, "order_time":"1:month",
     *              "site_count": 50, "sp_num": 1}}
     *          )
     *      ),
     *      @SWG\Parameter(
     *         name="续费实例订单",
     *         in="body",
     *         description="",
     *         required=true,
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"type": 3, "fee": 100, "instance_id":"ddos-1xouch23s", "sp_time":12}
     *          )
     *      ),
     *      @SWG\Parameter(
     *         name="升级实例订单",
     *         in="body",
     *         description="",
     *         required=true,
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"type": 4, "fee": 100, "instance_id":"ddos-1xouch23s","detail":
     *              {"area":"山东","bandwidth":"20G","base_bandwidth":"10G","line":"联通","normal_bandwidth":"10M","product_id":1,"product_name":"网站共享","product_sku_id":6,"site_count":"1","sp_num":1,"sp_time":3}}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 创建成功| !=0 创建失败",
     *          @SWG\Property(
     *              property="12",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok", "data":{"id":"118041603473"}}
     *          )
     *      )
     * )
     * @param \app\client\validate\Order $validator
     *
     * @return string
     * @throws \Exception
     */
    public function create(OrderValidator $validator)
    {
        $data = input();
        // 检查订单参数
        if ( ! $validator->scene('create_order')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
        }

        // 充值订单
        if ($data['type'] == OrderModel::ORDER_TYPE_RECHARGE) {
            if ( ! $validator->scene('recharge_order')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }

            if ($data['detail']['product_id'] != 0) {
                return Finalfail(REP_CODE_PARAMS_INVALID, '商品ID错误！');
            }
        }

        //消费订单
        if ($data['type'] == OrderModel::ORDER_TYPE_PAID) {
            if (!$validator->scene('instance_order')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }

            if (in_array($data['detail']['product_id'] ?? -1, [ 1, 2 ])) { // 站点
                if ($data['detail']) {
                    if ( ! $validator->scene('site_paid_order')->check($data)) { // 根据Type检查订单参数
                        return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
                    }
                }
            }

            if ($data['detail']['product_id'] == 3) { //非站点
                if ($data['detail']) {
                    if ( ! $validator->scene('port_paid_order')->check($data)) { // 根据Type检查订单参数
                        return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
                    }
                }
            }

            // 检查商品是否下架
            if ( ! empty($data['detail']['product_id'])) {
                $product = ( new ProductModel() )->esGetById($data['detail']['product_id']);
                if (( ! $product || $product['on_sale'] == ProductModel::PRODUCT_OFF_SALE )) {
                    return Finalfail(REP_CODE_PRODUCT_OFF_SALE, '您所购买商品目前已下架');
                }
            }

            // 检查库存是否充足
            if (isset($data['detail']['product_sku_id']) && ! empty($data['detail']['product_sku_id'])) {
                $filter['query']['bool']['must'] = [ 'term' => [ 'price_id' => $data['detail']['product_sku_id'] ] ];
                $product_skus                    = ( new ProductSkuModel() )->esSearch($filter, 0, 1);
                $product_sku                     = [];
                if ($product_skus) {
                    $product_sku = $product_skus[0];
                }

                if ( ! $product_sku || ! isset($product_sku['stock']) || $product_sku['stock'] == 0 || $data['detail']['sp_num'] > $product_sku['stock']) {
                    return Finalfail(REP_CODE_PRODUCT_STOCK_NOT_ENOUGH, '您所购买商品目前库存不足无法下单');
                }
            }

        }

        // 续费、升级订单
        if ($data['type'] == OrderModel::ORDER_TYPE_RENEWAL || OrderModel::ORDER_TYPE_UPGRADE == $data['type']) {
            if ( ! $validator->scene('renew_order')->check($data)) { // 检查订单参数
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }
            $userOrder = $this->repository->getFreshestOrderByInstanceId($data['instance_id']);
            if ( ! $userOrder) {
                return Finalfail(REP_CODE_ABNORMAL_OPERATION, '订单不存在！');
            }

            $productSkuInfo = ( new \app\client\repository\ProductSkuRepository )->getProductSkuById($userOrder['product_sku_id']);
            if ( ! $productSkuInfo) {
                return Finalfail(REP_CODE_ABNORMAL_OPERATION, '该产品已不存在不能继续操作！');
            }

            if ((int) $data['type'] === OrderModel::ORDER_TYPE_RENEWAL) {
                $amount = ( new ServerRepository )->calcRenewServerPrice($data);
                if ( ! $amount) {
                    return Finalfail(REP_CODE_ABNORMAL_OPERATION, '价格计算错误！');
                }
                if ($amount != $data['fee']) {
                    return Finalfail(REP_CODE_ABNORMAL_OPERATION, '价格有误！');
                }
                // 费率
                foreach ($productSkuInfo['sp_time'] as $tmp) {
                    if ($data['sp_time'] >= $tmp['min'] && $data['sp_time'] <= $tmp['max']) {
                        $userOrder['sp_time_price'] = $tmp['price'];
                    }
                }
                $userOrder['sp_time'] = $data['sp_time'];
            } else {
                $amount = ( new ServerRepository )->calcRenewServerPrice($data, 'upgrade');
                if ( ! $amount) {
                    return Finalfail(REP_CODE_ABNORMAL_OPERATION, '价格计算错误！');
                }
                if ($amount != $data['fee']) {
                    return Finalfail(REP_CODE_ABNORMAL_OPERATION, '价格有误！');
                }
                $userInstanceModel = new \app\common\model\UserInstanceModel();
                $userInstance = $userInstanceModel->esGetById($data['instance_id']);
                //对比时间
                $userOrder['sp_time'] = $data['detail']['sp_time'] - $userInstance['sp_time'];
                if ($userOrder['sp_time'] < 0) {
                    $userOrder['sp_time'] = 0;
                }

                foreach ($userOrder['detail']['attributes'] as &$item) {
                    if ($item['name'] == 'base_bandwidth') {
                        $item['value'] = $data['detail']['base_bandwidth'];
                    }
                    if ($item['name'] == 'normal_bandwidth') {
                        $item['value'] = $data['detail']['normal_bandwidth'];
                    }
                    if ($item['name'] == 'bandwidth') {
                        $item['value'] = $data['detail']['bandwidth'];
                    }
                    if ($item['name'] == 'site_count') {
                        $item['value'] = $data['detail']['site_count'];
                    }
                    if ($item['name'] == 'sp_num') {
                        $item['value'] = $data['detail']['sp_num'];
                    }
                    if ($item['name'] == 'sp_time') {
                        $item['value'] = $userOrder['sp_time'];
                    }
                }
                unset($item);
            }

            //为下面创建订单来设置订单类型.
            $userOrder['type']                  = $data['type'] + 0;
            $userOrder['fee']                   = $amount;
            $orderInfo['detail']['instance_id'] = [ $data['instance_id'] ];
            $data                               = $userOrder;
        }
        // 执行创建订单逻辑
        $result = $this->repository->createOrder($data);
        if ( ! $result) {
            return Finalfail(REP_CODE_DB_ERROR, '订单创建失败！');
        }
        request()->bind('email', Auth::id());
        request()->bind('order_id', $result['order_id']);

        return Finalsuccess([ 'data' => $result ]);
    }

    /**
     * @SWG\Get(
     *      path="/order/{id}",
     *      tags={"Order 订单管理"},
     *      summary="获取订单详情",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="Order Id",
     *          type="integer",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"type":"消费","fee":100,"status":0,"uid":"test@veda.com","oid":"11807251626589",
     *              "create_time":"2018-07-25
     *              16:26:21","pay_time":null,"start_date":1532507181,"end_date":1535185581,"instance_id":{},
     *              "detail":{"product_id":1,"product_name":"网站共享","product_type":"实例","product_description":"网站防护专用实例","on_sale":1,
     *              "attributes":{
     *                  {"name":"area","label":"地区","type":"离散属性","description":"","value":"山东"},
     *                  {"name":"line","label":"线路","type":"离散属性","description":"","value":"联通"},
     *                  {"name":"base_bandwidth","label":"保底带宽","type":"离散计费属性","description":"","value":10},
     *                  {"name":"normal_bandwidth","label":"业务宽带","type":"离散计费属性","description":"","value":10},
     *                  {"name":"bandwidth","label":"弹性宽带","type":"用后计费属性","description":"","value":10},
     *                  {"name":"sp_num","label":"购买数量","type":"倍率计费属性","description":"","value":1},
     *                  {"name":"sp_time","label":"购买时长","type":"倍率计费属性","description":"","value":1}
     *              },"created_by":"admin@veda.com","create_time":"2018-07-21T07:09:55.000Z","product_sku_id":2}}}
     *          )
     *      )
     * )
     * 获取订单详情
     *
     * @param $id
     *
     * @return string
     * @throws \Exception
     */
    public function show($id)
    {
        $order = ( new \app\common\repository\OrderRepository() )->getOrderDetail($id);
        if ( ! $order) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该订单！');
        }

        return Finalsuccess([ 'data' => $order ]);
    }

    /**
     * @SWG\Delete(
     *      path="/order/{id}",
     *      tags={"Order 订单管理"},
     *      summary="订单作废",
     *      @SWG\Parameter(
     *          name="id",
     *          in="path",
     *          description="订单ID",
     *          type="integer",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 操作成功| !=0 操作失败",
     *          @SWG\Property(
     *              property="12",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     * @param $id
     *
     * @return string
     * @throws \Exception
     */
    public function destroy($id)
    {
        if ( ! $this->validator->scene('delete_order')->check(input())) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        $order = $this->repository->getOrderById($id);
        if ( ! $order) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '订单不存在！');
        }

        if (!in_array($order['status'], [OrderModel::ORDER_STATUS_CREATED])) {
            return Finalfail(REP_CODE_ILLEGAL_OPERATION, '订单状态异常！');
        }

        // 更新订单状态为已作废
        if ( ! $this->repository->deleteOrder($id)) {
            return Finalfail(REP_CODE_ES_ERROR, '删除失败！');
        }
        request()->bind('email', Auth::id());
        request()->bind('order_id', $id);

        return Finalsuccess();
    }
}
