<?php

namespace app\client\controller;

use app\client\repository\DDoSRepository;
use app\client\repository\OrderRepository;
use app\client\repository\PortRepository;
use app\client\repository\ProductSkuRepository;
use app\client\repository\SiteRepository;
use app\client\service\Auth;
use app\client\service\MockData;
use app\client\traits\CheckLogin;
use app\client\validate\DDoS as DDoSValidate;
use app\client\validate\Port as PortValidator;
use app\client\validate\Site as SiteValidator;
use app\common\model\UserInstanceModel;
use think\Request;

class DDoS extends BaseController
{
    use CheckLogin;

    public function __construct(Request $request)
    {
        parent::__construct();
    }

    protected $beforeActionList = [
        'checkLogin'
    ];

    /**
     * @SWG\Get(
     *      path="/ddos",
     *      tags={"DDoS 高防实例"},
     *      summary="获取用户的高防实例列表",
     *      @SWG\Parameter(name="line", in="query", description="实例线路", type="string"),
     *      @SWG\Parameter(name="ip", in="query", description="实例IP", type="string"),
     *      @SWG\Parameter(name="id", in="query", description="实例ID", type="string"),
     *      @SWG\Parameter(name="type", in="query", description="类型", type="string"),
     *      @SWG\Parameter(name="status",in="query", description="状态", type="string"),
     *      @SWG\Parameter(name="area", in="query", description="区域", type="integer"),
     *      @SWG\Parameter(name="_from", in="query", description="查询范围开始", type="integer"),
     *      @SWG\Parameter(name="_size", in="query", description="查询数量", type="integer"),
     *      @SWG\Response(response="200", description="", ref="#/definitions/DDoSList")
     * )
     *
     * 获取高防IP列表：
     *
     * @return array     $domainList 返回结果数组
     * @throws \Exception
     */
    public function index(DDoSRepository $repository)
    {
        $filter = [['term' => ['uid.keyword' => Auth::id()]]];

        $from   = input('_from', 0);
        $size   = input('_size', 5);

        // 根据线路搜索
        $line = input('line', null);
        if ($line) {
            $filter[] = ['term' => ['instance_line' => $line]];
        }

        // 根据IP搜
        $ip = input('ip', null);
        if ($ip) {
            $filter[] = ['regexp' => ['hd_ip.ip' => ".*$ip.*"]];
        }

        // 根据ID搜索
        $id = input('id', null);
        if ($id) {
            $filter[] = ['regexp' => ['instance_id.keyword' => ".*$id.*"]];
        }

        // 根据状态搜索 0未启用 1启用
        $status = input('status', null);
        if (isset($status)) {
            $filter[] = ['term' => ['status' => $status]];
        }
        // 根据地域搜索
        $area = input('area', null);
        if ($area) {
            //地域是单个还是多个
            if (1 == strlen($area)) {
                $relationAreas = $repository->getRelationAreaIds($area);
            } else {
                $relationAreas = [$area];
            }

            $filter[] = ['terms' => ['area' => $relationAreas]];
        }

        // 根据类型搜索
        $type = input('type', null);
        if ($type) {
            $types = explode(',', trim($type));
            ! empty($types) && $filter[] = ['terms' => ['type' => $types]];
        }

        // 获取用户的高防实例列表
        $filter = [
            'query' => [
                'bool' => [
                    'filter' => $filter
                ]
            ],
            'sort'  => [
                [
                    'last_update' => [
                        'order' => 'desc'
                    ]
                ]
            ]
        ];

        $list   = $repository->getDDoSList($filter, $from, $size);
        $total  = $repository->getListTotal($filter);

        return Finalsuccess(compact('list', 'total'));
    }

    /**
     * @SWG\Post(path="/ddos/{id}/active",tags={"DDoS 高防实例"},
     *      summary="启用用户实例",
     *      @SWG\Parameter(
     *         name="area",
     *         in="query",
     *         type="string",
     *         description="实例接入区域",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * @param $id
     * @return string
     * @throws \Exception
     */
    public function active(DDoSRepository $repository, DDoSValidate $validator, $id)
    {
        // 参数校验
        if (! $validator->scene('active_ddos')->check(input())) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
        }

        // 检查当前实例是否存在
        if (! $ddosInstance = $repository->getDDoSById($id)) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该实例！');
        }

        // 校验当前实例的状态是否为未激活
        if ($ddosInstance['status'] != UserInstanceModel::STATUS_CREATED) {
            return Finalfail(REP_CODE_ILLEGAL_OPERATION, '该实例状态异常！');
        }

        // 查询高防节点信息
        if (! $proxyNodeInfo = $repository->getAvailableProxyNodeInfo(
            $ddosInstance['instance_line'],
            $ddosInstance['type'],
            input('area')
        )) {
            return Finalfail(REP_CODE_ILLEGAL_OPERATION, '暂无可用高防节点');
        }

        // 更新当前高防节点信息接入信息
        if (! $repository->updateProxyNodeUserCount($proxyNodeInfo)) {
            return Finalfail(REP_CODE_ES_ERROR, '更新高防节点用户接入数失败！');
        }

        // 激活当前实例
        if (! $repository->ddosActive($id, $proxyNodeInfo)) {
            return Finalfail(REP_CODE_ILLEGAL_OPERATION, '实例启用失败！');
        }

        return Finalsuccess();
    }

    /**
     *
     * @SWG\Get(
     *      path="/ddos/{id}",
     *      tags={"DDoS 高防实例"},
     *      summary="获取用户实例详情",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="用户实例 Id",
     *          type="integer",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"uid":"test@veda.com","type":3,"status":0,"instance_line":"11",
     *     "normal_bandwidth":50,"bandwidth":20,"base_bandwidth":20,"start_date":1523331760,"end_date":1586490160,"area":"",
     *     "hd_ip":{},"port_count":50}}
     *          )
     *      )
     * )
     *
     * 获取实例详情
     *
     * @param $id
     * @return string
     * @throws \Exception
     */
    public function show(DDoSRepository $repository, DDoSValidate $validator, $id)
    {
        if (! $ddos = $repository->getDDoSById($id)) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该实例！');
        }

        return Finalsuccess($ddos);
    }

    /**
     *
     * @SWG\Get(path="/ddos/{id}/renew/info",tags={"DDoS 高防实例"},
     *      summary="获取用户实例详情，用于生成相同订单,默认为续费,当type=upgrade时为升级",
     *      @SWG\Parameter(name="id", in="path", description="用户实例 Id", type="string"),
     *      @SWG\Parameter(name="type", in="path", description="操作类型:默认为续费,upgrade为升级", type="string"),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","product_id": "1", "sku_id": "6","attributes":
     *              {{"name":"area","description":"","label":"地区","type":"离散属性","value":"山东"}}}
     *          )
     *      )
     * )
     *
     * 实例续费
     *
     * @param \app\client\repository\DDoSRepository $repository
     * @param \app\client\repository\ProductSkuRepository $productSkuRepository
     * @param $id
     * @return string
     * @throws \Exception
     */
    public function renewinfo(DDoSRepository $repository,ProductSkuRepository $productSkuRepository, $id)
    {
        if (! $ddos = $repository->getDDoSById($id)) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该实例！');
        }
        //检查是否可以继续续费
        if (0 == $repository->getNearEndTime($ddos, true)) {
            return Finalfail(REP_CODE_ILLEGAL_OPERATION, '当前实例暂时无法续费或升级！');
        }

        $data = (new OrderRepository)->getFreshestOrderByInstanceId($id);
        if (! $data) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该实例订单！');
        }

        $productSkuInfo = $productSkuRepository->getProductSkuById($data['product_sku_id']);
        if (! $productSkuInfo) {
            return Finalfail(REP_CODE_ABNORMAL_OPERATION, '该产品不可续费！');
        }

        $info = [
            'product_id' => $data['product_id'],
            'sku_id'     => $data['product_sku_id'],
        ];
        //判断是升级还是续费
        $type = input('type');
        if (empty($type) || $type === 'renew') {
            $info['type'] = 'renew';
            $info['type_attr'] = '立即续费';
            $info['attributes'] = $data['detail']['attributes'];
        } else if ($type === 'upgrade') {
            $info['type'] = 'upgrade';
            $info['type_attr'] = '立即升级';
            $info['attributes'] = $data['detail']['attributes'];
            //重新赋值
            foreach ($info['attributes'] as $key => &$attribute) {
                if ($attribute['name'] == 'base_bandwidth') {
                    $attribute['value'] = $ddos['base_bandwidth'];
                }
                if ($attribute['name'] == 'normal_bandwidth') {
                    $attribute['value'] = $ddos['normal_bandwidth'];
                }
                if ($attribute['name'] == 'sp_num') {
                    $attribute['value'] = $ddos['sp_num'];
                }
                if ($attribute['name'] == 'sp_time') {
                    $attribute['value'] = $ddos['sp_time'];
                }
                if ($attribute['name'] == 'bandwidth') {
                    $attribute['value'] = $ddos['bandwidth'];
                }
                if ($attribute['name'] == 'site_count') {
                    $attribute['value'] = $ddos['site_count'];
                }
            }
        } else {
            return Finalfail(REP_CODE_PARAMS_INVALID, '非法操作！');
        }

        return Finalsuccess($info);
    }

    /**
     *
     * @SWG\Get(path="/ddos/ips",tags={"DDoS 高防实例"},
     *      summary="获取用户实例高防IP",
     *      @SWG\Parameter(name="_from",in="query",type="integer",
     *          description="查询范围开始"
     *      ),
     *      @SWG\Parameter(name="_size",in="query",type="integer",
     *          description="查询数量"
     *      ),
     *      @SWG\Parameter(name="line",in="query",type="string",
     *          description="接入线路"
     *      ),
     *      @SWG\Parameter(name="type",in="query",type="string",
     *          description="实例类型"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","list":{{"type":"3","area":11,"area_text":"北京","ddos_id":"ddos-l9umrps",
     *     "ips":{{"line":"1","ip":"192.168.9.20","port_count":2,"line_text":"电信"},{"line":"2","ip":"192.168.9.22",
     *     "port_count":2,"line_text":"联通"},{"line":"8","ip":"192.168.9.55","port_count":2,"line_text":"BGP"}}}},"total":1}
     *          )
     *      )
     * )
     *
     * @param DDoSRepository $repository
     *
     * @return string
     * @throws \Exception
     */
    public function ips(DDoSRepository $repository)
    {
        $from = input('_from', 0);
        $size = input('_size', null);

        $line = input('line', null);
        $type = input('type', null);

        $ips = $repository->getUserDDoSIps($line, $type, $from, $size);

        return Finalsuccess($ips);
    }

    /**
     * @SWG\Get(
     *      path="/ddos/areas",
     *      tags={"DDoS 高防实例"},
     *      summary="获取地域列表",
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          ref="#/definitions/AreaList"
     *      )
     * )
     *
     * 获取所有
     *
     * @return string
     * @throws \app\common\exception\client\MockDataModuleNotFound
     */
    public function areas()
    {
        // 获取所有的实例基础数据
        $data = MockData::value('AreaList');

        return Finalsuccess(['list' => $data]);
    }

    /**
     * @SWG\Get(
     *      path="/ddos/{id}/available-areas",
     *      tags={"DDoS 高防实例"},
     *      summary="用户实例可接入地域",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="用户实例Id",
     *          type="integer",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","areas":{{"value":1,"label":"华北","children":{{"value":11,
     *     "label":"北京"}}},{"value":3,"label":"华东","children":{{"value":37,"label":"山东"}}}}}
     *          )
     *      )
     * )
     * 用户实例可接入地域
     *
     * @param $id
     * @return string
     * @throws \Exception
     */
    public function availableAreas(DDoSRepository $repository, $id)
    {
        if (! $instance = $repository->getDDoSById($id)) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该实例！');
        }
        $areas = $repository->getAvailableArea($instance['instance_line'], $instance['type'], $instance['site_count'] ?? 0);

        return Finalsuccess(['areas' => $areas]);
    }

    /**
     * @SWG\Get(
     *      path="/ddos/{id}/proxy-ips",
     *      tags={"DDoS 高防实例"},
     *      summary="获取高防实例高防节点列表",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="站点ID",
     *          type="string"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","proxyIps":{{"area":33,"line":"8","ip":"192.16.19.1","ddos_id":"ddos-dknajde",
     *     "area_text":"浙江","line_text":"BGP"}}}
     *          )
     *      )
     * )
     *
     * @param $id
     * @param DDoSRepository $repository
     * @return string
     */
    public function proxyIps($id, DDoSRepository $repository)
    {
        try {
            if (! $ddos = $repository->getDDoSById($id)) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该实例！');
            }
            $hdIps = $ddos['hd_ip'] ?? [];
            foreach ($hdIps as &$hdIp) {
                $hdIp['ddos_id']   = $id;
                $hdIp['area_text'] = UserInstanceModel::$instanceAreas[$ddos['area']];
                $hdIp['line_text'] = UserInstanceModel::$instanceLines[$hdIp['line']];

                unset($hdIp['site_count']);
            }

            return Finalsuccess(compact('hdIps'));
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_FAILED_OPERATION, '获取高防实例IP失败！');
        }
    }

    /**
     * @SWG\Delete(
     *      path="/ddos/bundle/delete",
     *      tags={"DDoS 高防实例"},
     *      summary="高防实例批量删除",
     *      @SWG\Parameter(
     *          name="",
     *          in="body",
     *          description="高防实例ID数组",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"ids": {"ddos-o31tixf", "ddos-tzfq4ix"}}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 删除成功| !=0 删除失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     * 高防实例批量删除
     *
     * @param DDoSValidate $validator
     * @param DDoSRepository $repository
     *
     * @return string
     */
    public function bundleDelete(DDoSValidate $validator, DDoSRepository $repository)
    {
        request()->bind('email', Auth::id());
        try {
            $data = input();
            if (! $validator->scene('bundle_delete')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }

            foreach ($data['ids'] as $id) {
                // 依次移除对应应用的ES和ZK配置
                $result = ($this->destroy($id, $validator, $repository))->getData();
                if ($result['errcode'] != 0) {
                    return Finalfail($result['errcode'], $result['errmsg']);
                }
            }

            return Finalsuccess();
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_DB_ERROR, '高防实例删除失败！');
        }
    }

    /**
     * @SWG\Delete(
     *      path="/ddos/{id}",
     *      tags={"DDoS 高防实例"},
     *      summary="用户删除高防实例",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="DDoS Id",
     *          type="integer",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 删除成功| !=0 删除失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * 用户删除高防实例
     *
     * @param                $id
     * @param DDoSValidate   $validator
     * @param DDoSRepository $repository
     *
     * @return string    json     返回结果
     */
    public function destroy($id, DDoSValidate $validator, DDoSRepository $repository)
    {
        try {
            if ($validator->scene('del_port')->check(input())) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }

            $ddos = $repository->getDDoSById($id);
            // 检查高仿实例是否存在
            if (! $ddos) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该实例！');
            }

            // 删除对应的网站防护
            $this->deleteSite($id);

            // 删除对应的应用防护
            $this->deletePort($id);

            $delResult = $repository->delDDoSById($id);
            if (! $delResult) {
                $repository->updateDDoS(['status' => UserInstanceModel::DDOS_STATUS_DELETE_ERR], $id);

                return Finalfail(REP_CODE_DB_ERROR, '高防实例删除失败！');
            }

            return Finalsuccess();
        } catch (\Exception $e) {
            $this->errorHandle($e);

            return Finalfail(REP_CODE_DB_ERROR, '高防实例删除失败！');
        }
    }

    /**
     * 删除高仿实例对应的网站防护
     *
     * @param $id
     *
     * @return string
     * @throws \app\common\exception\client\ElasticSearchException
     */
    private function deleteSite($id)
    {
        $sites = (new SiteRepository())->getSiteByDDosId($id);

        if ($sites && ! (new SiteRepository())->rmSiteList($sites, new SiteValidator())) {
            return Finalfail(REP_CODE_DDOS_DELETE_SITE_FAIL, '删除站点失败！');
        }

        return Finalsuccess();
    }

    /**
     * 删除高仿实例对应的应用防护
     *
     * @param $id
     *
     * @return string
     * @throws \app\common\exception\client\ElasticSearchException
     */
    private function deletePort($id)
    {
        $ports = (new PortRepository())->getPortByDDosId($id);

        if ($ports && ! (new PortRepository())->rmPortList($ports, new PortValidator())) {
            return Finalfail(REP_CODE_DDOS_DELETE_PORT_FAIL, '删除应用失败！');
        }

        return Finalsuccess();
    }
}
