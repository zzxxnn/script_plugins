<?php

namespace app\client\controller\user;

use app\common\repository\UserRepository;
use app\client\service\Auth as AuthService;
use app\common\service\MailService;
use app\client\traits\CheckLogin;
use think\Cache;
use think\Controller;
use think\Loader;
use think\Request;

class Password extends Controller
{
    use CheckLogin;

    protected $validate;

    protected $repository;

    public function __construct(Request $request)
    {
        $this->validate   = Loader::validate('User');
        $this->repository = new UserRepository();

        parent::__construct($request);
    }

    /**
     * @SWG\Post(
     *      path="/password/send",
     *      tags={"user 用户管理"},
     *      summary="【发送】修改密码的链接并发送邮件",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="email", type="string", example="test@veda.com"),
     *              @SWG\Property(property="captcha", type="string", example="9716")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @throws \PHPMailer\PHPMailer\Exception
     */
    public function send()
    {
        if (! $this->validate->scene('password_send')->check(input())) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validate->getError());
        }
        $email   = input('post.email');
        $captcha = input('post.captcha');
        if (! captcha_check($captcha)) {
            return Finalfail(REP_CODE_CAPTCHA_INVALID, '验证码错误');
        }

        $data = $this->repository->find(['email' => $email]);
        if (empty($data)) {
            return Finalfail(REP_CODE_EMAIL_NOT_REGISTER, '该邮箱未注册');
        }


        $safe_email = $data['email_verify_status'] === 1 ? $data['safe_email'] : $email; //安全邮箱
        if (Cache::get('forget_pwd_'.$safe_email) !== false) {
            return Finalfail(REP_CODE_EMAIL_SEND_TOO_FREQUENTLY, '五分钟内只能发送一封邮件');
        }

        $token  = hash('md5', $email.rand_char(10));
        $result = MailService::send($safe_email, $token, 'forget');
        if (! $result) {
            return Finalfail(REP_CODE_EMAIL_SEND_FAIL, '邮件发送失败');
        }

        Cache::set('forget_pwd_'.$safe_email, time(), 300);
        Cache::set($token, $email);

        return Finalsuccess($safe_email);
    }

    /**
     * @SWG\Put(
     *      path="/password",
     *      tags={"user 用户管理"},
     *      summary="【修改】修改密码",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="通过token修改密码：email，token，new_old；通过登陆修改：old_pwd，new_pwd",
     *          @SWG\Schema(
     *              @SWG\Property(property="email", type="string", example="test@veda.com"),
     *              @SWG\Property(property="token", type="string", example="fa4e51f56d5bba4404f96ea95b1943db"),
     *              @SWG\Property(property="old_pwd", type="string", example="veda2017"),
     *              @SWG\Property(property="new_pwd", type="string", example="veda2018"),
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     */
    public function update()
    {
        if (! empty(input('put.email')) && ! empty(input('put.token')) && ! empty(input('put.new_pwd'))) {

            if (! $this->validate->scene('password_token_update')->check(input())) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $this->validate->getError());
            }
            $email   = input('put.email');
            $token   = input('put.token');
            $new_pwd = input('put.new_pwd');

            if (!config('app_debug')) {  // Debug模式下不校验重置密码的Token
                if (! Cache::get($token) || (Cache::get($token) !== $email)) {
                    return Finalfail(REP_CODE_LINK_TIME_OUT, "链接超时");
                }
                Cache::rm($token);
            }
        } elseif (! empty(input('put.old_pwd')) && ! empty(input('put.new_pwd'))) {

            $this->checkLogin();

            if (! $this->validate->scene('password_update')->check(input())) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $this->validate->getError());
            }
            $email     = AuthService::id();
            $old_pwd   = input('put.old_pwd');
            $new_pwd   = input('put.new_pwd');
            $user_info = $this->repository->find(['email' => $email]);
            if (! password_verify($old_pwd, $user_info['password'])) {
                return Finalfail(REP_CODE_PASSWORD_ERROR, "密码错误");
            }
        } else {
            return Finalfail(REP_CODE_ILLEGAL_OPERATION, "密码重置失败！");
        }

        request()->bind('email', AuthService::id());
        $result = $this->repository->editData(['password' => password_hash($new_pwd, PASSWORD_DEFAULT)], $email);
        if ($result) {
            return Finalsuccess();
        }
        return Finalfail(REP_CODE_DB_ERROR, "数据库操作失败");
    }
}
