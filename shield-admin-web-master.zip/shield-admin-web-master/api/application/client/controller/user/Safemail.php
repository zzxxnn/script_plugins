<?php

namespace app\client\controller\user;

use app\client\service\Auth;
use app\common\service\MailService;
use app\client\traits\CheckLogin;
use app\common\model\UserModel;
use app\common\repository\UserRepository;
use think\Cache;
use think\Controller;
use think\Loader;

class Safemail extends Controller
{
    use CheckLogin;

    protected $validate;

    protected $repository;

    public function _initialize()
    {
        $this->validate   = Loader::validate('User');
        $this->repository = new UserRepository();
    }

    protected $beforeActionList = [
        'checkLogin',
    ];

    /**
     * @SWG\Post(
     *      path="/safemail/send",
     *      tags={"user 用户管理"},
     *      summary="【发送】邮件验证码用于修改安全邮箱",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="【注】前端按钮限制一分钟获取一次验证码",
     *          @SWG\Schema(
     *              @SWG\Property(property="safemail", type="string", example="test@veda.com")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @throws \PHPMailer\PHPMailer\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function send()
    {
        if (! $this->validate->scene('safemail_send')->check(input())) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validate->getError());
        }
        $safeEmail = input('post.safemail');
        request()->bind('email', Auth::id());

        $result = UserModel::where(['safe_email' => $safeEmail, 'email_verify_status' => UserModel::SAFE_EMAIL_STATUS_VERIFIED])->find();
        if ($result) {
            return Finalfail(REP_CODE_EMAIL_IS_SAFE, '该邮箱已设置为安全邮箱');
        }

        if (Cache::get('reset_safemail_'.$safeEmail) !== false) {
            return Finalfail(REP_CODE_EMAIL_GET_AFTER_ONE_MINUTE, '请在一分钟后重新获取');
        }

        do {
            $token = rand_char(6);
        } while (Cache::get($token) !== false);

        $result = MailService::send($safeEmail, $token, 'safemail');
        if (! $result) {
            return Finalfail(REP_CODE_EMAIL_SEND_FAIL, '邮件发送失败');
        }

        Cache::set('reset_safemail_'.$safeEmail, time(), 60);
        Cache::set($token, $safeEmail);
        return Finalsuccess();
    }

    /**
     * @SWG\Put(
     *      path="/safemail",
     *      tags={"user 用户管理"},
     *      summary="【修改】安全邮箱",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="safemail", type="string", example="test@veda.com"),
     *              @SWG\Property(property="token", type="string", example="251014")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     */
    public function update()
    {
        if (! $this->validate->scene('safemail_update')->check(input())) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validate->getError());
        }
        $safemail = input('put.safemail');
        $token    = input('put.token');
        request()->bind('email', Auth::id());
        if (! Cache::get($token) || (Cache::get($token) !== $safemail)) {
            return Finalfail(REP_CODE_CAPTCHA_INVALID, '验证码错误');
        }
        Cache::rm($token);
        //mysql
        $data = ['safe_email' => $safemail, 'email_verify_status' => 1];
        if ($this->repository->editData($data)) {
            return Finalsuccess();
        }
        return Finalfail(REP_CODE_DB_ERROR, "数据库操作失败");
    }
}
