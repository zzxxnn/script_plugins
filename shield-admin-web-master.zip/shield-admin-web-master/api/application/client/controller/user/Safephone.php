<?php

namespace app\client\controller\user;

use app\client\service\Auth;
use app\common\service\NotifierService as Notifier;
use app\client\traits\CheckLogin;
use app\common\model\UserModel;
use app\common\repository\UserRepository;
use think\Cache;
use think\Controller;
use think\Loader;

class Safephone extends Controller
{
    use CheckLogin;

    protected $validate;

    protected $repository;

    public function _initialize()
    {
        $this->validate   = Loader::validate('User');
        $this->repository = new UserRepository();
    }

    protected $beforeActionList = [
        'checkLogin',
    ];

    /**
     * @SWG\Post(
     *      path="/safephone/send",
     *      tags={"user 用户管理"},
     *      summary="【发送】短信验证码用于修改安全手机",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="【注】前端按钮限制一分钟获取一次验证码",
     *          @SWG\Schema(
     *              @SWG\Property(property="safephone", type="string", example="157********")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     */
    public function send()
    {
        if (! $this->validate->scene('safephone_send')->check(input())) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validate->getError());
        }
        $safephone = input('post.safephone');
        request()->bind('email', Auth::id());

        $result = UserModel::where(['mobile' => $safephone, 'mobile_verify_status' => UserModel::SAFE_PHONE_STATUS_VERIFIED])->find();
        if ($result) {
            return Finalfail(REP_CODE_MOBILE_IS_SAFE, '该手机号已设置为安全手机');
        }

        // 同一个号码，同一个IP，一分钟只能发一次
        $ip           = request()->ip;
        $limitTimeKey = $ip.'_'.$safephone;
        if (Cache::get($limitTimeKey)) {
            return Finalfail(REP_CODE_MOBILE_SEND_TOO_FREQUENTLY, '验证码发送过于频繁，请稍后重试！');
        }

        $code   = rand_number(6);
        $expire = config('sms_expire');
        // 发送短信校验码
        $sendResult = Notifier::sendSms($safephone, compact('code', 'expire'), Notifier::SMS_USER_REGISTER);
        if (! $sendResult) {
            return Finalfail(REP_CODE_MOBILE_SEND_FAIL, '验证码发送失败！');
        }

        Cache::set($limitTimeKey, $code, 60);
        Cache::set($code, $safephone, $expire * 60);

        return Finalsuccess(['token' => $code]);
    }

    /**
     * @SWG\Put(
     *      path="/safephone",
     *      tags={"user 用户管理"},
     *      summary="【修改】安全手机",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="safephone", type="string", example="157********"),
     *              @SWG\Property(property="token", type="string", example="251014")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     */
    public function update()
    {
        if (! $this->validate->scene('safephone_update')->check(input())) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validate->getError());
        }
        $safePhone = input('put.safephone');
        $token     = input('put.token');
        request()->bind('email', Auth::id());
        if (! Cache::get($token) || (Cache::get($token) !== $safePhone)) {
            return Finalfail(REP_CODE_CAPTCHA_INVALID, '验证码错误');
        }
        Cache::rm($token);

        $data = ['mobile' => $safePhone, 'mobile_verify_status' => 1];

        if ($this->repository->editData($data)) {
            return Finalsuccess();
        }
        return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败');
    }
}
