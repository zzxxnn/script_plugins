<?php

namespace app\client\controller\user;

use app\client\service\Auth;
use app\client\traits\CheckLogin;
use app\common\repository\UserRepository;
use think\Controller;

/**
 * Class Avatar 用户头像
 *
 * @package app\client\controller\user
 * @author Teddy Sun <sgsheg@163.com>
 */
class Avatar extends Controller
{
    use CheckLogin;

    /**
     * @SWG\Post(
     *      path="/user/avatar",
     *      tags={"user 用户管理"},
     *      summary="用户头像上传",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="file", type="string", example="user.png"),
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 上传成功 !=0 ",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0, "errmsg":"上传成功","data":{"img_url":"upload/abc.jpg"}}
     *          )
     *     )
     * )
     *
     * 用户头像上传
     *
     * @param UserRepository $repository
     *
     * @return \think\Response
     */
    public function save(UserRepository $repository)
    {
        if ($this->request->isPost()) {
            $avatar = ajax_upload_avatar('/avatar');
            //生成缩略图
            $avatarThumb = crop_image($avatar);
            $data        = ['avatar' => $avatarThumb];

            if ($repository->editData($data)) {
                request()->bind('email', Auth::id());
                return Finalsuccess(['img_url' => $repository->getAvatar()]);
            }
            return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败！');
        }
        return Finalfail(REP_CODE_ILLEGAL_OPERATION, '非法操作！');
    }

    /**
     * @SWG\Put(
     *      path="/user/avatar",
     *      tags={"user 用户管理"},
     *      summary="用户头像更新",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="avatar", type="string", example="static/img/support-user0.png"),
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 更新成功 !=0 ",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0, "errmsg":"更新成功","data":{"img_url":"static/img/support-user0.png"}}
     *          )
     *     )
     * )
     *
     * 用户头像更新
     *
     * @param \app\common\repository\UserRepository $repository
     * @return \think\Response
     */
    public function update(UserRepository $repository)
    {
        //找到用户头像
        if ($this->request->isPut()) {
            $path = $this->request->put('avatar', 'avatar/support-user0.png');
            $data = ['avatar' => $path,];

            if ($repository->editData($data)) {
                request()->bind('email', Auth::id());
                return Finalsuccess(['img_url' => $path]);
            }
            return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败！');
        }

        return Finalfail(REP_CODE_ILLEGAL_OPERATION, '非法操作');
    }
}