<?php

namespace app\client\controller\user;

use app\client\service\Auth as AuthService;
use app\client\traits\CheckLogin;
use app\common\model\UserModel;
use app\common\repository\UserRepository;
use think\Controller;
use think\Exception;
use think\Loader;

class Users extends Controller
{

    use CheckLogin;

    protected $validate;

    protected $repository;

    public function _initialize()
    {
        $this->validate   = Loader::validate('User');
        $this->repository = new UserRepository();
    }

    protected $beforeActionList = [
        'checkLogin' => [ 'only' => 'profile' ],
    ];

    /**
     * @SWG\Get(
     *      path="/users/profile",
     *      tags={"user 用户管理"},
     *      summary="【获取】用户资料",
     *      @SWG\Response(response="200", ref="#/definitions/Userinfo")
     * )
     */
    public function profile()
    {
        $user = UserModel::where('email', AuthService::id())->find();
        if ($user) {
            return Finalsuccess($user);
        }

        return Finalfail(REP_CODE_PARAMS_INVALID, '未找到该用户');
    }

    /**
     * @SWG\Post(
     *      path="/users",
     *      tags={"user 用户管理"},
     *      summary="【注册】新用户",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="注册用户信息：",
     *          @SWG\Schema(
     *              @SWG\Property(property="email", type="string", example="test@veda.com"),
     *              @SWG\Property(property="password", type="string", example="veda2017"),
     *              @SWG\Property(property="captcha", type="string", example="9716"),
     *              @SWG\Property(property="mobile", type="string", example="13888888888")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     */
    public function create()
    {
        return $this->createUser();
    }

    /**
     * @SWG\Post(
     *      path="/users/h00bom",
     *      tags={"user 用户管理"},
     *      summary="【注册】通过代理商注册链接注册新用户",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="注册用户信息：",
     *          @SWG\Schema(
     *              @SWG\Property(property="email", type="string", example="test@veda.com"),
     *              @SWG\Property(property="password", type="string", example="veda2017"),
     *              @SWG\Property(property="captcha", type="string", example="9716"),
     *              @SWG\Property(property="mobile", type="string", example="13888888888")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     * @param $code
     *
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function createByAgentCode($code)
    {
        return $this->createUser($code);
    }

    /**
     * 创建用户
     *
     * @param null $code
     *
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    private function createUser($code = null)
    {
        if ( ! $this->validate->scene('register')->check(input())) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validate->getError());
        }
        if ( ! is_phpunit_testing() && ! captcha_check(input('post.captcha'))) {
            return Finalfail(REP_CODE_CAPTCHA_INVALID, '验证码错误');
        }

        $result = $this->repository->findExist([ 'email' => input('post.email') ]);
        if ( ! $result) {
            return Finalfail(REP_CODE_EMAIL_REGISTER, '该邮箱已注册');
        }

        $user_info = [
            'email'       => input('post.email'),
            'password'    => password_hash(input('post.password'), PASSWORD_DEFAULT),
            'mobile'      => ! input('post.mobile') ? '' : input('post.mobile'),
            'avatar'      => 'avatar/support-user0.png',
            'create_time' => date('Y-m-d H:i:s'),
        ];
        if ($code) {
            // 通过代理商注册客户链接进行注册
            $agent = ( new \app\common\model\AgentModel() )->where('user_invite_code', $code)->find();
            if ($agent) {
                $user_info['agent_id'] = $agent->id;
            } else {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '该代理商不存在');
            }
        }

        $result = ( new UserRepository() )->insertData($user_info);
        if ($result) {
            return Finalsuccess();
        }

        return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败');
    }
}
