<?php

namespace app\client\controller\user;

use app\client\service\Auth;
use app\client\traits\CheckLogin;
use app\common\repository\UserRepository;
use think\Controller;
use think\Loader;

class Realname extends Controller
{
    use CheckLogin;

    protected $validate;

    protected $repository;

    public function _initialize()
    {
        $this->validate   = Loader::validate('User');
        $this->repository = new UserRepository();
    }

    protected $beforeActionList = [
        'checkLogin',
    ];

    /**
     * @SWG\Put(
     *      path="/realname",
     *      tags={"user 用户管理"},
     *      summary="【更新】实名验证",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="real_name", type="string", example="土豪"),
     *              @SWG\Property(property="id_number", type="string", example="410527************"),
     *              @SWG\Property(property="captcha", type="string", example="25101")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     */
    public function update()
    {
        if (! $this->validate->scene('realname')->check(input())) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validate->getError());
        }
        $real_name = input('put.real_name');
        $id_number = input('put.id_number');
        if (! captcha_check(input('put.captcha'))) {
            return Finalfail(REP_CODE_CAPTCHA_INVALID, '验证码错误');
        }
        //mysql
        $data = ['real_name' => $real_name, 'id_number' => $id_number, 'id_verify_status' => 1];
        if ($this->repository->editData($data)) {
            request()->bind('email', Auth::id());
            return Finalsuccess($data);
        }
        return Finalfail(REP_CODE_DB_ERROR, "数据库操作失败");
    }
}
