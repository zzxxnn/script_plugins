<?php
namespace app\client\controller;

use think\Cache;
use think\Controller;

class Index extends Controller
{
    public function index()
    {
        if (IsClientLogin() === 0) {
            return view('login');
        }
        return view('index');
    }

    public function login()
    {
        return view('login');
    }

    /**
     * 注册: [包含普通注册和邀请码注册]
     * @param null $code
     * @return \think\response\View
     */
    public function register($code = null)
    {
        return view('register', ['code' => $code]);
    }

    public function password_find()
    {
        return view('password_find');
    }

    public function password_reset($token)
    {
        if (!Cache::get($token)) {
            return view('password_reset_expired');
        }

        $this->assign([
            'email' => Cache::get($token),
            'token' => $token
        ]);
        return $this->fetch('password_reset');
    }
}
