<?php

namespace app\index\traits;

trait CheckNodeConf
{
    /**
     * 校验DNS或高防节点网段IP个数与线路
     *
     * @param String $conf
     * @return Boolean 
     */
    function checkNodeConf($conf)
    {
        $line_type = $conf["line_type"];
        $node_list = $conf["node_ip"];
        
        switch ($line_type) {
            case 0:
            case 1:
            case 2:
            case 4:
            case 8:
                $line_arr = [$line_type];
                if (count($node_list) !== 1) {
                    return false;
                }
            break;
            case 3:
                $line_arr = [1,2];
                if (count($node_list) !== 2) {
                    return false;
                }
            break;
            case 7:
                $line_arr = [1,2,4];
                if (count($node_list) !== 3) {
                    return false;
                }
            break;
            case 11:
                $line_arr = [1,2,8];
                if (count($node_list) !== 3) {
                    return false;
                }
            break;
            default:
                return false;
            break;
        }

        $ip_range_arr = [];
        foreach ($node_list as $node) {
            if(!(isset($node['line']) && isset($node['ip']))){
                return false;
            }
            $line_arr = array_diff($line_arr, [$node['line']]);
            $ip_range_arr[] = $node['ip'];
        }
        if (!empty($line_arr)) {
            return false;
        }

        if(count($ip_range_arr) > 1){ // 验证ip段个数
            $ip_range_count_arr = array_map(function ($ip_range) {
                return $this->countIp($ip_range);
            }, $ip_range_arr);

            $unique_arr = array_unique($ip_range_count_arr);
            if(count($unique_arr) !== 1){
                return false;
            }
            if($unique_arr[0] > 256){
                return false;
            }
        }
        return true;
    }
}
