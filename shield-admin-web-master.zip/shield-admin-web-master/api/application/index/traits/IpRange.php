<?php

namespace app\index\traits;

trait IpRange
{
    /**
     * 解析IP段、IP/掩码、IP为数组返回
     *
     * @param string $ip
     * @return array $ip_arr
     */
    function parseIp($ip)
    {
        if ($this->checkIpMask($ip)) {
            $ip_arr = $this->parseIpMask($ip);
        } elseif ($this->checkIpRange($ip)) {
            $ip_arr = $this->parseIpRange($ip);
        } else {
            $ip_arr[] = $ip;
        }
        return $ip_arr;
    }

    /**
     * 解析IP段、IP/掩码、IP个数
     *
     * @param String $ip
     * @return array $ip_arr
     */
    function countIp($ip)
    {
        if ($this->checkIpMask($ip)) {
            $count = $this->countIpMask($ip);
        } elseif ($this->checkIpRange($ip)) {
            $count = $this->countIpRange($ip);
        } else {
            $count = 1;
        }
        return $count;
    }
    
    // 验证IP范围
    function checkIpRange($ip)
    {
        $ip_arr = explode('-', $ip);
        return count($ip_arr)==2 && ip2long($ip_arr[0]) && ip2long($ip_arr[1]) ;
    }

    // 验证IP/MASK
    function checkIpMask($ip)
    {
        $ip_mask = explode('/', $ip);
        return count($ip_mask)==2 && ip2long($ip_mask[0]) && is_numeric($ip_mask[1]) && is_int((int)$ip_mask[1]) && $ip_mask[1] >= 1 && $ip_mask[1] <= 32;
    }

    // 统计IP范围包含IP个数
    function countIpRange($ip)
    {
        $ip_arr = explode('-', $ip);
        if (ip2long($ip_arr[1]) > ip2long($ip_arr[0])) {
            return ip2long($ip_arr[1]) - ip2long($ip_arr[0]) + 1;
        } else {
            return ip2long($ip_arr[0]) - ip2long($ip_arr[1]) + 1;
        }
    }

    // 统计IP/MASK包含IP个数
    function countIpMask($ip)
    {
        $ip_mask = explode('/', $ip_mask);
        $ip = $ip_mask[0];
        $mask = $ip_mask[1];
        $pro_ip_arr = [];

        if (!is_numeric($mask)) {
            return 1;
        }
    
        return pow(2, (32-$mask)) - 1;
    }

    /**
     * 解析ip范围 192.168.2.5-192.168.3.5
     * @param  string    $ip_range  192.168.2.5-192.168.3.5
     * @return array     ip
     */
    function parseIpRange(String $ip_range)
    {
        $ip_arr = explode('-', $ip_range);

        if (ip2long($ip_arr[1]) > ip2long($ip_arr[0])) {
            $ip_start = $ip_arr[0];
            $ip_end = $ip_arr[1];
        } else {
            $ip_start = $ip_arr[1];
            $ip_end = $ip_arr[0];
        }
    
        $pro_ip_arr = [];
        $tmp_ip_long = ip2long($ip_start);
    
        while ($tmp_ip_long <= ip2long($ip_end)) {
            if (!(($tmp_ip_long & 255) == 0 || ($tmp_ip_long & 255) == 255)) {
                $pro_ip_arr[] = long2ip($tmp_ip_long);
            }
            $tmp_ip_long ++ ;
        }

        return $pro_ip_arr;
    }

    /**
     * 解析ip/mask 192.168.2.5/24
     * @param  string    $ip_mask  ip/mask 192.168.2.5/24
     * @return array     ip
     */
    function parseIpMask(String $ip_mask)
    {
        $ip_mask = explode('/', $ip_mask);
        $ip = $ip_mask[0];
        $mask = $ip_mask[1];
        $pro_ip_arr = [];

        if (!is_numeric($mask)) {
            return $pro_ip_arr;
        }
    
        $a = pow(2, (32-$mask)) - 1;
        $start_ip_long = ~(ip2long($ip) & $a) & ip2long($ip);
        $end_ip_long = $start_ip_long + $a;
    
        $tmp_ip_long = $start_ip_long;
        while ($tmp_ip_long <= $end_ip_long) {
            if (!(($tmp_ip_long & 255) == 0 || ($tmp_ip_long & 255) == 255)) {
                $pro_ip_arr[] = long2ip($tmp_ip_long);
            }
            $tmp_ip_long ++ ;
        }
    
        return $pro_ip_arr;
    }
}
