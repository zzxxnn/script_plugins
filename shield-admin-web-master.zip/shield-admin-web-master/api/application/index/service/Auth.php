<?php

namespace app\index\service;

/**
 * 管理员登录及处理类
 * Class Auth
 * @package app\index\service
 */
class Auth
{
    const USER_INFO_SESSION_KEY = 'user_auth';
    const USER_SIGN_SESSION_KEY = 'user_auth_sign';

    /**
     * 返回当前登录用户的信息
     * @return array|null
     */
    public static function info()
    {
        return session(self::USER_INFO_SESSION_KEY) ?: null;
    }

    /**
     * 获取当前登录用户的ID
     *
     * @return mixed|null
     */
    public static function id()
    {
        $userInfo = self::info();

        return !empty($userInfo) ? $userInfo['uid'] : null;
    }

    /**
     * 用户登录
     * @param array $auth
     * @return boolean
     */
    public static function login($auth)
    {
        try {
            $auth = [
                'uid'       => $auth['username'],
                'login_time'=> \Carbon\Carbon::now()->toDateTimeString(),
            ];
            session(self::USER_INFO_SESSION_KEY, $auth);
            session(self::USER_SIGN_SESSION_KEY, AuthSign($auth));
            return ;
        } catch (\Exception $e) {
            return ;
        }
    }

    /**
     * 注销登录
     * @return null
     */
    public static function logout()
    {
        try {
            session(self::USER_INFO_SESSION_KEY, null);
            session(self::USER_SIGN_SESSION_KEY, null);
            return ;
        } catch (\Exception $e) {
            return ;
        }
    }
}
