<?php

namespace app\index\controller;
use app\common\model\UserModel;
use app\index\repository\DnsNodeRepository;
use app\index\repository\ProxyNodeRepository;
use app\index\repository\UserappRepository;

class Contents extends Base
{
    /**
     * @SWG\Get(
     *      path="/contents",
     *      tags={"index 首页"},
     *      summary="【获取】首页状态",
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          @SWG\Property(property="", type="object",
     *              example={"errcode":0,"errmsg":"ok","users":12,"user_domains":100,"user_servers":100,"dns_servers":10,"anti_nodes":200,"clean_devices":10,"detect_devices":10}
     *          )
     *      )
     * )
     * @throws \app\common\exception\RepositoryException
     * @throws \Exception
     */
    public function index()
    {
        $counts_data = [];

        $counts_data['users'] = UserModel::where('role', UserModel::USER_ROLE)->count();
        
        $repository = new UserappRepository;
        $counts_data['user_domains'] = $repository->countApps([]);

        $repository = new ProxyNodeRepository;
        $counts_data['anti_nodes'] = $repository->countNodes([]);
        
        $repository = new DnsNodeRepository;
        $counts_data['dns_servers'] = $repository->countNodes([]);

        $counts_data['clean_devices'] = 0;

        $counts_data['detect_devices'] = 0;

        return Finalsuccess($counts_data);
    }

}