<?php

namespace app\index\controller;

use app\index\model\ProxyNodeModel;
use app\index\repository\ProxyConfRepository;
use app\index\repository\ProxyNodeRepository;
use app\index\validate\ProxyNodes as ProxyNodesValidate;

class ProxyNodes extends Base
{
    use \app\index\traits\IpRange;
    use \app\index\traits\CheckNodeConf;

    /**
     * @SWG\Get(
     *      path="/antinodes",
     *      tags={"antinode 高防节点"},
     *      summary="【获取】高防节点列表",
     *      @SWG\Parameter(name="_from", in="query", required=false, type="integer", description="查询范围开始"),
     *      @SWG\Parameter(name="_size", in="query", required=false, type="integer", description="查询数量"),
     *      @SWG\Parameter(name="ip", in="query", required=false, type="string", description="查询ip，完全匹配"),
     *      @SWG\Parameter(name="area", in="query", required=false, type="integer", description="查询地区"),
     *      @SWG\Parameter(name="prvc", in="query", required=false, type="integer", description="查询省份"),
     *      @SWG\Parameter(name="line_type", in="query", required=false, type="integer", description="线路类型"),
     *      @SWG\Parameter(name="node_type", in="query", required=false, type="integer", description="查询节点类型"),
     *      @SWG\Parameter(name="node_id", in="query", required=false, type="string", description="查询节点ID，完全匹配"),
     *      @SWG\Parameter(name="username", in="query", required=false, type="string", description="查询用户"),
     *      @SWG\Response(response="200", ref="#/definitions/Antinodelist")
     * )
     * @param ProxyNodeRepository $pxyNodeRepository
     *
     * @return string
     */
    public function index(ProxyNodeRepository $pxyNodeRepository)
    {
        $node_id = input('node_id', null);
        if (! empty($node_id)) {
            $node = $pxyNodeRepository->selectNodeById($node_id);
            if (empty($node)) {
                Success(['list' => [], 'total' => 0]);
            }

            $node['id'] = $node_id;
            $userList = $this->getProxyUserInfo($node['id']);
            $node['user_count'] = count($userList);
            $node['user_detail'] = $userList;
            return Finalsuccess(['list' => [$this->parseNodeInfo($node)], 'total' => 1]);
        }

        // 条件筛选
        $from = input('_from', 0);
        $size = input('_size', null);

        // 地区筛选条件
        $area = input('area', '');
        $prvc = input('prvc', '');
        $filters = [];
        if ($area) {
            if ($prvc) {
                $filters[] = ['term' => ['area' => $prvc]];
            } else {
                switch ($area) {
                    case 1:
                        $term = ['terms' => ['area' => [11,12,13,14]]];
                    break;
                    case 2:
                        $term = ['terms' => ['area' => [21,22,23]]];
                    break;
                    case 3:
                        $term = ['terms' => ['area' => [31,32,33,34,35,36,37]]];
                    break;
                    case 4:
                        $term = ['terms' => ['area' => [41,42,43,44,45,46]]];
                    break;
                    case 5:
                        $term = ['terms' => ['area' => [50,51,52,53,54]]];
                    break;
                    case 6:
                        $term = ['terms' => ['area' => [61,62,63,64,65]]];
                    break;
                    case 71:
                        $term = ['term' => ['area' => 71]];
                    break;
                    case 81:
                        $term = ['term' => ['area' => 81]];
                    break;
                    case 91:
                        $term = ['term' => ['area' => 91]];
                    break;
                    default:
                        $term = [];
                    break;
                }
                $filters[] = $term;
            }
        }

        // 高防节点ip查询条件
        $ip = input('ip', '');
        if ($ip) {
            $filters[] = ['wildcard' => ['node_ip.ip.keyword' => "*$ip*"]];
        }

        // 线路类型ip查询条件
        $line_type = input('line_type', null);
        if (isset($line_type)) {
            $filters[] = ['term' => ['line_type' => $line_type]];
        }

        // 节点类型ip查询条件
        $node_type = input('node_type', '');
        if ($node_type) {
            $filters[] = $node_type === "1,2" ? ['terms' => ['node_type' => [1,2]]] : ['term' => ['node_type' => $node_type]];
        }

        // 根据使用用户进行查询
        $username = input('username', '');
        if ($username) {
            $node_id = [];
            $query['query']['bool']['filter'][] = ['term' => ['uid.keyword' => $username]];
            $result = $pxyNodeRepository->getNodeIdByUser($query);
            if ($result) {
                foreach ($result as $tmp) {
                    if (isset($tmp['node_id']) && ($tmp['node_id'] !== "")) {
                        $node_id[] = $tmp['node_id'];
                    }
                }

                if ($node_id) {
                    $filters[] = ['terms' => ['node_id.keyword' => $node_id]];
                }
            } else {
                return Finalsuccess(['list'=>[], "total"=>0]);
            }
        }

        $filter['query']['bool']['filter'] = $filters;
        $filter['sort'][] = ['last_update' => ['order' => 'desc']];
        $list = $pxyNodeRepository->selectNodes($filter, $from, $size);
        $list = array_map(function ($item) {
            $userList = $this->getProxyUserInfo($item['id']);
            $item['user_count'] = count($userList);
            $item['user_detail'] = $userList;
            return $this->parseNodeInfo($item);
        }, $list);

        $total = $pxyNodeRepository->countNodes($filter);
        return Finalsuccess(['list'=>$list, "total"=>$total]);
    }

    /**
     * @SWG\Post(
     *      path="/antinodes",
     *      tags={"antinode 高防节点"},
     *      summary="【添加】高防节点",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="高防节点信息：",
     *          @SWG\Schema(
     *              @SWG\Property(property="line_type", type="integer", example=3, description="线路类型"),
     *              @SWG\Property(property="node_ip", type="object", example={{"line": 1,"ip": "1.1.1.1-1.1.1.10"},{"line": 2,"ip": "2.2.2.1-2.2.2.10"}}, description="节点线路ip"),
     *              @SWG\Property(property="area", type="integer", example=41, description="地区"),
     *              @SWG\Property(property="site_limit", type="integer", example=50, description="网站上限"),
     *              @SWG\Property(property="bandwidth", type="integer", example="100", description="业务带宽，单位Mb/s"),
     *              @SWG\Property(property="node_type", type="integer", example=1, description="1/2/3 (独享型网站类/共享型网站类/非网站类)"),
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     */
    public function create(ProxyNodesValidate $validator, ProxyNodeRepository $pxyNodeRepository)
    {
        if (!$validator->scene('add_proxy_node')->check(input())) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
        }
        if (!$this->checkNodeConf(input())) {
            return Finalfail(REP_CODE_PROXY_NODE_CONFIG_ERROR, "高防节点配置有误");
        }
        $node_list = input('node_ip/a');
        $ip_list = [];
        $line_arr = [];
        $ip_count = 0;
        $hd_id_arr = [];//生成的id统计
        $hd_ip = []; //统计添加ip
        $hd_node_conf = [
            'line_type'   =>  (int)input('line_type'),
            'area'        =>  (int)input('area'),
            'node_type'   =>  (int)input('node_type'),
            'bandwidth'   =>  (int)input('bandwidth').'M',
            'user_count'  =>  0,
            'last_update' =>  gmt_withTZ()
        ];

        if ($hd_node_conf['node_type'] !== ProxyNodeModel::USER_APP_TYPE) {
            $hd_node_conf['site_limit'] = (int)input('site_limit');

            if (($hd_node_conf['node_type'] === ProxyNodeModel::USER_UNSHARE_SITE_TYPE && $hd_node_conf["site_limit"] !== 1)
             || ($hd_node_conf['node_type'] !== ProxyNodeModel::USER_UNSHARE_SITE_TYPE && $hd_node_conf["site_limit"] === 1)) {
                return Finalfail(REP_CODE_PROXY_NODE_SITE_LIMIT_ERROR, "网站上限设置错误");
            }
        }

        foreach ($node_list as $tmp) {
            $ip_list[$tmp['line']] = $this->parseIp($tmp["ip"]);
            $ip_count = $ip_count === 0 ? count($ip_list[$tmp['line']]) : $ip_count;
            $line_arr []= $tmp['line'];
        }

        for ($n = 0; $n < $ip_count; $n++) {
            $tmp_arr = [];
            foreach ($line_arr as $line) {
                $tmp_arr[] = [
                    'line'  =>  $line,
                    'ip'    =>  $ip_list[$line][$n]
                ];

                $hd_ip[] = $ip_list[$line][$n];
            }

            do {
                $id = $pxyNodeRepository->generateInstanceId();
            } while (isset($hd_id_arr[$id]));
            $hd_id_arr[$id] = $id;
            $hd_node_conf['node_id'] = $id;
            $hd_node_conf['node_ip'] = $tmp_arr;

            $hd_node_arr[] = $hd_node_conf;
        }

        //自身查重
        if (count(array_unique($hd_ip)) !== count($hd_ip)) {
            return Finalfail(REP_CODE_PROXY_NODE_REPEAT_ERROR, '高防节点添加重复');
        }

        //数据库查重
        $finder['query']['bool']['filter'][] = count($hd_ip) === 1 ?
            ['term' => ['node_ip.ip.keyword' => $hd_ip[0]]] : ['terms' => ['node_ip.ip.keyword' => $hd_ip]];
        $list = $pxyNodeRepository->selectNodes($finder);
        if (!empty($list)) {
            return Finalfail(REP_CODE_PROXY_NODE_REPEAT_ERROR, '高防节点添加重复');
        }

        foreach ($hd_node_arr as $node) {
            $bulk[] = [
                'index' =>  ['_id' => $node['node_id']]
            ];
            $bulk[] = $node;
        }

        $result = $pxyNodeRepository->insertAllNodes($bulk);

        if ($result) {
            return Finalsuccess(['data' => $bulk[1]]);
        }
        return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败');
    }

    /**
     * @SWG\Delete(
     *      path="/antinodes/delete",
     *      tags={"antinode 高防节点"},
     *      summary="【删除】高防节点",
     *      @SWG\Parameter(
     *          name="",
     *          in="body",
     *          description="高防节点ID数组",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"ids": {"proxy-3anhp92o3u", "proxy-3anhp92o8lV3D"}}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 删除成功| !=0 删除失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     */
    public function bundleDelete(ProxyNodesValidate $validator, ProxyNodeRepository $pxyNodeRepository)
    {
        $data = input();
        if (!$validator->scene('bundle_delete')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
        }

        $result = $pxyNodeRepository->bundleDelete($data['ids']);
        if (!$result) {
            return Finalfail(REP_CODE_DB_ERROR, "数据库操作失败");
        }
        return Finalsuccess();
    }

    /**
     * 获取网站或应用详情
     *
     * @SWG\Get(
     *      path="/antinodes/{id}/apps[sites]",
     *      tags={"antinode 高防节点"},
     *      summary="【获取】高防节点应用或网站详情",
     *      @SWG\Parameter(name="id", in="path", required=true, type="string", description="高防节点ID"),
     *      @SWG\Parameter(name="page", in="query", required=false, type="integer", description="页码，默认为1"),
     *      @SWG\Parameter(name="row", in="query", required=false, type="integer", description="显示条数，默认为10"),
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","list":{"veda.com","shao.com"},"total":2}
     *          )
     *      )
     * )
     */
    public function getAppSiteConfig(ProxyConfRepository $pxyConfRepository, ProxyNodeRepository $pxyNodeRepository, $id)
    {
        $total = 0;
        $list = [];
        $page = input('page', 1);
        $row = input('row', 10);

        $node = $pxyNodeRepository->selectNodeById($id);
        if (empty($node) || !$node['node_type']) {
            return Finalsuccess(['total' => $total, 'list' => $list]);
        }

        foreach ($node["node_ip"] as $tmp) {
            $config = $pxyConfRepository->selectConfById($tmp['ip']);
            if ($node['node_type'] === ProxyNodeModel::USER_APP_TYPE) {
                if (isset($config['forwarding'])) {
                    $total = count($config['forwarding']);
                    $list = array_map(function ($tmp) {
                        return ['ip' => $tmp['server_ip'], 'port' => $tmp['proxy_port']];
                    }, $config['forwarding']);
                }
            } elseif ($node['node_type'] === ProxyNodeModel::USER_SHARE_SITE_TYPE || $node['node_type'] === ProxyNodeModel::USER_UNSHARE_SITE_TYPE) {
                if (isset($config['web'])) {
                    $total = count($config['web']);
                    $list = array_map(function ($tmp) {
                        return $tmp['name'];
                    }, $config['web']);
                }
            }
        }

        $list=array_slice($list, ($page-1)*$row, $row);

        return Finalsuccess(['total' => $total, 'list' => $list]);
    }

    /**
     * 修改共享类节点网站上限
     *
     * @SWG\Put(
     *      path="/antinodes/{id}/sitelimit",
     *      tags={"antinode 高防节点"},
     *      summary="【修改】修改共享类节点网站上限",
     *      @SWG\Parameter(name="id", in="path", required=true, type="string", description="高防节点ID"),
     *      @SWG\Parameter(name="site_limit", in="query", required=true, type="integer", description="上限"),
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     */
    public function editNodeSiteLimit(ProxyNodeRepository $pxyNodeRepository, $id)
    {
        $node = $pxyNodeRepository->selectNodeById($id);
        if (is_null($node)) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, "未找到该节点");
        }

        if ($node['node_type'] !== ProxyNodeModel::USER_SHARE_SITE_TYPE) {
            return Finalfail(REP_CODE_PROXY_NODE_SITE_TYPE_ERROR, '高防节点类型错误');
        }

        $data = input('put.site_limit', 0);
        if ($data < $node['site_limit']) {
            return Finalfail(REP_CODE_PROXY_NODE_SITE_LIMIT_ERROR, '不得小于当前上限');
        } else {
            $node['site_limit'] = $data;
        }

        $result = $pxyNodeRepository->updateNodeById($node, $id);
        if ($result) {
            return Finalsuccess();
        }

        return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败');
    }

    /**
     * 根据高防节点的id，获取用户信息
     *
     * @param   String  $id         高防节点ID
     * @return  array   $userList   用户信息列表
     */
    private function getProxyUserInfo($id)
    {
        $node = (new ProxyNodeRepository)->selectNodeById($id);
        $userList = [];

        if ($node) {
            foreach ($node['node_ip'] as &$tmp) {
                $node_info = (new ProxyConfRepository)->selectConfById($tmp['ip']);
                $node_conf = $node['node_type'] === ProxyNodeModel::USER_APP_TYPE ? $node_info["forwarding"] : $node_info["web"];
                if ($node_conf) {
                    $users = array_map(function ($item) {
                        return $item['uid'];
                    }, $node_conf);
                    $userList = array_unique(array_merge($userList, $users));
                }
            }
        }

        return array_values($userList);
    }

    /**
     * 解析节点信息统计出网站或应用详情
     *
     * @param   array   $node   高防节点信息
     * @return  array   $node
     */
    private function parseNodeInfo($node)
    {
        foreach ($node["node_ip"] as &$tmp) {
            $config = (new ProxyConfRepository)->selectConfById($tmp['ip']);

            if ($node['node_type'] === ProxyNodeModel::USER_SHARE_SITE_TYPE || $node['node_type'] === ProxyNodeModel::USER_UNSHARE_SITE_TYPE) {
                $count = isset($config['web']) ? count($config['web']) : 0;
                $tmp['site_count'] = $count;
                $node['total_site_count'] = $node['total_site_count'] ?? 0 + $count;
            } elseif ($node['node_type'] === ProxyNodeModel::USER_APP_TYPE) {
                $count = isset($config['forwarding']) ? count($config['forwarding']) : 0;
                $tmp['app_count'] = $count;
                $node['total_app_count'] = $node['total_app_count'] ?? 0 + $count;
            }
        }

        $node['last_update'] = strtotime($node['last_update']);
        return $node;
    }
}
