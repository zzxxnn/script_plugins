<?php
/**
 * This file  is a part of  Veda- Platform
 * Copyright (c) 2015 - 2018. Veda Software Inc. (http://www.veda.com)
 *
 * @file                Product.php
 * @author              Teddy Sun
 */

namespace app\index\controller;

use app\index\repository\PriceRepository;
use think\Request;

/**
 * Class Price 定价
 *
 * @package app\index\controller
 * @author Teddy Sun <sgsheg@163.com>
 */
class Price extends Base
{
    /**
     * @SWG\Get(
     *      path="price",
     *      tags={"price 价格"},
     *      summary="【获取】区域价格列表",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="区域 Id",
     *          type="integer",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data": {}}
     *          )
     *      )
     * )
     *
     * 从后台产品价格表
     *
     * @param \app\index\repository\PriceRepository $repository
     * @return \think\Response
     * @throws \Exception
     */
    public function index(PriceRepository $repository)
    {
        //从路由中获取province 默认为11 北京
        $provinceId = $this->request->get('id') ?? 11;
        // 如果传入的是区域的话读取区域对应的第一个记录
        if ((int) $provinceId < 10) {
            $provinceId = (int) $provinceId * 10 + 1;
        }

        //获取北京下面在products中的记录
        $filter['query']['bool']['must'][] = ['term' => ['province_id' => $provinceId]];

        $list = $repository->all($filter);

        return json(['data' => $list, 'errcode' => 0, 'errmsg' => '获取成功']);
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
    }

    /**
     * 显示指定的资源
     *
     * @param  int
     * @return \think\Response
     */
    public function read($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int
     * @return \think\Response
     */
    public function edit($id)
    {
    }

    /**
     * @SWG\Put(
     *      path="price/{id}",
     *      tags={"price 价格"},
     *      summary="【修改】区域价格列表",
     *     @SWG\Parameter(
     *         name="",
     *         in="body",
     *         description="应该信息",
     *         required=true,
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"product" : {{"value" : 1,"label" : "网站共享类","children": {{"value" : 11,"label" : "电信","children" : {{"bandwidth": 22,"domain" : 1,"service" : 1,}}}}}
    }}
     *          )
     *     ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 更新成功| !=0 更新失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     * 保存更新的资源
     *
     * @param \app\index\repository\PriceRepository $productRepository
     * @param  int $id
     * @return \think\response\Json
     * @throws \Exception
     */
    public function update(PriceRepository $productRepository, $id)
    {
        $filter['query']['bool']['must'][] = ['term' => ['province_id' => (int)$id]];

        $record = $productRepository->all($filter);

        $priceId = $record[0]['id'];

        if ($this->request->isPut()) {
            $price = input('price/a');

            $data = [];

            foreach ($price as $key => $items) {
                $parentValue = $items[0]['parent'];
                $parentLabel = $items[0]['plabel'];
                $priceChildren = [];
                foreach ($items as $item) {
                    if ('-' == $item['domain']) {
                        $item['domain'] = 0; //应用
                    }
                    $children        = [
                        [
                            'bandwidth' => $item['bandwidth'],
                            'domain'    => (int) $item['domain'],
                            'service'   => $item['service']
                        ]
                    ];
                    $priceChildren[] = [
                        'value'    => $item['value'],
                        'label'    => $item['label'],
                        'children' => $children,
                    ];
                }
                $data[$key] = ['value' => (int)$parentValue, 'label' => $parentLabel, 'children' => $priceChildren];
            }

            $product = [
                'province_id' => $record[0]['province_id'],
                'province'=> $record[0]['province'],
                'price' => $data,
            ];

            $result = $productRepository->update($product, $priceId);

            if ($result) {
                return json(['data' => [], 'errcode' => 0, 'errmsg' => '更新成功']);
            } else {
                return json(['data' => [], 'errcode' => 1, 'errmsg' => '更新失败.']);
            }
        }
    }

    /**
     * 删除指定资源
     *
     * @param  int
     * @return \think\Response
     */
    public function delete($id)
    {
        //
    }
}