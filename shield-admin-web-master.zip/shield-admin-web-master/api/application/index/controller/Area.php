<?php

namespace app\index\controller;

use app\index\repository\AreaRepository;
use think\Controller;
use think\Request;

/**
 * Class Area 区域
 *
 * @package app\index\controller\
 * @author Teddy Sun <sgsheg@163.com>
 */
class Area extends Controller
{
    /**
     * @SWG\Get(
     *      path="areas",
     *      tags={"areas 区域"},
     *      summary="【获取】区域列表",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data": {"value": 91,"label": "澳门","children": ""}}
     *          )
     *      )
     * )
     *
     * 获取系统区域列表
     *
     * @param \app\index\repository\AreaRepository $repository
     * @return \think\Response
     * @throws \Exception
     */
    public function index(AreaRepository $repository)
    {
        $areas = $repository->all();

        foreach ($areas as &$area) {
            unset($area['id']);
        }

        return json(['errcode' => 0, 'errmsg' => '获取成功', 'data' => $areas,]);
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
    }

    /**
     * 显示指定的资源
     *
     * @param  int
     * @return \think\Response
     */
    public function read($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request
     * @param  int
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * 删除指定资源
     *
     * @param  int
     * @return \think\Response
     */
    public function delete($id)
    {
        //
    }
}