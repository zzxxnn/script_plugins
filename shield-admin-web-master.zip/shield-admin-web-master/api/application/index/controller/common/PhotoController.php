<?php

namespace app\index\controller\common;

use app\common\repository\PhotoRepository;
use app\index\controller\Base;

class PhotoController extends Base
{
    /**
     *
     * @SWG\Post(
     *      path="/photo/upload",
     *      tags={"Photo 上传图片"},
     *      summary="上传图片",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="file", type="string", example="avatar.png"),
     *              @SWG\Property(property="type", type="int", example="1: 审批单; 2: 其他单据;(如果是上传头像，type不需要传)"),
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 上传成功 !=0 上传失败",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0, "errmsg":"上传成功","data": "/uploads/photo/5b5815353daea.jpg"}
     *          )
     *     )
     * )
     *
     */
    public function upload()
    {
        $data = input();
        if (isset($data['type'])) {
            // recharge：充值
            return (new PhotoRepository())->uploadPhoto('/photo','recharge', $data['type']);
        } else {
            return (new PhotoRepository())->uploadPhoto('/photo');
        }
    }
}