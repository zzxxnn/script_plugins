<?php

namespace app\index\controller;

use app\agent\validate\UserValidator;
use app\client\validate\Port;
use app\common\model\AgentModel;
use app\index\validate\Agent as AgentValidate;
use think\Request;

/**
 * Class Agent 代理商
 *
 * @package app\index\controller
 * @author Teddy Sun <sgsheg@163.com>
 */
class Agent extends Base
{
    /**
     * @SWG\Get(path="agent",tags={"agent 代理商"},
     *      summary="【获取】代理商列表",
     *      @SWG\Parameter(name="id_card",in="query",type="string",
     *          description="身份证"
     *      ),
     *      @SWG\Parameter(name="status",in="query",type="integer",
     *          description="状态:1正常,2不正常"
     *      ),
     *     @SWG\Parameter(name="full_name",in="query",type="string",
     *          description="姓名"
     *      ),
     *     @SWG\Parameter(name="agent_id",in="query",type="string",
     *          description="销售支持ID（传值为已绑定的代理商ID，如果未绑定传空）"
     *      ),
     *      @SWG\Response(response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{{"id": "VT9bO2QBw5XrXgevT4wm","full_name": "李四","username": "lisi","company": "北京卫达","id_card": 4.104261989012e+17,"mobile": 18610875206,"qq": 1621125714,"wechat": 18610875206,"email": "lisi@veda.com","status": 1,"status_text": "正常","avatar": "/avatar/support-user2.png","create_time": "2018-06-26T08:19:57.000Z"}}}
     *          )
     *      )
     * )
     *
     * @return \think\Response
     * @throws \Exception
     */
    public function index()
    {
        $must = [];

        // 分页相关
        $from = input('_from', 1);
        $size = input('_size', 10);

        $idCard = input('id_number', null);
        if (isset($idCard)) {
            $must['id_number'] = ['like', '%' . $idCard .'%'];
        }

        //姓名
        $fullName = input('user_name', null);
        if (isset($fullName)) {
            $must['user_name'] = ['like', '%' . $fullName . '%'];
        }

        $getList = model('app\common\model\AgentModel')->getListWithPage($from, $size, $must, '*', 'create_time desc');

        $getList['data'] = $getList['list'];
        unset($getList['list']);

        return Finalsuccess($getList);
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function save()
    {
        //
    }

    /**
     * 保存新的代理商.
     *
     * @param \app\agent\validate\UserValidator $validator
     *
     * @return string
     */
    public function create(UserValidator $validator)
    {
        $data = input();
        if ($data) {
            if ( ! $validator->scene('add_agent')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
            }
            //user_type?为啥这里没有呢 少了个代理类型
            if (empty($data['user_type'])) {
                $data['user_type'] = AgentModel::USER_TYPE_CLIENT;
            }
            //email todo:干掉email todo:等待优化
            $data['user_email'] = $data['email'];
            $data['user_invite_code'] = '';
            $data['last_login_ip'] = '';
            $data['phone'] = '';
            $data['bank'] = '';
            $data['bank_account'] = '';
            $data['bank_card'] = '';

            $result = AgentModel::create($data);
            if ($result) {
                return Finalsuccess();
            }
            return Finalfail(11001, '添加失败');
        } else {
            return Finalfail(11002, '请求无效');
        }
    }

    /**
     * @SWG\Get(
     *      path="/agent/{id}",
     *      tags={"agent 代理商"},
     *      summary="【获取】代理商详情",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","agent":{"id":1,"user_type":1,"sex":0,"birthday":0,"last_login_time":null,"score":0,"balance":"0.00","user_status":0,"user_name":"","user_nickname":"","user_email":"agent8227@veda.com","user_url":"","avatar":"avatar\/support-user1.png","user_invite_code":"","last_login_ip":"","mobile":"18610875205","phone":"","id_number":"","id_verify_status":0,"company":"\u5317\u4eac\u536b\u8fbe","create_time":"2018-07-23
     *              15:01:10","qq":"","user_invite_url":"ye.shielduser.com\/users\/","user_number":10}}
     *          )
     *      )
     * )
     * @param $id
     *
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function show($id)
    {
        $agent = AgentModel::find($id);
        if ($agent) {
            if(! $agent->last_login_time) {
                $agent->last_login_time = null;
            } else {
                $agent->last_login_time = format_time($agent->last_login_time);
            }
            //$agent->user_invite_url = env('CLIENT_URL').'/users/'.$agent->user_invite_code;

            return Finalsuccess(compact('agent'));
        }

        return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '该代理商不存在');
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request
     * @param  int
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * 删除指定资源
     *
     * @param  int
     * @return \think\Response
     */
    public function delete($id)
    {
        //
    }

    /**
     * @SWG\Delete(
     *      path="/agent",
     *      tags={"agent 代理商"},
     *      summary="【删除】代理商",
     *      @SWG\Parameter(
     *          name="ids",
     *          in="body",
     *          description="代理商ID数组",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"ids": {"1", "2"}}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * @param AgentValidate $agentValidate
     *
     * @return string
     */
    public function bundleDelete(AgentValidate $agentValidate)
    {

        if ($this->request->isDelete()) {
            $data        = input();
            $checkResult = $agentValidate->scene('delete')->check($data);

            if (true !== $checkResult) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $agentValidate->getError());
            }
            //开始删除
            $result = AgentModel::whereIn('id', $data['ids'])->delete();

            if (! $result) {
                return Finalfail(REP_CODE_DB_ERROR, '删除失败,请重试.');
            }
            return Finalsuccess();
        }
    }
}
