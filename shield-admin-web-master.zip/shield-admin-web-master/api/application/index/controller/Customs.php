<?php

namespace app\index\controller;

use app\client\repository\SupportRepository;
use app\common\model\AgentModel;
use app\client\repository\DDoSRepository;
use app\common\model\UserModel;
use app\common\model\OrderModel;
use app\common\repository\PhotoRepository;
use app\common\service\MailService;
use app\common\service\NotifierService;
use app\common\model\SiteModel;
use app\common\repository\OrderRepository;
use app\index\model\ApprovePhotoModel;
use app\index\repository\UserappRepository;
use app\index\service\Auth;
use app\index\validate\Userinfo;
use app\index\validate\Userinfo as UserInfoValidate;
use Carbon\Carbon;
use think\Request;

/**
 * Class Customs 普通用户
 *
 * @package app\index\controller
 * @author  Teddy Sun <sgsheg@163.com>
 */
class Customs extends Base
{
    public function _initialize()
    {
        $this->validator = new UserInfoValidate();
    }

    /**
     * @SWG\Get(
     *      path="/customs",
     *      tags={"custom 用户管理"},
     *      summary="【获取】用户管理列表",
     *      @SWG\Parameter(name="_from", in="query", required=false, type="integer", description="查询范围开始"),
     *      @SWG\Parameter(name="_size", in="query", required=false, type="integer", description="查询数量"),
     *      @SWG\Parameter(name="account", in="query", required=false, type="string", description="查询账号"),
     *      @SWG\Parameter(name="safe_mail", in="query", required=false, type="string", description="查询安全邮箱"),
     *      @SWG\Parameter(name="phone", in="query", required=false, type="string", description="查询手机号"),
     *      @SWG\Parameter(name="id_num", in="query", required=false, type="string", description="查询身份证"),
     *      @SWG\Parameter(name="if_bind_agent", in="query", required=false, type="string", description="查询是否绑定代理商"),
     *      @SWG\Parameter(name="agent_id", in="query", required=false, type="integer", description="代理商id"),
     *      @SWG\Parameter(name="username", in="query", required=false, type="string", description="用户名"),
     *      @SWG\Response(response="200", ref="#/definitions/Userlist")
     * )
     */
    public function index()
    {
        $from = input('_from', 1);
        $size = input('_size', 10);

        if (! $this->validator->scene('list')->check(input())) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        $must['role'] = UserModel::USER_ROLE;
        //邮箱
        $account = input('account', null);
        if ($account) {
            $must['email'] = [ 'like', '%'.$account.'%' ];
        }
        //安全邮箱
        $safeEmail = input('safe_mail', null);
        if ($safeEmail) {
            $must['safe_email'] = [ 'like', '%'.$safeEmail.'%' ];
        }
        //手机号码
        $phone = input('phone', null);
        if ($phone) {
            $must['mobile'] = [ 'like', '%'.$phone.'%' ];
        }

        $idNumber = input('id_num', null);
        if ($idNumber) {
            $must['id_number'] = [ 'like', '%'.$idNumber.'%' ];
        }

        $username = input('username', null);
        if ($username) {
            $must['username'] = ['like', '%' . $username . '%'];
        }

        // 是否绑定代理商
        $if_bind_agent = input('if_bind_agent', '');
        $agent_id      = input('agent_id', '');
        if ($if_bind_agent == 'false') {
            //筛选未绑定代理商的客户
            $must['agent_id'] = 0;
        } elseif ($if_bind_agent == 'true') {
            //筛选已绑定代理商的客户
            if ($agent_id) {
                $must['agent_id'] = $agent_id;
            }
        }

        $getList = model('app\common\model\UserModel')->getListWithPage($from, $size, $must);
        foreach ($getList['list'] as $key => $value) {
            if (! $value['last_login_time']) {
                $value['last_login_time'] = null;
            }
            unset($value[$key]);
            $getList['list'][$key] = $value;
        }

        return Finalsuccess($getList);
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request
     *
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
    }

    /**
     * @SWG\Get(
     *      path="/customs/{id}",
     *      tags={"custom 用户管理"},
     *      summary="【获取】用户详情",
     *      @SWG\Parameter(name="id", in="path", required=true, type="string", description="用户email(用户名)"),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"id":12,"role":1,"last_login_time":1532154682,"account":"10000.00","real_name":"test@veda.com","id_number":"","id_verify_status":0,"username":"test","email":"test@veda.com","safe_email":"","email_verify_status":0,"avatar":"avatar\/support-user0.png","last_login_ip":"127.0.0.1","mobile":"","mobile_verify_status":0,"agent_id":1,"create_time":"2018-07-19
     *              17:20:54","qq":"","agent_name":"","role_name":"\u666e\u901a\u7528\u6237","img_url":"http:\/\/ye.shieldadmin.com\/avatar\/support-user0.png"},"agent":{"id":1,"avatar":"avatar\/support-user1.png","mobile":"18610875205","name":"","qq":""},"ddos_count":30,"fees":9809,"orders":{{"id":"11806090945412","type":"\u6d88\u8d39","fee":50,"pay_time":"2018-07-11T05:53:06.000Z"},{"id":"11807101806412","type":"\u6d88\u8d39","fee":100,"pay_time":"2018-07-11T05:50:34.000Z"},{"id":"11807111039690","type":"\u6d88\u8d39","fee":100,"pay_time":"2018-07-11T05:46:42.000Z"},{"id":"11807031102581","type":"\u6d88\u8d39","fee":100,"pay_time":"2018-07-03T10:03:12.000Z"},{"id":"11807031539709","type":"\u6d88\u8d39","fee":100,"pay_time":"2018-07-03T07:46:19.000Z"}}}
     *          )
     *      )
     * )
     *
     *
     * @param $id
     *
     * @return string
     * @throws \Exception
     * @throws \app\common\exception\RepositoryException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function show($id)
    {
        $user  = UserModel::where('email', $id)->find();
        if (! $user) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '用户不存在！');
        }

        $agent = null;
        $user_agent = AgentModel::find($user->agent_id);
        if ($user_agent) {
            $agent = [
                    'id'     => $user_agent->id,
                    'avatar' => 'http://'.env('BACKGROUND_URL').'/'.$user_agent->avatar,
                    'mobile' => $user_agent->mobile,
                    'name'   => $user_agent->user_name,
                    'qq'     => $user_agent->qq,
                ];
        }

        $ddos_count  = ( new DDoSRepository() )->getUserDDoSTotal($id);
        $amount      = ( new OrderRepository() )->getUserAmountTotal($id);
        $user_orders = ( new OrderRepository() )->getUserOrdersById($id);

        $site_filter['query']['bool']['must']     = [
            [ 'term' => [ 'status' => SiteModel::DOMAIN_STATUS_NORMAL ] ],
            [ 'term' => [ 'uid.keyword' => $id ] ]
        ];
        $site_filter['query']['bool']['must_not'] = [
            [ 'term' => [ 'type' => SiteModel::USER_APP_TYPE_PORT ] ]
        ];
        $site_count                               = ( new UserappRepository() )->countApps($site_filter);

        $port_filter['query']['bool']['must'] = [
            [ 'term' => [ 'uid.keyword' => $id ] ],
            [ 'term' => [ 'status' => SiteModel::PORT_STATUS_NORMAL ] ],
            [ 'term' => [ 'type' => SiteModel::USER_APP_TYPE_PORT ] ]
        ];
        $port_count                           = ( new UserappRepository() )->countApps($port_filter);

        $orders = [];
        foreach ($user_orders as $order) {
            $orders[] = [
                'id'       => $order['id'] + 0,
                'type'     => $order['type'] == OrderModel::ORDER_STATUS_PAID ? '充值' : '消费',
                'fee'      => $order['fee'],
                'pay_time' => format_time(strtotime($order['pay_time'])),
            ];
        }
        //支持人员
        $supportRepository = new SupportRepository();
        list($technical, $sale) = $supportRepository->getSupport();

        return Finalsuccess([
            'data'       => $user,
            'agent'      => $agent,
            'ddos_count' => $ddos_count,
            'site_count' => $site_count,
            'port_count' => $port_count,
            'fees'       => $amount,
            'orders'     => $orders,
            'sale'       => $sale,
        ]);
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int
     *
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     *
     * @SWG\PUT(
     *      path="/customs/{id}",
     *      tags={"custom 用户管理"},
     *      summary="【修改】用户详情",
     *      @SWG\Parameter(
     *          name="mobile",
     *          in="body",
     *          description="手机",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"mobile": "18638121735"}
     *          )
     *      ),
     *      @SWG\Parameter(
     *          name="username",
     *          in="body",
     *          description="用户名",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"username": "123"}
     *          )
     *      ),
     *      @SWG\Parameter(
     *          name="avatar",
     *          in="body",
     *          description="头像图片（参考用户充值图片）",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"avatar": "图片"}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 修改成功| !=0 修改失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     * @param      $id
     *
     * @return bool
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function update($id)
    {
        $data   = input();
        if ($data && count($data) > 1) {
            $custom = UserModel::find($id);
            if (! $custom) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '找不到该用户');
            }
            request()->bind('email', $custom->email);
            if (! $this->validator->scene('update_customer')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
            }

            $result = $custom->save($data);
            if ($result) {
                return Finalsuccess();
            }

            return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败');
        }

        return Finalfail(REP_CODE_UPDATE_USER_NOTHING, '您未作出任何修改');
    }

    /**
     * @SWG\Put(
     *      path="/customs/{id}/password",
     *      tags={"custom 用户管理"},
     *      summary="【修改】用户密码",
     *      @SWG\Parameter(
     *          name="new_password",
     *          required=true,
     *          in="body",
     *          description="新密码（密码验证规则参照C端）",
     *          @SWG\Schema(
     *              @SWG\Property(property="new_password", type="string", example="veda2018"),
     *          )
     *      ),
     *      @SWG\Parameter(
     *          name="confirm_password",
     *          required=true,
     *          in="body",
     *          description="确认密码",
     *          @SWG\Schema(
     *              @SWG\Property(property="confirm_password", type="string", example="veda2018"),
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     * @param $id
     *
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function password($id)
    {
        $data = input();
        if (! $this->validator->scene('update_password')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }
        $user = UserModel::find($id);
        if (! $user) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该用户！');
        }
        request()->bind('email', $user->email);
        $user->password = password_hash($data['new_password'], PASSWORD_DEFAULT);
        if ($user->save()) {
            request()->bind('username', $user->username);

            return Finalsuccess();
        }

        return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败');
    }

    /**
     *
     * @SWG\Post(
     *      path="/customs/{id}/recharge",
     *      tags={"custom 用户管理"},
     *      summary="【充值】充值",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="充值信息：",
     *          @SWG\Schema(
     *              @SWG\Property(property="amount", type="integer",description="充值金额(需大于10，保留两位小数，最大值还不明确)", example=1000),
     *              @SWG\Property(property="approver_name", type="string", description="审批人名字", example="张三"),
     *              @SWG\Property(property="receipt_number", type="string", description="审批单号\或其他单据编号(产品暂时没有提供验证标准)", example="1123456875"),
     *              @SWG\Property(property="approve_photos", type="file", description="审批单或其他单据图片ID(暂时仅上传一张)", example="图片"),
     *              @SWG\Property(property="type", type="integer", description="审批单或其他单据图片(暂且为1，因为产品还没有区分审批单和其他单据。)", example=1)
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 充值成功| !=0 充值失败",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"account":140}}
     *          )
     *      )
     * )
     * @param      $id
     *
     * @return bool
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \PHPMailer\PHPMailer\Exception
     * @throws \app\common\exception\RepositoryException
     * @throws \Exception
     */
    public function recharge($id)
    {
        $data   = input();

        $custom = UserModel::find($id);
        if (! $custom) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '客户不存在，请检查后再充值！');
        }
        if (! $this->validator->scene('update_account')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        // PHPUnit 发来的请求不进行文件上传
        if (! is_phpunit_testing()) {
            if (empty($_FILES)) {
                return Finalfail(REP_CODE_USER_RECHARGE_FILE_CANNOT_EMPTY, '图片不能为空');
            }
            $result = ( new PhotoRepository() )->uploadPhoto('/photo', 'recharge', $data['type']);
            if ($result) {
                $photo             = new ApprovePhotoModel();
                $photo->user_id    = $id;
                $photo->photo_type = $data['type'];
                $photo->url        = $result->getData()['data'];
                $photo->save();
            }
        }

        $amount = $custom->account + $data['amount'];
        $custom->save([
            'update_time'     => Carbon::now()->toDateTimeString(),
            'last_login_time' => Carbon::now()->toDateTimeString(),
            'account'         => $amount
        ]);

        $data  = [
            'uid'    => Auth::id(),
            'type'   => OrderModel::ORDER_TYPE_RECHARGE,
            'fee'    => $data['amount'],
            'status' => OrderModel::ORDER_STATUS_PAID,
        ];
        $order = ( new OrderRepository() )->createRechargeOrder($data);
        if ($order) {
            // 邮件、短信通知
            list($emailTemplate, $smsTemplate) = [ MailService::USER_RECHARGE, NotifierService::SMS_ORDER_CREATED ];
            $data = [
                'email'    => $custom->email,
                'mobile'   => $custom->mobile,
                'order_id' => $order['id']
            ];
            // 以下发送消息暂未在线上测试
            $this->sendMessages($data, $smsTemplate, $emailTemplate);
        }

        return Finalsuccess([ 'data' => [ 'account' => $custom['account'] ] ]);

        //return Finalfail(REP_CODE_USER_RECHARGE_SNED_NOTIFY_FAIL, '您的充值已完成，系统将稍后发送通知');
    }

    /**
     * @param $data
     * @param $amount
     * @param $smsTemplate
     * @param $emailTemplate
     *
     * @return bool
     * @throws \PHPMailer\PHPMailer\Exception
     */
    private function sendMessages($data, $smsTemplate, $emailTemplate)
    {
        if (isset($data['email']) && ! empty($data['email'])) {
            $result = MailService::send($data['email'], '', $emailTemplate);
            if (! $result) {
                return false;
            }
        }
        if (isset($data['mobile']) && ! empty($data['mobile'])) {
            $result = NotifierService::sendSms($data['mobile'], [ 'order' => $data['order_id'] ], $smsTemplate);
            if (! $result) {
                return false;
            }
        }

        return true;
    }

    /**
     * 删除指定资源
     *
     * @param  int
     *
     * @return \think\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     * @SWG\Delete(
     *      path="/customs/delete",
     *      tags={"custom 用户管理"},
     *      summary="【删除】用户",
     *      @SWG\Parameter(
     *          name="",
     *          in="body",
     *          description="用户ID数组",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"ids": {12, 13}}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 删除成功| !=0 删除失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     */
    public function bundleDelete()
    {
        $data = input();
        if (! $this->validator->scene('bundle_delete')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        $result = UserModel::where('id', 'in', $data['ids'])->delete();

        if (! $result) {
            return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败');
        }

        return Finalsuccess();
    }

    /**
     * @SWG\PUT(
     *      path="/customs/bundleSale",
     *      tags={"custom 用户管理"},
     *      summary="【绑定】用户",
     *      @SWG\Parameter(
     *          name="ids",
     *          in="body",
     *          description="用户ID数组",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"ids": {"2", "3"}}
     *          )
     *      ),
     *      @SWG\Parameter(
     *          name="agent_id",
     *          in="body",
     *          description="代理商ID, 解绑时传空，绑定时需传代理商ID",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"agent_id": "1"}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 绑定成功| !=0 绑定失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     */
    public function bundleSale()
    {
        $data = input();
        if (! $this->validator->scene('bundle_sale')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }
        $agent_id = 0;
        if (isset($data['agent_id'])) {
            $agent_id = $data['agent_id'];
        }
        $result = $this->bindSale($data['ids'], $agent_id);
        if ($result) {
            return Finalsuccess();
        }

        return Finalfail(REP_CODE_DB_ERROR, '绑定失败，请稍后重试！');
    }

    private function bindSale($ids, $agent_id = null)
    {
        // 绑定逻辑
        $ids     = implode(',', $ids);
        $customs = UserModel::all($ids);
        if (! $customs) {
            return false;
        }

        $update_data = [
            'update_time'     => Carbon::now()->toDateTimeString(),
            'last_login_time' => Carbon::now()->toDateTimeString(),
        ];
        //todo:优化.
        if (! empty($agent_id)) {
            $update_data['agent_id'] = $agent_id;
        } else {
            $update_data['agent_id'] = 0;
        }
        $result = UserModel::where("id", "in", $ids)->update($update_data);
        if ($result) {
            $agent = AgentModel::find($agent_id);
            if ($agent) {
                request()->bind('username', $agent->user_name);
            }

            return true;
        }
    }

    /**
     * @SWG\PUT(
     *      path="/customs/{id}/resetRealName",
     *      tags={"custom 用户管理"},
     *      summary="【实名认证】重置用户实名认证",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 绑定成功| !=0 绑定失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * @param $id
     *
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function resetRealName($id)
    {
        $custom = UserModel::find($id);
        request()->bind('email', Auth::id());
        request()->bind('username', $custom->username);
        if (! $custom) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '客户不存在，请刷新页面重试！');
        }
        if ($custom->id_verify_status == UserModel::USER_REAL_NAME_UNVERIFIED) {
            return Finalfail(REP_CODE_USER_REAL_NAME_NOT_EXIST, '该客户并未实名认证，您无法进行重置操作！');
        }

        $custom->real_name = '';
        $custom->id_number = '';
        $custom->id_verify_status = UserModel::USER_REAL_NAME_UNVERIFIED;
        if ($custom->save()) {
            return Finalsuccess();
        }

        return Finalfail(REP_CODE_DB_ERROR, "数据库操作失败");
    }
}
