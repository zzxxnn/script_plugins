<?php

namespace app\index\controller\dns;

use app\index\controller\Base;
use app\index\repository\DnsConfRepository;
use app\index\validate\DnsNodes as DnsNodesValidate;

class StaticConf extends Base
{
    use \app\index\traits\BeforeAction;

    protected $beforeActionList = [
        'checkLogin',
    ];

    public function _initialize()
    {
        $this->validator = new DnsNodesValidate();
        $this->repository = new DnsConfRepository();
    }

    /**
     * @SWG\Get(
     *      path="/dnsnodes/{id}/static",
     *      tags={"dnsnode DNS节点"},
     *      summary="【获取】DNS静态解析配置",
     *      @SWG\Parameter(name="_from", in="query", required=false, type="integer", description="查询范围开始"),
     *      @SWG\Parameter(name="_size", in="query", required=false, type="integer", description="查询数量"),
     *      @SWG\Parameter(name="ip", in="query", required=false, type="string", description="查询ip，完全匹配"),
     *      @SWG\Parameter(name="domain", in="query", required=false, type="string", description="查询域名，完全匹配"),
     *      @SWG\Response(response="200", ref="#/definitions/Dnsnodelist")
     * )
     */
    public function index($id)
    {
        $from = input('_from', 0);
        $size = input('_size', null);
        $ip   = input('ip', null);
        $domain = input('domain', null);

        if (!is_null($ip)) {
            $filter['query']['bool']['must'][] = ['term' => ['response.ip.keyword' => $ip]];
        }

        if (!is_null($domain)) {
            $filter['query']['bool']['must'][] = ['term' => ['name.keyword' => $domain]];
        }

        $filter['query']['bool']['must'][] = ['term' => ['type.keyword' => "static"]];
        $list = $this->repository->selectConfs($filter, $from, $size);
        $total = $this->repository->countConfs($filter);
        return Finalsuccess(['list'=>$list, "total"=>$total]);
    }

    /**
     * @SWG\Post(
     *      path="/dnsnodes/{id}/static",
     *      tags={"dnsnode DNS节点"},
     *      summary="【添加】DNS静态解析配置",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="DNS静态解析配置信息：",
     *          @SWG\Schema(
     *              @SWG\Property(property="domain", type="string", example="abcd.com", description="域名"),
     *              @SWG\Property(property="line_ip", type="object", example={{"line": 4,"ip": "1.1.1.1"},{"line": 2,"ip": "2.2.2.1"},{"line": 1,"ip": "3.3.3.1"},{"line": 8,"ip": "4.4.4.1"}}, description="线路ip"),
     *              @SWG\Property(property="area", type="integer", example=41, description="地区")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     */
    public function create()
    {
        if (!$this->validator->scene('add_dns_static_conf')->check(input())) {
            return Fail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        $line_ip = input('post.line_ip/a');
        $domain = input('post.domain');
        $area = input('post.area');

        $result = $this->repository->selectConfById($domain . "-static");
        if(!is_null($result)){
            return Finalfail(REP_CODE_FAILED_OPERATION, '配置重复');
        }

        $response = array_map(function ($tmp) use ($area) {
            $tmp['area'] = $area;
            return $tmp;
        },$line_ip);

        $conf = [
            'conf_id'    =>  $domain . "-static",
            'name'       =>  $domain,
            'type'       =>  "static",
            'response'   =>  $response,
            'last_update'=>  gmt_withTZ()
        ];

        $result = $this->repository->insertConf($conf, $conf['conf_id']);
        if ($result) {
            return Finalsuccess();
        }
        return Finalfail(REP_CODE_ES_ERROR, "数据库操作失败");
    }

    /**
     * @SWG\Delete(
     *      path="/dnsnodes/{id}/static",
     *      tags={"dnsnode DNS节点"},
     *      summary="【删除】DNS静态解析配置",
     *      @SWG\Parameter(
     *          name="",
     *          in="body",
     *          description="DNS静态解析配置ID数组",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"ids": {"333.com-static", "fly.cn-static"}}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 删除成功| !=0 删除失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     */
    public function bundleDelete()
    {
        $data = input();
        if (!$this->validator->scene('bundle_delete')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        $result = $this->repository->bundleDelete($data['ids']);
        if (!$result) {
            return Finalfail(REP_CODE_ES_ERROR, "数据库操作失败");
        }
        return Finalsuccess();
    }
}
