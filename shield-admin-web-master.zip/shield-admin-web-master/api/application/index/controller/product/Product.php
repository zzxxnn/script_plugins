<?php

namespace app\index\controller\product;

use app\index\controller\Base;
use app\index\repository\ProductRepository;
use app\index\validate\Product as ProductValidate;
use think\Request;

/**
 * Class Product
 *
 * @package app\index\controller
 * @author Teddy Sun <sgsheg@163.com>
 */
class Product extends Base
{
    /**
     *
     * @SWG\Get(
     *      path="/product",
     *      tags={"product 商品管理"},
     *      summary="【获取】 商品列表",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok", "data": {{"id": "xXgZbWQBkdRoYao1huSl","product_id": 1,"product_name": "网站共享","product_type": "实例","product_description": "网站防护专用实例","on_sale": 1,"attributes": {{"name": "area","label": "地区","type": "离散属性","description": ""}, {"name": "line","label": "线路","type": "离散属性","description": ""}, {"name": "base_bandwidth","label": "保底带宽","type": "离散计费属性","description": ""}, {"name": "normal_bandwidth","label": "业务宽带","type": "离散属性","description": ""}, {"name": "bandwidth","label": "弹性宽带","type": "用后计费属性","description": ""}, {"name": "site_count","label": "防护域名数","type": "连续计费属性","description": ""}, {"name": "sp_num","label": "购买数量","type": "倍率计算属性","description": ""}, {"name": "sp_time","label": "购买时长","type": "倍率计算属性","description": ""}},"created_by": "admin@veda.com","create_time": "2018-07-06T00:59:04.000Z"}}, "total": 1}
     *          )
     *      )
     * )
     *
     * 获取商品列表
     *
     * @param \app\index\repository\ProductRepository $productRepository
     * @return \think\Response
     * @throws \Exception
     */
    public function index(ProductRepository $productRepository)
    {
        $must = [];

        // 分页相关
        $from = input('_from', 0);
        $size = input('_size', 10);

        //产品关键字
        $productText = input('product_name', null);
        if ($productText) {
            $must[] = ['regexp' => ['product_name.keyword' => ".*$productText.*"]];
        }

        // 产品类型
        $type = input('product_type', null);
        if ($type) {
            $must[] = ['term' => ['product_type' => $type]];
        }

        // 产品状态
        $status = input('on_sale', null);
        if (isset($status)) {
            $must[] = ['term' => ['on_sale' => $status]];
        }

        $filter   = [
            'query' => ['bool' => ['must' => $must]],
            'sort'  => [['product_id' => ['order' => 'desc']]], //按照生成的product_id倒序
        ];
        $supports = $productRepository->all($filter, $from, $size);
        $total    = $productRepository->count($filter);

        return Finalsuccess(['data' => $supports, 'total' => $total]);
    }

    /**
     *
     * @SWG\Post(path="/product",tags={"product 商品管理"},
     *      summary="【新增】 商品",
     *      description="商品添加接口",
     *      @SWG\Parameter(name="product_name",type="string",required=true,in="formData",
     *          description="商品标题"
     *      ),
     *      @SWG\Parameter(name="product_type",type="string",required=true,in="formData",
     *          description="商品类型"
     *      ),
     *      @SWG\Parameter(name="product_description",type="string",required=false,in="formData",
     *          description="商品描述"
     *      ),
     *      @SWG\Parameter(name="on_sale",type="integer",required=true,in="formData",
     *          default="1",
     *          description="上下架 1是上架;2是下架"
     *      ),
     *      @SWG\Parameter(name="attributes",type="array",required=false,in="formData",
     *          @SWG\Items(type="string"),
     *          description="属性"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      ),
     * )
     *
     * 新增商品
     *
     * @param ProductRepository $productRepository
     * @param ProductValidate   $validate
     *
     * @return string
     */
    public function create(ProductRepository $productRepository, ProductValidate $validate)
    {
        if ($this->request->isPost()) {
            $data = input();

            $checkResult = $validate->scene('add')->check($data);

            if (! $checkResult) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validate->getError());
            }

            if ($productRepository->checkExist($data)) {
                $maxProductId        = (int) $productRepository->getMaxProductId();
                $data['create_time'] = gmt_withTZ();
                $data['create_by']   = get_uid();
                $data['product_id']  = $maxProductId + 1;

                $result = $productRepository->create($data);
                if (! $result) {
                    return Finalfail(REP_CODE_DB_ERROR, '添加失败,请重试!');
                }
                return Finalsuccess(['data' => $data]);
            }
        }
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
    }

    /**
     *
     * @SWG\Get(path="/product/{id}",tags={"product 商品管理"},
     *      summary="获取商品详情",
     *      @SWG\Parameter(name="id",type="integer",required=true,in="query",
     *          description="产品product-Id",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"id": "z3jJbmQBkdRoYao1zeSd","product_id": 1,"product_name": "网站共享","product_type": "实例","product_description": "网站防护专用实例","on_sale": 1,"attributes": {{"name": "area","label": "地区","type": "离散属性","description": ""},{"name": "line","label": "线路","type": "离散属性","description": ""},{"name": "base_bandwidth","label": "保底带宽","type": "离散计费属性","description": ""},{"name": "normal_bandwidth","label": "业务宽带","type": "离散属性","description": ""},{"name": "bandwidth","label": "弹性宽带","type": "用后计费属性","description": ""},{"name": "site_count","label": "防护域名数","type": "连续计费属性","description": ""},{"name": "sp_num","label": "购买数量","type": "倍率计算属性","description": ""},{"name": "sp_time","label": "购买时长","type": "倍率计算属性","description": ""}},"created_by": "admin@veda.com","create_time": "2018-07-06T08:51:14.000Z"}}
     *          )
     *      )
     * )
     *
     * 获取实例详情
     *
     * @param $id
     * @return string
     * @throws \Exception
     */
    public function show(ProductValidate $validate, ProductRepository $productRepository, $id)
    {
        $data = input();

        $checkResult = $validate->scene('show')->check($data);

        if (true !== $checkResult) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $validate->getError());
        }

        $filter = ['query' => ['term' => ['product_id' => (int) $id]]];

        $product = $productRepository->findBy($filter);

        if (! $product) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到记录');
        }

        return Finalsuccess(['data' => $product[0]]);
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * @SWG\Put(path="product/{id}",tags={"product 商品管理"},
     *      summary="【修改】商品信息",
     *      @SWG\Parameter(name="product_name",type="string",required=false,in="formData",
     *          description="商品标题"
     *      ),
     *      @SWG\Parameter(name="product_type",type="string",required=false,in="formData",
     *          description="商品类型"
     *      ),
     *      @SWG\Parameter(name="product_description",type="string",required=false,in="formData",
     *          description="商品描述"
     *      ),
     *      @SWG\Parameter(name="on_sale",type="integer",required=false,in="formData",
     *          default="1",
     *          description="上下架 1是上架;2是下架"
     *      ),
     *      @SWG\Parameter(name="attributes",type="array",required=false,in="formData",
     *          @SWG\Items(type="string"),
     *          description="属性"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"修改成功"}
     *          )
     *      )
     * )
     *
     * @param $id
     * @param \app\index\repository\ProductRepository $productRepository
     * @param \app\index\validate\Product $productValidate
     * @return String
     */
    public function update($id, ProductRepository $productRepository, ProductValidate $productValidate)
    {
        if ($this->request->isPut()) {
            //验证
            $data        = input();
            $checkResult = $productValidate->scene('edit')->check($data);

            if (true !== $checkResult) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $productValidate->getError());
            }

            $support = $productRepository->find($id);

            if (! $support) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '当前商品记录不存在');
            }

            $mustNot = ['term' => ['_id' => $id]];

            if ($productRepository->checkExist($data, $mustNot)) {
                //修改时间
                $data['update_time'] = gmt_withTZ();

                $result = $productRepository->update($data, $id);
                if (! $result) {
                    return Finalfail(REP_CODE_DB_ERROR, '修改失败,请重试!');
                }
                return Finalsuccess();
            }
        }
    }

    /**
     *
     * @SWG\Delete(path="/product",tags={"product 商品管理"},
     *      summary="【删除】 商品",
     *      @SWG\Parameter(name="ids",in="formData",type="array",
     *          @SWG\Items(
     *              type="string"
     *          ),
     *          description="商品ids"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok", "data": {}})
     *      )
     * )
     *
     * @param \app\index\validate\Product             $productValidate
     * @param \app\index\repository\ProductRepository $productRepository
     *
     * @return string
     * @throws \app\common\exception\RepositoryException
     */
    public function bundleDelete(ProductValidate $productValidate, ProductRepository $productRepository)
    {
        if ($this->request->isDelete()) {
            $data = input();

            $checkResult = $productValidate->scene('delete')->check($data);

            if (true !== $checkResult) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $productValidate->getError());
            }

            //如果选中的商品下面有定价管理信息那么就不允许进行删除

            if (true === $productRepository->allowDelete($data['ids'])) {
                //开始删除
                $result = $productRepository->multipleDelete($data['ids']);
                if (! $result) {
                    return Finalfail(REP_CODE_DB_ERROR, '删除失败,请重试.');
                }
                return Finalsuccess();
            } else {
                return Finalfail(REP_CODE_PRODUCT_ATTRIBUTES_EXIST, '请先删除该商品下的相关定价');
            }
        }
    }
}