<?php

namespace app\index\controller\product;

use app\common\exception\RepositoryException;
use app\index\controller\Base;
use app\index\repository\ProductRepository;
use app\index\repository\ProductSkuRepository;
use app\index\validate\ProductSku as SkuValidate;
use think\Request;

/**
 * Class ProductSku
 *
 * @package app\index\controller\product
 * @author Teddy Sun <sgsheg@163.com>
 */
class ProductSku extends Base
{
    protected $product;

    public function _initialize()
    {
        try {
            $productRepository = new ProductRepository();
            $id                = $this->request->param('id', 1, 'intval');
            $filter            = ['query' => ['term' => ['product_id' => (int) $id]]];

            $this->product = $productRepository->findBy($filter);

            if (! $this->product) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到记录');
            }
        } catch (RepositoryException $e) {
            return Finalfail(REP_CODE_ABNORMAL_OPERATION, '操作异常');
        }
    }

    /**
     *
     * @SWG\Get(path="/product/{id}/sku",tags={"sku 定价管理"},
     *      summary="【获取】 商品定价",
     *      @SWG\Parameter(name="id",in="query",required=true, type="integer",
     *          description="产品product-id"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok", "data":{}}
     *          )
     *      )
     * )
     *
     * 显示资源列表
     *
     * @param $id
     * @param \app\index\repository\ProductSkuRepository $skuRepository
     * @return string
     * @throws \Exception
     */
    public function index($id, ProductSkuRepository $skuRepository)
    {
        $must = [];
        // 分页相关
        $from = input('_from', 0);
        $size = input('_size', 10);

        $must[] = ['term' => ['product_id' => (int) $id]];

        $filter     = [
            'query' => ['bool' => ['must' => $must]],
            'sort'  => [['create_time' => ['order' => 'desc']]],
        ];
        $productSku = $skuRepository->all($filter, $from, $size);
        //todo:优化
        foreach($productSku as &$sku) {
            if (isset($sku['sku'])) {
                $sku['id'] = $sku['sku'];
            } else {
                $sku['sku'] = $sku['id'];
            }
        }
        unset($sku);

        $total      = $skuRepository->count($filter);

        return Finalsuccess(['data' => $productSku, 'total' => $total]);
    }

    /**
     *
     * @SWG\Post(path="product/{id}/sku", tags={"sku 定价管理"},
     *     summary="【保存】 商品定价",
     *     @SWG\Parameter(name="id",in="query",required=true, type="integer",
     *          description="产品product-id"
     *     ),
     *     @SWG\Response(
     *         response="200",
     *         description="errcode: 0 正常| !=0 异常",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *         )
     *     )
     * )
     *
     * @param                                            $id
     * @param \app\index\validate\ProductSku             $validate
     * @param \app\index\repository\ProductSkuRepository $skuRepository
     *
     * @return string
     */
    public function create($id, SkuValidate $validate, ProductSkuRepository $skuRepository)
    {
        if ($this->request->isPost()) {
            $data = input();

            if (! $validate->scene('add')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validate->getError());
            }

            //检查区域和线路对应的sku是否已存在
            if ($skuRepository->checkAreaAndLineExist($id, $data)) {
                unset($data['id']);

                $data['create_time'] = gmt_withTZ();
                $data['create_by']   = get_uid();
                $data['product_id']  = (int) $id;
                $data['price_id']    = (int) $skuRepository->getMaxPriceId() + 1;
                $data['stock']       += 0;  //库存

                $result = $skuRepository->create($data);
                if (! $result) {
                    return Finalfail(REP_CODE_DB_ERROR, '添加失败,请重试!');
                }
                return Finalsuccess(['data' => $data]);
            }
        }
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
    }

    /**
     *
     * @SWG\Get(path="product/{id}/sku/{sku}", tags={"sku 定价管理"},
     *     summary="【查看】 sku详情",
     *     @SWG\Parameter(name="id",in="query",required=true, type="integer",
     *          description="产品product-id"
     *     ),
     *     @SWG\Parameter(name="sku",in="query",required=true, type="string",
     *          description="sku_id"
     *     ),
     *     @SWG\Response(
     *         response="200",
     *         description="errcode: 0 正常| !=0 异常",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok", "data":{}}
     *         )
     *     )
     * )
     */
    public function show($id, $sku, ProductSkuRepository $productSkuRepository)
    {
        if (isset($sku)) {
            $data = $productSkuRepository->find($sku);

            if (! $data) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到记录');
            }

            return Finalsuccess(['data' => $data]);
        }
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     *
     * @SWG\Put(path="product/{id}/sku/{sku}", tags={"sku 定价管理"},
     *     summary="【修改】 商品定价",
     *     @SWG\Parameter(name="id",in="query",required=true, type="integer",
     *          description="产品product-id"
     *     ),
     *     @SWG\Parameter(name="sku",in="query",required=true, type="string",
     *          description="sku"
     *     ),
     *     @SWG\Response(
     *         response="200",
     *         description="errcode: 0 正常| !=0 异常",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *         )
     *     )
     * )
     * @param                                            $id
     * @param \app\index\validate\ProductSku             $validate
     * @param \app\index\repository\ProductSkuRepository $skuRepository
     *
     * @return string
     */
    public function update($id, $sku, SkuValidate $validate, ProductSkuRepository $skuRepository)
    {
        if ($this->request->isPut()) {
            $data = input();
            if (isset($data['id'])) {
                unset($data['id']);
            }
            if (isset($data['sku'])) {
                unset($data['sku']);
            }
            //库存
            if (isset($data['stock'])) {
                $data['stock'] += 0;
            }
            if (! $validate->scene('edit')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validate->getError());
            }

            $data['update_time'] = gmt_withTZ();

            $skuRecord = $skuRepository->find($sku);

            if (! $skuRecord) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到记录');
            }

            $result = $skuRepository->update($data, $sku);
            if (! $result) {
                return Finalfail(REP_CODE_DB_ERROR, '更新失败,请重试!');
            }
            return Finalsuccess();
        }
    }

    /**
     * 删除指定资源
     *
     * @param  int
     * @return \think\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     *
     * @SWG\Delete(path="/product/{id}/sku",tags={"sku 定价管理"},
     *      summary="【删除】 商品定价",
     *      @SWG\Parameter(name="ids",in="formData",required=true,type="array",
     *          @SWG\Items(
     *              type="string"
     *          ),
     *          description="sku ids"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok", "data": {}})
     *      )
     * )
     *
     * @param \app\index\validate\ProductSku             $validate
     * @param \app\index\repository\ProductSkuRepository $productRepository
     *
     * @return string
     */
    public function bundleDelete(SkuValidate $validate, ProductSkuRepository $productRepository)
    {
        if ($this->request->isDelete()) {
            $data = input();

            $checkResult = $validate->scene('delete')->check($data);

            if (true !== $checkResult) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validate->getError());
            }
            //开始删除
            $result = $productRepository->multipleDelete($data['ids']);

            if (! $result) {
                return Finalfail(REP_CODE_DB_ERROR, '删除失败,请重试!');
            }
            return Finalsuccess();
        }
    }

    /**
     *
     * @SWG\Get(path="/product/{id}/attributes",tags={"sku 定价管理"},
     *      summary="【获取】 商品自定义属性",
     *      @SWG\Parameter(name="id",in="query",required=true, type="integer",
     *          description="产品product-id"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok", "data":{}}
     *          )
     *      )
     * )
     */
    public function getAttributes()
    {
        $product = $this->product;

        return Finalsuccess(['data' => $product[0]['attributes']]);
    }
}