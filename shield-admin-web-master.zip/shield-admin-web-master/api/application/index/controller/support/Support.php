<?php

namespace app\index\controller\support;

use app\index\controller\Base;
use app\index\repository\SupportRepository;
use app\index\validate\Support as SupportValidate;
use think\Request;

/**
 * Class Support 支持管理
 *
 * @package app\index\controller
 * @author Teddy Sun <sgsheg@163.com>
 */
class Support extends Base
{
    /**
     * @SWG\Get(
     *      path="support",
     *      tags={"support 支持人员管理"},
     *      summary="【获取】人员列表",
     *      @SWG\Parameter(
     *          name="type",
     *          in="query",
     *          description="类型:1销售,2技术",
     *          type="integer"
     *      ),
     *      @SWG\Parameter(
     *          name="status",
     *          in="query",
     *          description="状态:1正常,2不正常",
     *          type="integer"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{{"id": "GT8vO2QBw5XrXgev8Yps","name": "李四","nickname": "四儿","mobile": 18610875206,"qq": 1621125714,"wechat": 18610875206,"email": "sunhaolei@gmail.com","type": 2,"type_name": "技术","status": 1,"avatar": "/avatar/support-user2.png","create_time": "2018-06-26T08:19:57.000Z"}}}
     *          )
     *      )
     * )
     *
     * @param \app\index\repository\SupportRepository $supportRepository
     * @return \think\Response
     * @throws \Exception
     */
    public function index(SupportRepository $supportRepository)
    {
        $must = [];

        // 分页相关
        $from = input('_from', 0);
        $size = input('_size', 10);

        // 根据订单类型查询： 1 - ,2 - 消费
        $type = input('type', null);
        if ($type) {
            $must[] = ['term' => ['type' => $type]];
        }

        // 支持状态
        $status = input('status', null);
        if (isset($status)) {
            $must[] = ['term' => ['status' => $status]];
        }

        $filter   = [
            'query' => ['bool' => ['must' => $must]],
            'sort'  => [['create_time' => ['order' => 'desc']]],
        ];
        $supports = $supportRepository->all($filter, $from, $size);
        foreach ($supports as $key => $support) {
            if (isset($support['create_time'])) {
                $support['create_time'] = format_time(strtotime($support['create_time']));
                unset($support[$key]);
                $supports[$key] = $support;
            }
        }
        $total    = $supportRepository->count($filter);

        return Finalsuccess(['data' => $supports, 'total' => $total]);
    }

    /**
     * @SWG\Post(
     *      path="support",
     *      tags={"support 支持人员管理"},
     *      summary="【新增】人员信息",
     *      @SWG\Parameter(
     *          name="avatar",
     *          in="query",
     *          type="string",
     *          description="头像",
     *      ),
     *      @SWG\Parameter(
     *          name="name",
     *          in="query",
     *          type="string",
     *          description="名称",
     *      ),
     *      @SWG\Parameter(
     *          name="mobile",
     *          in="query",
     *          type="string",
     *          description="手机号码",
     *      ),
     *      @SWG\Parameter(
     *          name="qq",
     *          in="query",
     *          type="string",
     *          description="QQ号码",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * 新增支持人员
     *
     * @param \app\index\repository\SupportRepository $supportRepository
     * @param \app\index\validate\Support             $supportValidate
     *
     * @return string
     */
    public function create(SupportRepository $supportRepository, SupportValidate $supportValidate)
    {
        if ($this->request->isPost()) {
            //验证
            $data        = input();
            $checkResult = $supportValidate->scene('add')->check($data);

            if (true !== $checkResult) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $supportValidate->getError());
            }

            if ($supportRepository->checkExist($data)) {
                $data['create_time'] = gmt_withTZ();
                $data['status']      = 1;
                $data['type']        = 2;

                $result = $supportRepository->create($data);
                if (! $result) {
                    return Finalfail(REP_CODE_DB_ERROR, '添加失败,请重试!');
                }
                return Finalsuccess();
            }
        }
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request
     * @return \think\Response
     */
    public function save(Request $request)
    {

    }

    /**
     * @SWG\Get(
     *      path="support/{id}",
     *      tags={"support 支持人员管理"},
     *      summary="【查看】人员信息",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"name": "技术1号","nickname": "技术1号","mobile": 18610875206,"qq": 1621125714,"wechat": 18610875206,"email": "sunhaolei@gmail.com","type": 2,"type_name": "技术","status": 1,"avatar": "/avatar/support-user2.png","create_time": "2018-07-02T07:32:29.000Z"}}
     *          )
     *      )
     * )
     *
     * @param \app\index\repository\SupportRepository $supportRepository
     * @param $id
     * @return mixed
     */
    public function show(SupportRepository $supportRepository, $id)
    {
        $support = $supportRepository->find($id);

        if (! $support) {
            return Finalfail(REP_CODE_DB_ERROR, '未找到对应记录');
        }

        return Finalsuccess(['data' => $support]);
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * @SWG\Put(
     *      path="support/{id}",
     *      tags={"support 支持人员管理"},
     *      summary="【修改】人员信息",
     *      @SWG\Parameter(
     *          name="avatar",
     *          in="query",
     *          type="string",
     *          description="头像",
     *      ),
     *      @SWG\Parameter(
     *          name="name",
     *          in="query",
     *          type="string",
     *          description="名称",
     *      ),
     *      @SWG\Parameter(
     *          name="mobile",
     *          in="query",
     *          type="string",
     *          description="手机号码",
     *      ),
     *      @SWG\Parameter(
     *          name="qq",
     *          in="query",
     *          type="string",
     *          description="QQ号码",
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"修改成功"}
     *          )
     *      )
     * )
     *
     * 保存更新的资源
     *
     * @param  \think\Request
     * @param  int
     * @return \think\Response
     */
    public function update(SupportRepository $supportRepository, SupportValidate $supportValidate, $id)
    {
        if ($this->request->isPut()) {
            //验证
            $data        = input();
            $checkResult = $supportValidate->scene('edit')->check($data);

            if (true !== $checkResult) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $supportValidate->getError());
            }

            $support = $supportRepository->find($id);

            if (! $support) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到记录');
            }

            $mustNot = ['term' => ['_id' => $id]];

            if ($supportRepository->checkExist($data, $mustNot)) {
                //修改时间
                $data['update_time'] = gmt_withTZ();

                $result = $supportRepository->update($data, $id);
                if (! $result) {
                    return Finalfail(REP_CODE_DB_ERROR, '更新失败,请重试!');
                }
                return Finalsuccess();
            }
        }
    }

    /**
     * @param $id
     */
    public function delete($id)
    {

    }

    /**
     * 批量删除支持人员
     *
     * @param \app\index\repository\SupportRepository $repository
     * @param \app\index\validate\Support             $supportValidate
     *
     * @return string
     */
    public function bundleDelete(SupportRepository $repository, SupportValidate $supportValidate)
    {

        if ($this->request->isDelete()) {
            $data = input();

            $checkResult = $supportValidate->scene('delete')->check($data);

            if (true !== $checkResult) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $supportValidate->getError());
            }
            //开始删除
            $result = $repository->multipleDelete($data['ids']);
            if (! $result) {
                return Finalfail(REP_CODE_DB_ERROR, "数据库操作失败");
            }
            return Finalsuccess();
        }
    }
}