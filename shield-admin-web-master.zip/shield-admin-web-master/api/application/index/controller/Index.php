<?php

namespace app\index\controller;

use think\Controller;

class Index extends Controller
{
    public function index()
    {
        return view('index');
    }

    /**
     * @SWG\Get(
     *      path="app-version",
     *      tags={"index 首页"},
     *      summary="获取系统版本号",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":"v1.0.2.1"}
     *          )
     *      )
     * )
     *
     * 获取系统区域列表
     */
    public function appVersion()
    {
        $version = env('APP_VERSION','未知版本');
        return Finalsuccess($version);
    }
}