<?php

namespace app\index\controller;

use app\common\model\SiteModel;
use app\index\repository\UserappRepository;
use app\index\validate\Userapps as AppValidate;

class Site extends Base
{
    public function _initialize()
    {
        $this->validator  = new AppValidate();
        $this->repository = new UserappRepository();
    }

    /**
     * @SWG\Get(
     *      path="/usersites",
     *      tags={"usersite 网站防护"},
     *      summary="【获取】网站列表",
     *      @SWG\Parameter(name="_from", in="query", required=false, type="integer", description="查询范围开始"),
     *      @SWG\Parameter(name="_size", in="query", required=false, type="integer", description="查询数量"),
     *      @SWG\Parameter(name="type", in="query", required=false, type="string", description="网站类型，1/2（无此参数为所有网站）"),
     *      @SWG\Parameter(name="domain", in="query", required=false, type="string", description="查询域名，完全匹配（网站）"),
     *      @SWG\Parameter(name="proxy_ip", in="query", required=false, type="string", description="查询高防IP，完全匹配"),
     *      @SWG\Parameter(name="username", in="query", required=false, type="string", description="查询用户"),
     *      @SWG\Parameter(name="is_normal", in="query", required=false, type="boolean", description="查询用户正常接入的网站信息，true：筛选用户正常接入的网站信息，false：正常网站防护列表"),
     *      @SWG\Response(response="200", ref="#/definitions/Domainlist")
     * )
     */
    public function index()
    {
        $from = input('_from', 0);
        $size = input('_size', null);
        $must = [];

        $type = input('type', null);
        if (! is_null($type) && in_array($type, [0, 1, 2])) {
            $must[] = ['term' => ['type' => $type]];
        }

        $domain = input('domain', null);
        if (! is_null($domain)) {
            $must[] = ['wildcard' => ['app_id.keyword' => "*$domain*"]];
        }

        $proxy_ip = input('proxy_ip', null);
        if (! is_null($proxy_ip)) {
            $must[] = ['term' => ['proxy_ip.ip.keyword' => $proxy_ip]];
        }

        $username = input('username', null);
        if (! is_null($username)) {
            $must[] = ['term' => ['uid.keyword' => $username]];
        }

        // 从用户详情点击查看跳入网站防护列表，需查询该用户正常接入的网站防护信息
        $is_normal = input('is_normal', 'false');
        if ($is_normal != 'false') {
            $must[] = [ 'term' => [ 'status' => SiteModel::DOMAIN_STATUS_NORMAL ] ];
        }

        if (! empty($must)) {
            $filter['query']['bool']['must'][] = $must;
        }

        $should                              = [
            ['term' => ['type' => 0]],
            ['term' => ['type' => 1]],
            ['term' => ['type' => 2]]
        ];
        $filter['query']['bool']['should'][] = $should;
        $filter['sort'][] = [
            'last_update' => [
                'order' => 'desc'
            ]
        ];
        
        $list  = $this->repository->appList($filter, $from, $size);
        $total = $this->repository->countApps($filter);
        return Finalsuccess(['list' => $list, 'total' => $total]);
    }

    /**
     * @SWG\Delete(
     *      path="/usersites/delete",
     *      tags={"usersite 网站防护"},
     *      summary="【删除】网站",
     *      @SWG\Parameter(
     *          name="",
     *          in="body",
     *          description="站点ID数组",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"ids": {"test1.com", "test3.com"}}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 删除成功| !=0 删除失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     */
    public function bundleDelete()
    {
        $data = input();
        if (! $this->validator->scene('bundle_delete')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        $result = $this->repository->bundleDelete($data['ids']);
        if (! $result) {
            return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败');
        }
        return Finalsuccess();
    }
}
