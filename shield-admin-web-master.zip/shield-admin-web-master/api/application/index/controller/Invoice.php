<?php

namespace app\index\controller;

use app\common\model\InvoiceModel;
use app\common\repository\InvoiceRepository;
use app\common\validate\InvoiceValidator;
use app\index\service\Auth;
use think\Request;

class Invoice extends Base
{

    public function __construct(Request $request)
    {
        parent::__construct();

        $this->validator  = new InvoiceValidator();
        $this->repository = new InvoiceRepository();
    }

    /**
     * @SWG\Get(
     *      path="/invoice",
     *      tags={"Invoice 开票管理"},
     *      summary="【获取】开票列表",
     *      @SWG\Parameter(name="_from", in="query", required=false, type="integer", description="查询范围开始，分页数"),
     *      @SWG\Parameter(name="_size", in="query", required=false, type="integer", description="查询数量"),
     *      @SWG\Parameter(name="uuid", in="query", required=false, type="string", description="开票申请UUID"),
     *      @SWG\Parameter(name="order_id", in="query", required=false, type="integer", description="订单ID"),
     *      @SWG\Parameter(name="status", in="query", required=false, type="integer", description="开票状态，传值为search-config接口中循环key值"),
     *      @SWG\Parameter(name="start_date", in="query", required=false, type="integer", description="开始时间"),
     *      @SWG\Parameter(name="end_date", in="query", required=false, type="integer", description="结束时间"),
     *      @SWG\Parameter(name="user_email", in="query", required=false, type="integer", description="用户名"),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","list":{{"id":1,"uuid":"11808301026978","user_email":"test54814@veda.com","status":1,"create_time":"2018-08-25 15:25:51","amount":200}},"total":1}
     *          )
     *      )
     * )
     *
     * @return \think\Response
     * @throws \Exception
     */
    public function index()
    {
        $from = input('_from', 1);
        $size = input('_size', 10);
        $must = [];

        // 开票申请ID
        $uuid = input('uuid', null);
        if ($uuid) {
            $must['invoices.uuid'] = $uuid;
        }

        // 订单ID
        $order_id = input('order_id', null);
        if ($order_id) {
            $must['invoice_orders.order_id'] = $order_id;
        }

        // 开票状态
        $status = input('status', null);
        if (isset($status)) {
            $must['invoices.status'] = $status;
        }

        // 开始时间
        $start = input('start_date', null);
        if ($start) {
            $must['invoices.create_time'] = ['>=', $start];
        }

        // 结束时间
        $end = input('end_date', null);
        if ($end) {
            $must['invoices.create_time'] = ['<=', $end];
        }

        if ($start && $end) {
            $must['invoices.create_time'] = ['between', [$start, $end]];
        }

        //用户邮箱
        $user_email = input('user_email', null);
        if (isset($user_email)) {
            $must['invoices.user_email'] = ['like', '%' . $user_email . '%'];
        }

        $getList = $this->repository->getList($from, $size, $must);

        return Finalsuccess($getList);
    }

    /**
     * @SWG\Get(
     *      path="/invoice/{id}",
     *      tags={"Invoice 开票管理"},
     *      summary="【获取】用户开票详情",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"id":3,"uuid":"11808301026978","user_id":1,"user_email":"test54814@veda.com","system":"client","ivc_type":0,"ivc_numbers":null,"ivc_title":"北京卫达","ivc_tax_id":"123456789","ivc_address":"北京市","ivc_mobile":"18638121735","ivc_bank":"招商银行","ivc_account":"123456789","consignee_name":"叶肖肖","consignee_address":"郑州市大学科技园","consignee_mobile":"18638121735","track_ship_id":null,"track_company":null,"description":null,"create_time":"2018-08-25
     *              15:07:10","update_time":"2018-08-25
     *              15:07:10","delete_time":null,"logs":{{"id":3,"status":0,"create_time":"2018-08-25
     *              15:07:10"}},"orders":{{"id":3,"order_id":"11807031102581","order_type":1,"content":"技术服务费","fee":"100","final_fee":"0"},{"id":4,"order_id":"11805301538535","order_type":2,"content":"技术服务费","fee":"100","final_fee":"0"}}}}
     *          )
     *      )
     * )
     *
     *
     * @param $id
     *
     * @return string
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function show($id)
    {
        $invoice = $this->repository->getDetail($id);
        if ( ! $invoice) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到该订单的开票信息！');
        }

        return Finalsuccess([ 'data' => $invoice ]);
    }

    /**
     * @SWG\Put(
     *      path="/invoice/{id}/agree",
     *      tags={"Invoice 开票管理"},
     *      summary="【通过】开票审批通过",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 通过成功| !=0 通过失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     *
     * @return string
     * @throws \app\common\exception\RepositoryException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function agree()
    {
        $data = input();
        request()->bind('email', Auth::id());
        // 普通发票参数校验
        if ( ! $this->validator->scene('agree_invoice')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        $result = $this->repository->agree($data);
        if ($result) {
            return Finalsuccess();
        }

        return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败！');
    }

    /**
     * @SWG\Put(
     *      path="/invoice/{id}/track",
     *      tags={"Invoice 开票管理"},
     *      summary="【快递】开票审批快递",
     *     @SWG\Parameter(
     *         name="track_ship_id",
     *         in="body",
     *         description="快递单号",
     *         required=true,
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example="快递单号"
     *          )
     *     ),
     *     @SWG\Parameter(
     *         name="track_company",
     *         in="body",
     *         description="快递公司",
     *         required=true,
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example="快递公司"
     *          )
     *     ),
     *     @SWG\Parameter(
     *         name="ivc_numbers",
     *         in="body",
     *         description="发票号",
     *         required=true,
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example="101,102"
     *          )
     *     ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 拒绝成功| !=0 拒绝失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     *
     * @return string
     * @throws \app\common\exception\RepositoryException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function track()
    {
        $data = input();
        request()->bind('email', Auth::id());
        // 普通发票参数校验
        if ( ! $this->validator->scene('agree_invoice')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        $result = $this->repository->track($data);
        if ($result) {
            return Finalsuccess();
        }

        return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败！');
    }

    /**
     * @SWG\Put(
     *      path="/invoice/{id}/reject",
     *      tags={"Invoice 开票管理"},
     *      summary="【拒绝】开票审批拒绝",
     *     @SWG\Parameter(
     *         name="description",
     *         in="body",
     *         description="拒绝理由",
     *         required=true,
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example="拒绝理由"
     *          )
     *     ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 拒绝成功| !=0 拒绝失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * @return string
     * @throws \app\common\exception\RepositoryException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function reject()
    {
        $data = input();
        request()->bind('email', Auth::id());
        // 普通发票参数校验
        if ( ! $this->validator->scene('reject_invoice')->check(input())) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        $result = $this->repository->reject($data);
        if ($result) {
            return Finalsuccess();
        }

        return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败！');
    }

    /**
     * @SWG\Get(
     *      path="/invoice/search-config",
     *      tags={"Invoice 开票管理"},
     *      summary="【获取】开票搜索状态项",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"待申请","待审批","已通过","快递中","已完成","已拒绝"}}
     *          )
     *      )
     * )
     *
     * @return string
     */
    public function searchConfig()
    {
        return Finalsuccess(['data' => InvoiceModel::INVOICE_STATUS_INDEX_ARR]);
    }
}
