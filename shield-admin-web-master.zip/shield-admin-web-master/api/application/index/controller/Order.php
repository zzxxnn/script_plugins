<?php

namespace app\index\controller;

use app\client\repository\OrderRepository as ClientOrderRepository;
use app\client\repository\SupportRepository;
use app\client\validate\Order as OrderValidator;
use app\common\model\OrderModel;
use app\common\repository\OrderRepository;
use app\common\repository\UserRepository;
use app\common\service\MailService;
use app\common\service\NotifierService;
use app\index\service\Auth as AuthService;
use app\index\validate\OrderValidate;
use Carbon\Carbon;
use think\Request;

/**
 * Class Order B端订单控制器
 *
 * @package app\index\controller
 * @author Teddy Sun <sgsheg@163.com>
 */
class Order extends Base
{
    /**
     * @SWG\Get(
     *      path="/order",
     *      tags={"Order 订单管理"},
     *      summary="获取订单列表 todo:过滤谁的订单",
     *      @SWG\Parameter(name="type",in="query",type="integer",
     *          description="类型:1-充值;2-消费"
     *      ),
     *      @SWG\Parameter(name="status",in="query",type="integer",
     *          description="支付状态:0-未支付；1-已支付；2-已作废"
     *      ),
     *      @SWG\Parameter(name="start_date",in="query",type="integer",
     *          description="开始时间戳"
     *      ),
     *      @SWG\Parameter(name="end_date",in="query",type="integer",
     *          description="结束时间戳"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          @SWG\Property(
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{{"uid":"test@veda.com","oid":"11808271409542","type":2,"type_attr":"消费","create_time":"2018-08-27 14:09:25","status":0,"status_attr":"已创建","fee":40,"final_fee":40,"invoice_status":0,"invoice_content":"技术服务费"}},"total":1}
     *          )
     *      )
     * )
     *
     * 显示资源列表
     *
     * @param \app\common\repository\OrderRepository $orderRepository
     * @return \think\Response
     * @throws \Exception
     */
    public function index(OrderRepository $orderRepository)
    {
        $must = [];

        // 分页相关
        $from = input('_from', 0);
        $size = input('_size', 10);

        // 根据订单类型查询： 1 - 充值,2 - 消费
        $type = input('type', null);
        if ($type) {
            $must[] = ['term' => ['type' => $type]];
        }

        // 订单状态 [0,1,2]
        $status = input('status', null);
        if (isset($status)) {
            $must[] = ['term' => ['status' => $status]];
        }

        // 开始时间
        $start = input('start_date', null);
        if ($start) {
            $must[] = ['range' => ['create_time' => ['gte' => $start]]];
        }

        // 结束时间
        $end = input('end_date', null);
        if ($end) {
            $must[] = ['range' => ['create_time' => ['lte' => $end]]];
        }

        //过滤订单号
        $orderId = input('oid', null);
        if ($orderId) {
            $must[] = ['term' => ['_id' => $orderId]];
        }
        // 过滤用户
        $userId = input('uid', null);
        if ($userId) {
            $must[] = ['wildcard' => ['uid.keyword' => "*$userId*"]];
        }

        $filter = [
            'query' => ['bool' => ['must' => $must]],
            'sort'  => [['create_time' => ['order' => 'desc']]],
        ];
        $orders = $orderRepository->getOrderList($filter, $from, $size);
        foreach ($orders as &$order) {
            $order['create_time'] = format_time(strtotime($order['create_time']));
            $order['status_attr'] = OrderModel::statusArray[$order['status']] ?? '未知';
            $order['oid'] = (int)$order['oid'];
        }
        unset($order);

        $count = $orderRepository->count($filter);

        return Finalsuccess(['data' => $orders, 'total' => $count]);
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
    }

    /**
     * @SWG\Get(
     *      path="/order/{id}",
     *      tags={"Order 订单管理"},
     *      summary="获取订单详情",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="订单号",
     *          type="integer"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          @SWG\Property(
     *              type="object",
     *              example={"errcode": 0,"errmsg": "ok","data": {"type": 1,"fee": 10,"detail": {"product_id": 0,"start_date": false,"end_date": false,"fee": 10,"bandwidth": "0Gb","base_bandwidth": "0Gb","normal_bandwidth": "0M"},"create_time": "2018-06-25 11:28:13","pay_time": "2018-06-25 11:28:31","status": 1,"uid": "test@veda.com","last_update": "2018-06-25 11:28:31","oid": "11806251128848"}}
     *          )
     *      )
     * )
     *
     * @param $id
     * @param \app\common\repository\OrderRepository $orderRepository
     * @return string
     * @throws \app\common\exception\RepositoryException
     */
    public function show($id, OrderRepository $orderRepository)
    {
        $order = $orderRepository->getOrderDetail($id);
        if (! $order) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到记录');
        }

        return Finalsuccess(['data' => $order]);
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     *
     * @SWG\PUT(
     *      path="/order/{id}",
     *      tags={"Order 订单管理"},
     *      summary="修改订单详情",
     *      @SWG\Parameter(name="password",type="string",required=true,in="formData",
     *          description="管理员密码"
     *      ),
     *      @SWG\Parameter(name="final_fee",type="number",required=false,in="formData",
     *          description="修改后价格"
     *      ),
     *      @SWG\Parameter(name="discount",type="number",required=false,in="formData",
     *          description="折扣"
     *      ),
     *      @SWG\Parameter(name="approved_by",type="string",required=false,in="formData",
     *          description="审批人"
     *      ),
     *      @SWG\Parameter(name="approve_number",type="string",required=false,in="formData",
     *          description="审批单号"
     *      ),
     *      @SWG\Parameter(name="contract_number",type="string",required=false,in="formData",
     *          description="合同编号"
     *      ),
     *      @SWG\Parameter(name="approval_sheet",type="string",required=false,in="formData",
     *          description="审批单"
     *      ),
     *      @SWG\Parameter(name="contract_sheet",type="string",required=false,in="formData",
     *          description="合同单"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 修改成功| !=0 修改失败",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * 修改订单价格
     *
     * @param \app\index\validate\OrderValidate $validate
     * @param $id
     * @return String
     * @throws \app\common\exception\RepositoryException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function update(OrderRepository $orderRepository, OrderValidate $validate, $id)
    {
        $order = $this->getOrderExists($id);

        //数据是否完善
        $data = input();
        if (! $validate->scene('edit')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $validate->getError());
        }
        //比对密码
        $user = model('app\common\model\UserModel')->where(['username' => AuthService::id()])->find();
        $comparePasswordResult = password_verify($data['password'], $user['password']);
        if (! $comparePasswordResult) {
            return Finalfail(REP_CODE_PASSWORD_ERROR, '密码错误');
        }

        //判断修改后的价格或折扣
        if (isset($data['final_fee'])) {
            $data['final_fee'] = (int)$data['final_fee'];
            //修改后的价格大于订单价格
            if ($data['final_fee'] - $order['fee'] > 0) {
                return Finalfail(REP_CODE_ORDER_TOO_MUCH_DISCOUNT_FEE, '优惠价格不能大于原订单金额');
            }
            $data['final_fee'] += 0;
        }
        if (isset($data['discount']) && !empty($data['discount'])) {
            $data['final_fee'] = $order['fee'] * $data['discount'] + 0;
        }
        //改完后价格为0
        if (empty($data['final_fee'])) {
            return Finalfail(REP_CODE_ORDER_ZERO_DISCOUNT_FEE, '优惠金额不能为空!');
        }
        //修改后的改价是否和订单的折后价相同,相同则返会
        if ($data['final_fee'] === $order['final_fee']) {
            return Finalsuccess(['data' => ['final_fee' => $order['final_fee']]]);
        }
        //开始更新订单数据
        if ($orderRepository->update($data, $id)) {
            return Finalsuccess(['data' => ['final_fee' => $order['final_fee']]]);
        }

        return Finalfail(REP_CODE_ES_ERROR, '修改订单失败,请重试.');
    }

    /**
     * 
     * @SWG\Delete(
     *      path="/order/{id}",
     *      tags={"Order 订单管理"},
     *      summary="作废订单",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="订单号",
     *          type="integer"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          @SWG\Property(
     *              type="object",
     *              example={"errcode": 0,"errmsg": "ok"}
     *          )
     *      )
     * )
     * 
     * 作废订单
     *
     * @param  int
     * @param OrderValidator $validator
     * @param ClientOrderRepository $repository
     * @return \think\Response
     * @throws \Exception
     */
    public function destroy($id, OrderValidator $validator, ClientOrderRepository $repository)
    {
        $order = $this->getOrderExists($id);

        if (! $validator->scene('delete_order')->check(input())) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
        }

        // 更新订单状态为已作废
        if (! $repository->deleteOrder($id)) {
            return Finalfail(REP_CODE_ES_ERROR, '订单作废失败！');
        }

        return Finalsuccess();
    }

    /**
     *
     * @SWG\Post(
     *      path="/order/{id}/remind",
     *      tags={"Order 订单管理"},
     *      summary="订单 发送提醒",
     *      @SWG\Parameter(name="user",in="body",required=true,type="array",
     *          description="客户",
     *          @SWG\Schema(
     *              @SWG\Property(property="email",type="string"),
     *              @SWG\Property(property="mobile",type="string")
     *          )
     *      ),
     *      @SWG\Parameter(name="password",in="body",required=true,type="string",
     *          description="密码",
     *          @SWG\Schema()
     *      ),
     *      @SWG\Parameter(name="support",in="body",required=false,type="array",
     *          description="技术支持",
     *          @SWG\Schema(
     *              @SWG\Property(property="email",type="string"),
     *              @SWG\Property(property="mobile",type="string")
     *          )
     *      ),
     *      @SWG\Parameter(name="sale",in="body",required=false,type="array",
     *          description="销售支持",
     *          @SWG\Schema(
     *              @SWG\Property(property="email",type="string"),
     *              @SWG\Property(property="mobile",type="string")
     *          )
     *      ),
     *      @SWG\Parameter(name="other",in="body",required=false,type="array",
     *          description="其他人员,最多输入10个联系人",
     *          @SWG\Schema(
     *              @SWG\Property(property="email",type="string"),
     *              @SWG\Property(property="mobile",type="string")
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 提醒成功| !=0 提醒失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * 给改价订单发送提醒
     *
     * @throws \app\common\exception\RepositoryException
     * @throws \PHPMailer\PHPMailer\Exception
     * @throws \Exception
     */
    public function remindOrder($id, OrderValidate $validate, OrderRepository $orderRepository)
    {
        if ($this->request->isPost()) {
            $order = $this->getOrderExists($id);

            //获取邮件短信模板
            list($emailTemplate, $smsTemplate) = $this->checkSendTemplate($order);

            if (isset($order['remind_time'])) {
                //检查订单是否进行了改价
                list($diffHour, $diffNextMinutes) = $this->getAllowSendTime($order);
                //判断上次时间和这次时间是否对等
                if (1 >= $diffHour) {
                    request()->bind('minutes', $diffNextMinutes);
                    return Finalfail(REP_CODE_ORDER_SEND_PAY_REMAIND_TOO_FREQUENTLY, $diffNextMinutes. '分钟后，可再次发送支付提醒');
                }
            }

            $data = input();
            //验证数据
            if (! $validate->scene('remind')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validate->getError());
            }
            if ($orderRepository->sendMessages($data, $order, $smsTemplate, $emailTemplate)) {
                //更新提醒发送时间
                if (! $orderRepository->update(['remind_time' => gmt_withTZ()], $order['order_id'])) {
                    Finalfail(REP_CODE_DB_ERROR, '操作失败,请重试.');
                }
                return Finalsuccess();
            }
            return Finalfail(REP_CODE_ORDER_SEND_PAY_REMAIND_FAIL, '支付提醒发送失败，请稍后再试');
        }

        return Finalfail(REP_CODE_ABNORMAL_OPERATION, '操作异常');
    }

    /**
     * @SWG\Get(
     *      path="/order/{id}/user",
     *      tags={"Order 订单管理"},
     *      summary="获取订单关联客户信息",
     *      @SWG\Parameter(
     *          name="id",
     *          in="query",
     *          description="订单号",
     *          type="integer"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          @SWG\Property(
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"user":{"email":"test@veda.com","mobile":"18610875205"},"support":{},"sale":{}}}
     *          )
     *      )
     * )
     * 获取客户相关信息
     *
     * @param \app\client\repository\SupportRepository $supportRepository
     * @param \app\common\repository\OrderRepository $orderRepository
     * @param \app\common\repository\UserRepository $userRepository
     * @param $id
     * @return string
     * @throws \Exception
     * @throws \app\common\exception\RepositoryException
     */
    public function showUserInfo(SupportRepository $supportRepository, OrderRepository $orderRepository, UserRepository $userRepository, $id)
    {
        $data = ['user' => [], 'support' => [], 'sale' => []];
        $order = $this->getOrderExists($id);
        $userId = $order['uid'];
        if ($userId) {
            //存在找不到用户的情况?那还发个毛价格提醒.
            $userInformation = $userRepository->find(['email' => $userId]);
            if (!$userInformation) {
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '找不到用户'. $userId . '有关记录');
            }
            $data['user']    = ['email' => $userInformation->email, 'mobile' => $userInformation->mobile];
        }

        //从es中获取第一条技术支持和销售支持 todo:技术人员和销售人员有问题.
        list($technicals, $sales) = $supportRepository->getSupport();
        $data['support'] = ['mobile' => $technicals[0]['mobile'] ?? '', 'email' => $technicals[0]['email'] ?? ''];
        $data['sale'] = ['mobile' => $sales['mobile'] ?? '', 'email' => $sales['email'] ?? ''];

        return Finalsuccess(['data' => $data]);
    }

    /**
     * 判断并返会订单信息
     *
     * @param integer $id
     * @return mixed
     * @throws \app\common\exception\RepositoryException
     */
    private function getOrderExists($id)
    {
        $orderRepository = new OrderRepository();
        $order = $orderRepository->getOrderDetail($id);
        if (! $order) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到订单记录');
        }
        //订单状态是否允许
        if ($order['status'] !== OrderModel::ORDER_STATUS_CREATED) {
            return Finalfail(REP_CODE_ABNORMAL_OPERATION, '您的订单无法进行改价操作，请检查订单状态');
        }

        return $order;
    }

    /**
     * 获取时间戳
     * @param $order
     * @return array
     */
    private function getAllowSendTime($order)
    {
        $now = Carbon::now();
        $dt = new Carbon($order['remind_time']);
        $diffHour = $now->diffInHours($dt);
        $nextSendTime = $dt->addHour(1);
        $diffNextMinutes = $nextSendTime->diffInMinutes($now);

        return [$diffHour, $diffNextMinutes];
    }

    /**
     * 检查订单状态返回对应邮件、短信模板
     * @param $order
     * @return array
     */
    private function checkSendTemplate($order)
    {
        if ($order['final_fee'] != $order['fee']) {
            return [MailService::ORDER_CHANGE,NotifierService::SMS_ORDER_CHANGE];
        }

        return [MailService::ORDER_CREATED,NotifierService::SMS_ORDER_CREATED];
    }
}