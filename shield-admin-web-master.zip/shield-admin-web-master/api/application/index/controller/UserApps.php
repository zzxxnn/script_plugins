<?php

namespace app\index\controller;

use app\common\model\SiteModel;
use app\index\repository\UserappRepository;
use app\index\validate\Userapps as UserappsValidate;
use think\Request;

class UserApps extends Base
{
    public function __construct(Request $request)
    {
        $this->validator  = new UserappsValidate();
        $this->repository = new UserappRepository();

        parent::__construct($request);
    }

    /**
     * @SWG\Get(
     *      path="/userapps",
     *      tags={"userapp 应用管理"},
     *      summary="【获取】应用列表",
     *      @SWG\Parameter(name="_from", in="query", required=false, type="integer", description="查询范围开始"),
     *      @SWG\Parameter(name="_size", in="query", required=false, type="integer", description="查询数量"),
     *      @SWG\Parameter(name="app_id", in="query", required=false, type="string", description="应用ID"),
     *      @SWG\Parameter(name="proxy_ip", in="query", required=false, type="string", description="查询高防IP，完全匹配"),
     *      @SWG\Parameter(name="proxy_port", in="query", required=false, type="string", description="查询转发端口，完全匹配"),
     *      @SWG\Parameter(name="server_ip", in="query", required=false, type="string", description="源站IP，完全匹配"),
     *      @SWG\Parameter(name="server_port", in="query", required=false, type="string", description="查询源站端口，完全匹配"),
     *      @SWG\Parameter(name="username", in="query", required=false, type="string", description="查询用户"),
     *      @SWG\Response(response="200", ref="#/definitions/Domainlist")
     * )
     */
    public function index()
    {
        $from = input('_from', 0);
        $size = input('_size', null);

        $app_id = input('app_id', null);
        if (! is_null($app_id)) {
            $must[] = ['wildcard' => ['app_id.keyword' => "*$app_id*"]];
        }

        $proxy_ip = input('proxy_ip', null);
        if (! is_null($proxy_ip)) {
            $must[] = ['wildcard' => ['proxy_ip.ip.keyword' => "*$proxy_ip*"]];
        }

        $proxy_port = input('proxy_port', null);
        if (! is_null($proxy_port)) {
            $must[] = ['term' => ['proxy_port' => $proxy_port]];
        }

        $server_ip = input('server_ip', null);
        if (! is_null($server_ip)) {
            $must[] = ['wildcard' => ['server_ip.keyword' => "*$server_ip*"]];
        }

        $server_port = input('server_port', null);
        if (! is_null($server_port)) {
            $must[] = ['term' => ['server_port' => $server_port]];
        }

        $username = input('username', null);
        if (! is_null($username)) {
            $must[] = ['term' => ['uid.keyword' => $username]];
        }

        //过滤应用型的.
        $must[] = ['term' => ['type' => SiteModel::USER_APP_TYPE_PORT]];
        $filter['query']['bool']['must'] = $must;
        
        $list  = $this->repository->appList($filter, $from, $size);
        foreach ($list as &$item) {
            $item['proxy_port'] = implode(',', (array)$item['proxy_port']);
        }

        $total = $this->repository->countApps($filter);
        return Finalsuccess(['list' => $list, 'total' => $total]);
    }

    /**
     * @SWG\Delete(
     *      path="/userapps/delete",
     *      tags={"userapp 应用管理"},
     *      summary="【删除】应用列表",
     *      @SWG\Parameter(
     *          name="",
     *          in="body",
     *          description="应用ID数组",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"ids": {"app-ddos-nLJh27a", "app-ddos-Hk8lV3D"}}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 删除成功| !=0 删除失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     */
    public function bundleDelete()
    {
        $data = input();
        if (! $this->validator->scene('bundle_delete')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        $result = $this->repository->bundleDelete($data['ids']);
        if (! $result) {
            return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败');
        }

        return Finalsuccess();
    }
}
