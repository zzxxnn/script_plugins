<?php

namespace app\index\controller;

use app\common\model\UserModel;
use app\index\service\Auth as AuthService;
use app\index\validate\Admins as AdminsValidate;

class Admins extends Base
{
    public function _initialize()
    {
        $this->validator  = new AdminsValidate();
    }

    /**
     * @SWG\Get(
     *      path="/admins",
     *      tags={"admin 管理员"},
     *      summary="【获取】管理员列表",
     *      @SWG\Parameter(name="_from", in="query", required=false, type="integer", description="查询范围开始"),
     *      @SWG\Parameter(name="_size", in="query", required=false, type="integer", description="查询数量"),
     *      @SWG\Parameter(name="username", in="query", required=false, type="string", description="查询管理员账户，完全匹配"),
     *      @SWG\Response(response="200", ref="#/definitions/Success")
     * )
     */
    public function index()
    {
        $from     = input('_from', 1);
        $size     = input('_size', 10);
        $username = input('username', null);

        $where = ['role' => UserModel::ADMIN_ROLE];

        if ($username) {
            $where['username'] = ['like', '%' . $username . '%'];
        }

        $getList = model('app\common\model\UserModel')->getListWithPage($from, $size, $where);

        return Finalsuccess($getList);
    }

    /**
     * @SWG\Post(
     *      path="/admins",
     *      tags={"admin 管理员"},
     *      summary="【添加】管理员",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="添加管理员",
     *          @SWG\Schema(
     *              @SWG\Property(property="username", type="string", example="veda", description="管理员账户"),
     *              @SWG\Property(property="password", type="string", example="veda2017", description="密码，八位，数字大小写字母")
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 成功| !=0 失败",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","id":12}
     *          )
     *      )
     * )
     */
    public function create()
    {
        if (! $this->validator->scene('add_admins')->check(input())) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        $userName = input('post.username');
        $password = input('post.password');

        //输入用户名是否已经存在于数据库
        if ($this->checkUserExist($userName)) {
            return Finalfail(REP_CODE_SOURCE_EXIST, '用户名已经存在');
        }

        $add = [
            'username'    => $userName,
            'password'    => password_hash($password, PASSWORD_DEFAULT),
            'agent_id'    => 0,
            'role'        => UserModel::ADMIN_ROLE,
            'email'       => $userName.'@veda.com',
            'avatar'      => 'avatar/support-user0.png',
            'real_name'   => '',
        ];
        //新增用户
        $result = model('app\common\model\UserModel')->add($add);
        if ($result) {
            return Finalsuccess(['id' => $result]);
        }
        return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败');
    }

    /**
     * @SWG\Put(
     *      path="/admins/{id}/password",
     *      tags={"admin 管理员"},
     *      summary="【修改】管理员密码",
     *      @SWG\Parameter(
     *          name="new_pwd",
     *          required=true,
     *          in="body",
     *          description="修改密码：",
     *          @SWG\Schema(
     *              @SWG\Property(property="new_pwd", type="string", example="veda2018"),
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     * @param $id
     *
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function password($id)
    {
        $new_pwd = input('put.new_pwd');
        if (! $this->validator->scene('update_pwd')->check(input())) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        $uid = AuthService::id();
        $user = UserModel::find($id);
        if (! $user) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '管理员不存在！');
        }

        if($uid != 'admin' && $user->username == 'admin'){
            return Finalfail(REP_CODE_PERMISSION_DENY, '禁止修改默认管理员');
        }

        $user->password = password_hash($new_pwd, PASSWORD_DEFAULT);
        if ($user->save()) {
            request()->bind('username', $user->username);
            return Finalsuccess();
        }

        return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败');
    }

    /**
     * @SWG\Put(
     *      path="/admins/{id}/username",
     *      tags={"admin 管理员"},
     *      summary="【修改】管理员用户名",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="修改用户名：",
     *          @SWG\Schema(
     *              @SWG\Property(property="new_uname", type="string", example="veda2018"),
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     * @param $id
     *
     * @return String
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function username($id)
    {
        $userName = input('put.new_uname');

        if (! $this->validator->scene('update_uname')->check(input())) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        $uid = AuthService::id();
        $user = UserModel::find($id);
        if (! $user) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '管理员不存在！');
        }
        
        if($user->username == 'admin'){
            return Finalfail(REP_CODE_PERMISSION_DENY, '禁止修改默认管理员');
        }

        if ($this->checkUserExist($userName)) {
            return Finalfail(REP_CODE_SOURCE_EXIST, '用户名已经存在');
        }
        
        $user->username = $userName;
        if ($user->save()) {
            request()->bind('username', $user->username);
            return Finalsuccess();
        }

        return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败');
    }

    /**
     * @SWG\Delete(
     *      path="/admins/delete",
     *      tags={"admin 管理员"},
     *      summary="【删除】管理员",
     *      @SWG\Parameter(
     *          name="",
     *          in="body",
     *          description="管理员ID数组",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"ids": {11, 12}}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 删除成功| !=0 删除失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     */
    public function bundleDelete()
    {
        $data = input();
        if (! $this->validator->scene('bundle_delete')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        $uid = AuthService::id();

        $result = UserModel::all($data['ids']);

        $delete_ids = [];
        foreach ($result->toArray() as $tmp) {
            if ($tmp['role'] !== 0) {
                return Finalfail(REP_CODE_PERMISSION_DENY, '禁止删除用户');
            }
            if ($tmp['username'] == 'admin') {
                return Finalfail(REP_CODE_PERMISSION_DENY, '禁止删除默认管理员');
            }
            if ($tmp['id'] == $uid) {
                return Finalfail(REP_CODE_PERMISSION_DENY, '禁止删除当前管理员');
            }
            $delete_ids[] = $tmp['id'];
        }

        $result = UserModel::where('id', 'in', $data['ids'])->delete();
        if (! $result) {
            return Finalfail(REP_CODE_DB_ERROR, '数据库操作失败');
        }

        return Finalsuccess();
    }

    /**
     * 检查用户是否存在
     *
     * @param $userName
     * @return bool
     */
    private function checkUserExist($userName)
    {
        //查找角色为0的admins是否已经存在这个username
        $list = model('app\common\model\UserModel')->getByField(['username' => $userName]);
        if ($list->count()) {
            return true;
        }

        return false;
    }
}
