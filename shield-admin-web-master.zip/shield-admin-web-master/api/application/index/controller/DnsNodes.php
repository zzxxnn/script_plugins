<?php

namespace app\index\controller;

use app\index\repository\DnsConfRepository;
use app\index\repository\DnsNodeRepository;
use app\index\repository\UserappRepository;
use app\index\validate\DnsNodes as DnsNodesValidate;

class DnsNodes extends Base
{
    use \app\index\traits\IpRange;
    use \app\index\traits\CheckNodeConf;

    public function _initialize()
    {
        $this->validator = new DnsNodesValidate();
        $this->repository = new DnsNodeRepository();
    }
    /**
     * @SWG\Get(
     *      path="/dnsnodes",
     *      tags={"dnsnode DNS节点"},
     *      summary="【获取】DNS节点列表",
     *      @SWG\Parameter(name="_from", in="query", required=false, type="integer", description="查询范围开始"),
     *      @SWG\Parameter(name="_size", in="query", required=false, type="integer", description="查询数量"),
     *      @SWG\Parameter(name="ip", in="query", required=false, type="string", description="查询ip，完全匹配"),
     *      @SWG\Parameter(name="area", in="query", required=false, type="integer", description="查询地区"),
     *      @SWG\Parameter(name="prvc", in="query", required=false, type="integer", description="查询省份"),
     *      @SWG\Parameter(name="line_type", in="query", required=false, type="integer", description="线路类型"),
     *      @SWG\Parameter(name="node_id", in="query", required=false, type="string", description="查询节点ID，完全匹配"),
     *      @SWG\Response(response="200", ref="#/definitions/Dnsnodelist")
     * )
     */
    public function index()
    {
        $from = input('_from', 0);
        $size = input('_size', null);
        $ip   = input('ip', "");
        $area = input('area', "");
        $prvc = input('prvc', "");
        $line_type = input('line_type', "");
        $filter = [];

        if ($area !== "") {
            if ($prvc !== "") {
                $filter['query']['bool']['filter'][] = ['term' => ['area' => $prvc]];
            } else {
                switch ($area) {
                    case 1:
                        $term = ['terms' => ['area' => [11, 12, 13, 14]]];
                        break;
                    case 2:
                        $term = ['terms' => ['area' => [21, 22, 23]]];
                        break;
                    case 3:
                        $term = ['terms' => ['area' => [31, 32, 33, 34, 35, 36, 37]]];
                        break;
                    case 4:
                        $term = ['terms' => ['area' => [41, 42, 43, 44, 45, 46]]];
                        break;
                    case 5:
                        $term = ['terms' => ['area' => [50, 51, 52, 53, 54]]];
                        break;
                    case 6:
                        $term = ['terms' => ['area' => [61, 62, 63, 64, 65]]];
                        break;
                    case 71:
                        $term = ['term' => ['area' => 71]];
                        break;
                    case 81:
                        $term = ['term' => ['area' => 81]];
                        break;
                    case 91:
                        $term = ['term' => ['area' => 91]];
                        break;
                    default:
                        $term = [];
                        break;
                }
                $filter['query']['bool']['filter'][] = $term;
            }
        }
        if ($ip !== "") {
            $filter['query']['bool']['must'][] = ['wildcard' => ['node_ip.ip.keyword' => "*$ip*"]];
        }
        if ($line_type !== "") {
            $filter['query']['bool']['must'][] = ['term' => ['line_type' => $line_type]];
        }

        $node_id = input('node_id', null);
        if (!is_null($node_id)) {
            $item = $this->repository->selectNodeById($node_id);
            if (is_null($item)) {
                Success(['list'=>[], "total"=>0]);
            }
            $item['id'] = $node_id;
            $item['last_update'] = strtotime($item['last_update']);
            $repository = new DnsConfRepository();
            $item['site_count'] = $repository->countConfs();
            return Finalsuccess(['list'=>[$item], "total"=>1]);
        }

        $filter['sort'][] = ['last_update' => ['order' => 'desc']];
        $repository = new DnsConfRepository();
        $list = $this->repository->selectNodes($filter, $from, $size);
        $site_count = $repository->countConfs();
        $list = array_map(function ($item) use ($site_count) {
            $item['last_update'] = strtotime($item['last_update']);
            $item['site_count'] = $site_count;
            return $item;
        }, $list);
        $total = $this->repository->countNodes($filter);
        return Finalsuccess(['list'=>$list, "total"=>$total]);
    }

    /**
     * @SWG\Post(
     *      path="/dnsnodes",
     *      tags={"dnsnode DNS节点"},
     *      summary="【添加】DNS节点",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="DNS节点信息：",
     *          @SWG\Schema(
     *              @SWG\Property(property="line_type", type="integer", example=3, description="线路类型"),
     *              @SWG\Property(property="node_ip", type="object", example={{"line": 1,"ip": "1.1.1.1-1.1.1.10"},{"line": 2,"ip": "2.2.2.1-2.2.2.10"}}, description="节点线路ip"),
     *              @SWG\Property(property="area", type="integer", example=41, description="地区")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     */
    public function create()
    {
        if (!$this->validator->scene('add_dns_node')->check(input())) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }
        if (!$this->checkNodeConf(input())) {
            return Finalfail(REP_CODE_DNS_NODE_CONFIG_ERROR, "DNS节点配置有误");
        }
        $node_list = input("node_ip/a");
        $ip_list = [];
        $line_arr = [];
        $ip_count = 0;
        $dns_id_arr = [];//生成的id统计
        $dns_ip = []; //统计添加ip
        $dns_node_conf = [
            "line_type"   =>  (int)input("line_type"),
            "area"        =>  (int)input("area"),
            "last_update" =>  gmt_withTZ()
        ];

        foreach ($node_list as $tmp) {
            $ip_list[$tmp['line']] = $this->parseIp($tmp["ip"]);
            $ip_count = $ip_count === 0 ? count($ip_list[$tmp['line']]) : $ip_count;
            $line_arr []= $tmp['line'];
        }

        for ($n = 0; $n < $ip_count; $n++) {
            $tmp_arr = [];
            foreach ($line_arr as $line) {
                $tmp_arr[] = [
                    'line'  =>  $line,
                    'ip'    =>  $ip_list[$line][$n]
                ];

                $dns_ip[] = $ip_list[$line][$n];
            }

            do {
                $id = $this->repository->generateInstanceId();
            } while (isset($dns_id_arr[$id]));
            $dns_id_arr[$id] = $id;
            $dns_node_conf['node_id'] = $id;
            $dns_node_conf['node_ip'] = $tmp_arr;

            $dns_node_arr[] = $dns_node_conf;
        }

        //自身查重
        if (count(array_unique($dns_ip)) !== count($dns_ip)) {
            return Finalfail(REP_CODE_DNS_NODE_REPEAT_ERROR, "DNS节点添加重复");
        }
        //数据库查重
        $finder['query']['bool']['filter'][] = count($dns_ip) === 1 ? ['term' => ['node_ip.ip.keyword' => $dns_ip[0]]] : ['terms' => ['node_ip.ip.keyword' => $dns_ip]];
        $list = $this->repository->selectNodes($finder);
        if (!empty($list)) {
            return Finalfail(REP_CODE_DNS_NODE_REPEAT_ERROR, "DNS节点添加重复");
        }

        foreach ($dns_node_arr as $node) {
            $bulk[] = [
                'index' =>  ['_id' => $node['node_id']]
            ];
            $bulk[] = $node;
        }

        $result = $this->repository->insertAllNodes($bulk);
        if ($result) {
            return Finalsuccess(['data' => $bulk[1]]);
        }
        return Finalfail(REP_CODE_DB_ERROR, "数据库操作失败");
    }

    /**
     * @SWG\Delete(
     *      path="/dnsnodes/delete",
     *      tags={"dnsnode DNS节点"},
     *      summary="【删除】DNS节点",
     *      @SWG\Parameter(
     *          name="",
     *          in="body",
     *          description="DNS节点ID数组",
     *          required=true,
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"ids": {"dns-adfiwjask12cd", "dns-dd1s1Hk8lV3D"}}
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 删除成功| !=0 删除失败",
     *         @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     */
    public function bundleDelete()
    {
        $data = input();
        if (!$this->validator->scene('bundle_delete')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        $result = $this->repository->bundleDelete($data['ids']);
        if (!$result) {
            return Finalfail(REP_CODE_DB_ERROR, "数据库操作失败");
        }
        return Finalsuccess();
    }

    /**
     * @SWG\Get(
     *      path="/dnsnodes/sites",
     *      tags={"dnsnode DNS节点"},
     *      summary="【获取】DNS节点网站数详情",
     *      @SWG\Parameter(name="_from", in="query", required=false, type="integer", description="查询范围开始"),
     *      @SWG\Parameter(name="_size", in="query", required=false, type="integer", description="查询数量"),
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","list":{"a.com","ab3.com"},"total":2}
     *          )
     *      )
     * )
     */
    public function siteDetail()
    {
        $total = 0;
        $list = [];
        $from = input('_from', 0);
        $size = input('_size', null);

        $repository = new DnsConfRepository();
        $result = $repository->selectConfs([], $from, $size);
        if(empty($result)){
            return Finalsuccess(['list'=>$list, "total"=>$total]);
        }

        $total = $repository->countConfs();
        $list = array_map(function ($tmp) {
            return $this->getSiteByCname($tmp['name']);
        }, $result);

        return Finalsuccess(['list'=>$list, "total"=>$total]);
    }

    private function getSiteByCname($cname)
    {
        $repository = new UserappRepository();
        $filter['query']['bool']['must'][] = ['term' => ['cname.keyword' => $cname]];
        $result = $repository->appList($filter);
        if($result){
            return $result[0]['name'];
        }
        return $cname;
    }
}
