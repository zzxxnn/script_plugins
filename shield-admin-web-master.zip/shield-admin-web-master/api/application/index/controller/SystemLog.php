<?php

namespace app\index\controller;

use app\common\model\ESSystemLogModel;
use app\common\repository\SystemLogRepository;
use app\common\service\MockDataService;

class SystemLog extends Base
{

    public function _initialize()
    {
        $this->repository = new SystemLogRepository();
    }

    /**
     * @SWG\Get(
     *      path="/system-log",
     *      tags={"system log 系统日志"},
     *      summary="【获取】系统日志列表",
     *      @SWG\Parameter(name="_from", in="query", required=false, type="integer", description="查询范围开始"),
     *      @SWG\Parameter(name="_size", in="query", required=false, type="integer", description="查询数量"),
     *      @SWG\Parameter(name="module",type="array",required=false,in="formData",
     *          @SWG\Items(type="string"),
     *          description="模块"
     *      ),
     *     @SWG\Parameter(name="type",type="array",required=false,in="formData",
     *          @SWG\Items(type="string"),
     *          description="类型"
     *      ),
     *      @SWG\Parameter(name="status", in="query", required=false, type="string", description="日志属性"),
     *      @SWG\Parameter(name="content", in="query", required=false, type="string", description="日志内容"),
     *      @SWG\Parameter(name="system", in="query", required=false, type="string", description="系统"),
     *      @SWG\Parameter(name="ip", in="query", required=false, type="string", description="ip"),
     *      @SWG\Parameter(name="id", in="query", required=false, type="string", description="id"),
     *      @SWG\Parameter(name="operator", in="query", required=false, type="string", description="用户名"),
     *      @SWG\Parameter(name="start_date", in="query", required=false, type="integer", description="开始时间戳"),
     *      @SWG\Parameter(name="end_date", in="query", required=false, type="integer", description="结束时间戳"),
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          @SWG\Property(
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{{"id":"LZIyVmUBMgp_XYNhFytk","method":"PUT","operator":"admin","path":"index\/Admins\/password","ip":"192.168.9.76","system":"index","operator_type":"修改管理员密码","module":"用户管理","content":"修改管理员aaa1的密码成功","request_type":"update","request_status":"info","request_url":"v1\/admins\/177\/password","request_body":{"debug":"true","new_pwd":"veda2017","id":"177"},"reponse_data":{"errcode":0,"errmsg":"ok"},"create_time":"2018-08-20
     *              15:17:05","update_time":"2018-08-20T07:17:05.000Z"},{"id":"GpIvVmUBMgp_XYNhlyu1","method":"POST","operator":"test@veda.com","path":"client\/Sessions\/create","ip":"127.0.0.1","system":"client","operator_type":"登录","module":"登录
     *              &
     *              注册","content":"用户test@veda.com登录成功","request_type":"select","request_status":"info","request_url":"v1\/login","request_body":{"email":"Ps4OP307E4UCFcyCZ\/hr6h0UMEJiBgZfPXOBadAAkk8EqWXJIL36yNcUNHtG8azv8ETEX14qZLnZRU6zZtedb9Nc0aMkh1TB6LPxmKEXlU07rdxNrrdOLBoUqHDNUx8UN6C5yD4dx9EmCYzqJDb71vdTPgY2iZ3lKOw6UW84Uzw=","password":"TOm3RRyMZdJ4xfC+rX4mWrb+WzXxf3dMjGosMAUa5tNVIZFolxUhdvtp4i9ebSY5iLZXaoVd7FAF1XJe5Ig48+G\/GDVp6qdu7GyUjxzX4V5Rtmzg0WMloezf3vRUc1fFNRll6++dQWvZhVf3EF3CsvEjG\/v7rveYb7oTuc4MA5U=","captcha":"2996"},"reponse_data":{"errcode":0,"errmsg":"ok"},"create_time":"2018-08-20
     *              15:14:42","update_time":"2018-08-20T07:14:42.000Z","agent":"sgsheg@gmail.com"},{"id":"GJIvVmUBMgp_XYNhiCu6","method":"DELETE","operator":null,"path":"client\/Sessions\/destroy","ip":"127.0.0.1","system":"client","operator_type":"退出登录","module":"登录","content":"用户退出登录成功","request_type":"select","request_status":"info","request_url":"v1\/logout","request_body":{},"reponse_data":{"errcode":0,"errmsg":"ok"},"create_time":"2018-08-20
     *              15:14:38","update_time":"2018-08-20T07:14:38.000Z"}},"total":3}
     *          )
     *      )
     * )
     */
    public function index()
    {
        $data   = input();
        $must   = [];
        $filter = [];

        // 分页相关
        $from = input('_from', 0);
        $size = input('_size', 10);

        // 根据id查询
        $id = input('id', null);
        if ($id) {
            $must[] = [ 'term' => [ '_id' => $id ] ];
        }

        // 根据模块module查询
        if (isset($data['module'])) {
            $filter[] = [ 'terms' => [ 'module.keyword' => $data['module'] ] ];
        }

        // 根据属性type查询
        if (isset($data['type'])) {
            $filter[] = [ 'terms' => [ 'request_type.keyword' => $data['type'] ] ];
        }

        // 根据日志属性status查询
        $status = input('status', null);
        if ($status) {
            $must[] = [ 'term' => [ 'request_status.keyword' => $status ] ];
        }

        // 根据系统查询
        $system = input('system', null);
        if ($system) {
            $must[] = [ 'term' => [ 'system.keyword' => $system ] ];
        }

        // 根据ip查询
        $ip = input('ip', null);
        if ($ip) {
            $must[] = [ 'term' => [ 'ip.keyword' => $ip ] ];
        }

        // 根据用户名查询
        $operator = input('operator', null);
        if ($operator) {
            $must[] = [ 'term' => [ 'operator.keyword' => $operator ] ];
        }

        // 开始时间
        $start = input('start_date', null);
        if ($start) {
            $must[] = [ 'range' => [ 'create_time' => [ 'gte' => $start ] ] ];
        }

        // 结束时间
        $end = input('end_date', null);
        if ($end) {
            $must[] = [ 'range' => [ 'create_time' => [ 'lte' => $end ] ] ];
        }

        // 根据内容过滤
        $content = input('content', null);
        if ($content) {
            $must[] = [ 'wildcard' => [ 'content.keyword' => "*$content*" ] ];
        }

        $filter = [
            'query' => [ 'bool' => [ 'filter' => $filter, 'must' => $must ] ],
            'sort'  => [ [ 'create_time' => [ 'order' => 'desc' ] ] ],
        ];
        $logs   = $this->repository->getList($filter, $from, $size);
        foreach ($logs as $key => $log) {
            $log['create_time'] = format_time(strtotime($log['create_time']));
            unset($log[$key]);
            $logs[$key] = $log;
        }
        $count = $this->repository->count($filter);

        return Finalsuccess([ 'data' => $logs, 'total' => $count ]);
    }

    /**
     * @SWG\Get(
     *      path="/system-log/search-config",
     *      tags={"system log 系统日志"},
     *      summary="【获取】系统日志列表搜索项",
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          @SWG\Property(
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"modules":{
     *              "index":{"用户管理","登录","代理商管理","订单管理","商品管理","应用管理","资源管理","技术支持管理"},
     *              "client":{"登录 & 注册","个人资料","订单管理","支付管理","高仿实例","网站防护","应用防护"}},
     *              "types":{"create":"增加","delete":"删除","update":"修改","select":"查询"},
     *              "status":{"info":"正常","notice":"警告","error":"异常"},"system":{"client":"用户系统","index":"管理系统"}}}
     *          )
     *      )
     * )
     *
     * @return string
     * @throws \app\common\exception\MockDataModuleNotFound
     */
    public function searchConfig()
    {
        $templates = MockDataService::value('SystemLogTemplate');
        $modules   = [
            ESSystemLogModel::ES_SYSTEM_LOG_SYSTEM_INDEX  => [],
            ESSystemLogModel::ES_SYSTEM_LOG_SYSTEM_CLIENT => []
        ];
        foreach ($templates as $key => $template) {
            if ( ! in_array($template[0]['module'], $modules[ESSystemLogModel::ES_SYSTEM_LOG_SYSTEM_INDEX]) 
                && strpos($key, ESSystemLogModel::ES_SYSTEM_LOG_SYSTEM_INDEX) !== false) {
                $modules[ESSystemLogModel::ES_SYSTEM_LOG_SYSTEM_INDEX][] = $template[0]['module'];
            } elseif ( ! in_array($template[0]['module'], $modules[ESSystemLogModel::ES_SYSTEM_LOG_SYSTEM_CLIENT]) 
                && strpos($key, ESSystemLogModel::ES_SYSTEM_LOG_SYSTEM_CLIENT) !== false) {
                $modules[ESSystemLogModel::ES_SYSTEM_LOG_SYSTEM_CLIENT][] = $template[0]['module'];
            }
        }
        $reuslt = [
            'modules' => $modules,
            'types'   => ESSystemLogModel::ES_SYSTEM_LOG_TYPE_ARRAY,
            'status'  => [
                ESSystemLogModel::ES_SYSTEM_LOG_STATUS_INFO   => '正常',
                ESSystemLogModel::ES_SYSTEM_LOG_STATUS_NOTICE => '警告',
                ESSystemLogModel::ES_SYSTEM_LOG_STATUS_ERROR  => '异常'
            ],
            'system'  => ESSystemLogModel::ES_SYSTEM_LOG_SYSTEM_ARRAY
        ];

        return Finalsuccess([ 'data' => $reuslt ]);
    }

}
