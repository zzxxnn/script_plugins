<?php

namespace app\index\controller;

use think\Controller;

class Base extends Controller
{
    protected $validator;

    protected $repository;

    protected function _initialize()
    {
        if (IsLogin() === 0) {
            // 注意：Fail函数仅在判断是否登录时返回使用，其余需要返回异常信息请使用Finalfail
            return Fail(REP_CODE_NEED_LOGIN, '请先登陆！');
        }
    }
}
