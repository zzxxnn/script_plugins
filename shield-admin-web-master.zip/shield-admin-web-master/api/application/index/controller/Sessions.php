<?php

namespace app\index\controller;

use app\common\repository\UserRepository;
use app\common\service\LogService;
use app\index\service\Auth as AuthService;
use app\index\validate\Admins as AdminsValidate;
use think\Log;

class Sessions extends Base
{
    public function _initialize()
    {
        $this->validator = new AdminsValidate();
    }

    /**
     * @SWG\Get(
     *      path="/loginfo",
     *      tags={"session 登录管理"},
     *      summary="【获取】登录状态",
     *      @SWG\Response(response="200", ref="#/definitions/Loginfo")
     * )
     */
    public function index()
    {
        $user = AuthService::info();

        if ($user) {
            return Finalsuccess(['is_login' => true, 'uid' => $user['uid'], 'login_time' => $user['login_time']]);
        } else {
            return Finalfail(REP_CODE_NEED_LOGIN, '需要登录');
        }
    }

    /**
     * @SWG\Post(
     *      path="/login",
     *      tags={"session 登录管理"},
     *      summary="【登录】管理员登录",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="登录post信息：",
     *          @SWG\Schema(
     *              @SWG\Property(property="username", type="string", example="root"),
     *              @SWG\Property(property="password", type="string", example="veda2017"),
     *              @SWG\Property(property="captcha", type="string", example="9716"),
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     */
    public function create(UserRepository $repository)
    {
        Log::info('Unit test: ' . is_phpunit_testing());

        $auth = $this->request->post();
        if (!$this->validator->scene('login')->check($auth)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        // PHPUnit 发来的请求不进行校验码校验
        if (!is_phpunit_testing() && !captcha_check($auth['captcha'])) {
            return Finalfail(REP_CODE_CAPTCHA_INVALID, '验证码错误');
        }

        // PHPUnit 发来的请求不进行解密
        if (!is_phpunit_testing()) {
            //解密传递过来的账号信息
            $auth['username'] = rsa_decrypt($auth['username']);
            $auth['password'] = rsa_decrypt($auth['password']);
        }

        //处理登录
        $log = $repository->doUserName($auth);

        switch ($log) {
            case 0:
                //写入session
                AuthService::login($auth);
                // 加密前的邮箱，用作记录日志使用
                request()->bind('decrypt_email', $auth['username']);
                return Finalsuccess();
                break;
            case 1:
                return Finalfail(REP_CODE_PASSWORD_ERROR, '密码不正确');
                break;
            case 2:
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '账户不存在');
                break;
            default :
                return Finalfail(REP_CODE_ILLEGAL_OPERATION, '非法操作');
        }
    }

    /**
     * @SWG\Delete(
     *      path="/logout",
     *      tags={"session 登录管理"},
     *      summary="【注销】管理员注销",
     *      parameters={},
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     */
    public function destroy()
    {
        AuthService::logout();
        return Finalsuccess();
    }
}
