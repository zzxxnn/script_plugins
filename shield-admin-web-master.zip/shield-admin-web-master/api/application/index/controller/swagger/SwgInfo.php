<?php

namespace app\index\controller;

class SwgInfo
{
    /**
     * Swagger v2
     * @SWG\Swagger(
     *      schemes={"http"},
     *      host="admin.shield.com",
     *      basePath="/v1",
     *      @SWG\Info(
     *          version="1.0.0",
     *          title="幻盾管理WEB",
     *          description="",
     *      ),
     *      consumes={"application/json"},
     *      produces={"application/json"}
     * )
     */

    /**
     * @SWG\Definition(
     *      definition="Errcode",
     *      type="object",
     *      @SWG\Property(property=" 0 ", type="请求成功"),
     *      @SWG\Property(property="10001", type="登陆错误"),
     *      @SWG\Property(property="10002", type="验证码错误"),
     *      @SWG\Property(property="10003", type="密码错误"),
     *      @SWG\Property(property="11000", type="参数错误"),
     *      @SWG\Property(property="12001", type="需要登录"),
     *      @SWG\Property(property="20000", type="数据库操作异常"),
     *  )
     *
     * @SWG\Definition(
     *      definition="Error",
     *      type="object",
     *      @SWG\Property(property="errcode", type="integer", example=10001),
     *      @SWG\Property(property="errmsg", type="string", example="params missing")
     *  )
     *
     * @SWG\Definition(
     *      definition="Success",
     *      type="object",
     *      @SWG\Property(property="errcode", type="integer", example=0),
     *      @SWG\Property(property="errmsg", type="string", example="ok")
     *  )
     *
     *  @SWG\Definition(
     *      definition="Detectorlist",
     *      type="object",
     *      allOf={
     *          @SWG\Schema(ref="#/definitions/Success"),
     *          @SWG\Schema(
     *              @SWG\Property(
     *                  property="list",
     *                  type="object",
     *                  example={
     *                      {"id":1,"device_id":101,"ip":"192.168.5.25","memory":200,"disk":10,"db":10,"online":1},
     *                      {"id":2,"device_id":102,"ip":"192.168.5.26","memory":200,"disk":10,"db":10,"online":0}
     *                  }
     *              ),
     *              @SWG\Property(property="page", type="integer", example=1),
     *              @SWG\Property(property="count", type="integer", example=10)
     *          )
     *      }
     *  )
     *
     *  @SWG\Definition(
     *      definition="Detectorssh",
     *      type="object",
     *      allOf={
     *          @SWG\Schema(ref="#/definitions/Success"),
     *          @SWG\Schema(
     *              @SWG\Property(property="ssh_ip", type="string", example="192.168.25.21"),
     *              @SWG\Property(property="ssh_uname", type="string", example="root"),
     *              @SWG\Property(property="ssh_pwd", type="string", example="veda1qaz"),
     *          )
     *      }
     *  )
     *
     *  @SWG\Definition(
     *      definition="Detectortime",
     *      type="object",
     *      allOf={
     *          @SWG\Schema(ref="#/definitions/Success"),
     *          @SWG\Schema(
     *              @SWG\Property(property="delay", type="integer", example=100),
     *              @SWG\Property(property="duration", type="integer", example=10)
     *          )
     *      }
     *  )
     *
     *  @SWG\Definition(
     *      definition="Domainlist",
     *      type="object",
     *      allOf={
     *          @SWG\Schema(ref="#/definitions/Success"),
     *          @SWG\Schema(
     *              @SWG\Property(
     *                  property="list",
     *                  type="object",
     *                  example={
     *                      {"id":"192.168.7.24-8080","uid":"test@veda.com","type":3,"proxy_ip":"192.168.7.24","line":"21_3","proxy_port":8080,"server_ip":"10.10.10.10","server_port":"800","status":1,"last_update":"2018-04-02T03:31:43.000Z"},
     *                      {"id":"www.alice.com","uid":"test@veda.com","name":"www.alice.com","type":"2","http":"1","https":"1","upstream":{"1.1.1.1"},"status":3,"text_code":"3b042fe718dc5a","ip":{},"last_update":"2018-04-03T10:48:15.000Z","hd_ip":{{"line":"11_1","ip":"100.123.100.12"},{"line":"11_1","ip":"100.123.100.7"},{"line":"11_1","ip":"100.123.100.4"},{"line":"11_1","ip":"100.123.100.33"}},"cname":"c424b1291e73f808.hd.vedasec.net"},
     *                  }
     *              ),
     *              @SWG\Property(property="tota", type="integer", example=10)
     *          )
     *      }
     *  )
     *
     *  @SWG\Definition(
     *      definition="DomainNodelist",
     *      type="object",
     *      allOf={
     *          @SWG\Schema(ref="#/definitions/Success"),
     *          @SWG\Schema(
     *              @SWG\Property(property="1", type="object", description="联通", example={"1.1.1.1","2.2.2.2"}),
     *              @SWG\Property(property="2", type="object", description="移动", example={"1.1.1.1","2.2.2.2"}),
     *              @SWG\Property(property="3", type="object", description="电信", example={"1.1.1.1","2.2.2.2"}),
     *              @SWG\Property(property="4", type="object", description="其他", example={"1.1.1.1","2.2.2.2"})
     *          )
     *      }
     *  )
     *
     *
     *  @SWG\Definition(
     *      definition="Site Type",
     *      type="object",
     *      @SWG\Property(property=" 0 ", type="未设置"),
     *      @SWG\Property(property="1", type="共享型网站类"),
     *      @SWG\Property(property="2", type="独享型网站类"),
     *      @SWG\Property(property="3", type="非网站类"),
     *  )
     *
     */
}
