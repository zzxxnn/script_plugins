<?php

namespace app\index\controller;

class Dnsnode
{
    /**
     *  @SWG\Definition(
     *      definition="Dnsnodelist",
     *      type="object",
     *      allOf={
     *          @SWG\Schema(ref="#/definitions/Success"),
     *          @SWG\Schema(
     *              @SWG\Property(
     *                  property="list",
     *                  type="object",
     *                  @SWG\Property(property="id", type="string", example="4nszmppamj", description="ID"),
     *                  @SWG\Property(property="line_type", type="integer", example=3, description="线路类型"),
     *                  @SWG\Property(property="area", type="integer", example=22, description="地区"),
     *                  @SWG\Property(property="node_id", type="string", example="4nszmppamj", description="节点ID"),
     *                  @SWG\Property(
     *                      property="node_ip",
     *                      type="object",
     *                      @SWG\Property(property="line", type="integer", example=1, description="线路"),
     *                      @SWG\Property(property="ip", type="string", example="1.1.1.2", description="IP"),
     *                  ),
     *                  @SWG\Property(property="last_update", type="string", example="1522233041", description="更新时间戳")
     *              ),
     *              @SWG\Property(property="total", type="integer", example=523, description="总数"),
     *          )
     *      }
     *  )
     */
}
