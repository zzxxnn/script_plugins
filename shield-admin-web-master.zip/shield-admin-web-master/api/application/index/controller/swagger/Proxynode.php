<?php

namespace app\index\controller;

class Proxynode
{
    /**
     *
     *  @SWG\Definition(
     *      definition="Antinodelist",
     *      type="object",
     *      allOf={
     *          @SWG\Schema(ref="#/definitions/Success"),
     *          @SWG\Schema(
     *              @SWG\Property(
     *                  property="list",
     *                  type="object",
     *                  @SWG\Property(property="id", type="string", example="4nszmppamj", description="ID"),
     *                  @SWG\Property(property="line_type", type="integer", example=3, description="线路类型"),
     *                  @SWG\Property(property="area", type="integer", example=22, description="地区"),
     *                  @SWG\Property(property="node_type", type="integer", example=2, description="节点类型"),
     *                  @SWG\Property(property="node_id", type="string", example="4nszmppamj", description="节点ID"),
     *                  @SWG\Property(
     *                      property="node_ip",
     *                      type="object",
     *                      @SWG\Property(property="line", type="integer", example=1, description="线路"),
     *                      @SWG\Property(property="ip", type="string", example="1.1.1.2", description="IP"),
     *                      @SWG\Property(property="user_count", type="integer", example=2, description="用户数"),
     *                      @SWG\Property(property="user_detail", type="object", example={"test@veda.com","shao@veda.com"}, description="用户详情"),
     *                      @SWG\Property(property="site_count", type="integer", example=10, description="网站数"),
     *                      @SWG\Property(property="site_detail", type="object", example={"hdtest.vedasec.net","test.veda.com"}, description="网站防护详情"),
     *                      @SWG\Property(property="app_count", type="integer", example=10, description="应用防护数"),
     *                      @SWG\Property(
     *                          property="app_detail",
     *                          type="object",
     *                          description="应用防护详情",
     *                          example={{"ip":"127.0.0.1","port":8080},{"ip":"127.18.9.1","port":"8081"}},
     *                          @SWG\Property(property="ip", type="string", example="1.1.1.2", description="源站IP"),
     *                          @SWG\Property(property="line", type="integer", example=1, description="源站端口"),
     *                      ),
     *                  ),
     *                  @SWG\Property(property="total_app_count", type="integer", example=10, description="应用防护总数"),
     *                  @SWG\Property(property="total_site_count", type="integer", example=10, description="网站防护总数"),
     *                  @SWG\Property(property="site_limit", type="integer", example=50, description="网站上限，独享型只能为1"),
     *                  @SWG\Property(property="bandwidth", type="string", example="100M", description="暂时默认100M"),
     *                  @SWG\Property(property="last_update", type="string", example="1522233041", description="更新时间戳")
     *              ),
     *              @SWG\Property(property="total", type="integer", example=523, description="总数"),
     *          )
     *      }
     *  )
     *
     *
     */
}