<?php 

namespace app\index\controller;

class Users
{
    /**
     *  @SWG\Definition(
     *      definition="Loginfo",
     *      type="object",
     *      allOf={
     *          @SWG\Schema(ref="#/definitions/Success"),
     *          @SWG\Schema(
     *              @SWG\Property(property="is_login", type="boolean", example=true),
     *              @SWG\Property(property="uid", type="string", example="admin"),
     *              @SWG\Property(property="login_time", type="string", example="2018-03-29 12:22:22")
     *          )
     *      }
     *  )
     *
     *  @SWG\Definition(
     *      definition="Userlist",
     *      type="object",
     *      allOf={
     *          @SWG\Schema(ref="#/definitions/Success"),
     *          @SWG\Schema(
     *              @SWG\Property(
     *                  property="list",
     *                  type="object",
     *                  example={
     *                      {"id":"53","email":"shaoyuansy@126.com","qq":"","phone":"","registered_time":"2017-10-25 16:36:36","last_login_time":"2018-03-12 14:48:39","last_login_ip":"192.168.9.28"},
     *                      {"id":"54","email":"905606202@qq.com","qq":"","phone":"","registered_time":"2017-10-25 16:57:55","last_login_time":"2018-03-12 14:48:39","last_login_ip":"192.168.9.30"}
     *                  }
     *              ),
     *              @SWG\Property(property="total", type="integer", example=10)
     *          )
     *      }
     *  )
     *
     */
}
