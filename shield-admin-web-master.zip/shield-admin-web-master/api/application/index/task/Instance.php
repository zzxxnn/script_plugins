<?php

namespace app\index\task;

use app\client\repository\DDoSRepository;
use app\client\repository\SupportRepository;
use app\common\model\UserInstanceModel;
use app\common\model\UserModel;
use app\common\service\MailService;
use app\common\service\NotifierService;
use Carbon\Carbon;
use think\console\Command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;

/**
 * Class Instance 实例任务
 *
 * @package app\index\command
 * @author Teddy Sun <sgsheg@163.com>
 */
class Instance extends Command
{
    protected $dosModel;

    protected $dosRepository;

    protected $supportRepository;

    protected $oneMonth;

    protected $halfMonth;

    protected $twoWeeks;

    protected $oneWeek;

    /**
     * Instance constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->dosModel          = new UserInstanceModel();
        $this->dosRepository     = new DDoSRepository();
        $this->supportRepository = new SupportRepository();
        //定义日期长度 1月|半个月|2周|1周
        $this->oneMonth = env('INSTANCE_REMIND_YEAR_CUSTOMER') ?? 30;
        $this->halfMonth = env('INSTANCE_REMIND_YEAR_SUPPORT') ?? 15;
        $this->twoWeeks = env('INSTANCE_REMIND_CUSTOMER') ?? 14;
        $this->oneWeek = env('INSTANCE_REMIND_SUPPORT') ?? 7;
    }

    protected function configure()
    {
        parent::configure();
        $this->setName('run:instance')
            ->addOption('plain', null, Option::VALUE_NONE, '执行实例提醒任务')
            ->setDescription('执行实例提醒任务');
    }

    /**
     * @param \think\console\Input $input
     * @param \think\console\Output $output
     * @return int|null|void
     * @throws \Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $output->writeln('<info>执行实例提醒任务</info>');
        # 获取实例记录中状态为正常的实例列表
        $instances = $this->getInstanceList();
        $i = 0;
        # 根据获取的列表比对实例到期日期和当前日期的差值
        foreach ($instances as $instance) {
            //实例到期时间
            $endDate      = format_time(strtotime($instance['end_date']));
            $diffTwoWeeks = $this->diffTwoDate($output, $instance, $endDate,$this->twoWeeks);
            //条件满足2周通知
            if ($diffTwoWeeks) {
                //是否已经提醒过了
                if (! isset($instance['remind_two_weeks']) || empty($instance['remind_two_weeks'])) {
                    $output->writeln('<info>当前实例:'.$instance['id']. '到期日期为'.$endDate.'满足2周内续费提醒条件</info>');
                    $i++;
                    $result = $this->doUserNotificationAction($instance, MailService::INSTANCE_TWO_WEEKS, NotifierService::SMS_INSTANCE_TWO_WEEKS, 'remind_two_weeks', $output);
                    continue;
                } else {
                    $diffOneWeek = $this->diffTwoDate($output, $instance, $endDate, $this->oneWeek);
                    if ($diffOneWeek) {
                        //是否已经提醒过了
                        if (! isset($instance['remind_one_week']) || empty($instance['remind_one_week'])) {
                            $output->writeln('<info>当前实例:'.$instance['id'].' 到期日期为'.$endDate.'满足1周内提醒相关人员条件</info>');
                            $i++;
                            //给客户关联相关销售发送邮件和短信.
                            $result = $this->doSupportNotificationAction($instance, MailService::INSTANCE_ONE_WEEK, NotifierService::SMS_INSTANCE_ONE_WEEK, 'remind_one_week', $output);
                            continue;
                        }
                    }
                }
            } else {
                //其他问题需要对实例进行操作.
                //到期日期在2周以外,到期日期远远在2周以外,年付用户怎么办?
                //那这个两周的是否还要继续提醒?
                $startDate = new Carbon(format_time(strtotime($instance['start_date'])));
                $oneYearEndDate = $startDate->addYear(1);
                $endTime = new Carbon($endDate);
                //年付
                if ($endTime > $oneYearEndDate) {
                    //这个实例是年付用户
                    $diffOneMonth = $this->diffTwoDate($output, $instance, $endDate, $this->oneMonth);
                    if ($diffOneMonth) {
                        //干活
                        if (! isset($instance['remind_one_month']) || empty($instance['remind_one_month'])) {
                            $output->writeln('<info>当前实例:'.$instance['id'].' 到期日期为'.$endDate.'满足1月内提醒相关人员条件</info>');
                            $i++;
                            $result = $this->doUserNotificationAction($instance, MailService::INSTANCE_ONE_MONTH, NotifierService::SMS_INSTANCE_ONE_MONTH, 'remind_one_month', $output);
                            continue;
                        } else {
                            $diffHalfMonth = $this->diffTwoDate($output, $instance, $endDate, $this->halfMonth);
                            if ($diffHalfMonth) {
                                if (! isset($instance['remind_half_month']) || empty($instance['remind_half_month'])) {
                                    $output->writeln('<info>当前实例:'.$instance['id'].' 到期日期为'.$endDate.'满足半个月提醒相关人员条件</info>');
                                    $result = $this->doSupportNotificationAction($instance, MailService::INSTANCE_HALF_MONTH, NotifierService::SMS_INSTANCE_HALF_MONTH, 'remind_half_month', $output);
                                    continue;
                                }
                            }
                        }
                    }
                } else {
                    //什么也不用做
                    continue;
                }
            }
        }

        $output->writeln('<info>结束执行实例提醒任务,共执行了' . $i . '个提醒任务</info>');
    }

    /**
     * 获取实例
     *
     * @throws \Exception
     */
    public function getInstanceList()
    {
        $filter = [
            'query' => [
                'bool' => [
                    'filter' => [
                        ['term' => ['status' => UserInstanceModel::STATUS_ACTIVATED]],
                    ]
                ]
            ],
            'sort'  => ['last_update' => 'desc']
        ];

        //todo: 查询处理的分页
        return $this->dosRepository->getDDoSList($filter, 0, 10000);
    }

    /**
     * 2周动作
     *
     * @param $instance
     * @param \think\console\Output $output
     * @return bool
     * @throws \Exception
     * @throws \PHPMailer\PHPMailer\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    private function doUserNotificationAction($instance, $emailTemplate, $smsTemplate, $key = 'remind_two_weeks', Output $output)
    {
        //实例归属用户信息 [邮箱+手机]
        $userEmail = $instance['uid'];
        if ($userEmail) {
            //send Email
            $sendEmail = MailService::send($userEmail, $instance['id'], $emailTemplate);
            if (! $sendEmail) {
                //记录发送邮件失败日志
                $output->writeln('<error>给实例id为'.$instance['id'].'发送提醒到期邮件未能成功发送给邮箱'.$sendEmail.',请留意.</error>');
            }
            //手机号码不一定存在
            $user = UserModel::where('email', $userEmail)->find();
            if ($user) {
                //$userMobile = $user->mobile;
                //if ($userMobile) {
                //    //给用户发送短信通知
                //    $result = NotifierService::sendSms($userMobile, ['instance' => $instance['id']], $smsTemplate);
                //    if (! $result) {
                //        $output->writeln('<error>给实例id为'.$instance['id'].'发送提醒到期短信未能成功发送给手机'.$userMobile.',请留意.</error>');
                //    }
                //}
            }

            if ($this->updateInstance($instance['id'], $key)) {
                return true;
            }
            $output->writeln('<error>给实例id为'.$instance['id'].'添加' . $key . '提醒字段失败</error>');

            return false;
        }

        return false;
    }

    /**
     * 1周动作
     * todo:系统目前的支持人员和销售人员有问题
     *
     * @throws \Exception
     */
    private function doSupportNotificationAction($instance,$emailTemplate, $smsTemplate, $key = 'remind_one_week', OutPut $output)
    {
        //用户邮箱
        $userEmail = $instance['uid'];
        $supports  = $this->supportRepository->getSupport();

        if (empty($supports)) {
            //系统目前没有支持人员
            $output->writeln('<error>实例id为'.$instance['id'].'没有对应的技术和销售支持请留意.</error>');
            return false;
        }

        $technical = $supports[0][0]; //技术支持
        $sale = $supports[1]; //销售支持

        if (! empty($technical)) {
            $this->doSupportRemind($instance, $technical, $output, $emailTemplate, $smsTemplate);
        } else {
            $output->writeln('<error>实例id为'.$instance['id'].'没有对应的技术支持,请留意.</error>');
        }

        //if (! empty($sale)) {
        //    $this->doSupportRemind($instance, $sale, $output, $emailTemplate, $smsTemplate);
        //} else {
        //    $output->writeln('<error>实例id为'.$instance['id'].'没有对应的销售支持,请留意.</error>');
        //}

        //干完了给实例用户添加标识字段
        if ($this->updateInstance($instance['id'], $key)) {
            return true;
        }
        $output->writeln('<error>给实例id为'.$instance['id'].'添加'.$key.'提醒字段失败</error>');

        return false;
    }

    /**
     * 比对2个日期相差天数
     *
     * @param $endDate
     * @param int $diff
     * @return bool
     * @throws \Exception
     */
    private function diffTwoDate(Output $output, $instance, $endDate, $diff)
    {
        $now     = Carbon::now();
        $endDate = new Carbon($endDate);

        //当前日期大于了实例到期日期
        if ($now > $endDate) {
            //执行实例清除工作
            if ($this->doKillInstance($instance, $output)) {
                return false;
            }
            return false;
        }

        $diffDays = $endDate->diff($now)->days;
        //到期日期与当前日期相差符合
        if ($diffDays <= $diff) {
            return true;
        }

        return false;
    }

    /**
     * 提醒后为记录添加提醒标识
     *
     * @param $id
     * @param $key
     * @return bool
     * @throws \Exception
     */
    private function updateInstance($id, $key)
    {
        $data = [$key => Carbon::now()->toDateTimeString()];
        if ($this->dosModel->esUpdateById($data, $id)) {
            return true;
        }

        return false;
    }

    /**
     * @param $instance
     * @param $support
     * @param \think\console\Output $output
     * @throws \PHPMailer\PHPMailer\Exception
     */
    private function doSupportRemind($instance, $support, OutPut $output, $emailTemplate, $smsTemplate)
    {
        $support['email'] = 'zhanghl@veda.com';
        //发送邮件|短信
        if (isset($support['email'])) {
            //发送邮件
            //send Email
            $sendEmail = MailService::send($support['email'], $instance, $emailTemplate);
            if (! $sendEmail) {
                //记录发送邮件失败日志
                $output->writeln('<error>实例id为'.$instance['id'].'发送邮件提醒给'.$support['name'].'失败,请留意.</error>');
            }
        }

        //todo:暂时不要给支持发送短信
        //if (isset($support['mobile'])) {
        //    //发送短信
        //    $result = NotifierService::sendSms($support['mobile'], ['instance' => $instance['id']], $smsTemplate);
        //    if (! $result) {
        //        $output->writeln('<error>实例id为'.$instance['id'].'发送短信提醒给'.$support['name'] .',失败请留意.</error>');
        //    }
        //}
    }

    /**
     * 停止实例
     *
     * @param $instance
     * @param \think\console\Output $output
     * @return bool
     * @throws \Exception
     */
    private function doKillInstance($instance, Output $output)
    {
        //删除实例相关信息,保留实例名称
        $instanceId = $instance['id'];
        $data       = [
            'status'      => UserInstanceModel::STATUS_OVERDUE,
            'last_update' => gmt_withTZ(),
        ];

        //更改状态
        if ($this->dosModel->esUpdateById($data, $instanceId)) {
            $output->writeln('<info>实例'.$instanceId.'已经停止,开始执行其他动作</info>');
            return true;
            //执行其他任务
            //
            //$output->writeln('<info>实例'.$instanceId.'终止动作已结束');
        } else {
            $output->writeln('<error>实例id为'.$instanceId.'停止失败,请手动处理!!!!.</error>');
        }

    }
}