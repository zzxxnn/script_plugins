<?php

namespace app\index\task;

use app\common\exception\RepositoryException;
use app\common\model\OrderModel;
use think\console\Command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;
use Carbon\Carbon;
use app\common\repository\OrderRepository;

/**
 * Class Order 订单任务 <订单24小时内不支付状态修改为无效>
 *
 * @package app\index\command
 * @author Teddy Sun <sgsheg@163.com>
 */
class Order extends Command
{
    protected function configure()
    {
        parent::configure();
        $this->setName('run:order')
            ->addOption('plain', null, Option::VALUE_NONE, '执行24小时订单自动修改状态任务')
            ->setDescription('执行订单过期任务');
    }

    /**
     * @param \think\console\Input $input
     * @param \think\console\Output $output
     * @return int|null|void
     * @throws \Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $output->writeln('<info>开始执行24小时订单状态修改任务</info>');
        $i = 0;
        //处理方法
        //1.获取订单列表中未支付的订单列表
        //2.比对当前时间和订单创建时间,如果2者时间差在24小时以外,自动修改订单状态为无效.
        $orders = $this->getOrderList();

        if ($orders) {
            foreach ($orders as $order) {
                $now = Carbon::now();
                $orderCreateTime = Carbon::parse($order['create_time']);

                $result = $now->diffInHours($orderCreateTime);
                if ($result > 24) {
                    //update 订单状态
                    $orderRepository = new OrderRepository();
                    $checkOrder = $orderRepository->getOrderDetail($order['oid']);
                    if ($checkOrder && $checkOrder['status'] === OrderModel::ORDER_STATUS_CREATED) {
                        $i++;
                        if ($orderRepository->update(['status' => OrderModel::ORDER_STATUS_TRASHED], $order['oid'])) {
                            $output->writeln('<info>修改订单:' . $order['oid'] . '状态为取消状态</info>');
                            continue;
                        }
                    }
                }
            }
        }
        $output->writeln('<info>执行完毕.共处理了' . $i . '个订单</info>');
    }

    private function getOrderList()
    {
        $must = [];
        $must[] = ['term' => ['status' => OrderModel::ORDER_STATUS_CREATED]];
        $filter = [
            'query' => ['bool' => ['must' => $must]],
            'sort'  => [['create_time' => ['order' => 'desc']]],
        ];

        try {
            $orderRepository = new OrderRepository();
            //todo:这里线上测试一次是一页一页
            return $orderRepository->getOrderList($filter, 0, 10000);
        } catch (RepositoryException $e) {
            return false;
        } catch (\Exception $e) {
            return false;
        }
    }
}