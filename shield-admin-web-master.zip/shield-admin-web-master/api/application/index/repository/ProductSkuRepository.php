<?php

namespace app\index\repository;

use app\index\model\ProductSkuModel;

/**
 * Class ProductSkuRepository
 *
 * @package app\index\repository
 * @author Teddy Sun <sgsheg@163.com>
 */
class ProductSkuRepository extends Repository
{
    public function model()
    {
        return ProductSkuModel::class;
    }

    /**
     * @param array $data
     * @return mixed
     */
    public function save(array $data)
    {
        $result = $this->makeModel()->esAdd($data, $data['price_id']);

        return isset($result['result']) && $result['result'] === 'created';
    }

    /**
     * 获取产品表中最大的product_id
     */
    public function getMaxPriceId()
    {
        $filter         = [];
        $filter['aggs'] = [
            'max_price_id' => [
                'max' => [
                    'field' => 'price_id'
                ]
            ]
        ];

        $result = $this->makeModel()->esAggsSearch($filter);

        if (isset($result['aggs'])) {

            if (isset($result['aggs']['max_price_id'])) {
                $existProduct = $result['aggs']['max_price_id'];

                return $existProduct['value'];
            }
        }

        return 0;
    }

    /**
     * 查找sku是否已经存在
     *
     * @param $data
     * @return bool|String
     */
    public function checkAreaAndLineExist($prodcutId, $data)
    {
        $filter = [
            'query' => [
                'bool' => [
                    'must' => [

                    ],
                ]
            ]
        ];

        $filter['query']['bool']['must'][] = ['term' => ['product_id' => $prodcutId]];

        if (isset($data['area'])) {
            $filter['query']['bool']['must'][] = ['term' => ['area.keyword' => $data['area']]];
            if (isset($data['line'])) {
                $filter['query']['bool']['must'][] = ['term' => ['line.keyword' => $data['line']]];
            }

            $existProductSku = $this->findBy($filter);
            if ($existProductSku) {
                return Finalfail(REP_CODE_PRODUCT_SKU_LINE_EXIST, '该地区线路sku已存在');
            }
        }

        return true;
    }
}