<?php

namespace app\index\repository;

use app\common\exception\RepositoryException;
use app\index\repository\interfaces\RepositoryInterface;
use think\App;
use think\Model;

abstract class Repository implements RepositoryInterface
{
    /**
     * @var Model
     */
    private $model;

    /**
     * @var \think\App
     */
    private $app;

    /**
     * BaseRepository constructor.
     *
     * @throws \app\common\exception\RepositoryException
     */
    public function __construct()
    {
        $this->app = new App();

        $this->makeModel();
    }

    /**
     *
     * @return mixed
     */
    public abstract function model();

    /**
     * @return \think\Model
     * @throws \app\common\exception\RepositoryException
     */
    public function makeModel()
    {
        $model = $this->app->invokeClass($this->model());

        if (! $model instanceof Model) {
            throw new RepositoryException('model class not found');
        }

        return $this->model = $model;
    }

    /**
     * Specify Model class name
     *
     * @return mixed
     */

    /**
     * @param array $filter
     * @param int $from
     * @param null $size
     * @return mixed
     */
    public function all($filter = [], $from = 0, $size = null)
    {
        return $this->model->esSearch($filter, $from, $size);
    }

    /**
     * @param array $data
     * @return mixed
     */
    public function create(array $data)
    {
        $result = $this->model->esAdd($data);

        return isset($result['result']) && $result['result'] === 'created';
    }

    /**
     * @param array $info
     * @param $id
     * @param string $attribute
     * @return bool
     */
    public function update(array $info, $id, $attribute = "id")
    {
        $data = $this->model->esUpdateById($info, $id);

        if ($data === false) {
            return false;
        }

        return $data['result'] === 'updated';
    }

    /**
     * @param $id
     * @return mixed
     */
    public function delete($id)
    {
        return $this->model->esDeleteById($id);
    }

    /**
     * @param array $ids
     * @return mixed
     */
    public function multipleDelete(array $ids)
    {
        return $this->model->esBulkDelete($ids);
    }

    /**
     * @param $id
     * @return mixed
     */
    public function find($id)
    {
        return $this->model->esGetById($id);
    }

    /**
     * @param $filter
     * @param int $from
     * @param int $size
     */
    public function findBy($filter, $from = 0, $size = 50)
    {
        return $this->model->esSearch($filter, $from, $size);
    }

    /**
     * @param array $filter
     * @return null|string
     * @throws \Exception
     */
    public function count($filter = [])
    {
        return $this->model->esCountDocs($filter);
    }
}
