<?php

namespace app\index\repository;

use app\index\model\ProductModel;

/**
 * Class ProductRepository
 *
 * @package app\index\repository
 * @author Teddy Sun <sgsheg@163.com>
 */
class ProductRepository extends Repository
{
    public function model()
    {
        return ProductModel::class;
    }

    /**
     * @param $data
     * @param null $mustNot
     * @return bool|String
     */
    public function checkExist($data, $mustNot = null)
    {
        $filter = [
            'query' => [
                'bool' => [
                    'must'     => [

                    ],
                    'must_not' => [

                    ]
                ]
            ]
        ];
        if ($mustNot) {
            $filter['query']['bool']['must_not'] = $mustNot;
        }
        //在es中查找是否已经存在了手机或者号码
        if (isset($data['product_name'])) {
            $filter['query']['bool']['must'][] = ['term' => ['product_name.keyword' => $data['product_name']]];
            if (isset($data['product_type'])) {
                $filter['query']['bool']['must'][] = ['term' => ['product_type.keyword' => $data['product_type']]];
            }

            $existProduct = $this->findBy($filter);
            if ($existProduct) {
                return Finalfail(REP_CODE_PRODUCT_NAME_EXIST, '商品名称已存在');
            }
        }

        return true;
    }

    /**
     * 获取产品表中最大的product_id
     */
    public function getMaxProductId()
    {
        $filter         = [];
        $filter['aggs'] = [
            'max_product_id' => [
                'max' => [
                    'field' => 'product_id'
                ]
            ]
        ];

        $result = $this->makeModel()->esAggsSearch($filter);

        if (isset($result['aggs'])) {

            if (isset($result['aggs']['max_product_id'])) {
                $existProduct = $result['aggs']['max_product_id'];

                return $existProduct['value'];
            }
        }

        return 0;
    }

    /**
     * 定价管理中存在product_id就不能删除商品
     *
     * @param $productIds
     * @return bool
     * @throws \app\common\exception\RepositoryException
     */
    public function allowDelete($productIds)
    {
        foreach ($productIds as $productId) {
            $product = $this->find($productId);

            $filter = ['query' => ['term' => ['product_id' => $product['product_id']]]];

            $sku    = new ProductSkuRepository();
            $result = $sku->findBy($filter);

            if (! empty($result)) {
                return false;
            }
        }

        return true;
    }
}