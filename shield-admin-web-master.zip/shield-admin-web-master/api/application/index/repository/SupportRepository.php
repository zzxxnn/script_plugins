<?php

namespace app\index\repository;

/**
 * Class SupportRepository 支持人员
 *
 * @package app\index\repository
 * @author Teddy Sun <sgsheg@163.com>
 */
use app\common\model\SupportModel;

class SupportRepository extends Repository
{
    public function model()
    {
        return SupportModel::class;
    }

    /**
     * 更新用户信息
     *
     * @param array $user_info
     * @param $id
     * @return Boolean
     * @throws \Exception
     */
    public function updateUser($user_info, $id): bool
    {
        $data = $this->makeModel()->esUpdateById($user_info, $id);
        if ($data === false) {
            return false;
        }

        return 'updated' === $data['result'];
    }

    /**
     * 是否进行新增或者修改
     *
     * @param $data
     * @param null $mustNot
     * @return bool|String
     */
    public function checkExist($data, $mustNot = null)
    {
        $filter = [
            'query' => [
                'bool' => [
                    'must'     => [

                    ],
                    'must_not' => [

                    ]
                ]
            ]
        ];
        if ($mustNot) {
            $filter['query']['bool']['must_not'] = $mustNot;
        }
        //在es中查找是否已经存在了手机或者号码
        if (isset($data['mobile'])) {
            $filter['query']['bool']['must'] = ['term' => ['mobile' => $data['mobile']]];
            $existSupport                    = $this->findBy($filter);

            if ($existSupport) {
                return Finalfail(REP_CODE_SOURCE_EXIST, '手机号已存在');
            }
        }

        if (isset($data['qq'])) {
            $filter['query']['bool']['must'] = ['term' => ['qq' => $data['qq']]];
            $existSupport                    = $this->findBy($filter);

            if ($existSupport) {
                return Finalfail(REP_CODE_SUPPORT_QQ_EXIST, 'QQ号已存在');
            }
        }

        return true;
    }
}