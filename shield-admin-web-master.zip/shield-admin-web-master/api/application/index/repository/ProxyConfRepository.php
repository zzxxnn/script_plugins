<?php

namespace app\index\repository;

use app\index\model\ProxyConfModel;

class ProxyConfRepository
{
    public function __construct()
    {
        $this->model = new ProxyConfModel();
    }

    /**
     * 根据IP查找
     *
     * @param String $id
     * @return Array
     */
    public function selectConfById($id)
    {
        $data = $this->model->esGetById($id);
        return $data;
    }

    /**
     * @param $ids
     * @return array|bool
     */
    public function bundleDelete($ids)
    {
        try {
            return $this->model->esBulkDelete($ids);
        } catch (\Exception $e) {
            return false;
        }
    }

}
