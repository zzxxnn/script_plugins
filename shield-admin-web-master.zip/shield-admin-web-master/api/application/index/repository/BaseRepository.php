<?php

namespace app\index\repository;

/**
 * 一系列针对Model 的操作
 *
 * Class BaseRepository
 *
 * @package app\index
 */
abstract class BaseRepository
{
    protected $model;

    public function getListTotal($filter, $model = null)
    {
        try {
            $model = $model ?: $this->model;

            return (int) $model->esCount($filter);
        } catch (\Exception $e) {
            return 0;
        }
    }
}