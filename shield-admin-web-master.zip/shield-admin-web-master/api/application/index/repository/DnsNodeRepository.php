<?php

namespace app\index\repository;

use app\index\model\DnsNodeModel;

class DnsNodeRepository extends BaseRepository
{
    public function __construct()
    {
        $this->model = new DnsNodeModel();
    }

    /**
     * 生成不重复ID
     *
     * @return String $id
     */
    public function generateInstanceId()
    {
        do {
            $id = "dns-".strtolower(str_rand(10));
            $result = $this->selectNodeById($id);
        } while ($result);

        return $id;
    }

    /**
     * 获取高防节点列表
     *
     * @param array $filter
     * @param integer $from
     * @param integer $size
     * @return Array
     */
    public function selectNodes($filter = [], $from = 0, $size = null)
    {
        $data = $this->model->esSearch($filter, $from, $size);
        return $data;
    }

    /**
     * 获取高防节点列表个数
     * 
     * @param array $filter
     * @return Array
     */
    public function countNodes($filter = []){
        $count = $this->model->esCountDocs($filter);
        return $count;
    }

    /**
     * 根据IP查找节点
     *
     * @param String $id
     * @return Array
     */
    public function selectNodeById($id)
    {
        $data = $this->model->esGetById($id);
        return $data;
    }

    /**
     * 批量添加
     *
     * @param Array $node_info
     * @return Boolean
     */
    public function insertAllNodes($node_info){
        $data = $this->model->esBulk($node_info);
        return $data ? true : false;
    }

    /**
     * 删除节点
     *
     * @param String $id
     * @return Array
     */
    public function removeNode($id)
    {
        $result = $this->model->esDeleteById($id);
        return $result;
    }

    /**
     * 删除dns节点
     * 
     * @param $ids
     * @return array|bool
     */
    public function bundleDelete($ids)
    {
        try {
            return $this->model->esBulkDelete($ids);
        } catch (\Exception $e) {
            return false;
        }
    }
}
