<?php

namespace app\index\repository;

use app\index\model\AreaModel;

/**
 * Class AreaRepository
 *
 * @package app\index\repository
 * @author Teddy Sun <sgsheg@163.com>
 */
class AreaRepository extends BaseRepository
{
    public function __construct()
    {
        $this->model = new AreaModel();
    }

    /**
     * 添加区域记录
     *
     * @param $area
     * @return bool
     * @throws \Exception
     */
    public function create($area): bool
    {
        $result = $this->model->esAdd($area);

        return isset($result['result']) && $result['result'] === 'created';
    }

    /**
     * 获取所有区域
     *
     * @param array $filter
     * @param int $from
     * @param null $size
     * @return array
     * @throws \Exception
     */
    public function all($filter = [], $from = 0, $size = null)
    {
        return $this->model->esSearch($filter, $from, $size);
    }
}