<?php

namespace app\index\repository\interfaces;

interface RepositoryInterface
{
    public function all($columns = ['*']);

    public function create(array $data);

    public function update(array $data, $id);

    public function delete($id);

    public function multipleDelete(array $ids);

    public function find($id);

    public function findBy($filter,$from,$size);

    public function count();
}