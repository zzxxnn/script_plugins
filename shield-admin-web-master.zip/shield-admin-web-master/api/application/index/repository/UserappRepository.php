<?php

namespace app\index\repository;

use app\common\model\SiteModel;

class UserappRepository extends BaseRepository
{
    public function __construct()
    {
        $this->model = new SiteModel();
    }

    /**
     * @param array $filter
     * @param int $from
     * @param null $size
     * @return array
     * @throws \Exception
     */
    public function appList($filter = [], $from = 0, $size = null)
    {
        $list = $this->model->esSearch($filter, $from, $size);

        return $list;
    }

    /**
     * 获取列表个数
     *
     * @throws \Exception
     */
    public function countApps($filter = [])
    {
        return $this->model->esCountDocs($filter);
    }

    /**
     * @param $ids
     * @return array|bool
     */
    public function bundleDelete($ids)
    {
        try {
            return $this->model->esBulkDelete($ids);
        } catch (\Exception $e) {
            return false;
        }
    }
}
