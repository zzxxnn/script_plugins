<?php

namespace app\index\repository;

use app\index\model\ProxyNodeModel;
use app\index\model\UserInstanceModel;

class ProxyNodeRepository extends BaseRepository
{
    public function __construct()
    {
        $this->model = new ProxyNodeModel();
        $this->instanceModel = new UserInstanceModel();
    }

    /**
     * 生成不重复ID
     *
     * @return String $id
     */
    public function generateInstanceId()
    {
        do {
            $id = 'proxy-'.strtolower(str_rand(10));
            $result = $this->selectNodeById($id);
        } while ($result);

        return $id;
    }

    /**
     * 获取高防节点列表
     *
     * @param Array $filter
     * @param Integer $from
     * @param Integer $size
     * @return array
     */
    public function selectNodes($filter = [], $from = 0, $size = null)
    {
        $data = $this->model->esSearch($filter, $from, $size);
        return $data;
    }

    /**
     * 获取高防节点列表个数
     */
    public function countNodes($filter = []){
        $count = $this->model->esCountDocs($filter);
        return $count;
    }

    /**
     * 根据IP查找节点
     *
     * @param String $id
     * @return Array
     */
    public function selectNodeById($id)
    {
        $data = $this->model->esGetById($id);
        return $data;
    }

    /**
     * 创建高防节点
     *
     * @param Array $node_info
     * @return Boolean
     */
    public function insertNode($node_info)
    {
        $id = $node_info['ip'];
        $data = $this->model->esAdd($node_info, $id);
        if ($data === false) {
            return false;
        }
        return $data["result"] == 'created' ? true : false;
    }

    /**
     * 批量添加高防节点
     *
     * @param Array $node_info
     * @return Boolean
     */
    public function insertAllNodes($node_info){
        $data = $this->model->esBulk($node_info);
        return $data ? true : false;
    }

    /**
     * 更新高防节点
     *
     * @param Array $node_info
     * @return Boolean
     */
    public function updateNodeById($node_info, $id){
        $data = $this->model->esUpdateById($node_info, $id);
        return $data ? true : false;
    }

    /**
     * 删除高防节点
     *
     * @param String $id
     * @return Array
     */
    public function removeNode($id)
    {
        $result = $this->model->esDeleteById($id);
        return $result;
    }

    /**
     * 从用户实例中拿出node_id
     *
     * @param array $filter
     * @return array
     */
    public function getNodeIdByUser($filter){
        $result = $this->instanceModel->esSearch($filter);
        return $result;
    }

    /**
     * @param $ids
     * @return array|bool
     */
    public function bundleDelete($ids)
    {
        try {
            return $this->model->esBulkDelete($ids);
        } catch (\Exception $e) {
            return false;
        }
    }

}
