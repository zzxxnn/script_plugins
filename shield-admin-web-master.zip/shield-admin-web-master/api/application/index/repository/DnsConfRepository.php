<?php

namespace app\index\repository;

use app\index\model\DnsConfModel;

class DnsConfRepository extends BaseRepository
{
    public function __construct()
    {
        $this->model = new DnsConfModel();
    }

    /**
     * 获取dns解析配置个数
     *
     * @param array $filter
     * @return null|string
     * @throws \Exception
     */
    public function countConfs($filter = [])
    {
        return $this->model->esCountDocs($filter);
    }

    /**
     * 获取dns解析配置
     *
     * @param array $filter
     * @param Integer $from
     * @param Integer $size
     * @return array
     * @throws \Exception
     */
    public function selectConfs($filter = [], $from = 0, $size = null): array
    {
        return $this->model->esSearch($filter, $from, $size);
    }

    /**
     * 根据IP查找dns解析配置
     *
     * @param $id
     * @return null|string
     * @throws \Exception
     */
    public function selectConfById($id)
    {
        return $this->model->esGetById($id);
    }

    /**
     * 创建dns解析配置
     *
     * @param $conf
     * @param null $id
     * @return bool
     * @throws \Exception
     */
    public function insertConf($conf, $id = null): bool
    {
        $data = $this->model->esAdd($conf, $id);
        if ($data === false) {
            return false;
        }

        return $data['result'] === 'created';
    }

    /**
     * 删除dns解析配置
     *
     * @param $ids
     * @return array|bool
     */
    public function bundleDelete($ids)
    {
        try {
            return $this->model->esBulkDelete($ids);
        } catch (\Exception $e) {
            return false;
        }
    }
}
