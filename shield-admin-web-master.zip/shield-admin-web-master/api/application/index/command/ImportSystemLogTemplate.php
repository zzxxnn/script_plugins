<?php

namespace app\index\command;

use app\index\repository\SystemLogTemplateRepository;
use think\console\Command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;

/**
 * class ImportLogTemplate 日志文案模板导入
 * @package app\index\command
 */
class ImportSystemLogTemplate extends Command
{

    protected function configure()
    {
        parent::configure();
        $this->setName('import:system-log-template')->addOption('plain', null, Option::VALUE_NONE,
                'import system log templates to elasticSearch')->setDescription('Import system log templates to database');
    }

    protected function execute(Input $input, Output $output)
    {
        $output->writeln("<info>begin to import system log templates.</info>");
        $system_log_templates = file_get_contents(APP_PATH.'index/database/SystemLogTemplate.json');

        if ($system_log_templates) {
            $repository = new SystemLogTemplateRepository();
            $templates  = json_decode($system_log_templates, true);
            foreach ($templates as $template) {
                try {
                    if ($repository->create($template)) {
                        $output->write('<info>导入'.$template['name'].'成功.</info>', true);
                    }

                } catch (\Exception $e) {
                    $output->write('<error>导入数据遇到问题了.请查看日志.</error>');
                    die;
                }
            }
        }
        $output->writeln('<info>end to import system log templates.</info>');
    }
}