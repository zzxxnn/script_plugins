<?php
/**
 * This file  is a part of  Veda- Platform
 * Copyright (c) 2015 - 2018. Veda Software Inc. (http://www.veda.com)
 *
 * @file                ImportPrice.php
 * @author              Teddy Sun
 */

namespace app\index\command;

use app\index\repository\AreaRepository;
use app\index\repository\PriceRepository;
use think\console\command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;

/**
 * Class ImportPrice 导入
 *
 * @package app\index\command
 * @author Teddy Sun <sgsheg@163.com>
 */
class ImportPrice extends command
{
    protected function configure()
    {
        parent::configure();
        $this->setName('import:price')
            ->addOption('plain', null, Option::VALUE_NONE, 'import data to elasticSearch price table')
            ->setDescription('Import price to database');
    }

    // 执行命令
    protected function execute(Input $input, Output $output)
    {
        $output->writeln("<info>开始导入单价到数据库中.</info>");
        $provinces = [];
        // 获取系统所有的区域
        $areaRepository = new AreaRepository();
        try {
            $areas = $areaRepository->all();
            foreach ($areas as $area) {

                $children = $area['children'];

                if (! empty($children)) {
                    foreach ($children as $child) {
                        $provinces[] = ['id' => $child['value'], 'province' => $child['label']];
                    }
                } else {
                    //特殊省份 澳门香港台湾
                    $provinces[] = ['id' => $area['value'], 'province' => $area['label']];
                }
            }
        } catch (\Exception $e) {
            $output->write('<error>遇到问题了.</error>');
        }

        $prices = file_get_contents(APP_PATH.'index/database/Price.json');

        if ($prices) {
            $repository = new PriceRepository();
            $prices   = json_decode($prices, true);

            foreach ($provinces as $province) {
                $insert = [
                    'province_id' => $province['id'],
                    'province'    => $province['province'],
                    'price'       => $prices,
                ];

                try {
                    if ($repository->create($insert)) {
                        $output->write('<info>导入'.$province['province'].'成功.</info>', true);
                    }
                } catch (\Exception $e) {
                    dump($e->getMessage());
                    $output->write('<error>导入数据遇到问题了.请查看日志.</error>');
                }
            }
        }
        $output->write('<info>导入结束.</info>');
    }
}