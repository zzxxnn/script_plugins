<?php
/*
* This file  is a part of  Veda- Platform
* Copyright (c) 2015 - 2018. Veda Software Inc. (http://www.veda.com)
*
* @file             ImportSupport.php
* @author           Teddy Sun
*/

namespace app\index\command;

use app\index\repository\SupportRepository;
use think\console\Command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;

/**
 * Class ImportSupport 导入支持人员
 *
 * @package app\index\command
 * @author Teddy Sun <sgsheg@163.com>
 */
class ImportSupport extends Command
{
    protected function configure()
    {
        parent::configure();
        $this->setName('import:support')
            ->addOption('plain', null, Option::VALUE_NONE, 'import data to elasticSearch user_support')
            ->setDescription('Import support to database');
    }

    /**
     * @param \think\console\Input $input
     * @param \think\console\Output $output
     * @return int|null|void
     */
    protected function execute(Input $input, Output $output)
    {
        $output->writeln("<info>begin to import support.</info>");
        $supports = file_get_contents(APP_PATH.'index/database/Support.json');

        if ($supports) {
            $supports = json_decode($supports, true);

            $repository = new SupportRepository();

            foreach ($supports as $support) {
                $insert = [
                    'name'        => $support['name'],
                    'nickname'    => $support['nickname'],
                    'mobile'      => $support['mobile'],
                    'qq'          => $support['qq'],
                    'wechat'      => $support['wechat'],
                    'email'       => $support['email'],
                    'type'        => $support['type'],
                    'type_name'   => $support['type_name'],
                    'status'      => $support['status'],
                    'avatar'      => $support['avatar'] ?? '/avatar/support-user1.png',
                    'create_time' => $support['create_time'] ?? gmt_withTZ(),
                ];

                try {
                    if ($repository->create($insert)) {
                        $output->write('<info>导入'.$support['name'].'成功.</info>', true);
                    }
                } catch (\Exception $e) {
                    $output->write('<error>导入数据遇到问题了.请查看日志.</error>');
                    die;
                }
            }
        }
        $output->write('<info>导入结束.</info>');
    }
}