<?php
/*
* This file  is a part of  Veda- Platform
* Copyright (c) 2015 - 2018. Veda Software Inc. (http://www.veda.com)
*
* @file             ImportProduct.php
* @author           Teddy Sun
*/

namespace app\index\command;

use app\index\repository\ProductRepository;
use app\index\repository\ProductSkuRepository;
use think\console\Command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;

/**
 * Class ImportProduct 导入商品和商品sku
 *
 * @package app\index\command
 * @author Teddy Sun <sgsheg@163.com>
 */
class ImportProduct extends Command
{
    protected function configure()
    {
        parent::configure();
        $this->setName('import:product')
            ->addOption('plain', null, Option::VALUE_NONE, 'import data to elasticSearch products and product_sku')
            ->setDescription('Import product and product_sku to database');
    }

    /**
     * @param \think\console\Input $input
     * @param \think\console\Output $output
     * @return int|null|void
     * @throws \app\common\exception\RepositoryException
     * @throws \Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $output->writeln("<info>begin to import product and product sku.</info>");
        $products = file_get_contents(APP_PATH.'index/database/Product.json');

        if ($products) {
            $products = json_decode($products, true);

            $repository = new ProductRepository();
            //获取当前products中的个数
            // $count = (int)$repository->getMaxProductId() + 1;

            foreach ($products as $product) {
                $insert = [
                    'product_id'          => $product['product_id'],
                    'product_name'        => $product['product_name'],
                    'product_type'        => $product['product_type'],
                    'product_description' => $product['product_description'],
                    'on_sale'             => $product['on_sale'],
                    'attributes'          => $product['attributes'],
                    'created_by'          => $product['created_by'] ?? 'admin@veda.com',
                    'create_time'         => $product['create_time'] ?? gmt_withTZ(),
                ];

                try {
                    if ($repository->create($insert)) {
                        $output->write('<info>导入'.$product['product_name'].'成功.</info>', true);
                    }
                } catch (\Exception $e) {
                    $output->write('<error>导入数据遇到问题了.请查看日志.</error>');
                    die;
                }
            }
        }
        $output->write('<info>导入products结束.</info>');
        $output->write('<info>开始导入sku.</info>');

        $productSku = file_get_contents(APP_PATH.'index/database/ProductSku.json');
        if ($productSku) {
            $items = json_decode($productSku, true);

            $repository = new ProductSkuRepository();

            foreach ($items as $item) {
                try {
                    if ($repository->save($item)) {
                        $output->write('<info>导入'.$item['product_id'].'成功.</info>', true);
                    }
                } catch (\Exception $e) {
                    $output->write('<error>导入数据遇到问题了.请查看日志.</error>');
                    die;
                }
            }
        }
        $output->write('<info>导入sku结束.</info>');
    }
}