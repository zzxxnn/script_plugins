<?php

namespace app\index\command;

use app\index\repository\ProxyNodeRepository;
use think\console\Command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;


/**
 * class ImportProxyNode 高防节点信息导入
 * @package app\index\command
 */
class ImportProxyNode extends Command
{
    protected function configure()
    {
        parent::configure();
        $this->setName('import:proxynode')
            ->addOption('plain', null, Option::VALUE_NONE, 'import data to elasticSearch proxy_node_info')
            ->setDescription('Import proxy_node_info to database');
    }

    protected function execute(Input $input, Output $output)
    {
        $output->writeln("<info>begin to import proxy_node_info.</info>");
        $proxys = file_get_contents(APP_PATH.'index/database/ProxyNode.json');

        if ($proxys) {
            $proxys = json_decode($proxys, true);

            $repository = new ProxyNodeRepository();

            $bulk = [];

            foreach ($proxys as $proxy) {
                $bulk[] = [
                    'index' => ['_id' => $proxy['node_id']]
                ];
                $bulk[] = $proxy;
            }

            try {
                if ($repository->insertAllNodes($bulk)) {
                    $output->writeln('<info>成功导入'.count($proxys).'条成功.</info>');
                }
            } catch (\Exception $e) {
                $output->writeln('<error>导入数据遇到问题了.请查看日志.</error>');
                die;
            }
        }
        $output->writeln('<info>导入结束.</info>');
    } 
}