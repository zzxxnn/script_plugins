<?php
/**
 * This file  is a part of  Veda- Platform
 * Copyright (c) 2015 - 2018. Veda Software Inc. (http://www.veda.com)
 *
 * @file                ImportAreas.php
 * @author              Teddy Sun
 */

namespace app\index\command;

use app\index\repository\AreaRepository;
use think\console\command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;

/**
 * Class ImportAreas 导入
 *
 * @package app\index\command
 * @author Teddy Sun <sgsheg@163.com>
 */
class ImportAreas extends command
{
    protected function configure()
    {
        parent::configure();
        $this->setName('import:areas')
            ->addOption('plain', null, Option::VALUE_NONE, 'import data to elasticSearch')
            ->setDescription('Import areas to database');
    }

    // 执行命令
    protected function execute(Input $input, Output $output)
    {
        $output->writeln("<info>begin to import area.</info>");
        $areas = file_get_contents(APP_PATH.'index/database/AreaList.json');

        if ($areas) {
            $areas = json_decode($areas, true);

            $repository = new AreaRepository();
            foreach ($areas as $area) {
                $insertData = [
                    'label'    => $area['label'],
                    'value'    => $area['value'],
                    'children' => $area['children'] ?? [],
                ];
                try {
                    if ($repository->create($insertData)) {
                        $output->write('<info>导入'.$area['label'].'成功.</info>', true);
                    }

                } catch (\Exception $e) {
                    $output->write('<error>导入数据遇到问题了.请查看日志.</error>');
                    die;
                }
            }
        }
        $output->write('<info>导入结束.</info>');
    }
}