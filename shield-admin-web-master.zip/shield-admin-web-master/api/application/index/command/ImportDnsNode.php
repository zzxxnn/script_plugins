<?php

namespace app\index\command;

use app\index\repository\DnsNodeRepository;
use think\console\Command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;


/**
 * class ImportDnsNode 高防节点信息导入
 * @package app\index\command
 */
class ImportDnsNode extends Command
{
    protected function configure()
    {
        parent::configure();
        $this->setName('import:dnsnode')
            ->addOption('plain', null, Option::VALUE_NONE, 'import data to elasticSearch dns_node_info')
            ->setDescription('Import dns_node_info to database');
    }

    protected function execute(Input $input, Output $output)
    {
        $output->writeln("<info>begin to import dns_node_info.</info>");
        $dnss = file_get_contents(APP_PATH.'index/database/DnsNode.json');

        if ($dnss) {
            $dnss = json_decode($dnss, true);

            $repository = new DnsNodeRepository();

            $bulk = [];

            foreach ($dnss as $dns) {
                $bulk[] = [
                    'index' => ['_id' => $dns['node_id']]
                ];
                $bulk[] = $dns;
            }

            try {
                if ($repository->insertAllNodes($bulk)) {
                    $output->writeln('<info>成功导入'.count($dnss).'条成功.</info>');
                }
            } catch (\Exception $e) {
                $output->writeln('<error>导入数据遇到问题了.请查看日志.</error>');
                die;
            }
        }
        $output->writeln('<info>导入结束.</info>');
    } 
}