<?php

use think\Route;

Route::group('v1', function () {
    Route::get([
        'loginfo'                  => 'index/Sessions/index',
        'dnsnodes/:id/dynamic'     => 'index/dns.DynamicConf/index',
        'dnsnodes/:id/static'      => 'index/dns.StaticConf/index',
        'antinodes/:id/sites'      => 'index/ProxyNodes/getAppSiteConfig',
        'antinodes/:id/apps'       => 'index/ProxyNodes/getAppSiteConfig',
        'dnsnodes/sites'           => 'index/DnsNodes/siteDetail',
        'product/:id/sku'          => 'index/product.ProductSku/index',   //商品下的sku信息
        'product/:id/attributes'   => 'index/product.ProductSku/getAttributes',
        'product/:id/sku/:sku'     => 'index/product.ProductSku/show',
        'app-version'              => 'index/Index/appVersion',
        'system-log'               => 'index/SystemLog/index',  // 日志列表
        'system-log/search-config' => 'index/SystemLog/searchConfig',  // 日志列表搜索项
        'invoice'                  => 'index/Invoice/index',  // 开票列表
        'invoice/search-config'    => 'index/Invoice/searchConfig',  // 开票搜索项
        'invoice/:id'              => 'index/Invoice/show',  // 开票详情
    ]);
    Route::post([
        'login'                => 'index/Sessions/create',
        'dnsnodes/:id/static'  => 'index/dns.StaticConf/create',
        'product/:id/sku'      => 'index/product.ProductSku/create',   //保存sku信息
        'customs/:id/recharge' => 'index/Customs/recharge',   // 充值
        'photo/upload'         => 'index/common.PhotoController/upload',  // 上传审批单以及单据等图片
        'customs/:id'          => 'index/Customs/update',   // 更新用户信息
    ]);
    Route::put([
        'admins/:id/password'       => 'index/Admins/password',
        'admins/:id/username'       => 'index/Admins/username',
        'antinodes/:id/sitelimit'   => 'index/ProxyNodes/editNodeSiteLimit',
        'customs/bundleSale'        => 'index/Customs/bundleSale',
        'product/:id/sku/:sku'      => 'index/product.ProductSku/update',   //修改sku信息
        'customs/:id/password'      => 'index/Customs/password',  // 修改用户密码
        'invoice/:id/agree'         => 'index/Invoice/agree',  // 发票审批通过
        'invoice/:id/track'         => 'index/Invoice/track',  // 发票审批快递
        'invoice/:id/reject'        => 'index/Invoice/reject',  // 发票审批拒绝
        'customs/:id/resetRealName' => 'index/Customs/resetRealName',  // 重置用户实名认证
    ]);
    Route::delete([
        'logout'               => 'index/Sessions/destroy',
        'usersites/delete'     => 'index/Site/bundleDelete',
        'userapps/delete'      => 'index/UserApps/bundleDelete',
        'customs/delete'       => 'index/Customs/bundleDelete',
        'admins/delete'        => 'index/Admins/bundleDelete',
        'antinodes/delete'     => 'index/ProxyNodes/bundleDelete',
        'dnsnodes/delete'      => 'index/DnsNodes/bundleDelete',
        'dnsnodes/:id/dynamic' => 'index/dns.DynamicConf/bundleDelete',
        'dnsnodes/:id/static'  => 'index/dns.StaticConf/bundleDelete',
        'support'              => 'index/support.Support/bundleDelete',
        'agent'                => 'index/Agent/bundleDelete',
        'product'              => 'index/product.Product/bundleDelete',
        'product/:id/sku'      => 'index/product.ProductSku/bundleDelete',
    ]);

    Route::resource('admins', 'index/Admins');
    Route::resource('customs', 'index/Customs');            //普通用户
    Route::resource('contents', 'index/Contents', [ 'only' => [ 'index' ] ]);
    Route::resource('userapps', 'index/UserApps');
    Route::resource('usersites', 'index/Site');
    Route::resource('antinodes', 'index/ProxyNodes');
    Route::resource('dnsnodes', 'index/DnsNodes');
    Route::resource('price', 'index/Price');                //定价接口
    Route::resource('areas', 'index/Area');                 //区域接口
    Route::resource('order', 'index/Order');                //订单接口
    Route::resource('support', 'index/support.Support');    //技术支持
    Route::resource('agent', 'index/Agent');                //代理商
    Route::resource('product', 'index/product.Product');    //产品
    Route::resource('systemlog', 'index/SystemLog');        //日志
    Route::get('order/:id/user', 'index/Order/showUserInfo'); //获取订单客户信息
    Route::post('order/:id/remind', 'index/Order/remindOrder'); //发送提醒
});
