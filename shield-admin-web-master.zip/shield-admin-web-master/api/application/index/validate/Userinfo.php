<?php

namespace app\index\validate;

use app\common\model\UserModel;
use think\Validate;

class Userinfo extends Validate
{
    protected $rule = [
        'ids'              => 'require|array|min:1',
        'id'               => 'require',
        'amount'           => 'require|number|between:10,1000000|regex:amount|checkMaxAmount',
        'approver_name'    => 'require',
        'receipt_number'   => 'require|alphaNum',
        'approve_photos'   => 'require|file|array',
        'safe_email'       => 'email|checkSafeEmail',
        'mobile'           => 'mobile|checkMobile',
        'new_password'     => 'require|min:8|max:16|password',
        'confirm_password' => 'require|min:8|max:16|password|checkConfirmPassword',
        '_from'            => 'integer|egt:0',
        '_size'            => 'integer|gt:0',
        'username'         => 'chsDash|min:1|max:20'
    ];

    protected $regex = [
        'amount' => '/^([1-9]\d*|0)(\.\d{1,2})?$/'
    ];

    protected $field = [
        'ids'              => '站点ID',
        'id'               => '用户ID',
        'amount'           => '充值金额',
        'approver_name'    => '审批人名字',
        'receipt_number'   => '审批单号\或其他单据编号',
        'approve_photos'   => '审批单或其他单据图片',
        'safe_email'       => '安全邮箱',
        'mobile'           => '手机号',
        'new_password'     => '新密码',
        'confirm_password' => '确认密码',
        '_from'            => '列表开始',
        '_size'            => '列表行数',
        'username'         => '用户名'
    ];

    protected $message = [
        'id.require'                            => '用户ID不能为空',
        'amount.require'                        => '充值金额不能为空',
        'amount.number'                         => '充值金额必须为数字',
        'amount.regex'                          => '充值金额近支持小数点后两位小数',
        'approver_name.require'                 => '审批人名字不能为空',
        'receipt_number.require'                => '审批单号\或其他单据编号不能为空',
        'receipt_number.alphaNum'               => '审批单号\或其他单据编号不能包含中文',
        'approve_photos.require'                => '审批单或其他单据不能为空',
        'approve_photos.array'                  => '审批单或其他单据必须为数组',
        'safe_email.email'                      => '安全邮箱格式错误',
        'mobile.require'                        => '手机号不能为空',
        'mobile.mobile'                         => '手机号格式错误',
        'mobile.checkMobile'                    => '手机号不能重复',
        'new_password.require'                  => '密码不能为空',
        'new_password.min'                      => '密码不能小于8个字符',
        'new_password.max'                      => '密码不能超过16个字符',
        'new_password.password'                 => '密码必须包括数字、字母大小写',
        'confirm_password.require'              => '确认密码不能为空',
        'confirm_password.min'                  => '确认密码不能小于8个字符',
        'confirm_password.max'                  => '确认密码不能超过16个字符',
        'confirm_password.password'             => '确认密码必须包括数字、字母大小写',
        'confirm_password.checkConfirmPassword' => '两次输入密码不一致',
    ];

    // update_account: 充值金额验证
    protected $scene = [
        'list'            => ['_from', '_size'],
        'bundle_delete'   => [ 'ids' ],
        'bundle_sale'     => [ 'ids' ],
        'update_account'  => [ 'id', 'amount', 'approver_name', 'receipt_number' ],
        'update_customer' => [ 'id', 'mobile', 'username' ],
        'update_password' => [ 'id', 'new_password', 'confirm_password' ]
    ];

    /**
     * TODO:每天仅能充值一次100万最大值
     * 每天仅能充值一次100万最大值
     *
     * @param $value
     * @param $rule
     * @param $data
     *
     * @return bool
     */
    protected function checkMaxAmount($value, $rule, $data)
    {
        return true;
    }

    protected function mobile($value)
    {
        return is_cellphone_number($value);
    }

    protected function password($value)
    {
        return is_correct_password($value);
    }

    /**
     * 验证手机号是否存在
     *
     * @param $value
     *
     * @return bool
     * @throws \think\exception\DbException
     */
    protected function checkMobile($value)
    {
        return UserModel::get([ 'mobile' => $value ]) ? false : true;
    }

    protected function checkSafeEmail($value)
    {
        $result = UserModel::where([
            'safe_email'          => $value,
            'email_verify_status' => UserModel::SAFE_EMAIL_STATUS_VERIFIED
        ])->find();
        if ($result) {
            return false;
        }

        return true;
    }

    /**
     * 验证确认密码是否与输入密码一致
     *
     * @param $value
     * @param $rule
     * @param $data
     *
     * @return bool
     */
    protected function checkConfirmPassword($value, $rule, $data)
    {
        return ($value == $data['new_password']) ? true : false;
    }
}
