<?php

namespace app\index\validate;

use think\Validate;

/**
 * Class Agent 代理商
 *
 * @package app\index\validate
 * @author Teddy Sun <sgsheg@163.com>
 */
class Agent extends Validate
{
    protected $rule = [
        'name'    => 'require',
        'mobile'  => 'require',
        'company' => 'require',
        'ids'     => 'require|array|min:1',
    ];

    protected $field = [
        'name'    => '代理商名称',
        'mobile'  => '手机号码',
        'company' => '公司名称',
        'ids'     => '代理商id',
    ];

    protected $message = [
        'name.require'    => '代理商名称必须',
        'mobile.require'  => '手机号码必须',
        'company.require' => '公司名称必须',
        'ids.require'     => '代理商必须',
        'min'             => '至少选择一个代理商',
        'array'           => '代理商格式有误',
    ];

    protected $scene = [
        'add'    => '',
        'edit'   => '',
        'delete' => ['ids'],
    ];
}