<?php

namespace app\index\validate;

use think\Validate;

class Admins extends Validate
{

    protected $rule = [
        'username'  => 'require',
        'password'  => 'require',
        'captcha'   => 'require',
        'old_pwd'   => 'require',
        'new_pwd'   => 'require|pwd_format',
        'new_uname' => 'require|alphaDash|length:4,16',
        'ids'       => 'require|array|min:1',
    ];

    protected $field = [
        'username'  => '用户名',
        'password'  => '密码',
        'captcha'   => '验证码',
        'old_pwd'   => '旧密码',
        'new_pwd'   => '新密码',
        'new_uname' => '新用户名',
        'ids'       => '管理员ID',

    ];

    protected $message = [
        'new_pwd.pwd_format'  => '新密码复杂度低',
        'password.pwd_format' => '密码复杂度低',
        'new_uname.length'    => '新用户名长度至少为4 ~ 16位'
    ];

    protected $scene = [
        'login'         => [ 'username', 'password', 'captcha' ],
        'add_admins'    => [ 'username', 'password' => 'require|pwd_format' ],
        'update_pwd'    => [ 'new_pwd' ],
        'update_uname'  => [ 'new_uname' ],
        'bundle_delete' => [ 'ids' ],

    ];

    protected function pwd_format($value)
    {
        return is_correct_password($value);
    }
}
