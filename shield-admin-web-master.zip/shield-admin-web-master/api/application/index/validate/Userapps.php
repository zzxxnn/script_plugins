<?php

namespace app\index\validate;
use think\Validate;

class Userapps extends Validate{

    protected $rule = [
        'ids' => 'require|array|min:1',

    ];

    protected $field = [
        'ids' => '站点ID',
    ];

    protected $message  =   [
        
    ];

    protected $scene = [
        'bundle_delete' => ['ids'],
    ];

}

