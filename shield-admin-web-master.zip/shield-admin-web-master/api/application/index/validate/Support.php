<?php

namespace app\index\validate;

use think\Validate;

/**
 * Class Support 支持人员
 *
 * @package app\index\validate
 * @author Teddy Sun <sgsheg@163.com>
 */
class Support extends Validate
{
    protected $rule = [
        'avatar' => 'require',
        'name'   => 'require|max:25',
        'mobile' => 'require|mobile',
        'qq'     => 'require',
        'ids'    => 'require|array|min:1',
    ];

    protected $field = [
        'avatar' => '头像',
        'name'   => '名称',
        'mobile' => '手机号码',
        'qq'     => 'QQ号码',
        'ids'    => '技术支持人员id'
    ];

    protected $message = [
        'avatar.require' => '头像必须',
        'name.require'   => '名称必须',
        'name.max'       => '名称最多不能超过25个字符',
        'qq.require'     => 'QQ号码必须',
        'mobile.require' => '手机号码必须',
        'mobile'         => '手机号码格式错误',
    ];

    protected $scene = [
        'add'    => ['avatar', 'name', 'mobile', 'qq'],
        'edit'   => ['mobile', 'qq'],
        'delete' => ['ids'],
    ];

    protected function mobile($value)
    {
        return is_cellphone_number($value);
    }
}