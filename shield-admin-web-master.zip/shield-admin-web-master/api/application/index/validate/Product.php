<?php

namespace app\index\validate;

use think\Validate;

/**
 * Class Product 商品
 *
 * @package app\index\validate
 * @author Teddy Sun <sgsheg@163.com>
 */
class Product extends Validate
{
    protected $rule = [
        'product_name'        => 'require|max:255',
        'product_type'        => 'require',
        'product_description' => 'max:500',
        'on_sale'             => 'require|number|in:1,2',
        'attributes'          => 'array',
        'ids'                 => 'require|array|min:1'
    ];

    protected $field = [
        'product_id'          => '商品id',
        'product_name'        => '商品名称',
        'product_type'        => '商品类型',
        'product_description' => '商品描述',
        'on_sale'             => '是否上架',
        'attributes'          => '商品属性',
    ];

    protected $message = [
        'product_name.require'    => '商品名称必须',
        'product_name.max'        => '商品名最多不能超过255个字符',
        'product_type'            => '商品类型必须',
        'product_description.max' => '商品描述最多500个字符',
        'on_sale.require'         => '上下架必须',
        'on_sale.number'          => '上下架必须是数字',
        'on_sale.in'              => '上下架介于1和2之间',
        'attributes.array'        => '商品属性必须为数组',
    ];

    protected $scene = [
        'show'   => ['id'],
        'add'    => ['product_name', 'product_type', 'on_sale'],
        'edit'   => '',
        'delete' => ['ids'],
    ];
}