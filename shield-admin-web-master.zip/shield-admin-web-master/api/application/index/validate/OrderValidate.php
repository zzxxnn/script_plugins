<?php

namespace app\index\validate;

use think\Validate;

/**
 * Class OrderValidate
 *
 * @package app\index\validate
 * @author  Teddy Sun <sgsheg@163.com>
 */
class OrderValidate extends Validate
{

    protected $rule = [
        'password'        => 'require',
        'final_fee'       => 'number',
        'discount'        => 'number|between:0.1,0.99',
        'user'            => 'require|array',
        'support'         => 'array',
        'sale'            => 'array',
        'other'           => 'array|checkCount',
        'email'           => 'email',
        'mobile'          => 'mobile',
        'approved_number' => 'alphaNum',
        'contract_number' => 'alphaNum'
    ];

    protected $field = [
        'final_fee'       => '价格',
        'discount'        => '折扣',
        'approved_by'     => '审批人',
        'approved_number' => '审批单号',
        'contract_number' => '合同编号',
        'approval_sheet'  => '审批单',
        'contract_sheet'  => '合同单',
        'password'        => '密码',
        'user'            => '客户',
        'support'         => '技术支持',
        'sale'            => '销售支持',
        'other'           => '特别通知',
        'email'           => '邮箱',
        'mobile'          => '手机号码',
    ];

    protected $message = [
        'password.require'         => '密码必须',
        'final_fee.number'         => '价格必须是数字',
        'user.require'             => '客户信息必须',
        'other.checkCount'         => '最多发送给10个联系人',
        'discount.between'         => '折扣输入不正确,9折请输入0.9',
        'mobile'                   => '手机格式错误',
        'email'                    => '邮箱错误',
        'approved_number.alphaNum' => '审批单号不能包含中文',
        'contract_number.alphaNum' => '合同编号不能包含中文'
    ];

    protected $scene = [
        'edit'   => [ 'password', 'final_fee', 'discount', 'approved_number', 'contract_number' ],
        'remind' => [ 'password', 'user', 'support', 'sale', 'other' ],
        'send'   => [ 'email', 'mobile' ],
    ];

    /**
     * 发送给至多10个联系人
     *
     * @param $value
     *
     * @return bool
     */
    protected function checkCount($value)
    {
        if (\count($value) > 10) {
            return false;
        }

        return true;
    }

    protected function mobile($value)
    {
        return is_cellphone_number($value);
    }
}
