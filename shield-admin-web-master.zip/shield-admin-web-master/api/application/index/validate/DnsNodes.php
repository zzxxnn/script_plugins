<?php

namespace app\index\validate;
use think\Validate;

class DnsNodes extends Validate{

    protected $rule = [
        'line_type'  =>  'require|integer|in:0,1,2,3,4,5,6,7,8,11',
        'node_ip'    =>  'require|array',
        'area'       =>  'require|integer|in:11,12,13,14,21,22,23,31,32,33,34,35,36,37,41,42,43,44,45,46,50,51,52,53,54,61,62,63,64,65,71,81,91',
        'ids'        =>  'require|array|min:1',
        'line_ip'    =>  'require|array|line_ip_format',
        'domain'     =>  'require',
    ];

    protected $field = [
        'line_type'  =>  '线路类型',
        'node_ip'    =>  'IP地址列表',
        'area'       =>  '地域',
        'ids'        =>  'DNS服务器ID',
        'line_ip'    =>  'IP地址线路',
        'domain'     =>  '域名',
    ];

    protected $message  =   [
        "line_type.in"   =>  "当前线路类型无效",
        "area.in"        =>  "当前地域无效",
        "line_ip.line_ip_format"  =>  "线路IP格式错误"
        
    ];

    protected $scene = [
        'add_dns_node'  =>  ['line_type','node_ip','area'],
        'add_dns_static_conf' => ['domain','line_ip','area'],
        'bundle_delete' => ['ids'],
    ];

    protected function line_ip_format($value)
    {
        if(count($value) !== 4){
            return false;
        }

        $line = [1=>0,2=>0,4=>0,8=>0];

        foreach($value as $tmp){
            unset($line[$tmp['line']]);
            if(!ip2long($tmp['ip'])){
                return false;
            }
        }

        if(!empty($line)){
            return false;
        }

        return true;
    }

}

