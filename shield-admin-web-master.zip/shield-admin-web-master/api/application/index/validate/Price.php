<?php
/*
* This file  is a part of  Veda- Platform
* Copyright (c) 2015 - 2018. Veda Software Inc. (http://www.veda.com)
*
* @file             Price.php
* @author           Teddy Sun
*/

namespace app\index\validate;

use think\Validate;

/**
 * Class Price
 *
 * @package app\index\validate
 * @author Teddy Sun <sgsheg@163.com>
 */
class Price extends Validate
{
    protected $rule = [
        'id'    => 'require|positiveInt',
        'price' => 'require|json|checkPrice',
    ];

    protected $field = [
        'id'    => '区域id',
        'price' => '定价配置',
    ];

    protected $scene = [
        'update' => ['id', 'price'],
    ];

    /**
     * @param $value
     * @param string $rule
     * @param $data
     * @return bool|string
     */
    protected function positiveInt($value, $rule = '', $data)
    {
        if (\is_int(($value + 0)) && ($value + 0) > 0) {
            return true;
        } else {
            return 'id必须为正整数';
        }
    }

    protected function checkPrice($value, $rule='', $data)
    {
        foreach ($value as $item) {
            //检查里面是否为数字且必须大于等于0
        }

        return true;
    }
}