<?php

namespace app\index\validate;

use think\Validate;

/**
 * Class ProductSku 商品定价
 *
 * @package app\index\validate
 * @author Teddy Sun <sgsheg@163.com>
 */
class ProductSku extends Validate
{
    protected $rule = [
        'ids'              => 'require|array|min:1',
        'area'             => 'require',
        'line'             => 'require',
        'base_bandwidth'   => 'require|array',
        'normal_bandwidth' => 'require|array',
        'site_count'       => 'require|array',
        'sp_num'           => 'require|array',
        'sp_time'          => 'require|array',
        'product_id'       => 'require',
        'stock'            => 'require|regex:/^\+?[1-9][0-9]*$/',
    ];

    protected $field = [
        'product_id'       => '商品id',
        'ids'              => '商品定价',
        'area'             => '地区',
        'line'             => '线路',
        'base_bandwidth'   => '保底带宽',
        'normal_bandwidth' => '业务带宽',
        'bandwidth'        => '弹性带宽',
        'site_count'       => '防护域名数',
        'sp_num'           => '购买数量',
        'sp_time'          => '购买时长',
        'stock'            => '库存',
    ];

    protected $message = [
        'stock.require' => '库存数量必须',
        'stock.regex'   => '库存必须为正整数',
    ];

    protected $scene = [
        'add'    => ['stock'],
        'edit'   => ['stock'],
        'delete' => ['ids'],
    ];
}