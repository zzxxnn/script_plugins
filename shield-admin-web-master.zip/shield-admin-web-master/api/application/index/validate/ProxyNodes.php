<?php

namespace app\index\validate;

use think\Validate;

class ProxyNodes extends Validate
{

    protected $rule = [
        'line_type'  => 'require|integer|in:0,1,2,3,4,5,6,7,8,11',
        'node_ip'    => 'require|array',
        'area'       => 'require|integer|in:11,12,13,14,15,21,22,23,31,32,33,34,35,36,37,41,42,43,44,45,46,50,51,52,53,54,61,62,63,64,65,71,81,91',
        'node_type'  => 'require|integer|in:1,2,3',
        'site_limit' => 'require|number',
        'bandwidth'  => 'require|alphaNum',
        'ids'        => 'require|array|min:1',
    ];

    protected $field = [
        'line_type'  => '线路类型',
        'node_ip'    => 'IP地址列表',
        'area'       => '地域',
        'node_type'  => '节点类型',
        'site_limit' => '网站上限',
        'bandwidth'  => '业务带宽',
        'ids'        => '高防节点ID',

    ];

    protected $message = [
        "line_type.in"       => "当前线路类型无效",
        "area.in"            => "当前地域无效",
        "node_type.in"       => "当前节点类型无效",
        "site_limit.require" => "网站上限不能为空",
        "site_limit.number"  => "网站上限只能为数字",
        "bandwidth.require"  => "业务带宽不能为空",
        "bandwidth.alphaNum" => "业务带宽必须包含数字和字母",
    ];

    protected $scene = [
        'add_proxy_node' => [ 'line_type', 'node_ip', 'area', 'node_type', 'bandwidth', 'site_limit' ],
        'bundle_delete'  => [ 'ids' ],
    ];

}

