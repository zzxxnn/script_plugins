<?php

namespace app\index\model;

/**
 * Class ProductModel 产品
 *
 * @package app\index\model
 * @author Teddy Sun <sgsheg@163.com>
 */
class ProductModel extends BaseModel
{
    protected $esIndex = 'products';

    protected $esType = 'type';

    const ON_SALE     = 1;
    const OFF_SALE    = 2;
    const productSale = [
        self::ON_SALE  => '上架',
        self::OFF_SALE => '下架',
    ];
}
