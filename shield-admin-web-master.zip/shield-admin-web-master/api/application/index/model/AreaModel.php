<?php
/**
 * This file  is a part of  Veda- Platform
 * Copyright (c) 2015 - 2018. Veda Software Inc. (http://www.veda.com)
 *
 * @file                AreaModel.php
 * @author              Teddy Sun
 */

namespace app\index\model;

/**
 * Class AreaModel 区域
 *
 * @package app\index\model
 * @author Teddy Sun <sgsheg@163.com>
 */
class AreaModel extends BaseModel
{
    protected $esIndex = 'areas';

    protected $esType = 'type';
}
