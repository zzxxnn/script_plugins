<?php

namespace app\index\model;

/**
 * Class ProductSkuModel 产品sku
 *
 * @package app\index\model
 * @author Teddy Sun <sgsheg@163.com>
 */
class ProductSkuModel extends BaseModel
{
    protected $esIndex = 'product_skus';

    protected $esType = 'type';

    const lineArray = [
        2  => '联通',
        3  => '电信、联通',
        8  => 'BGP',
        11 => '电信、联通和BGP',
    ];
    const versionArray = [
        1 => '共享',
        2 => '独享'
    ];
}
