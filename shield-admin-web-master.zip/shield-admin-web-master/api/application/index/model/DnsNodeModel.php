<?php

namespace app\index\model;

class DnsNodeModel extends BaseModel
{
    protected $esIndex = 'dns_node_info';
    protected $esType = 'type';
}