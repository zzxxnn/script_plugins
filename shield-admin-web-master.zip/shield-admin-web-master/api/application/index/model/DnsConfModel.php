<?php

namespace app\index\model;

class DnsConfModel extends BaseModel
{
    protected $esIndex = 'dns_conf';
    protected $esType = 'type';
}