<?php

namespace app\index\model;

class UserInstanceModel extends BaseModel
{
    protected $esIndex = 'user_instance';
    protected $esType = 'type';
}
