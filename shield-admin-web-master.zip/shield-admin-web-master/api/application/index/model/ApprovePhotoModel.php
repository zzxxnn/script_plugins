<?php

namespace app\index\model;

/**
 * Class ApprovePhotoModel 审批图片
 *
 */
class ApprovePhotoModel extends BaseModel
{
    protected $table = 'approve_photos';

    protected $autoWriteTimestamp = 'datetime';

    protected $resultSetType = 'collection';

    public function getCreateTimeAttr($time)
    {
        return $time;
    }

    public function getUpdateTimeAttr($time)
    {
        return $time;
    }
}
