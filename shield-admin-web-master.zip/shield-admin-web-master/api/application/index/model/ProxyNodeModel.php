<?php

namespace app\index\model;

class ProxyNodeModel extends BaseModel
{
    protected $esIndex = 'proxy_node_info';
    protected $esType = 'type';

    const USER_SHARE_SITE_TYPE = 1; // 共享网站防护
    const USER_UNSHARE_SITE_TYPE = 2; // 专享网站防护
    const USER_APP_TYPE = 3; // 非网站防护
}