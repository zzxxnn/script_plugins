<?php

namespace app\index\model;

class ProxyConfModel extends BaseModel
{
    protected $esIndex = 'proxy_conf';

    protected $esType = 'type';

}