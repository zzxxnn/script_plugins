<?php

namespace app\index\model;

use app\client\traits\ESQuery;
use app\client\traits\ZKQuery;
use Elasticsearch\ClientBuilder;
use Elasticsearch\Common\Exceptions\BadRequest400Exception;
use Elasticsearch\Common\Exceptions\Missing404Exception;
use think\Model;
use think\Log;

class BaseModel extends Model
{
    use ESQuery, ZKQuery;
    
    protected static $esInstance;

    // ES Index
    protected $esIndex;

    // ES Type
    protected $esType;

    public function __construct($data = [])
    {
        parent::__construct($data);
    }

    /**
     * 获取ES client 实例
     *
     * @return \Elasticsearch\Client|null
     */
    public function getESInstance()
    {
        if (! self::$esInstance) {
            $ESHost           = config('database.es_host');
            self::$esInstance = ClientBuilder::create()->setHosts($ESHost)->build();
        }

        return self::$esInstance;
    }

    /**
     * 获取ES Client 实例
     *
     * @return \ElasticSearch\Client|null
     */
    protected static function esInstance()
    {
        if (! self::$esInstance) {
            $ESHost           = config('database.es_host');
            self::$esInstance = ClientBuilder::create()->setHosts($ESHost)->build();
        }

        return self::$esInstance;
    }

    /**
     * 执行ES 搜索
     *
     * @param $filter
     * @param int $from
     * @param null $size
     * @return array
     * @throws \Exception
     */
    public function esSearch($filter, $from = 0, $size = null)
    {
        try {
            $filter = [
                'index' => $this->esIndex,
                'type'  => $this->esType,
                'from'  => $from,
                'body'  => $filter
            ];

            if ($size) {
                $filter['size'] = $size;
            }

            env('ES_DEBUG') && Log::info('ES Search Filter:' . json_encode(compact('filter', 'from', 'size')));

            $resources = self::esInstance()->search($filter);
            $hits      = $resources['hits']['hits'];
            $result    = array_map(function ($hit) {
                return array_merge(['id' => $hit['_id']], $hit['_source']);
            }, $hits);

            env('ES_DEBUG') && Log::info('ES Search Result:' . json_encode($result));

            return $result;
        } catch (\Exception $e) {
            Log::error('ES Search Error:' . $e->getMessage());
            //  404 Exception
            if ($e instanceof Missing404Exception) {
                return [];
            }

            if ($e instanceof BadRequest400Exception) {
                return [];
            }
            throw $e;
        }
    }

    /**
     *
     * ES统计索引中文档数量
     *
     * @param array $filter
     * @return null|string
     * @throws \Exception
     */
    public function esCountDocs($filter = [])
    {
        try {
            $filter   = array_merge(['index' => $this->esIndex, 'type' => $this->esType, 'body' => $filter]);
            env('ES_DEBUG') && Log::info('ES Search Filter:' . json_encode(compact('filter')));
            $resource = self::esInstance()->search($filter);

            return $resource['hits']['total'];
        } catch (\Exception $e) {
            Log::error('ES Search Error:' . $e->getMessage());
            if ($e instanceof Missing404Exception) {
                return null;
            }

            throw $e;
        }
    }

    /**
     * 执行ES添加
     *
     * @param $data
     * @param null $id
     * @return array|bool
     * @throws \Exception
     */
    public function esAdd($data, $id = null)
    {
        try {
            $attributes = array_merge(['index' => $this->esIndex, 'type' => $this->esType], ['body' => $data]);
            if ($id) {
                $attributes['id'] = $id;
            }

            env('ES_DEBUG') && Log::info('ES Add Data:' . json_encode(compact('data', 'id')));

            return self::esInstance()->index($attributes);
        } catch (\Exception $e) {
            Log::error('ES Search Error:' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * 执行ES批量添加
     *
     * @param $data
     * @return array|bool
     * @throws \Exception
     */
    public function esBulk($data)
    {
        try {
            $attributes = array_merge(['index' => $this->esIndex, 'type' => $this->esType], ['body' => $data]);
            env('ES_DEBUG') && Log::info('ES Add Data:' . json_encode(compact('data')));

            return self::esInstance()->bulk($attributes);
        } catch (\Exception $e) {
            Log::error('ES Search Error:' . $e->getMessage());
            throw $e;
        }
    }

    /**
     *
     * 根据ID 获取ES数据
     *
     * @param $id
     * @return null|string
     * @throws \Exception
     */
    public function esGetById($id)
    {
        try {
            $filter   = array_merge(['index' => $this->esIndex, 'type' => $this->esType, 'id' => $id]);
            $resource = self::esInstance()->get($filter);
            env('ES_DEBUG') && Log::info('ES Get Data:' . json_encode($filter));

            return $resource['_source'];
        } catch (\Exception $e) {
            Log::error('ES Search Error:' . $e->getMessage());
            if ($e instanceof Missing404Exception) {
                return null;
            }

            throw $e;
        }
    }

    /**
     * 更新ES 记录的值
     *
     * @param array $data
     * @param $id
     * @return array|bool
     * @throws \Exception
     */
    public function esUpdateById($data = [], $id)
    {
        try {
            $attributes = array_merge([
                'index' => $this->esIndex,
                'type'  => $this->esType,
                'id'    => $id,
                'body'  => [
                    'doc' => $data
                ]
            ]);

            env('ES_DEBUG') && Log::info('ES Update Data:' . json_encode(compact('data', 'id')));

            return self::esInstance()->update($attributes);
        } catch (\Exception $e) {
            Log::error('ES Search Error:' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * 删除特定ID的ES记录
     *
     * @param $id
     * @return array|bool
     * @throws \Exception
     */
    public function esDeleteById($id)
    {
        try {
            $attributes = [
                'index' => $this->esIndex,
                'type'  => $this->esType,
                'id'    => $id,
            ];

            env('ES_DEBUG') && Log::info('ES Delete Data:' . json_encode($attributes));

            return self::esInstance()->delete($attributes);
        } catch (\Exception $e) {
            Log::error('ES Search Error:' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * ES 批量删除操作
     *
     * @param $ids
     * @return array|bool
     * @throws \Exception
     */
    public function esBulkDelete($ids)
    {
        try {
            $attributes = [];
            foreach ($ids as $id) {
                $attributes['body'][] = [
                    'delete' => [
                        '_index' => $this->esIndex,
                        '_type'  => $this->esType,
                        '_id'    => $id
                    ]
                ];
            }

            env('ES_DEBUG') && Log::info('ES BulkDelete Data:' . json_encode($attributes));

            return self::esInstance()->bulk($attributes);
        } catch (\Exception $e) {
            Log::error('ES Search Error:' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * ES 聚合查询
     * @param $filter
     * @param int $from
     * @param null $size
     * @return array
     * @throws \Exception
     */
    public function esAggsSearch($filter, $from = 0, $size = null)
    {
        try {
            $filter['aggs'] = $filter['aggs'] ?? ['_' => ['sum' => ['field' => '_']]];
            $filter = [
                'index' => $this->esIndex,
                'type'  => $this->esType,
                'from'  => $from,
                'body'  => $filter
            ];
            $filter['size'] = $size ?: 50;

            env('ES_DEBUG') && Log::info('ES Search Filter:' . json_encode(compact('filter', 'from', 'size')));

            $resources = self::esInstance()->search($filter);
            $hits = $this->processESHits($resources['hits']['hits'] ?? []);
            $aggs = $resources['aggregations'] ?? [];

            return compact('hits', 'aggs');
        } catch (\Exception $e) {
            Log::error('ES Search Error:' . $e->getMessage());
            if ($e instanceof Missing404Exception) {
                return null;
            }

            throw $e;
        }
    }

    /**
     * @param $hits
     * @return array
     */
    private function processESHits($hits)
    {
        $results = array_map(function ($hit) {
            return array_merge($hit['_source'], ['id' => $hit['_id']]);
        }, $hits);

        return $results;
    }
}