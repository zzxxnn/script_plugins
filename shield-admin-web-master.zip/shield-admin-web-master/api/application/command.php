<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: yunwuxin <448901948@qq.com>
// +----------------------------------------------------------------------

return [
    \app\index\command\ImportAreas::class,
    \app\index\command\ImportPrice::class,
    \app\index\command\ImportSupport::class,
    \app\index\command\ImportProduct::class,
    \app\index\command\ImportProxyNode::class,
    \app\index\command\ImportDnsNode::class,
    \app\index\command\ImportSystemLogTemplate::class,
    \app\index\task\Order::class,
    \app\index\task\Instance::class,
    \app\common\command\UnitCommand::class
];
