<?php

define("API_SERVER_URL", "http://api.vedasec.net");

use app\agent\service\Auth as AuthAgent;
use app\client\service\Auth as AuthClient;
use app\common\model\AgentModel;
use app\index\service\Auth as AuthIndex;
use app\common\model\UserModel;
use think\Env;

function IsLogin()
{
    $user = session('user_auth');
    if (empty($user)) {
        return 0;
    } else {
        return session('user_auth_sign') == AuthSign($user) ? $user['uid'] : 0;
    }
}

function IsClientLogin()
{
    $user = session('user_auth');
    if (empty($user)) {
        return 0;
    } else {
        return session('user_auth_sign') == AuthSign($user) ? $user['id'] : 0;
    }
}

function IsAgentLogin()
{
    $user = session('user_auth');
    if (empty($user)) {
        return 0;
    } else {
        return session('user_auth_sign') == AuthSign($user) ? $user['id'] : 0;
    }
}

if (! function_exists('env')) {
    /**
     * 获取环境变量的值
     *
     * @param string $key
     * @param null $default
     * @return mixed
     */
    function env($key = '', $default = null)
    {
        return Env::get($key, $default);
    }
}

function AuthSign($data)
{
    if (! is_array($data)) {
        $data = (array) $data;
    }
    ksort($data);//对数组进行降序排列
    $code = http_build_query($data);//将数组处理为url-encoded 请求字符串
    $sign = sha1($code);//进行散列算法

    return $sign;
}

/**
 * post方法发送表单请求
 *
 * @param  string $url 请求url
 * @param  string $post_data 数据
 * @param  string $method 提交方式 form or json
 * @return array     返回结果数组
 */
function Sendpost($url, $post_data, $method = "from")
{ // 发送post请求
    if ($method == "json") {
        $options = [
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-type: application/json\r\n" //json
                    ."Content-Length: ".strlen($post_data)."\r\n",
                'content' => $post_data,
                'timeout' => 15 * 60 // 超时时间（单位:s）
            ]
        ];
    } else {
        $options = [
            'http' => [
                'method'  => 'POST',
                'header'  => 'Content-type:application/x-www-form-urlencoded',
                'content' => http_build_query($post_data),
                'timeout' => 15 * 60 // 超时时间（单位:s）
            ]
        ];
    }

    try {
        $result = file_get_contents($url, false, stream_context_create($options));
    } catch (Exception $e) {
        return false;
    }

    if (is_null($result) || empty($result)) {
        return Finalfail("20002", "the api services error");
    }

    $result_arr = json_decode($result, true);

    return $result_arr;
}

/**
 * 接口返回成功方法
 *
 * @param  string|array $data 返回数据
 * @param  string $code 状态码默认0为请求成功
 * @return string    json
 */
function Finalsuccess($data = null, $code = "0")
{
    $jsonData = ['errcode' => intval($code), 'errmsg' => 'ok'];
    if (is_null($data)) {
        return json($jsonData);
    } elseif (is_array($data) && empty($data)) {
        $jsonData = ['errcode' => intval($code), 'errmsg' => 'ok', 'data' => []];
    } elseif (is_array($data)) {
        foreach ($data as $name => $value) {
            $jsonData[$name] = $value;
        }
    } else {
        $jsonData = ['errcode' => intval($code), 'errmsg' => 'ok', 'data' => $data];
    }

    return json($jsonData);
}

/**
 * 接口返回失败方法
 *
 * @param  string $code 状态码
 * @param  string $errorMessage 错误信息
 * @param  array $additionResults 追加data数据
 * @return string    json
 */
function Finalfail($code, $errorMessage = '', array $additionResults = [])
{
    $jsonData = ['errcode' => intval($code), 'errmsg' => $errorMessage];
    if (! empty($additionResults)) {
        foreach ($additionResults as $name => $value) {
            $jsonData[$name] = $value;
        }
    }

    return json($jsonData);
}

/**
 * 接口失败
 *
 * @param  String $code 状态码 （若为10001|miss，则解析为状态码+错误信息）
 * @param  String $errorMessage 错误信息
 * @param  array $additionResults 追加data数据
 * @return String    json字符串
 */
function Fail($code, $errorMessage = '', array $additionResults = [])
{
    header("Content-Type: application/json");
    $tmp = explode("|", $code);
    if (count($tmp) == 2) {
        $code         = $tmp[0];
        $errorMessage = $tmp[1];
    }

    $jsonData = ['errcode' => intval($code), 'errmsg' => $errorMessage];
    if (! empty($additionResults)) {
        foreach ($additionResults as $name => $value) {
            $jsonData[$name] = $value;
        }
    }

    die(json_encode($jsonData));
}

/**
 * 接口返回成功方法
 *
 * @param  string|array $data 返回数据
 * @param  string $code 状态码默认0为请求成功
 * @return string    json
 */
function Success($data = null, $code = "0")
{
    header("Content-Type: application/json");
    $jsonData = ['errcode' => intval($code), 'errmsg' => 'ok'];
    if (is_null($data)) {
        die(json_encode($jsonData));
    }

    if (is_array($data) && ! empty($data)) {
        foreach ($data as $name => $value) {
            $jsonData[$name] = $value;
        }
    } else {
        $jsonData = ['errcode' => intval($code), 'errmsg' => 'ok', 'data' => $data];
    }
    die(json_encode($jsonData));
}

function Time2string($min)
{
    if ($min == 0) {
        $time_str = '';
    }
    if ($min > 0 && $min < 60) {
        $time_str = $min.'m';
    }
    if ($min >= 60 && $min < 1440) {
        $time_str = floor($min / 60)."h";
    }
    if ($min >= 1440) {
        $time_str = floor($min / 1440)."d";
    }

    return $time_str;
}

function String2time($str)
{
    if ($str == "") {
        $time = 0;
    }
    $unit = substr($str, -1);
    $time = (int) substr($str, 0, strlen($str) - 1);
    if ($unit == 'h') {
        $time = $time * 60;
    }
    if ($unit == 'd') {
        $time = $time * 24 * 60;
    }

    return $time;
}

function ShortMd5($str)
{
    return substr(md5($str), 8, 16);
}

if (! function_exists('rand_char')) {
    /**
     * 生成指定长度的字符串
     *
     * @param string $length
     * @return string
     */
    function rand_char($length = '')
    {
        $chars      = 'abcdefghijklmnopqrstuvwxyz0123456789';
        $randString = '';
        for ($i = 0; $i < $length; $i++) {
            $randString .= $chars[mt_rand(0, strlen($chars) - 1)];
        }

        return $randString;
    }
}

if (! function_exists('gmt_withTZ')) {
    /**
     * 生成附带时区标志的 GMT 时间
     * example "2018-03-31T04:04:10.000Z"
     *
     * @param null $timestamp
     * @return false|string
     */
    function gmt_withTZ($timestamp = null)
    {
        $timestamp = $timestamp ?: time();

        return gmdate('Y-m-d\TH:i:s.v\Z', $timestamp);
    }
}

if (! function_exists('str_rand')) {
    /**
     * 生成指定长度的随机字符串
     *
     * @param int $length
     * @return string
     * @throws Exception
     */
    function str_rand($length = 0)
    {
        $string = '';

        while (($len = strlen($string)) < $length) {
            $size = $length - $len;

            $bytes = random_bytes($size);

            $string .= substr(str_replace(['/', '+', '='], '', base64_encode($bytes)), 0, $size);
        }

        return $string;
    }
}

if (! function_exists('format_bytes')) {
    /**
     * 格式化字节大小
     *
     * @param  number $size 字节数
     * @param  string $delimiter 数字和单位分隔符
     * @return string            格式化后的带单位的大小
     */
    function format_bytes($size, $delimiter = '')
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
        for ($i = 0; $size >= 1024 && $i < 5; $i++) {
            $size /= 1024;
        }

        return round($size, 2).$delimiter.$units[$i];
    }
}

if (! function_exists('format_time')) {
    /**
     * 时间戳格式化
     *
     * @param int $time 时间戳
     * @param string $format 输出格式
     * @return false|string
     */
    function format_time($time = null, $format = 'Y-m-d H:i:s')
    {
        return ! $time ? '' : date($format, (int) $time);
    }
}

/**
 * 上传文件类型控制   此方法仅限ajax上传使用
 *
 * @param  string $path 字符串 保存文件路径示例： /Upload/image/
 * @param  string $format 文件格式限制
 * @param  integer $maxSize 允许的上传文件最大值 52428800
 * @return string   返回ajax的json格式数据
 */
if (! function_exists('ajax_upload_avatar')) {
    function ajax_upload_avatar($path = 'file', $format = 'empty', $maxSize = '52428800')
    {
        ini_set('max_execution_time', '0');
        // 去除两边的/
        $path = trim($path, '/');
        // 上传文件类型控制
        $ext_arr = [
            'image' => ['gif', 'jpg', 'jpeg', 'png', 'bmp'],
            'photo' => ['jpg', 'jpeg', 'png'],
            'flash' => ['swf', 'flv'],
            'media' => ['swf', 'flv', 'mp3', 'wav', 'wma', 'wmv', 'mid', 'avi', 'mpg', 'asf', 'rm', 'rmvb'],
            'file'  => ['doc', 'docx', 'xls', 'xlsx', 'ppt', 'htm', 'html', 'txt', 'zip', 'rar', 'gz', 'bz2', 'pdf']
        ];
        if (! empty($_FILES)) {
            // 上传文件配置
            $config = [
                'maxSize'  => $maxSize,               //   上传文件最大为50M
                'rootPath' => config('upload_path').'/',       // 文件上传保存的根路径
                'savePath' => $path.'/',         //文件上传的保存路径（相对于根路径）
                'saveName' => ['uniqid', ''],          //上传文件的保存规则，支持数组和字符串方式定义
                'autoSub'  => false,                   //  自动使用子目录保存上传文件 默认为true
                'callback' => true,
                'exts'     => isset($ext_arr[$format]) ? $ext_arr[$format] : '',
            ];
            // 实例化上传
            $upload = new upload\Upload($config);
            // 调用上传方法
            $info = $upload->upload();
            $data = [];
            if (! $info) {
                // 返回错误信息
                $error              = $upload->getError();
                $data['error_info'] = $error;
                die(json_encode($data));
            } else {
                // 返回成功信息
                foreach ($info as $file) {
                    $data['name'] = trim('/uploads/'.$file['savepath'].$file['savename'], '.');

                    return $data['name'];
                }
            }
        }
    }
}

if (! function_exists('crop_image')) {
    /**
     * 生成缩略图
     *
     * @param  string $image_path 原图path
     * @param  integer $width 缩略图的宽
     * @param  integer $height 缩略图的高
     * @return string             缩略图path
     */
    function crop_image($image_path, $width = 60, $height = 60)
    {
        $public_path = ROOT_PATH.'public';
        $image_path  = trim($image_path, '.');
        $min_path    = str_replace('.', '_'.$width.'_'.$height.'.', $image_path);
        $image       = \think\Image::open($public_path.$image_path);
        $image->thumb($width, $height, \think\Image::THUMB_CENTER)->save($public_path.$min_path);

        return $min_path;
    }
}

if (! function_exists('get_uid')) {
    /**
     * 返回用户id
     *
     * @return integer 用户id
     */
    function get_uid()
    {
        return session('user_auth')['uid'];
    }
}

if (! function_exists('current_domain')) {
    /**
     * 获取当前域名（不带http）
     *
     * @return string
     */
    function current_domain()
    {
        return $_SERVER['HTTP_HOST'];
    }
}

if (! function_exists('rand_number')) {
    /**
     * 生成指定长度的字符串
     *
     * @param string $length
     * @return string
     */
    function rand_number($length = '')
    {
        $chars      = '0123456789';
        $randString = '';
        for ($i = 0; $i < $length; $i++) {
            $randString .= $chars[mt_rand(0, strlen($chars) - 1)];
        }

        return $randString;
    }
}

if (! function_exists('micro_timestamp')) {
    /**
     * 获取毫秒级时间戳
     *
     * @param null $timestamp
     * @return float
     */
    function micro_timestamp($timestamp = null)
    {
        $_timestamp = (int) (microtime(true) * 1000);
        $_timestamp = $timestamp ? $timestamp + 1 : $_timestamp;

        return $_timestamp;
    }
}

if (! function_exists('get_client_ip')) {
    /**
     * 获取客户端ip
     *
     * @param int $type
     * @param bool $adv
     * @return mixed
     */
    function get_client_ip($type = 0, $adv = false)
    {
        return request()->ip($type, $adv);
    }
}

if (! function_exists('update_current_user')) {
    /**
     * 更新当前登录用户的信息
     *
     * @param $user
     * @param $type [user|agent|admin]
     */
    function update_current_user($user, $type)
    {
        session($type, $user);
    }
}

if (!function_exists('array_wrap')) {
    /**
     * 如果不是数组，将值包装为数组
     *
     * @param $value
     * @return array
     */
    function array_wrap($value)
    {
        return !is_array($value) ? [$value] : $value;
    }
}

if (! function_exists('rsa_decrypt')) {
    function rsa_decrypt($cipertext)
    {
        $cipertext   = base64_decode($cipertext);
        $private_key = <<<EOD
-----BEGIN RSA PRIVATE KEY-----
MIICXAIBAAKBgQCEXxw+an28E6/XqTy6Xo5XrDd7zwZt5qesYQRK/NowJmmTiqwD
Xwx9yrKPIhnV3yx+2pqETMMe+vcEC4HD3uJAVRGkffUpMuZfGynK4/xidsUmQaMC
1rx+zc0/K2ViMRlKD98A9gLs7nCv3pRB6hEEXmqd7xxN8ZN31u6JBx4zMQIDAQAB
AoGAJwKonjRgDbd3kQUNIpePN4NHbrNaX7UkIQcObtMJsjr/zj2F6BBw6/l6mfgg
yQjWYiQmeWrt7glkFssVWRYscv5Xled979wyd0tsxlTPQlLBXVyFbs0h3MIzJizk
0sYRjKrctEpoUxsMTTYLxLRUgDI6l4QQN5NBTDrreaWgA6kCQQDh2wYSavqJbQhn
Jn0ct5DzABSOV6Msw3HLKWhXWoxQfXTGQad3A2x3K8ET920c+CPPSp6vH86qaLND
g5//watjAkEAlgnyi9SF2WX+YDCO8ZVCT7x6hP+sFSrjwtVaf88kGCr5M8C5ZFJS
vue5Bqtti9eGXWjf2rKsdO/fALFWf1jNWwJAIbmMzI9A3eh0CsMKh5E5ia+HYkHf
0b1Vbpq+Q9z3esVg/IGtOe4+8gSMjiiyGFNNNZTU4R2ExJlhu0EaURxgNQJAUVD8
2loJXQTRM9K9diM9+Dcfc/uZiTNgk5TMYp6iYlLQEwNttviDDiJKflnkmjjqArA3
OrFBlHL4ushiJ8y6JwJBAJdZ7NCzOouAFhPtV+2Xo9NbCezoGkdGH20VODzIvZbK
WE70gE9CVOHFznJ8iqrpT4JN4hrPN+Vih+H1vzSS8tc=
-----END RSA PRIVATE KEY-----
EOD;
        openssl_private_decrypt($cipertext, $plaintext, $private_key);

        return $plaintext;
    }
}

if ( ! function_exists('upload_image_with_base64')) {
    function upload_image_with_base64($content)
    {
        header('Content-type:text/html;charset=utf-8');
        $base64_image_content = trim($content);
        //正则匹配出图片的格式
        if (preg_match('/^(data:\s*image\/(\w+);base64,)/', $base64_image_content, $result)) {
            $filename = time().".".$result[2]; //文件名
            $new_file = './uploads/photo/'.$filename;

            //写入操作
            if (file_put_contents($new_file, base64_decode(str_replace($result[1], '', $base64_image_content)))) {
                return $new_file;  //返回文件名及路径
            } else {
                return false;
            }
        }
        return false;
    }
}

if (! function_exists('is_cellphone_number')) {
    /**
     * 检测是否是手机号码
     *
     * @param $cellPhoneNumber
     * @return boolean
     */
    function is_cellphone_number($cellPhoneNumber)
    {
        $regex  = "/^1(?:3\d|4[4-9]|5[0-35-9]|6[67]|7[013-8]|8\d|9\d)\d{8}$/";
        return \think\Validate::regex($cellPhoneNumber, $regex);
    }
}

if (! function_exists('is_correct_password')) {
    /**
     * 检测密码问题 [规则:1密码长度介于8到16之间2密码不能为纯数字3密码不能为纯数字]
     *
     * @param $value
     * @return bool
     */
    function is_correct_password($value)
    {
        $valueLength = \strlen($value);
        if ($valueLength < 8 || (16 < $valueLength)) {
            return false;
        }
        $n = preg_match('/\d/', $value);
        $e = preg_match('/[a-zA-Z]/', $value);

        return ($n && $e);
    }
}

if (! function_exists('current_user')) {
    /**
     * 获取当前登录用户
     *
     * @param $system
     *
     * @return boolean
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    function current_user($system)
    {
        if ($system == 'agent') {
            return AgentModel::where('email', AuthAgent::id())->find();
        } elseif($system == 'client') {
            return UserModel::where('email', AuthClient::id())->find();
        } elseif($system == 'index') {
            return UserModel::where('email', AuthIndex::id())->find();
        }
    }
}

if (!function_exists('is_phpunit_testing')) {
    /**
     * 当前请求是否是PHPUnit发起的
     * 检查当前请求头中是否包含 HTTP_PHPUNIT_TESTING 项
     *
     * @return bool
     */
    function is_phpunit_testing()
    {
        return isset($_SERVER['HTTP_PHPUNIT_TESTING']);
    }
}