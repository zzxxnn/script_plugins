<?php

return [
    //定义返回格式
    'default_return_type' => 'html',
];