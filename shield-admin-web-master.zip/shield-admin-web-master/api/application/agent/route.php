<?php

use think\Route;

Route::group('v1', function () {

    require APP_PATH . 'agent/route/info.php';

    require APP_PATH.'agent/route/profile.php';
});

require APP_PATH.'agent/route/info.php';

/**
 * 界面路由（只负责页面跳转）
 */
Route::get('user/register', 'agent/auth.RegisterController/index');               //注册页面
Route::get('user', 'agent/auth.LoginController/index');                      //获取用户信息
Route::get('user/login', 'agent/auth.LoginController/index');                //登录界面
Route::get('user/find-password', 'agent/auth.LoginController/findPassword'); //找回密码界面
Route::any('logout', 'agent/IndexController/logout');                        //退出
Route::get('user/reset-password', 'agent/auth.LoginController/passwordReset'); //修改密码界面

/**
 * 接口路由（只负责传输数据）
 */
Route::group('v1', function () {

    // 版本号
    Route::get('app-version', function () {
        $version = env('APP_VERSION', '未知版本');
        return Finalsuccess($version);
    });

    // 注册
    Route::post('register', 'agent/auth.RegisterController/doRegister');
    // 登录
    Route::post('login', 'agent/auth.LoginController/doLogin');
    // 登出
    Route::any('logout', 'agent/IndexController/logout');
    // 找回密码 - 发送邮件或发送短信
    Route::post('password/send', 'agent/auth.PasswordController/send');
    // 修改密码
    Route::put('password', 'agent/auth.PasswordController/update');

    // 首页
    Route::resource('index', 'agent/IndexController');

    Route::get('agent', 'agent/IndexController/agent');

    //订单
    Route::resource('order', 'agent/order.OrderController');

    //消息
    Route::resource('message', 'agent/message.MessageController');

    //用户管理
    Route::resource('user', 'agent/user.UserController');

    //用户管理提现账号设置
    Route::resource('withdraw', 'agent/user.WithDrawController');

    //用户管理提现记录
    Route::resource('cash', 'agent/user.CashOutController');
    
    require APP_PATH.'agent/route/profile.php';

    Route::get('profile/:id', 'agent/profile.ProfileController/show');

    Route::put('profile/:id', 'agent/profile.ProfileController/update');

    Route::post('profile/:id/real-name-authentication', 'agent/profile.ProfileController/putRealNameAuthentication');

    // 上传图片
    Route::post('photo/upload', 'agent/common.PhotoController/upload');

    // 产品资料下载
    Route::resource('product-information', 'agent/productinformation.ProductInformationController');

});