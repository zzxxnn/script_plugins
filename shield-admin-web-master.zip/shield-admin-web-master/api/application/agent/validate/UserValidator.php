<?php

namespace app\agent\validate;

use app\common\model\AgentModel;
use app\agent\service\Auth;
use think\exception\DbException;
use think\Validate;

class UserValidator extends Validate
{

    protected $rule = [
        'user_email'       => 'require|email|checkEmail',
        'user_mobile'      => 'require|mobile|checkMobile',
        'user_name'        => 'require|checkName',
        'password'         => 'require|min:8|max:16|password',
        'old_password'     => 'require|min:8|max:16|checkOldPassword',
        'new_password'     => 'require|min:8|max:16',
        'confirm_password' => 'require|min:8|max:16|password|checkConfirmPassword',
        'captcha'          => 'require|checkCaptcha',
        'user_type'        => 'require|checkType',
        'name'             => 'require|checkLoginEmailOrMobile',
        'token'            => 'require',
        'id_number'        => 'require',
        'photos'           => 'require',
        'bank'             => 'require',
        'bank_account'     => 'require',
        'bank_card'        => 'require',
    ];

    protected $message = [
        'user_email.require'                    => '11000|邮箱不能为空',
        'user_email.email'                      => '11001|邮箱格式错误',
        'user_email.checkEmail'                 => '11001|邮箱已存在',
        'user_mobile.require'                   => '11000|电话不能为空',
        'user_mobile.mobile'                    => '11003|电话格式错误',
        'user_mobile.checkMobile'               => '11003|电话已存在',
        'user_name.require'                     => '11000|用户名不能为空',
        'user_name.mobile'                      => '11003|用户名格式错误',
        'user_name.checkName'                   => '11003|用户名已存在',
        'password.require'                      => '11000|密码不能为空',
        'password.min'                          => '11001|密码不能小于8个字符',
        'password.max'                          => '11001|密码不能超过16个字符',
        'password.password'                     => '11001|密码必须包括数字、字母大小写',
        'confirm_password.require'              => '11000|确认密码不能为空',
        'confirm_password.min'                  => '11001|确认密码不能小于8个字符',
        'confirm_password.max'                  => '11001|确认密码不能超过16个字符',
        'confirm_password.checkConfirmPassword' => '11003|两次输入密码不一致',
        'old_password.require'                  => '11000|原密码不能为空',
        'old_password.min'                      => '11001|原密码不能小于8个字符',
        'old_password.max'                      => '11001|原密码不能超过16个字符',
        'old_password.checkOldPassword'         => '11003|原密码输入错误',
        'captcha.require'                       => '11000|验证码不能为空',
        'captcha.checkCaptcha'                  => '11003|验证码错误',
        'name.require'                          => '11000|手机号/邮箱不能为空',
        'name.checkLoginEmailOrMobile'          => '11003|手机号/邮箱不存在',
        'token.require'                         => '11000|验证码不能为空',
        'id_number.require'                     => '11000|身份证号不能为空',
        'photos.require'                        => '11000|照片不能为空',
        'bank.require'                          => '11000|开户行不能为空',
        'bank_account.require'                  => '11000|开户名不能为空',
        'bank_card.require'                     => '11000|开户账号不能为空',
    ];

    protected $scene = [
        'register'                 => [ 'user_email', 'user_mobile', 'password', 'confirm_password', 'captcha' ],
        'add_agent'                => [ 'avatar','mobile', 'qq', 'email', 'company','user_name','id_number'], //B端添加代理商
        'login'                    => [ 'name', 'password', 'captcha' ],
        'password_send'            => [ 'name' ],
        'find_password_update'     => [ 'name', 'password', 'confirm_password', 'token' ],
        'login_password_update'    => [ 'old_password', 'new_password', 'confirm_password' ],
        'real_name_authentication' => [ 'id_number', 'photos', ],
        'update_profile'           => [ 'user_mobile', 'user_email' ],
        'bank'                     => [ 'bank', 'bank_account', 'bank_card' ],
    ];

    protected function mobile($value)
    {
        return is_cellphone_number($value);
    }

    protected function password($value)
    {
        return is_correct_password($value);
    }

    /**
     * 验证邮箱是否存在
     *
     * @param $value
     *
     * @return bool
     * @throws DbException
     */
    protected function checkEmail($value)
    {
        return AgentModel::get([ 'user_email' => $value ]) ? false : true;
    }

    /**
     * 验证手机号是否存在
     *
     * @param $value
     *
     * @return bool
     * @throws DbException
     */
    protected function checkMobile($value, $rule, $data)
    {
        if ($data['user_type'] == AgentModel::USER_TYPE_AGENT) {
            return AgentModel::get([ 'phone' => $value ]) ? false : true;
        } elseif ($data['user_type'] == AgentModel::USER_TYPE_CLIENT) {
            return AgentModel::get([ 'mobile' => $value ]) ? false : true;
        }
    }

    /**
     * 验证用户名是否存在
     *
     * @param $value
     *
     * @return bool
     * @throws DbException
     */
    protected function checkName($value)
    {
        return AgentModel::get([ 'user_name' => $value ]) ? false : true;
    }

    /**
     * 验证确认密码是否与输入密码一致
     *
     * @param $value
     * @param $rule
     * @param $data
     *
     * @return bool
     */
    protected function checkConfirmPassword($value, $rule, $data)
    {
        if (isset($data['old_password'])) {
            return ( $value == $data['new_password'] ) ? true : false;
        } elseif (isset($data['token'])) {
            return ( $value == $data['password'] ) ? true : false;
        } else {
            return ( $value == $data['password'] ) ? true : false;
        }
    }

    /**
     * 验证验证码的是否正确
     *
     * @param $value
     *
     * @return bool
     */
    protected function checkCaptcha($value)
    {
        return captcha_check($value) ? true : false;
    }

    /**
     * @param $value
     * @param $rule
     * @param $data
     *
     * @return bool
     * @throws DbException
     */
    public function checkLoginEmailOrMobile($value, $rule, $data)
    {
        //对value进行处理
        //$value = rsa_decrypt($value);
        if ($this->is($value, 'email')) {
            if ( ! $this->checkEmail($value)) {
                return true;
            }
        } elseif ($this->mobile($value)) {
            $user = ( new AgentModel() )->where('mobile', $value)->whereOr('phone', $value)->find();
            if ($user) {
                return true;
            }
        }

        return false;
    }

    /**
     * 验证身份证号
     *
     * @param $value
     *
     * @return bool
     */
    public function id_num($value)
    {
        $pattern = "/^(\d{15}$|^\d{18}$|^\d{17}(\d|X|x))$/";

        return preg_match($pattern, $value) ? true : false;
    }

    /**
     * 登陆后重置密码验证原密码
     *
     * @param $value
     * @param $rule
     * @param $data
     *
     * @return bool
     * @throws DbException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function checkOldPassword($value, $rule, $data)
    {
        $user = ( new AgentModel() )->where('user_email', Auth::id())->find();
        if ($user) {
            if (password_verify($value, $user['user_pass'])) {
                return true;
            }
        }

        return false;
    }
}
