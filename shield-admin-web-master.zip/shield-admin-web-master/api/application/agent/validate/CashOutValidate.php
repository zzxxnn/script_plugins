<?php

namespace app\agent\validate;

use think\Validate;

/**
 * Class CashOutValidate 提现
 *
 * @package app\agent\validate
 * @author Teddy Sun <sgsheg@163.com>
 */
class CashOutValidate extends Validate
{
    protected $rule = [
        'express_company' => 'require',
        'express_number'  => 'require',
        'invoice_number'  => 'require',
        'proof'           => 'require',
        'amount'          => 'require',
        'password'        => 'require'
    ];

    protected $field = [
        'express_company' => '快递公司',
        'express_number'  => '快递单号',
        'invoice_number'  => '发票号',
        'amount'          => '提现金额',
        'password'        => '密码',
        'proof'           => '完税证明'
    ];

    protected $message = [
        'express_company.require' => '快递公司必须',
        'express_number.require'  => '快递单号必须',
        'invoice_number.require'  => '发票号必须',
        'proof.require'           => '完税证明必须',
        'amount.require'          => '提现金额必须',
        'password.require'        => '密码必须',
    ];

    protected $scene = [
        'add' => ['express_company', 'express_number', 'invoice_number', 'proof', 'amount', 'password'],
    ];
}