<?php

namespace app\agent\traits;

trait CheckLogin
{
    protected function checkLogin()
    {
        if (IsAgentLogin() === 0) {
            return Finalfail(REP_CODE_NEED_LOGIN, '请先登陆！');
        }
    }
}