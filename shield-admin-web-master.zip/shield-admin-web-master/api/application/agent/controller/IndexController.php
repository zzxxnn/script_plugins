<?php

namespace app\agent\controller;

use app\agent\service\Auth;
use app\common\service\LogService;

/**
 * Class Index 用户首页
 *
 * @package app\agent\controller
 * @author Teddy Sun <sgsheg@163.com>
 */
class IndexController extends BaseController
{
    public function index()
    {
        if (IsAgentLogin() === 0) {
            return view('./user/login');
        }

        return view('./index/index');
    }

    /**
     * @SWG\Get(
     *      path="/logout",
     *      tags={"Login 代理商登录"},
     *      summary="代理商注销",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example= {"errcode":0,"errmsg":"ok","data":"您已经退出平台"}
     *          )
     *      )
     * )
     */
    public function logout()
    {
        Auth::logout();
        //$this->renderSuccess('您已经退出平台');
        return Finalsuccess('您已经退出平台');
    }

    /**
     * @SWG\Get(
     *      path="/agent",
     *      tags={"账户信息"},
     *      summary="获取代理商信息",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example= {"errcode":0,"errmsg":"ok","data":{"id":2,"user_type":1,"sex":0,"birthday":0,"last_login_time":2018,"score":0,"balance":"0.00","user_status":1,"user_name":"agent","user_nickname":"","user_email":"agent@veda.com","user_url":"","avatar":"avatar/support-user1.png","user_invite_code":"","last_login_ip":"127.0.0.1","mobile":"17089497810","phone":"","id_number":"","id_verify_status":0,"company":"北京卫达","create_time":"2018-07-26 18:03:41","qq":"","bank":"","bank_account":"","bank_card":"","user_number":0,"img_url":"http://local.agent.shield.com/avatar/support-user1.png","cash_confirmed":0,"cash_has_been":0,"cash_all":0}}
     *          )
     *      )
     * )
     */
    public function agent()
    {
        return Finalsuccess($this->agent);
    }
}