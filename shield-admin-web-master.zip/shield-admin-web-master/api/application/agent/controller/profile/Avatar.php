<?php

namespace app\agent\controller\profile;

use app\agent\repository\ProfileRepository;
use think\Controller;

class Avatar extends Controller
{
    /**
     * @SWG\Post(
     *      path="/profile/avatar",
     *      tags={"设置"},
     *      summary="头像上传",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="file", type="string", example="avatar.png"),
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 上传成功 !=0 上传失败",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0, "errmsg":"上传成功","data":{"img_url":"avatar/avatar.jpg"}}
     *          )
     *     )
     * )
     *
     * 头像上传
     *
     * @param \app\agent\repository\ProfileRepository $profileRepository
     * @return \think\Response
     * @throws \Exception
     */
    public function save(ProfileRepository $profileRepository)
    {
        $userId = 1;
        if ($this->request->isPost()) {
            $avatar = ajax_upload_avatar('/avatar', 'image');
            //生成缩略图
            $avatarThumb = crop_image($avatar);

            if ($profileRepository->updateProfile(['img_url'=>$avatarThumb], $userId)) {
                return Finalsuccess(['data' => ['img_url' => $avatarThumb]]);
            } else {
                return Finalfail(REP_CODE_FAILED_OPERATION, '写入数据库失败,请稍后重试.');
            }
        } else {
            return Finalfail(REP_CODE_ILLEGAL_OPERATION, '非法请求!');
        }
    }

    /**
     * @SWG\Put(
     *      path="/profile/avatar",
     *      tags={"设置"},
     *      summary="头像更新",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="avatar", type="string", example="static/img/support-user0.png"),
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 更新成功 !=0 ",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0, "errmsg":"更新成功","data":{"img_url":"static/img/support-user0.png"}}
     *          )
     *     )
     * )
     *
     * 头像更新
     *
     * @param \app\agent\repository\ProfileRepository $profileRepository
     * @param  \think\Request
     * @return \think\Response
     * @throws \Exception
     */
    public function update(ProfileRepository $profileRepository)
    {
        $userId = 1;
        if ($this->request->isPut()) {

            $path = $this->request->put('avatar', 'avatar/support-user0.png');

            if ($profileRepository->updateProfile(['img_url'=>$path], $userId)) {
                return Finalsuccess(['data' => ['img_url' => $path]]);
            } else {
                return Finalfail(REP_CODE_FAILED_OPERATION, '写入数据库失败,请稍后重试.');
            }
            
        } else {
            return Finalfail(REP_CODE_ILLEGAL_OPERATION, '非法请求!');
        }
    }

}
