<?php

namespace app\agent\controller\profile;

use app\agent\controller\BaseController;
use app\agent\repository\UserRepository;
use app\agent\service\Auth;
use app\agent\validate\UserValidator;
use app\common\model\AgentModel;

class ProfileController extends BaseController
{

    protected $validator;

    protected $repository;

    public function _initialize()
    {
        $this->validator  = new UserValidator();
        $this->repository = new UserRepository();
    }

    /**
     * @SWG\Get(path="/profile/{id}",tags={"Profile 用户资料设置"},
     *      summary="获取用户资料",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example=
     *              {"errcode":0,"errmsg":"ok","data":{"avatar":"avatar\/support-user0.png","user_email":"yexx@veda.com","mobile":"18638121735","id_number":"","company":"","client_register_url":""}}
     *          )
     *      )
     * )
     *
     * @param $id
     *
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function show($id)
    {
        $agent = AgentModel::find($id);
        if ($agent) {
            $data = [
                'img_url'    => $agent->img_url,
                'user_email' => $agent->user_email,
                'mobile'     => $agent->mobile,
                'id_number'  => $agent->id_number,
                'company'    => $agent->company,
                'client_register_url' => $agent->client_register_url,
            ];

            return Finalsuccess(compact('data'));
        }
        return Finalfail(REP_CODE_PARAMS_INVALID, '找不到该用户');
    }

    /**
     *
     * @SWG\Post(path="/profile/{id}/real-name-authentication",tags={"Profile 用户资料设置"},
     *      summary="实名认证",
     *      @SWG\Parameter(
     *          name="id_number",
     *          required=true,
     *          in="body",
     *          description="身份证号/社会信用代码",
     *          @SWG\Schema(
     *              @SWG\Property(property="id_number", type="string", example="41032819959591212")
     *          )
     *      ),
     *      @SWG\Parameter(name="photos", required=true, in="body",
     *          description="上传的图像",
     *          @SWG\Schema(
     *              @SWG\Property(property="photos", type="array",
     *                  @SWG\Items(type="string", example={"name": "/uploads/photo/5b50372a46545_60_60.jpg","type":1})
     *              )
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 认证成功 !=0 认证失败",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *     )
     * )
     *
     * @param $id
     *
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function putRealNameAuthentication($id)
    {
        $data = input();
        request()->bind('name', Auth::id());

        $agent = AgentModel::find($id);
        if ($agent) {
            if ( ! $this->validator->scene('real_name_authentication')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
            }

            $result = $this->repository->updatePhotos($data, $agent);
            if ($result) {
                return Finalsuccess();
            }
            return Finalfail(REP_CODE_DB_ERROR, '上传失败');
        }
        return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '找不到该用户');
    }

    /**
     * @SWG\Put(path="/profile/{id}", tags={"Profile 用户资料设置"},
     *      summary="修改用户资料",
     *      @SWG\Parameter(name="user_mobile",required=true,in="body",
     *          description="用户手机号",
     *          @SWG\Schema(
     *              @SWG\Property(property="user_mobile", type="string", example="18638121735")
     *          )
     *      ),
     *      @SWG\Parameter(name="user_email",required=true,in="body",
     *          description="邮箱",
     *          @SWG\Schema(
     *              @SWG\Property(property="user_email", type="string", example="yexx@veda.com")
     *          )
     *      ),
     *      @SWG\Parameter(name="company",required=true,in="body",
     *          description="公司信息",
     *          @SWG\Schema(
     *              @SWG\Property(property="company", type="string", example="北京卫达")
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 认证成功 !=0 认证失败",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok"}
     *          )
     *     )
     * )
     * @param $id
     *
     * @return string
     */
    public function update($id)
    {
        $data  = input();
        if ( ! $this->validator->scene('update_profile')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }
        $result = $this->repository->updateAgentById($data);
        if ($result) {
            return Finalsuccess();
        }
        return Finalfail(REP_CODE_PARAMS_INVALID, '修改失败');

    }

}
