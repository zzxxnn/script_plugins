<?php

namespace app\agent\controller\productinformation;

use think\Controller;

/**
 * Class ProductInformation
 *
 * @description 产品资料控制器：1. 产品资料列表；2. 产品资料预览；3. 产品资料下载
 *
 * @package app\agent\controller
 */
class ProductInformationController extends Controller
{
    /**
     * @SWG\Get(
     *      path="/product-information",
     *      tags={"Product Information 产品资料"},
     *      summary="获取产品资料列表",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example= {"errcode":0,"errmsg":"ok","list":{{"name":"技术白皮书","url":"\/product\/技术白皮书.pdf"},{"name":"销售建议书","url":"\/product\/销售建议书.pdf"},{"name":"常见问题","url":"\/product\/常见问题.pdf"},{"name":"产品报价单","url":"\/product\/产品报价单.pdf"}}}
     *          )
     *      )
     * )
     *
     * 显示产品资料列表
     *
     * @return \think\Response
     */
    public function index()
    {
        $list = [
            [
                'name' => '技术白皮书',
                'url'  => '/product/技术白皮书.pdf',
            ],
            [
                'name' => '销售建议书',
                'url'  => '/product/销售建议书.pdf',
            ],
            [
                'name' => '常见问题',
                'url'  => '/product/常见问题.pdf',
            ],
            [
                'name' => '产品报价单',
                'url'  => '/product/产品报价单.pdf',
            ],
        ];
        return Finalsuccess(compact('list'));
    }

}
