<?php

namespace app\agent\controller\common;

use app\agent\controller\BaseController;
use app\common\repository\PhotoRepository;

class PhotoController extends BaseController
{
    /**
     *
     * @SWG\Post(
     *      path="/photo/upload",
     *      tags={"Photo 上传图片"},
     *      summary="上传图片",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="file", type="string", example="avatar.png"),
     *              @SWG\Property(property="type", type="int", example="1: 身份证正面; 2: 身份证反面; 3. 手持身份证; 4: 营业执照"),
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 上传成功 !=0 上传失败",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0, "errmsg":"上传成功","data": "/uploads/photo/5b5815353daea.jpg"}
     *          )
     *     )
     * )
     *
     */
    public function upload()
    {
        $data = input();

        $result = (new PhotoRepository())->uploadPhoto('/photo', 'real_name_auth', $data['type']);

        return $result;
    }
}