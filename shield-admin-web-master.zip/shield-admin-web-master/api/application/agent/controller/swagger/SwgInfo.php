<?php

namespace app\client\controller;

class SwgInfo {
 
    /**
     * Swagger v2
     * @SWG\Swagger(
     *      schemes={"http"},
     *      host="agent.shield.com",
     *      basePath="/v1",
     *      @SWG\Info(
     *          version="1.0.0",
     *          title="幻盾代理商Agent",
     *          description="",
     *      ),
     *      consumes={"application/json"},
     *      produces={"application/json"}
     * )
     */

    /**
     * @SWG\Definition(
     *      definition="Fail",
     *      type="object",
     *      @SWG\Property(property="errcode", type="integer", example=10001),
     *      @SWG\Property(property="errmsg", type="string", example="params missing")
     *  )
     * 
     * @SWG\Definition(
     *      definition="Success",
     *      type="object",
     *      @SWG\Property(property="errcode", type="integer", example=0),
     *      @SWG\Property(property="errmsg", type="string", example="ok")
     *  )
     *
     */


}