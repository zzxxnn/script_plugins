<?php

namespace app\agent\controller;

use app\common\model\AgentModel;
use think\Controller as ThinkController;

/**
 * Class BaseController 基类登录则跳转到首页
 *
 * @package app\agent\controller
 * @author Teddy Sun <sgsheg@163.com>
 */
class BaseController extends ThinkController
{
    // 正确为0|失败为1
    const SUCCESS_STATUS = 0;
    const ERROR_STATUS   = 1;

    protected $agent;

    protected $email;

    protected $model;

    /**
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function _initialize()
    {
        parent::_initialize();

        $this->model = new AgentModel();
        $this->email = $this->getUserEmail();
        $this->agent = $this->getAgent();
    }

    /**
     * 获取用户邮箱信息
     *
     * @return int
     */
    private function getUserEmail()
    {
        $userLogin = IsAgentLogin();

        if (empty($userLogin)) {
            if ($this->request->isAjax()) {
                return Finalfail(REP_CODE_NEED_LOGIN, '您尚未登录');
            } else {
                $this->redirect('./user/login');
            }
        }

        return $userLogin;
    }

    /**
     * 获取代理商信息
     *
     * @return array|false|\PDOStatement|string|\think\Model
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    private function getAgent()
    {
        //$user = Db::table('agents')->where('user_email', $this->getUserEmail())->find();
        $user = $this->model->where('user_email', $this->getUserEmail())->find();

        if (empty($user)) {
            $this->getUserEmail();
            //throw new ModelNotFoundException('找不到对应代理商');
        }

        return $user;
    }

}