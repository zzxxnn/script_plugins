<?php

namespace app\agent\controller\message;

use app\agent\controller\BaseController;
use think\Request;

/**
 * Class MessageController 消息接口
 *
 * @package app\agent\controller
 * @author Teddy Sun <sgsheg@163.com>
 */
class MessageController extends BaseController
{
    private $messages;

    public function __construct()
    {
        parent::__construct();

        $this->messages = [
            ['id' => 1, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 1, 'type_name' => '推送公告',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 2, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 1, 'type_name' => '推送公告',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 3, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 1, 'type_name' => '推送公告',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 4, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 1, 'type_name' => '推送公告',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 5, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 1, 'type_name' => '推送公告',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 6, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 1, 'type_name' => '推送公告',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 7, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 1, 'type_name' => '推送公告',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 8, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 1, 'type_name' => '推送公告',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 9, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 1, 'type_name' => '推送公告',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 10, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 1, 'type_name' => '推送公告',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 11, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 2, 'type_name' => '告警信息',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 12, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 2, 'type_name' => '告警信息',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 13, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 2, 'type_name' => '告警信息',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 14, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 2, 'type_name' => '告警信息',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 15, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 2, 'type_name' => '告警信息',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 16, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 2, 'type_name' => '告警信息',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 17, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 2, 'type_name' => '告警信息',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 18, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 2, 'type_name' => '告警信息',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 19, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 2, 'type_name' => '告警信息',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 20, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 2, 'type_name' => '告警信息',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 21, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 3, 'type_name' => '市场活动',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 22, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 3, 'type_name' => '市场活动',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 23, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 3, 'type_name' => '市场活动',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 24, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 3, 'type_name' => '市场活动',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 25, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 3, 'type_name' => '市场活动',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 26, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 3, 'type_name' => '市场活动',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 27, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 3, 'type_name' => '市场活动',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 28, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 3, 'type_name' => '市场活动',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 29, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 3, 'type_name' => '市场活动',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
            ['id' => 30, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 3, 'type_name' => '市场活动',  'status' => 'unread','create_time' => \Carbon\Carbon::now()->toDateTimeString(),],
        ];
    }
    /**
     * @SWG\Get(path="/message",tags={"消息管理"},
     *      summary="代理商获取消息[推送公告、告警信息、市场活动]",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example= {"errcode": 0,"errmsg": "ok","data": {{"id": 1,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 1,"type_name": "推送公告","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 2,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 1,"type_name": "推送公告","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 3,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 1,"type_name": "推送公告","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 4,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 1,"type_name": "推送公告","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 5,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 1,"type_name": "推送公告","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 6,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 1,"type_name": "推送公告","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 7,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 1,"type_name": "推送公告","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 8,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 1,"type_name": "推送公告","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 9,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 1,"type_name": "推送公告","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 10,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 1,"type_name": "推送公告","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 11,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 2,"type_name": "告警信息","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 12,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 2,"type_name": "告警信息","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 13,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 2,"type_name": "告警信息","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 14,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 2,"type_name": "告警信息","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 15,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 2,"type_name": "告警信息","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 16,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 2,"type_name": "告警信息","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 17,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 2,"type_name": "告警信息","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 18,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 2,"type_name": "告警信息","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 19,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 2,"type_name": "告警信息","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 20,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 2,"type_name": "告警信息","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 21,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 3,"type_name": "市场活动","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 22,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 3,"type_name": "市场活动","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 23,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 3,"type_name": "市场活动","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 24,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 3,"type_name": "市场活动","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 25,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 3,"type_name": "市场活动","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 26,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 3,"type_name": "市场活动","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 27,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 3,"type_name": "市场活动","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 28,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 3,"type_name": "市场活动","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 29,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 3,"type_name": "市场活动","status": "unread","create_time": "2018-07-21 17:25:49"},{"id": 30,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 3,"type_name": "市场活动","status": "unread","create_time": "2018-07-21 17:25:49"}}}
     *          )
     *      )
     * )
     *
     *
     * @return \think\Response
     */
    public function index()
    {
        $records = collection($this->messages);

        return Finalsuccess(['data' => $records, 'total' => $records->count()]);
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
    }

    /**
     * @SWG\Get(path="/message/{id}",tags={"消息管理"},
     *      summary="查看信息内容,并将用户选择读取的消息状态修改已阅读",
     *      @SWG\Parameter(name="id",type="integer",required=true,in="query",
     *          description="信息id"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example= {"errcode": 0,"errmsg": "ok","data": {"id": 1,"title": "【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送","content": "卫达安全的产品信息、公司新闻、行业动态","type": 1,"type_name": "推送公告","status": "read", "create_time": "2018-07-21 17:29:29"}}
     *          )
     *      )
     * )
     *
     */
    public function show($id)
    {
        return Finalsuccess(['data' => ['id' => (int)$id, 'title' => '【公告】卫达安全的产品信息、公司新闻、行业动态等内容的推送', 'content' => '卫达安全的产品信息、公司新闻、行业动态', 'type' => 1, 'type_name' => '推送公告',  'status' => 'read','create_time' => \Carbon\Carbon::now()->toDateTimeString()]]);
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     *
     * @param  \think\Request
     * @param  int
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {

    }

    /**
     * 删除指定资源
     *
     * @param  int
     * @return \think\Response
     */
    public function destroy($id)
    {
        //
    }
}