<?php

namespace app\agent\controller\user;

use app\agent\controller\BaseController;
use app\agent\service\Auth;
use app\agent\validate\UserValidator;
use think\Request;

/**
 * Class WithDrawController
 *
 * @package app\agent\controller\user
 * @author Teddy Sun <sgsheg@163.com>
 */
class WithDrawController extends BaseController
{
    /**
     * @SWG\Get(
     *      path="/withdraw",
     *      tags={"提现账号设置信息"},
     *      summary="获取账号提现信息",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example= {"errcode": 0,"errmsg": "ok","data": {"email": "agent@veda.com","avatar": "http://local.agent.shield.com/avatar/support-user1.png","bank": "","bank_account": "","bank_card": ""}}
     *          )
     *      )
     * )
     */
    public function index()
    {
        $agent = $this->agent;

        return Finalsuccess([
            'data' => [
                'email'        => $agent->user_email,
                'avatar'       => $agent->img_url,
                'bank'         => $agent->bank,
                'bank_account' => $agent->bank_account,
                'bank_card'    => $agent->bank_card
            ]
        ]);
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
    }

    /**
     * 显示指定的资源
     *
     * @param  int
     * @return \think\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * @SWG\Put(
     *      path="/withdraw/{agentId}",
     *      tags={"提现账号设置信息"},
     *      summary="更新提现账号信息",
     *      @SWG\Parameter(name="bank",type="string",required=true,in="query",
     *          description="开户行"
     *      ),
     *      @SWG\Parameter(name="bank_account",type="integer",required=true,in="query",
     *          description="开户名"
     *      ),
     *      @SWG\Parameter(name="bank_card",type="string",required=true,in="query",
     *          description="开户账号"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example= {"errcode": 0,"errmsg": "ok"}
     *          )
     *      )
     * )
     *
     * @param \app\agent\validate\UserValidator $validator
     * @param $id
     * @return String
     */
    public function update(UserValidator $validator, $id)
    {
        $data = input();
        request()->bind('name', Auth::id());

        if (! $validator->scene('bank')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $validator->getError());
        }
        //todo: id对等问题
        if ($this->agent->id != $id) {
            return Finalfail(REP_CODE_ILLEGAL_OPERATION, '非法操作');
        }

        if ($this->agent->update($data)) {
            return Finalsuccess();
        }

        return Finalfail(REP_CODE_DB_ERROR, '写入数据库失败,请稍后重试.');
    }

    /**
     * 删除指定资源
     *
     * @param  int
     * @return \think\Response
     */
    public function destroy($id)
    {
        //
    }
}