<?php

namespace app\agent\controller\user;

use app\agent\controller\BaseController;
use app\agent\model\CashOutModel;
use app\agent\service\Auth;
use app\agent\validate\CashOutValidate;
use think\Request;

/**
 * Class CashOutController 提现记录
 *
 * @package app\agent\controller\user
 * @author Teddy Sun <sgsheg@163.com>
 */
class CashOutController extends BaseController
{
    /**
     * @SWG\Get(path="/cash",tags={"cash 资产管理"},
     *      summary="获取资产和提现记录列表",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 获取成功| !=0 获取失败",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode":0,"errmsg":"ok","data":{"list":{},"total":0}}
     *          )
     *      )
     * )
     * 资产列表
     *
     */
    public function index()
    {
        $from = input('_from', 1);
        $size = input('_size', 10);

        $agent = $this->agent;

        // 过滤条件
        $must = ['agent_id' => $agent->id];

        $records = model('app\agent\model\CashOutModel')->getListWithPage($from, $size, $must, '*', ['create_time' => 'desc']);

        return Finalsuccess([
            'data'  => $records,
        ]);
    }

    /**
     * @SWG\Post(path="/cash",tags={"cash 资产管理"},
     *      @SWG\Parameter(name="express_company",type="string",required=true,in="query",
     *          description="快递公司"
     *      ),
     *      @SWG\Parameter(name="express_number",type="string",required=true,in="query",
     *          description="快递单号"
     *      ),
     *      @SWG\Parameter(name="invoice_number",type="string",required=true,in="query",
     *          description="发票号"
     *      ),
     *      @SWG\Parameter(name="proof",type="integer",required=true,in="query",
     *          description="是否包含完税证明,1是不包含完税证明;2是包含完税证明"
     *      ),
     *      @SWG\Parameter(name="amount",type="number",format="float",required=true,in="query",
     *          description="提现金额"
     *      ),
     *      @SWG\Parameter(name="password",type="string",required=true,in="query",
     *          description="密码?"
     *      ),
     *      summary="新建提现记录",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example= {"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     *
     * @param \think\Request $request
     * @param \app\agent\validate\CashOutValidate $validate
     * @return \think\Response
     */
    public function create(Request $request, CashOutValidate $validate)
    {
        if ($request->isPost()) {
            $data = input();
            request()->bind('name', Auth::id());

            //validate
            if (! $validate->scene('add')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $validate->getError());
            }

            //todo:checkout is able to save [密码是否正确、是否允许提取金钱]
            // save return Success
            unset($data['password']);
            $data['agent_id'] = $this->agent->id;
            if (model('app\agent\model\CashOutModel')->add($data)) {
                return Finalsuccess();
            }
            return Finalfail(REP_CODE_DB_ERROR, '写入数据库失败,请稍后重试.');
        }
        return Finalfail(REP_CODE_ILLEGAL_OPERATION, '非法操作');
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request
     * @return \think\Response
     */
    public function save()
    {
        //
    }

    /**
     * 显示指定的资源
     *
     * @param  int
     * @return \think\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request
     * @param  int
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * 删除指定资源
     *
     * @param  int
     * @return \think\Response
     */
    public function destroy($id)
    {
        //
    }
}