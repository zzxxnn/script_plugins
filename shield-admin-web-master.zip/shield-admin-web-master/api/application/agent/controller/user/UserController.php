<?php

namespace app\agent\controller\user;

use app\agent\controller\BaseController;
use app\common\model\UserModel;
use app\common\repository\AttackRepository;
use app\common\repository\InstanceRepository;
use app\common\repository\OrderRepository;
use app\common\model\OrderModel;
use app\index\model\UserInstanceModel;
use think\Request;

/**
 * Class UserController 用户管理
 *
 * @package app\agent\controller
 * @author Teddy Sun <sgsheg@163.com>
 */
class UserController extends BaseController
{
    /**
     * @SWG\Get(path="/user",tags={"用户管理"},summary="获取代理商下的用户",
     *      @SWG\Parameter(name="_from",type="integer",required=false,in="query",
     *          description="起点,和es列表保持一致,默认为1"
     *      ),
     *      @SWG\Parameter(name="_size",type="integer",required=false,in="query",
     *          description="分页大小,和其他es查询保持一致,默认为10"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example= {"errcode":0,"errmsg":"ok","data":{"list":{{"id": 12,"role": 1,"last_login_time": "2018-07-30 12:12:11","account": "0.00","real_name": "test@veda.com","id_number": "","id_verify_status": 0,"username": "test","email": "test@veda.com","safe_email": "","email_verify_status": 0,"avatar": "avatar/support-user0.png","last_login_ip": "","mobile": "","mobile_verify_status": 0,"agent_id": 2,"create_time": "2018-07-23 09:04:49","total_spend": 9859,"total_instance": 30,"agent_name": "","role_name": "普通用户","img_url": "http://local.agent.shield.com/avatar/support-user0.png"}}, "total":1}}
     *          )
     *      )
     * )
     *
     * 获取代理商下的用户列表信息
     *
     * @param \app\common\model\OrderModel $orderModel
     * @throws \Exception
     */
    public function index(OrderModel $orderModel)
    {
        $from = input('_from', 1);
        $size = input('_size', 10);
        
        $agent = $this->agent;
        
        // 过滤条件
        $must = ['agent_id' => $agent->id,];
        
        $users = model('app\common\model\UserModel')->getListWithPage($from, $size, $must);
        //list有用户列表且不为0
        if ($users['list']->count()) {
            //获取代理商下的用户信息
            foreach ($users['list'] as &$user) {
                $spend = [];
                //用户的消费总额
                $userEmail = $user->email;
                // 获取消费总值
                $user['total_spend'] = $this->getTotalSpend($userEmail, $user, $spend, $orderModel);
                // 获取高仿实例个数
                $user['total_instance'] = $this->getTotalInstance($userEmail);
            }
            unset($user);
        }

        return Finalsuccess(['data' => $users]);
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
    }

    /**
     * @SWG\Get(path="/user/{id}",tags={"用户管理"},
     *      summary="获取代理商下的用户详细信息",
     *      @SWG\Parameter(name="id",type="integer",required=true,in="query",
     *          description="用户id"
     *      ),
     *      @SWG\Parameter(name="type",type="string",required=false,in="query",
     *          description="列表类型,默认为高仿实例:instance;受攻击情况:attack;消费记录:customer"
     *      ),
     *      @SWG\Parameter(name="_from",type="integer",required=false,in="query",
     *          description="起点,和es列表保持一致,默认为0"
     *      ),
     *      @SWG\Parameter(name="_size",type="integer",required=false,in="query",
     *          description="分页大小,和其他es查询保持一致,默认为10"
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example={"errcode": 0,"errmsg": "ok","data": {{  "id": "ddos-oggyxgl",  "instance_id": "ddos-oggyxgl",  "uid": "test@veda.com",  "type": 3,  "status": 0,  "instance_line": 8,  "normal_bandwidth": 10,  "bandwidth": 10,  "base_bandwidth": 10,  "start_date": "2018-06-06T06:42:42.000Z",  "end_date": "2018-07-06T06:42:42.000Z",  "area": null,  "node_id": null,  "hd_ip": {  },  "last_update": "2018-06-06T06:42:47.000Z"},{  "id": "ddos-df1ayb8",  "instance_id": "ddos-df1ayb8",  "uid": "test@veda.com",  "type": 1,  "status": 0,  "instance_line": 11,  "normal_bandwidth": 10,  "bandwidth": 10,  "base_bandwidth": 10,  "start_date": "2018-06-08T10:50:16.000Z",  "end_date": "2018-07-08T10:50:16.000Z",  "area": null,  "node_id": null,  "hd_ip": {  },  "last_update": "2018-06-08T10:50:23.000Z",  "site_count": 2}},"total": 30,"user": {"id": 12,"role": 1,"last_login_time": "2018-07-30 12:12:11","account": "0.00","real_name": "test@veda.com","id_number": "","id_verify_status": 0,"username": "test","email": "test@veda.com","safe_email": "","email_verify_status": 0,"avatar": "avatar/support-user0.png","last_login_ip": "127.0.0.1","mobile": "","mobile_verify_status": 0,"agent_id": 2,"create_time": "2018-07-23 09:04:49","agent_name": "","role_name": "普通用户","img_url": "http://local.agent.shield.com/avatar/support-user0.png"}}
     *          )
     *      )
     * )
     *
     */
    public function show($id)
    {
        $user = UserModel::where('agent_id', $this->agent->id)->where('id', $id)->find();
        if (empty($user)) {
            return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '未找到用户信息');
        }
        //类型 instance:高仿实例 attack:攻击 consumer:消费
        $type = $this->request->get('type') ?? 'instance';
        //获取用户高仿实例列表
        $data = $this->getUserInstanceRecords($user, $type);

        return Finalsuccess($data);
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request
     * @param  int
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * 删除指定资源
     *
     * @param  int
     * @return \think\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     * @param $userEmail
     * @param $user
     * @param $spend
     * @return mixed
     * @throws \Exception
     */
    private function getTotalSpend($userEmail, $user, $spend, OrderModel $orderModel)
    {
        if (empty($userEmail)) {
            $user['total_spend'] = 0;
        } else {
            //get max spend value
            $spend['query'] = [
                'bool' => [
                    'must'     => [
                        ['term' => ['uid.keyword' => $userEmail]],
                    ],
                    'must_not' => [
                        ['term' => ['status' => OrderModel::ORDER_STATUS_CREATED]]
                    ]
                ]
            ];
            $spend['aggs']  = [
                'sum_age' => [
                    'sum' => [
                        'field' => 'fee'
                    ]
                ]
            ];

            $result = $orderModel->esAggsSearch($spend);

            $user['total_spend'] = $result['aggs']['sum_age']['value'] ?? 0;
        }

        return $user['total_spend'];
    }

    /**
     * 获取高仿实例个数
     *
     * @param $userEmail
     * @return int
     * @throws \Exception
     */
    private function getTotalInstance($userEmail)
    {
        $spend['query'] = [
            'bool' => [
                'must' => [
                    ['term' => ['uid.keyword' => $userEmail]],
                ]
            ]
        ];
        $spend['aggs']  = [
            'instance_count' => [
                'value_count' => [
                    'field' => 'instance_id.keyword'
                ]
            ]
        ];

        $userInstanceModel = new UserInstanceModel();
        $result            = $userInstanceModel->esAggsSearch($spend);

        return $result['aggs']['instance_count']['value'] ?? 0;
    }

    /**
     * @param $user
     * @param $type
     * @return array
     * @throws \Exception
     * @throws \app\common\exception\RepositoryException
     */
    private function getUserInstanceRecords($user, $type)
    {
        $must = [];

        // 分页相关
        $from = input('_from', 0);
        $size = input('_size', 10);

        //过滤条件
        $must[] = ['term' => ['uid.keyword' => $user->email]];

        $filter = [
            'query' => ['bool' => ['must' => $must]],
        ];

        if ('instance' === $type) {
            $repository = new InstanceRepository();
        } else {
            if ('customer' === $type) {
                $repository = new OrderRepository();
            } else {
                $repository = new AttackRepository();
            }
        }
        $records = $repository->all($filter, $from, $size);
        $total   = $repository->count($filter) ?? 0;

        return ['data' => $records, 'total' => $total, 'user' => $user];
    }
}