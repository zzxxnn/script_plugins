<?php

namespace app\agent\Controller\order;

use app\agent\controller\BaseController;
use app\common\repository\OrderRepository;
use think\Request;

/**
 * Class OrderController 订单
 *
 * @package app\agent\Controller\Order
 * @author Teddy Sun <sgsheg@163.com>
 */
class OrderController extends BaseController
{
    /**
     * @SWG\Get(path="/order",tags={"订单管理"},
     *      summary="获取代理商下的订单",
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example= {"errcode":0,"errmsg":"ok", "data": {}}
     *          )
     *      )
     * )
     *
     *
     */
    public function index(OrderRepository $orderRepository)
    {
        //获取代理商下用户的邮箱,通过邮箱然后去es中的user_order获取数据
        $emails = $this->agent->users->column('email');

        // 将获取到的邮箱来作为es查询的条件.
        $filter = ['query' => ['terms' => ['uid' => $emails]]];

        $orders = $orderRepository->all($filter);

        return Finalsuccess($orders);
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
    }

    /**
     * 显示指定的资源
     *
     * @param  int
     * @return \think\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request
     * @param  int
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * 删除指定资源
     *
     * @param  int
     * @return \think\Response
     */
    public function destroy($id)
    {
        //
    }
}