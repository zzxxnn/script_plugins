<?php

namespace app\agent\controller\auth;

use app\agent\controller\BaseController;
use app\agent\repository\UserRepository;
use app\agent\validate\UserValidator;
use think\Request;

/**
 * Class LoginController 登录
 *
 * @package app\agent\controller
 * @author Teddy Sun <sgsheg@163.com>
 */
class LoginController extends BaseController
{

    protected $validator;

    public function _initialize()
    {
        $this->validator = new UserValidator();
    }

    /**
     * 登录界面
     *
     * @return \think\Response
     */
    public function index()
    {
        // fetch无法加载模板，暂时更换为view
        if (empty(IsAgentLogin())) {
            return view('./index/login');
        }

        return view('./index/index');
    }

    /**
     * * @SWG\Post(
     *      path="/login",
     *      tags={"Login 代理商登录"},
     *      summary="【登录】新代理商",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="登录代理商：",
     *          @SWG\Schema(
     *              @SWG\Property(property="name", type="string", example="test@veda.com或18638121735"),
     *              @SWG\Property(property="password", type="string", example="12345678"),
     *              @SWG\Property(property="captcha", type="string", example="9176"),
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param UserRepository $userRepository
     *
     * @return String
     */
    public function doLogin(UserRepository $userRepository)
    {
        $data = input();
        if ( ! $this->validator->scene('login')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }
        $result = $userRepository->loginUserByEmailOrMobile($data);
        switch ($result) {
            case 0:
                return Finalsuccess();
                break;
            case 1:
                return Finalfail(REP_CODE_PASSWORD_ERROR, '密码不正确');
                break;
            case 2:
                return Finalfail(REP_CODE_SOURCE_NOT_FOUND, '账户不存在');
                break;
            case 3:
                $loginTimeLimit = \think\Env::get('Login_Time_Limit') ?? 30;
                request()->bind('minutes', $loginTimeLimit);

                return Finalfail(REP_CODE_LOGIN_TOO_MUCH_FAIL, '错误次数过多,请'.$loginTimeLimit.'分钟后重试.');
                break;
            case 4:
                return Finalfail(REP_CODE_LOGIN_NEED_REFRESH, '请刷新重试');
                break;
            default :
                return Finalfail(REP_CODE_ILLEGAL_OPERATION, '未受理的请求');
        }
    }

    /**
     * 找回密码
     *
     * @return mixed
     */
    public function findPassword()
    {
        return $this->fetch('./index/forgetPwd');
    }

    /**
     * 修改密码界面
     *
     * @param  int
     * @return \think\Response
     */
    public function passwordReset()
    {
        return $this->fetch('./index/resetPwd');
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request
     * @param  int
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * 删除指定资源
     *
     * @param  int
     * @return \think\Response
     */
    public function destroy($id)
    {
        //
    }
}