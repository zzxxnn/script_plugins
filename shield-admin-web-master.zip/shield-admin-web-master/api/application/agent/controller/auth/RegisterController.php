<?php

namespace app\agent\controller\auth;

use app\agent\controller\BaseController;
use app\agent\repository\UserRepository;
use app\agent\validate\UserValidator;

/**
 * Class RegisterController 注册
 *
 * @package app\agent\controller
 * @author  Teddy Sun <sgsheg@163.com>
 */
class RegisterController extends BaseController
{

    protected $validator;

    public function _initialize()
    {
        $this->validator = new UserValidator();
    }

    /**
     * 注册
     *
     * @return \think\Response
     */
    public function index()
    {
        return $this->fetch('./index/register');
    }

    /**
     * * @SWG\Post(
     *      path="/register",
     *      tags={"Register 代理商注册"},
     *      summary="【注册】新代理商",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="注册代理商信息：",
     *          @SWG\Schema(
     *              @SWG\Property(property="user_email", type="string", example="test@veda.com"),
     *              @SWG\Property(property="user_mobile", type="string", example="18638121735"),
     *              @SWG\Property(property="user_name", type="string", example="叶肖肖"),
     *              @SWG\Property(property="password", type="string", example="12345678"),
     *              @SWG\Property(property="confirm_password", type="string", example="12345678"),
     *              @SWG\Property(property="captcha", type="string", example="9176"),
     *              @SWG\Property(property="user_type", type="int", example="1 (1: 个人代理商；2.机构代理商；)")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     */
    public function doRegister()
    {
        $data = input();
        if ($data) {
            if ( ! $this->validator->scene('register')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
            }
            $result = ( new UserRepository() )->insertUser($data);
            if ($result) {
                return Finalsuccess();
            }
            return Finalfail(REP_CODE_FAILED_OPERATION, '注册失败');
        } else {
            return Finalfail(REP_CODE_ILLEGAL_OPERATION, '请求无效');
        }

    }
}