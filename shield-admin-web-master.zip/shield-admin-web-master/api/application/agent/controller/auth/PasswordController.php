<?php

namespace app\agent\controller\auth;

use app\agent\controller\BaseController;
use app\agent\repository\UserRepository;
use app\agent\service\Auth;
use app\agent\validate\UserValidator;
use app\agent\service\Auth as AuthService;
use app\agent\traits\CheckLogin;
use think\Cache;
use think\Controller;

class PasswordController extends Controller
{

    use CheckLogin;

    protected $validator;

    protected $repository;

    public function _initialize()
    {
        $this->validator  = new UserValidator();
        $this->repository = new UserRepository();
    }

    /**
     * @SWG\Post(
     *      path="/password/send",
     *      tags={"Password 密码管理"},
     *      summary="【发送】找回密码或修改密码时并发送邮件",
     *      @SWG\Parameter(
     *          name="",
     *          required=true,
     *          in="body",
     *          description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="name", type="string", example="test@veda.com或18638121735"),
     *          )
     *      ),
     *      @SWG\Response(
     *          response="200",
     *          description="errcode: 0 正常| !=0 异常",
     *          @SWG\Property(
     *              property="",
     *              type="object",
     *              example= {"errcode":0,"errmsg":"ok"}
     *          )
     *      )
     * )
     * )
     *
     */
    public function send()
    {
        $data = input();
        if ( ! $this->validator->scene('password_send')->check($data)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
        }

        //邮箱验证
        if ($this->validate([ 'name' => $data['name'] ], [ 'name' => 'email' ])) {
            if (Cache::get("forget_pwd_".$data['name']) !== false) {
                return Finalfail(REP_CODE_EMAIL_SEND_TOO_FREQUENTLY, '五分钟内只能发送一封邮件');
            }
            $result = $this->repository->sendEmail($data['name']);

            if ($result) {
                return Finalsuccess($data['name']);
            }
        } elseif ($this->validate([ 'name' => $data['name'] ], [ 'name' => 'mobile' ])) {
            // 手机验证
            // 同一个号码，同一个IP，一分钟只能发一次
            if (Cache::get(request()->ip.'_'.$data['name'])) {
                return Finalfail(REP_CODE_ILLEGAL_OPERATION, '验证码发送过于频繁，请稍后重试！');
            }
            $result = $this->repository->sendSms($data['name']);
            if ( ! $result) {
                return Finalfail(REP_CODE_SERVER_ERROR, '验证码发送失败！');
            }

            return Finalsuccess([ 'token' => $result ]);
        }

        return Finalfail(REP_CODE_SOURCE_EXIST, '发送失败，请稍后再试');
    }

    /**
     * @SWG\Put(
     *      path="/password",
     *      tags={"Password 密码管理"},
     *      summary="【修改】修改密码",
     *      @SWG\Parameter(
     *          name="1",
     *          required=true,
     *          in="body",
     *          description="1. 通过找回密码修改，参数为：name，token，password, confirm_password; ",
     *          @SWG\Schema(
     *              @SWG\Property(property="name", type="string", example="test@veda.com"),
     *              @SWG\Property(property="token", type="string", example="fa4e51f56d5bba4404f96ea95b1943db"),
     *              @SWG\Property(property="password", type="string", example="veda2017"),
     *              @SWG\Property(property="confirm_password", type="string", example="veda2018"),
     *          )
     *      ),
     *      @SWG\Parameter(
     *          name="2",
     *          required=true,
     *          in="body",
     *          description="2. 通过登录后修改，参数为：old_password，new_password, confirm_password;",
     *          @SWG\Schema(
     *              @SWG\Property(property="old_password", type="string", example="veda2017"),
     *              @SWG\Property(property="new_password", type="string", example="veda2018"),
     *              @SWG\Property(property="confirm_password", type="string", example="veda2018"),
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     */
    public function update()
    {
        $data = input();
        request()->bind('name', Auth::id());
        if (isset($data['token']) && ! empty($data['token'])) {
            // 通过找回密码进行修改
            if ( ! $this->validator->scene('find_password_update')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
            }
            if ( ! Cache::get($data['token']) || ( Cache::get($data['token']) !== $data['name'] )) {
                return Finalfail(REP_CODE_CAPTCHA_INVALID, "验证码错误");
            }

            $result = $this->repository->updatePasswordByEmailOrMobile($data['password'], [ 'name' => AuthService::id() ]);
            if ($result) {
                Cache::rm($data['token']);
                return Finalsuccess();
            }
        } elseif (isset($data['old_password']) && ! empty($data['old_password'])) {
            // 通过登录进行修改密码
            $this->checkLogin();

            if ( ! $this->validator->scene('login_password_update')->check($data)) {
                return Finalfail(REP_CODE_PARAMS_INVALID, $this->validator->getError());
            }

            $result = $this->repository->updatePasswordByEmailOrMobile($data['new_password'], [ 'name' => AuthService::id() ]);
            if ($result) {
                return Finalsuccess();
            }
        }
        return Finalfail(REP_CODE_ILLEGAL_OPERATION, '修改失败，请稍后再试');
    }
}
