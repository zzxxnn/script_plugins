<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/3/14
 * Time: 18:52
 */

namespace app\agent\repository;

/**
 * 一系列针对Model 的操作
 *
 * Class BaseRepository
 * @package app\agent
 */
abstract class BaseRepository
{
    protected $model = null;
}