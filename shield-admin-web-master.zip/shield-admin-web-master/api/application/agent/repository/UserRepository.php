<?php

namespace app\agent\repository;

use app\common\model\AgentModel;
use app\agent\model\AgentPhotoModel;
use app\agent\service\Auth;
use app\common\service\NotifierService as Notifier;
use app\common\service\LogService;
use Carbon\Carbon;
use think\Cache;
use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;
use think\db\Query;
use think\exception\DbException;
use app\common\service\MailService;

class UserRepository extends BaseRepository
{

    public function __construct()
    {
        $this->model = new AgentModel();
    }

    /**
     * 注册用户
     *
     * @param $data
     *
     * @return bool
     */
    public function insertUser($data)
    {
        if ($data['user_type'] == AgentModel::USER_TYPE_CLIENT) {
            $data['mobile'] = $data['user_mobile'];
            unset($data['user_mobile']);
        } elseif ($data['user_type'] == AgentModel::USER_TYPE_AGENT) {
            $data['phone'] = $data['user_mobile'];
            unset($data['user_mobile']);
        }
        $data['user_status'] = AgentModel::USER_STATUS_UNVALIDATED;
        $data['user_pass']   = password_hash($data['password'], PASSWORD_DEFAULT);
        unset($data['password']);
        unset($data['confirm_password']);
        $data['last_login_ip']   = get_client_ip(0, true);
        $data['last_login_time'] = Carbon::now()->toDateTimeString();
        $data['avatar']          = 'avatar/support-user0.png';
        unset($data['captcha']);
        $data['user_invite_code'] = rand_char(6);

        $user = $this->model->create($data);
        if ($user) {
            update_current_user($user, 'agent');

            return true;
        }

        return false;
    }

    /**
     * 通过邮箱或手机号进行筛选某一用户
     *
     * @param $data
     *
     * @return array|bool|false|\PDOStatement|string|\think\Model
     */
    public function selectUserByEmailOrMobile($data)
    {
        try {
            return ( new AgentModel() )->where('user_status', '<>', 0)->where(function (Query $query) use ($data) {
                $query->whereOr('mobile', $data['name']);
                $query->whereOr('phone', $data['name']);
                $query->whereOr('user_email', $data['name']);
            })->find();
        } catch (DataNotFoundException $e) {
            return false;
        } catch (ModelNotFoundException $e) {
            return false;
        } catch (DbException $e) {
            return false;
        }
    }

    /**
     * 登录时检查邮箱和手机号，以及更新登录时间和IP
     *
     * @param $data
     *
     * @return bool
     */
    public function loginUserByEmailOrMobile($data)
    {
        //处理username和password
        //$data['password'] = rsa_decrypt($data['password']);
        //$data['name'] = rsa_decrypt($data['name']);

        $user = $this->selectUserByEmailOrMobile($data);
        if ($user) {
            //比对密码
            if (password_verify($data['password'], $user['user_pass'])) {
                $auth = [
                    'id'         => $user['user_email'],
                    'login_time' => Carbon::now()->toDateTimeString(),
                ];
                session(Auth::USER_INFO_SESSION_KEY, $auth);
                session(Auth::USER_SIGN_SESSION_KEY, AuthSign($auth));

                $user->update_time     = Carbon::now()->toDateTimeString();
                $user->last_login_time = Carbon::now()->toDateTimeString();
                $user->last_login_ip   = get_client_ip(0, true);
                $user->save();

                return 0;
            }

            return LogService::writeLoginError($user['id'], 'app\common\model\AgentModel');
        }

        return 2;
    }

    /**
     * 发送邮件
     *
     * @param $email
     *
     * @return bool
     * @throws \PHPMailer\PHPMailer\Exception
     */
    public function sendEmail($email)
    {
        $token  = hash('md5', $email.rand_char(10));
        $result = MailService::send($email, $token, 'forget');
        if ( ! $result) {
            return false;
        }
        Cache::set("forget_pwd_".$email, time(), 300);
        Cache::set($token, $email);

        return true;
    }

    /**
     * 发送手机验证码
     *
     * @param $phone
     *
     * @return string
     */
    public function sendSms($phone)
    {
        $code   = rand_number(6);
        $expire = config('sms_expire');
        // 发送短信校验码
        $sendResult = Notifier::sendSms($phone, compact('code', 'expire'), Notifier::SMS_USER_REGISTER);
        if ( ! $sendResult) {
            return false;
        }

        Cache::set(request()->ip.'_'.$phone, $code, 60);
        Cache::set($code, $phone, $expire * 60);

        return $code;
    }

    /**
     * 修改密码
     *
     * @param $password
     * @param $data
     *
     * @return bool
     */
    public function updatePasswordByEmailOrMobile($password, $data)
    {
        $user = $this->selectUserByEmailOrMobile($data);
        if ($user) {
            $user->user_pass   = password_hash($password, PASSWORD_DEFAULT);
            $user->update_time = Carbon::now()->toDateTimeString();
            $user->save();

            return true;
        }

        return false;
    }

    /**
     * 上传图片
     *
     * @param $type
     */
    public function uploadPhoto($type)
    {
        $photo = ajax_upload_avatar('/photo');

        $avatarThumb = '';
        //生成缩略图
        if (in_array($type, [
            AgentPhotoModel::PHOTO_TYPE_ID_CARD_FRONT,
            AgentPhotoModel::PHOTO_TYPE_ID_CARD_BACK,
            AgentPhotoModel::PHOTO_TYPE_ID_CARD_WITH_PERSON
        ])) {
            $avatarThumb = crop_image($photo, 242, 146);
        } elseif ($type == AgentPhotoModel::PHOTO_TYPE_BUSINESS_LICENSE) {
            $avatarThumb = crop_image($photo, 405, 578);
        }

        Success([ 'data' => $avatarThumb ? $avatarThumb : $photo ]);
    }

    /**
     * 实名认证上传图片，点击确认后更新图片信息以及身份证号和营业执照社会信用号码
     *
     * @param $data
     * @param $agent
     *
     * @return bool
     */
    public function updatePhotos($data, $agent)
    {
        foreach ($data['photos'] as $photo) {
            $agent_photo              = new AgentPhotoModel();
            $agent_photo->agent_id    = $agent->id;
            $agent_photo->agent_type  = $agent->user_type;
            $agent_photo->photo_type  = $photo['type'];
            $agent_photo->url         = $photo['name'];
            $agent_photo->create_time = Carbon::now()->toDateTimeString();
            $agent_photo->update_time = Carbon::now()->toDateTimeString();
            $agent_photo->save();
        }

        $agent->id_number        = $data['id_number'];
        $agent->id_verify_status = AgentModel::USER_REAL_NAME_VERIFIED;
        if ($agent->save()) {
            return true;
        }
        return false;
    }

    /**
     * @param $id
     *
     * @param $data
     *
     * @return bool
     * @throws DataNotFoundException
     * @throws DbException
     * @throws ModelNotFoundException
     */
    public function updateAgentById($data)
    {
        $agent = AgentModel::find($data['id']);
        if ($agent) {
            if (isset($data['user_mobile'])) {
                if ($agent->user_type == AgentModel::USER_TYPE_CLIENT) {
                    $agent->mobile = $data['user_mobile'];
                } elseif ($agent->user_type == AgentModel::USER_TYPE_AGENT) {
                    $agent->phone = $data['user_mobile'];
                }
            }
            if (isset($data['user_email'])) {
                $agent->user_email = $data['user_email'];
            }
            if (isset($data['company'])) {
                $agent->company = $data['company'];
            }

            $agent->save();

            return true;
        }

        return false;
    }

}
