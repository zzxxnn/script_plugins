<?php

namespace app\agent\repository;

class ProfileRepository
{
    public function updateProfile($user_info, $uid): bool
    {
        return true;
    }
}