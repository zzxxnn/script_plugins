<?php

namespace app\agent\model;

use think\Model;

class AgentPhotoModel extends Model
{

    protected $table = 'agent_photos';

    //开启自动写入时间戳字段
    protected $autoWriteTimestamp = true;

    //------------------------- 照片类型 -------------------------------
    const PHOTO_TYPE_ID_CARD_FRONT = 1;   // 身份证正面
    const PHOTO_TYPE_ID_CARD_BACK = 2;   // 身份证反面
    const PHOTO_TYPE_ID_CARD_WITH_PERSON = 3;   // 手持身份证
    const PHOTO_TYPE_BUSINESS_LICENSE = 4;   // 营业执照
}
