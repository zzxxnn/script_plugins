<?php

namespace app\agent\model;

use app\common\traits\BaseModel;
use think\Model;
use traits\model\SoftDelete;

/**
 * Class CashOutModel 提现记录
 *
 * @package app\agent\model
 * @author Teddy Sun <sgsheg@163.com>
 */
class CashOutModel extends Model
{
    use SoftDelete, BaseModel;

    protected $table = 'cash_outs';

    protected $autoWriteTimestamp = 'datetime';

    protected $deleteTime = 'delete_time';

    protected $auto = ['cash_sn'];

    protected $hidden = ['delete_time'];

    protected $append = ['status_name', 'agent_name', 'after_amount'];

    //常量:1创建提现;2提现成功;3提现失败
    const CASH_CREATED = 1;
    const CASH_SUCCESS = 2;
    const CASH_FAILURE = 3;
    const statusArray  = [
        1 => '已创建',
        2 => '提现成功',
        3 => '提现失败',
    ];

    //字段进行类型处理
    protected $type = [
        'status'   => 'integer',
        'id'       => 'integer',
        'agent_id' => 'integer',
        'proof'    => 'integer',
    ];

    // 模型关系 提现记录->代理商
    public function agent()
    {
        return $this->belongsTo('app\common\model\AgentModel', 'agent_id', 'id');
    }

    private function cashSn()
    {
        $cash_sn = date('Ymd').substr(implode(null, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), -8, 8);

        return $cash_sn;
    }

    /**
     * @param $value
     * @return string
     */
    protected function setCashSnAttr()
    {
        return $this->cashSn();
    }

    /**
     * 获取状态
     *
     * @param $value
     * @return mixed
     */
    protected function getStatusNameAttr()
    {
        return self::statusArray[$this->status];
    }

    /**
     * 获取代理商邮箱
     *
     * @return string
     */
    protected function getAgentNameAttr()
    {
        return $this->agent->user_email ?? '';
    }

    /**
     * 为接口临时添加一个余额
     */
    protected function getAfterAmountAttr()
    {
        return '2000.00';
    }
}
