<?php

use think\Route;

Route::post([
    'profile/avatar'    =>  'agent/profile.Avatar/save'
]);

Route::put([
    'profile/avatar'    =>  'agent/profile.Avatar/update'
]);