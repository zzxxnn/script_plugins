<?php

use think\Route;

Route::resource('info', 'agent/IndexController');