<?php

//------------------------- RESPONSE CODE START -------------------------------

defined('REP_CODE_SUCCESS') or define('REP_CODE_SUCCESS', 0);   // 正常
defined('REP_CODE_PASSWORD_ERROR') or define('REP_CODE_PASSWORD_ERROR', 10003);     // 密码错误
defined('REP_CODE_SERVER_ERROR') or define('REP_CODE_SERVER_ERROR', 10500);   // 正常
defined('REP_CODE_PARAMS_INVALID') or define('REP_CODE_PARAMS_INVALID', 11000); // 请求参数不合法
defined('REP_CODE_SOURCE_EXIST') or define('REP_CODE_SOURCE_EXIST', 11001);   // 请求数据已存在
defined('REP_CODE_EMAIL_REGISTER') or define('REP_CODE_EMAIL_REGISTER', 11002);   // 邮箱已注册
defined('REP_CODE_CAPTCHA_INVALID') or define('REP_CODE_CAPTCHA_INVALID', 11003); // 验证码不合法
defined('REP_CODE_EMAIL_NOT_REGISTER') or define('REP_CODE_EMAIL_NOT_REGISTER', 11004);   // 邮箱未注册
defined('REP_CODE_EMAIL_SEND_TOO_FREQUENTLY') or define('REP_CODE_EMAIL_SEND_TOO_FREQUENTLY', 11005);   // 邮件发送太过频繁
defined('REP_CODE_EMAIL_SEND_FAIL') or define('REP_CODE_EMAIL_SEND_FAIL', 11006);   // 邮件发送失败
defined('REP_CODE_LINK_TIME_OUT') or define('REP_CODE_LINK_TIME_OUT', 11007);   // 链接超时
defined('REP_CODE_EMAIL_IS_SAFE') or define('REP_CODE_EMAIL_IS_SAFE', 11008);   // 该邮箱已设置为安全邮箱
defined('REP_CODE_EMAIL_GET_AFTER_ONE_MINUTE') or define('REP_CODE_EMAIL_GET_AFTER_ONE_MINUTE', 11009);   // 请在一分钟后重新获取
defined('REP_CODE_MOBILE_IS_SAFE') or define('REP_CODE_MOBILE_IS_SAFE', 11010);   // 该手机号已设置为安全手机
defined('REP_CODE_MOBILE_SEND_TOO_FREQUENTLY') or define('REP_CODE_MOBILE_SEND_TOO_FREQUENTLY', 11011);   // 手机验证码发送过于频繁
defined('REP_CODE_MOBILE_SEND_FAIL') or define('REP_CODE_MOBILE_SEND_FAIL', 11012);   // 手机验证码发送失败
defined('REP_CODE_ORDER_TOO_MUCH_DISCOUNT_FEE') or define('REP_CODE_ORDER_TOO_MUCH_DISCOUNT_FEE', 11013);   // 优惠价格不能大于原订单金额
defined('REP_CODE_ORDER_ZERO_DISCOUNT_FEE') or define('REP_CODE_ORDER_ZERO_DISCOUNT_FEE', 11014);   // 优惠金额不能为空
defined('REP_CODE_ORDER_SEND_PAY_REMAIND_TOO_FREQUENTLY') or define('REP_CODE_ORDER_SEND_PAY_REMAIND_TOO_FREQUENTLY', 11015);   // 支付提醒过于频繁
defined('REP_CODE_ORDER_SEND_PAY_REMAIND_FAIL') or define('REP_CODE_ORDER_SEND_PAY_REMAIND_FAIL', 11016);   // 支付提醒发送失败
defined('REP_CODE_PRODUCT_NAME_EXIST') or define('REP_CODE_PRODUCT_NAME_EXIST', 11017);   // 商品名称已存在
defined('REP_CODE_PRODUCT_ATTRIBUTES_EXIST') or define('REP_CODE_PRODUCT_ATTRIBUTES_EXIST', 11018);   // 该商品下的相关定价已存在
defined('REP_CODE_PRODUCT_SKU_LINE_EXIST') or define('REP_CODE_PRODUCT_SKU_LINE_EXIST', 11019);   // 该地区线路sku已存在
defined('REP_CODE_PROXY_NODE_CONFIG_ERROR') or define('REP_CODE_PROXY_NODE_CONFIG_ERROR', 11020);   // 高防节点配置有误
defined('REP_CODE_PROXY_NODE_SITE_LIMIT_ERROR') or define('REP_CODE_PROXY_NODE_SITE_LIMIT_ERROR', 11021);   // 网站上限设置错误
defined('REP_CODE_PROXY_NODE_REPEAT_ERROR') or define('REP_CODE_PROXY_NODE_REPEAT_ERROR', 11022);   // 高防节点添加重复
defined('REP_CODE_PROXY_NODE_SITE_TYPE_ERROR') or define('REP_CODE_PROXY_NODE_SITE_TYPE_ERROR', 11023);   // 高防节点类型错误
defined('REP_CODE_DNS_NODE_CONFIG_ERROR') or define('REP_CODE_DNS_NODE_CONFIG_ERROR', 11024);   // DNS节点配置有误
defined('REP_CODE_DNS_NODE_REPEAT_ERROR') or define('REP_CODE_DNS_NODE_REPEAT_ERROR', 11025);   // DNS节点添加重复
defined('REP_CODE_SUPPORT_QQ_EXIST') or define('REP_CODE_SUPPORT_QQ_EXIST', 11026);   // 技术支持QQ已存在
defined('REP_CODE_PRODUCT_OFF_SALE') or define('REP_CODE_PRODUCT_OFF_SALE', 11027);   // 商品已下架
defined('REP_CODE_PRODUCT_STOCK_NOT_ENOUGH') or define('REP_CODE_PRODUCT_STOCK_NOT_ENOUGH', 11028);   // 商品库存不足
defined('REP_CODE_ORDER_UPDATE_ERROR') or define('REP_CODE_ORDER_UPDATE_ERROR', 11029);   // 更新订单失败
defined('REP_CODE_ORDER_ALREADY_PAY') or define('REP_CODE_ORDER_ALREADY_PAY', 11030);   // 订单已支付
defined('REP_CODE_ORDER_REMAINING_FEE_NOT_ENOUGH') or define('REP_CODE_ORDER_REMAINING_FEE_NOT_ENOUGH', 11031);   // 余额不足
defined('REP_CODE_LOGIN_NEED_REFRESH') or define('REP_CODE_LOGIN_NEED_REFRESH', 11032);   // 登录需要重新刷新
defined('REP_CODE_USER_RECHARGE_SNED_NOTIFY_FAIL') or define('REP_CODE_USER_RECHARGE_SNED_NOTIFY_FAIL', 11033);   // 用户充值发送失败
defined('REP_CODE_USER_RECHARGE_FILE_CANNOT_EMPTY') or define('REP_CODE_USER_RECHARGE_FILE_CANNOT_EMPTY', 11034);   // 用户充值时图片不能为空
defined('REP_CODE_DDOS_DELETE_SITE_FAIL') or define('REP_CODE_DDOS_DELETE_SITE_FAIL', 11035);   // 删除DDOS时候删除站点失败
defined('REP_CODE_DDOS_DELETE_PORT_FAIL') or define('REP_CODE_DDOS_DELETE_PORT_FAIL', 11036);   // 删除DDOS时候删除应用防护失败

/**
 * 添加网站防护
 */
defined('REP_CODE_SITE_ALREADY_EXIST') or define('REP_CODE_SITE_ALREADY_EXIST', 11037);   // 新增网站防护时站点已存在
defined('REP_CODE_SITE_SAVE_CONFIG_FAIL') or define('REP_CODE_SITE_SAVE_CONFIG_FAIL', 11038);   // 新增网站防护时保存配置失败
defined('REP_CODE_SITE_TEXT_CODE_NOT_FOUND') or define('REP_CODE_SITE_TEXT_CODE_NOT_FOUND', 11039);   // 新增网站防护（测试）时未找到该站点TextCode值
defined('REP_CODE_SITE_TXT_PARSE_FAIL') or define('REP_CODE_SITE_TXT_PARSE_FAIL', 11040);   // 新增网站防护时TXT记录未正确解析
defined('REP_CODE_SITE_TEXT_CODE_ERROR') or define('REP_CODE_SITE_TEXT_CODE_ERROR', 11041);   // 新增网站防护时站点解析TxTCode值不匹配
defined('REP_CODE_SITE_UPDATE_APPROVED_STATUS_FAIL') or define('REP_CODE_SITE_UPDATE_APPROVED_STATUS_FAIL', 11042);   // 新增网站防护时更新站点状态为已审核失败
defined('REP_CODE_SITE_TEXT_CODE_VERIFY_FAIL') or define('REP_CODE_SITE_TEXT_CODE_VERIFY_FAIL', 11043);   // 新增网站防护时站点TextCode校验失败
defined('REP_CODE_SITE_ADD_PARAMS_INVALID') or define('REP_CODE_SITE_ADD_PARAMS_INVALID', 11044);   // 新增网站防护第一步添加时参数不合法
defined('REP_CODE_SITE_TXT_CODE_SITE_NOT_EXIST') or define('REP_CODE_SITE_TXT_CODE_SITE_NOT_EXIST', 11045);   // 新增网站防护第二步添加时获取txtcode时站点不存在
defined('REP_CODE_SITE_TXT_CODE_FAIL') or define('REP_CODE_SITE_TXT_CODE_FAIL', 11046);   // 新增网站防护第二步添加时获取txtcode时获取txtcode失败
defined('REP_CODE_SITE_TXT_CODE_VERIFY_SITE_NOT_EXIST') or define('REP_CODE_SITE_TXT_CODE_VERIFY_SITE_NOT_EXIST', 11047);   // 新增网站防护第三步校验txtcode时站点不存在
defined('REP_CODE_SITE_LINK_SITE_NOT_EXIST') or define('REP_CODE_SITE_LINK_SITE_NOT_EXIST', 11048);   // 新增网站防护第四步接入时站点不存在
defined('REP_CODE_SITE_LINK_PARAMS_INVALID') or define('REP_CODE_SITE_LINK_PARAMS_INVALID', 11049);   // 新增网站防护第四步接入时参数不合法
defined('REP_CODE_SITE_LINK_COUNT_NOT_ENOUGH') or define('REP_CODE_SITE_LINK_COUNT_NOT_ENOUGH', 11050);   // 新增网站防护第四步接入时防护域名数不足
defined('REP_CODE_SITE_LINK_NOT_APPROVED_STATUS') or define('REP_CODE_SITE_LINK_NOT_APPROVED_STATUS', 11051);   // 新增网站防护第四步接入时域名未通过审核
defined('REP_CODE_SITE_LINK_UPDATE_LINKING_STATUS_FAIL') or define('REP_CODE_SITE_LINK_UPDATE_LINKING_STATUS_FAIL', 11052);   // 新增网站防护第四步接入时更新配置（状态更新为正在接入）
defined('REP_CODE_SITE_LINK_UPDATE_PROXY_CONF_FAIL') or define('REP_CODE_SITE_LINK_UPDATE_PROXY_CONF_FAIL', 11053);   // 新增网站防护第四步接入时接入信息写入ES配置更新时失败
defined('REP_CODE_SITE_LINK_SET_PROXY_CONF_FAIL') or define('REP_CODE_SITE_LINK_SET_PROXY_CONF_FAIL', 11054);   // 新增网站防护第四步接入时Proxy Conf 配置保存失败
defined('REP_CODE_SITE_LINK_ADD_DNS_NODE_CONF_FAIL') or define('REP_CODE_SITE_LINK_ADD_DNS_NODE_CONF_FAIL', 11055);   // 新增网站防护第四步接入时DNS Node Info配置写入失败
defined('REP_CODE_SITE_LINK_SET_ZK_DNS_CONF_FAIL') or define('REP_CODE_SITE_LINK_SET_ZK_DNS_CONF_FAIL', 11056);   // 新增网站防护第四步接入时DNS配置写入Zookeeper失败
defined('REP_CODE_SITE_LINK_SET_ZK_PROXY_CONF_FAIL') or define('REP_CODE_SITE_LINK_SET_ZK_PROXY_CONF_FAIL', 11057);   // 新增网站防护第四步接入时转发设置写入Zookeeper失败
defined('REP_CODE_SITE_LINK_UPDATE_LINKED_STATUS_FAIL') or define('REP_CODE_SITE_LINK_UPDATE_LINKED_STATUS_FAIL', 11058);   // 新增网站防护第四步接入时更新站点状态为已接入失败
defined('REP_CODE_SITE_LINK_FAIL') or define('REP_CODE_SITE_LINK_FAIL', 11059);   // 新增网站防护第四步接入时域名接入失败
defined('REP_CODE_SITE_UPDATE_LINK_PARAMS_INVALID') or define('REP_CODE_SITE_UPDATE_LINK_PARAMS_INVALID', 11060);   // 新增网站防护第五步更新站点信息时参数不合法
defined('REP_CODE_SITE_UPDATE_LINK_SITE_NOT_EXIST') or define('REP_CODE_SITE_UPDATE_LINK_SITE_NOT_EXIST', 11061);   // 新增网站防护第五步更新站点信息时站点不存在
defined('REP_CODE_SITE_UPDATE_LINK_SITE_COUNT_NOT_ENOUGH') or define('REP_CODE_SITE_UPDATE_LINK_SITE_COUNT_NOT_ENOUGH', 11062);   // 新增网站防护第五步更新站点信息时防护域名数不足
defined('REP_CODE_SITE_UPDATE_LINK_RM_DNS_CONF_FAIL') or define('REP_CODE_SITE_UPDATE_LINK_RM_DNS_CONF_FAIL', 11063);   // 新增网站防护第五步更新站点信息时移除DNS Conf 信息失败
defined('REP_CODE_SITE_UPDATE_LINK_RM_PROXY_CONF_FAIL') or define('REP_CODE_SITE_UPDATE_LINK_RM_PROXY_CONF_FAIL', 11064);   // 新增网站防护第五步更新站点信息时移除Proxy Conf信息失败
defined('REP_CODE_SITE_UPDATE_LINK_RM_ZK_PROXY_CONF_FAIL') or define('REP_CODE_SITE_UPDATE_LINK_RM_ZK_PROXY_CONF_FAIL', 11065);   // 新增网站防护第五步更新站点信息时ZK删除Proxy数据写入失败
defined('REP_CODE_SITE_UPDATE_LINK_UPDATE_SITE_COUNT_FAIL') or define('REP_CODE_SITE_UPDATE_LINK_UPDATE_SITE_COUNT_FAIL', 11066);   // 新增网站防护第五步更新站点信息时更新用户实例域名接入数量失败
defined('REP_CODE_SITE_UPDATE_LINK_UPDATE_SITE_PROXY_CONF_FAIL') or define('REP_CODE_SITE_UPDATE_LINK_UPDATE_SITE_PROXY_CONF_FAIL', 11067);   // 新增网站防护第五步更新站点信息时更新站点配置失败
defined('REP_CODE_SITE_UPDATE_LINK_SET_PROXY_CONF_FAIL') or define('REP_CODE_SITE_UPDATE_LINK_SET_PROXY_CONF_FAIL', 11068);   // 新增网站防护第五步更新站点信息时Proxy Conf 配置保存失败
defined('REP_CODE_SITE_UPDATE_LINK_ADD_DNS_NODE_CONF_FAIL') or define('REP_CODE_SITE_UPDATE_LINK_ADD_DNS_NODE_CONF_FAIL', 11069);   // 新增网站防护第五步更新站点信息时DNS Node Info配置写入失败
defined('REP_CODE_SITE_UPDATE_LINK_SET_ZK_DNS_CONF_FAIL') or define('REP_CODE_SITE_UPDATE_LINK_SET_ZK_DNS_CONF_FAIL', 11070);   // 新增网站防护第五步更新站点信息时DNS配置信息写入失败
defined('REP_CODE_SITE_UPDATE_LINK_SET_ZK_PROXY_CONF_FAIL') or define('REP_CODE_SITE_UPDATE_LINK_SET_ZK_PROXY_CONF_FAIL', 11071);   // 新增网站防护第五步更新站点信息时Proxy信息写入ZK失败
defined('REP_CODE_SITE_UPDATE_LINK_FAIL') or define('REP_CODE_SITE_UPDATE_LINK_FAIL', 11072);   // 新增网站防护第五步更新站点信息时站点接入信息更新失败
defined('REP_CODE_SITE_UPDATE_LINK_RM_ZK_DNS_CONF_FAIL') or define('REP_CODE_SITE_UPDATE_LINK_RM_ZK_DNS_CONF_FAIL', 11073);   // 新增网站防护第五步更新站点信息时ZK删除DNS数据写入失败
defined('REP_CODE_SITE_DELETE_FAIL') or define('REP_CODE_SITE_DELETE_FAIL', 11074);   // 删除网站防护失败
defined('REP_CODE_SITE_UPDATE_SITE_CONFIG_FAIL') or define('REP_CODE_SITE_UPDATE_SITE_CONFIG_FAIL', 11075);   // 更新网站防护配置失败

/**
 * 应用防护
 */
defined('REP_CODE_PORT_ADD_PARAMS_INVALID') or define('REP_CODE_PORT_ADD_PARAMS_INVALID', 11076);   // 新增应用防护时参数不合法
defined('REP_CODE_PORT_ADD_FORWARD_INVALID') or define('REP_CODE_PORT_ADD_FORWARD_INVALID', 11077);   // 新增应用防护时转发端口输入非法
defined('REP_CODE_PORT_ADD_PROXY_PORT_OUT_OF_RANGE') or define('REP_CODE_PORT_ADD_PROXY_PORT_OUT_OF_RANGE', 11078);   // 新增应用防护时超过代理端口允许范围
defined('REP_CODE_PORT_ADD_PROXY_PORT_EXIST') or define('REP_CODE_PORT_ADD_PROXY_PORT_EXIST', 11079);   // 新增应用防护时转发端口已存在,不能选择全部
defined('REP_CODE_PORT_ADD_SAVE_CONFIG_FAIL') or define('REP_CODE_PORT_ADD_SAVE_CONFIG_FAIL', 11080);   // 新增应用防护时新应用配置保存失败
defined('REP_CODE_PORT_UPDATE_PORT_COUNT_FAIL') or define('REP_CODE_PORT_UPDATE_PORT_COUNT_FAIL', 11081);   // 新增应用防护时更新实例接入信息失败
defined('REP_CODE_PORT_SET_ES_PROXY_CONF_FAIL') or define('REP_CODE_PORT_SET_ES_PROXY_CONF_FAIL', 11082);   // 新增应用防护时HD Conf配置保存失败
defined('REP_CODE_PORT_SET_ZK_PROXY_CONF_FAIL') or define('REP_CODE_PORT_SET_ZK_PROXY_CONF_FAIL', 11083);   // 新增应用防护时新转发配置写入ZK失败
defined('REP_CODE_PORT_UPDATE_FAIL') or define('REP_CODE_PORT_UPDATE_FAIL', 11084);   // 新增应用防护时更新域名状态失败
defined('REP_CODE_PORT_ADD_FAIL') or define('REP_CODE_PORT_ADD_FAIL', 11085);   // 新增应用防护失败
defined('REP_CODE_PORT_UPDATE_PARAMS_INVALID') or define('REP_CODE_PORT_UPDATE_PARAMS_INVALID', 11086);   // 更新应用防护时参数不合法
defined('REP_CODE_PORT_NOT_EXIST') or define('REP_CODE_PORT_NOT_EXIST', 11087);   // 更新应用防护时应用不存在
defined('REP_CODE_PORT_RM_ZK_PROXY_CONF') or define('REP_CODE_PORT_RM_ZK_PROXY_CONF', 11088);   // 更新应用防护时移除ZK Proxy Conf信息失败
defined('REP_CODE_PORT_RM_ES_PROXY_CONF') or define('REP_CODE_PORT_RM_ES_PROXY_CONF', 11089);   // 更新应用防护时Proxy Conf配置更新失败
defined('REP_CODE_PORT_REDUCE_PORT_COUNT') or define('REP_CODE_PORT_REDUCE_PORT_COUNT', 11090);   // 更新应用防护时削减用户实例的端口接入数量
defined('REP_CODE_PORT_UPDATE_PORT_CONFIG_FAIL') or define('REP_CODE_PORT_UPDATE_PORT_CONFIG_FAIL', 11091);   // 更新应用防护时更新应用接入配置失败
defined('REP_CODE_PORT_SET_ZK_DNS_CONF_FAIL') or define('REP_CODE_PORT_SET_ZK_DNS_CONF_FAIL', 11092);   // 更新应用防护时ZK DNS Conf写入失败
defined('REP_CODE_PORT_DELETE_FAIL') or define('REP_CODE_PORT_DELETE_FAIL', 11093);   // 删除应用防护失败
defined('REP_CODE_USER_REAL_NAME_NOT_EXIST') or define('REP_CODE_USER_REAL_NAME_NOT_EXIST', 11094);   // B端用户重置实名认证
defined('REP_CODE_UPDATE_USER_NOTHING') or define('REP_CODE_UPDATE_USER_NOTHING', 11095);   // 修改用户信息时未作修改


defined('REP_CODE_LOGIN_TOO_MUCH_FAIL') or define('REP_CODE_LOGIN_TOO_MUCH_FAIL', 11094);   // 登录错误次数过多



defined('REP_CODE_NEED_LOGIN') or define('REP_CODE_NEED_LOGIN', 12001);   // 需要登陆
defined('REP_CODE_SOURCE_NOT_FOUND') or define('REP_CODE_SOURCE_NOT_FOUND', 13001);   // 请求数据不存在
defined('REP_CODE_ABNORMAL_OPERATION') or define('REP_CODE_ABNORMAL_OPERATION', 14000);   // 操作异常
defined('REP_CODE_ILLEGAL_OPERATION') or define('REP_CODE_ILLEGAL_OPERATION', 14001);   // 非法操作
defined('REP_CODE_FAILED_OPERATION') or define('REP_CODE_FAILED_OPERATION', 14200);     // 操作失败
defined('REP_CODE_PERMISSION_DENY') or define('REP_CODE_PERMISSION_DENY', 14003);     // 权限异常

defined('REP_CODE_DB_ERROR') or define('REP_CODE_DB_ERROR', 20000);   // 数据库操作失败
defined('REP_CODE_ES_ERROR') or define('REP_CODE_ES_ERROR', 21000);   // ES操作失败
defined('REP_CODE_ZK_ERROR') or define('REP_CODE_ZK_ERROR', 22000);   // ZK操作失败

//------------------------- RESPONSE CODE END -------------------------------
