<?php

namespace app\common\traits;

trait Unit
{
    /**
     * description 处理高级查询
     *
     * @param $model
     * @param $whereFunction
     * @return mixed
     */
    protected function handleFunction($model, $whereFunction)
    {
        if (! count($whereFunction)) {
            return $model;
        }
        foreach ($whereFunction as $key => $value) {
            $model = $model->{$key}(...$value);
        }

        return $model;
    }

    /**
     * description 查询条件处理
     *
     * @param $db
     * @param $where
     * @param bool $softDelete
     * @return mixed
     */
    protected function handleWhere($db, $where, $softDelete = true)
    {
        //处理字符串条件
        if (is_string($where)) {
            $db = $db->where($where);
            if ($softDelete && config('basemodel.soft_delete')) {
                return $db->where($this->getDeleteColumn(), 1);
            } else {
                return $db;
            }
        }

        if ($softDelete && config('basemodel.soft_delete')) {
            $where[$this->getDeleteColumn()] = 1;
        }
        if (count($where)) {
            foreach ($where as $key => $value) {
                if (is_array($value)) {
                    $db = $db->where($key, $value[0], $value[1]);
                } else {
                    $db = $db->where($key, $value);
                }
            }
        }

        return $db;
    }

    /**
     * description 处理查询得到的结果
     *
     * @param $data
     * @return array
     */
    protected function handleSelect($data)
    {
        if (count($data) && $this->retFormat()) {
            if (! is_object($data[0]) && count($data) == count($data, true)) {
                return $data->toArray();
            }
            $tmp_arr = [];
            foreach ($data as $key => $value) {
                $tmp_arr[$key] = $value->toArray();
            }
            $data = $tmp_arr;
        }

        return $data;
    }

    /**
     * description 获取删除标志
     *
     * @return bool
     */
    protected function getDeleteColumn()
    {
        if (isset($this->soft_delete)) {
            return $this->soft_delete;
        }

        return 'soft_delete';
    }

    /**
     * description 定义返回格式是否为数组
     *
     * @return mixed
     */
    protected function retFormat()
    {
        return config('basemodel.ret_array_format');
    }

    /**
     * description 获取主键id
     *
     * @return string
     */
    protected function getPrimaryId()
    {
        return isset($this->primaryId) ? $this->primaryId : 'id';
    }
}