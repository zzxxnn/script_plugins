<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/9/5
 * Time: 18:52
 */

namespace app\common\command;


use PHPUnit\Util\Blacklist;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Loader;
use think\Session;

class UnitCommand extends Command
{
    public function configure()
    {
        $this->setName('unit')->setDescription('phpunit')->ignoreValidationErrors();
    }

    public function execute(Input $input, Output $output)
    {
        //注册命名空间
        Loader::addNamespace('tests', ROOT_PATH . 'tests');

        Session::init();
        $argv = $_SERVER['argv'];
        array_shift($argv);
        array_shift($argv);
        array_unshift($argv, 'phpunit');
        Blacklist::$blacklistedClassNames = [];

        $code = (new \PHPUnit\TextUI\Command())->run($argv, false);

        return $code;
    }
}