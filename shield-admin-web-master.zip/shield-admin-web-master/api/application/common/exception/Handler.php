<?php

namespace app\common\exception;

use app\client\controller\BaseController;
use app\common\exception\client\ElasticSearchException;
use app\common\exception\client\PermissionDenyException;
use app\common\exception\client\ZookeeperException;
use Elasticsearch\Common\Exceptions\BadRequest400Exception;
use Elasticsearch\Common\Exceptions\NoNodesAvailableException;
use Exception;
use think\db\exception\ModelNotFoundException;
use think\exception\Handle;
use think\exception\ValidateException;

class Handler extends Handle
{
    public function render(Exception $e)
    {
        // 参数验证错误
        if ($e instanceof ValidateException) {
            return json($e->getError(), REP_CODE_PARAMS_INVALID);
        }
        //------------------------- ES Exceptions -------------------------------

        //请求异常
        if ($e instanceof NoNodesAvailableException) {  // 没有活跃节点
            return Finalfail(REP_CODE_ES_ERROR, $e->getMessage());
        }

        if ($e instanceof BadRequest400Exception) { // 查询构造错误
            return Finalfail(REP_CODE_ES_ERROR, $e->getMessage());
        }

        if ($e instanceof ElasticSearchException) {
            return Finalfail(REP_CODE_ES_ERROR, $e->getMessage());
        }

        //------------------------- ES Exceptions -------------------------------

        //------------------------- Zookeeper Exception -------------------------------

        if ($e instanceof ZookeeperException) {
            return Finalfail(REP_CODE_ES_ERROR, $e->getMessage());
        }

        //------------------------- Zookeeper Exception -------------------------------

        if ($e instanceof PermissionDenyException) {
            return Finalfail(REP_CODE_PERMISSION_DENY, '没有权限进行操作！');
        }

        // 404
        if ($e instanceof ModelNotFoundException) {
            $message = $e->getMessage() ?? '未找到对应记录';

            return Finalfail(404, $message);
        }

        //可以在此交由系统处理
        return parent::render($e);
    }
}