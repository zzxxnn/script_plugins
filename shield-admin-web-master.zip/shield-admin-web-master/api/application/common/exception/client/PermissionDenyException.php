<?php

namespace app\common\exception\client;

use think\Exception;

class PermissionDenyException extends Exception
{
}