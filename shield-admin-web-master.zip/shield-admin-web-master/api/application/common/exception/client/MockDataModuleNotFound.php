<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/4/9
 * Time: 11:11
 */

namespace app\common\exception\client;


class MockDataModuleNotFound extends \Exception
{

}