<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/6/22
 * Time: 14:32
 */

namespace app\common\exception\client\Pay;


class WxPayException extends \Exception
{

}