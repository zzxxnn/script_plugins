<?php
/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/7/25
 * Time: 10:20
 */

namespace app\common\exception\client\Pay;


class AccountPayException extends \Exception
{

}