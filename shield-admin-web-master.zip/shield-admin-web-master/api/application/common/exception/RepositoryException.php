<?php
/*
* This file  is a part of  Veda- Platform
* Copyright (c) 2015 - 2018. Veda Software Inc. (http://www.veda.com)
*
* @file             RepositoryException.php
* @author           Teddy Sun
*/

namespace app\common\exception;

use think\Exception;

/**
 * Class RepositoryException
 *
 * @package app\common\exception
 * @author Teddy Sun <sgsheg@163.com>
 */
class RepositoryException extends Exception
{
}