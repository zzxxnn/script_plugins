<?php

namespace app\common\exception;


class MockDataModuleNotFound extends \Exception
{

}