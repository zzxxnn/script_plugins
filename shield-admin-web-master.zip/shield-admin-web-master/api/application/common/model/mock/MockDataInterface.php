<?php

namespace app\common\model\mock;


interface MockDataInterface
{
    public function data();
}