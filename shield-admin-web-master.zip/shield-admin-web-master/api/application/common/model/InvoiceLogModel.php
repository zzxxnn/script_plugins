<?php

namespace app\common\model;

use think\Model;

class InvoiceLogModel extends Model
{

    protected $table = 'invoice_logs';

    protected $resultSetType = 'collection';

    protected $autoWriteTimestamp = 'datetime';
}
