<?php

namespace app\common\model;

use app\agent\model\CashOutModel;
use app\common\traits\BaseModel;
use think\Model;
use traits\model\SoftDelete;

/**
 * Class AgentModel 代理商
 *
 * @package app\common\model
 * @author Teddy Sun <sgsheg@163.com>
 */
class AgentModel extends Model
{
    use SoftDelete, BaseModel;

    protected $resultSetType = 'collection';

    protected $table = 'agents';

    //开启自动写入时间戳字段
    protected $autoWriteTimestamp = 'datetime';

    // 用户数量
    protected $append = [
        'user_number',
        'img_url',
        'cash_confirmed', //待确认总额
        'cash_has_been',  //已提现金额
        'cash_all',       //可提现金额
        'client_register_url',
    ];

    protected $type = [
        'id'               => 'integer',
        'id_verify_status' => 'integer',
        'sex'              => 'integer',
        'score'            => 'integer',
        'user_status'      => 'integer',
        'user_type'        => 'integer',
    ];

    //软删除
    protected $deleteTime = 'delete_time';

    public function getCreateTimeAttr($time)
    {
        return $time;
    }

    public function getUpdateTimeAttr($time)
    {
        return $time;
    }

    protected $hidden = [
        'user_pass',
        'update_time',
        'delete_time'
    ];

    //------------------------- 用户类型 -------------------------------
    const USER_TYPE_CLIENT = 1;   // 个人代理商
    const USER_TYPE_AGENT  = 2;   // 机构代理商
    const USER_TYPE_ADMIN  = 3;   // 管理员
    //------------------------- 用户状态 -------------------------------
    const USER_STATUS_FORBID      = 0;   // 禁止
    const USER_STATUS_NORMAL      = 1;   // 正常
    const USER_STATUS_UNVALIDATED = 2;   // 未验证

    const USER_REAL_NAME_UNVERIFIED = 0;
    const USER_REAL_NAME_VERIFIED = 1;

    //关系 按照创建时间倒叙
    public function users()
    {
        return $this->hasMany('UserModel', 'agent_id', 'id')->order(['create_time' => 'desc']);
    }

    public function cashOuts()
    {
        return $this->hasMany('app\agent\model\CashOutModel', 'agent_id', 'id');
    }

    //获取代理用户总数
    public function getUserNumberAttr()
    {
        return \count($this->users);
    }

    //头像
    public function getImgUrlAttr()
    {
        $request = \think\Request::instance();

        return $request->domain().'/'.$this->getAttr('avatar');
    }

    /**
     * 待确认总额
     *
     * @return float|int
     */
    protected function getCashConfirmedAttr()
    {
        return $this->cashOuts()->where('status', CashOutModel::CASH_CREATED)->sum('amount') ?? 0;
    }

    /**
     * 已提现金额
     *
     * @return float|int
     */
    protected function getCashHasBeenAttr()
    {
        return $this->cashOuts()->where('status', CashOutModel::CASH_SUCCESS)->sum('amount') ?? 0;
    }

    /**
     * 可提现金额 todo:提现金额的计算方式
     *
     * @return float|int
     */
    protected function getCashAllAttr()
    {
        return $this->cashOuts()->sum('amount') ?? 0;
    }

    /**
     * 邀请注册
     */
    protected function getClientRegisterUrlAttr()
    {
        $inviteCode = $this->getAttr('user_invite_code');
        //邀请码不为空的时候
        if (! empty($inviteCode)) {
            return 'http://'. env('CLIENT_URL') . '/register/'.$inviteCode;
        }

        return '';
    }
}
