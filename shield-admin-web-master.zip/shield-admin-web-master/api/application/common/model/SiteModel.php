<?php

namespace app\common\model;

use app\index\model\BaseModel;

/**
 * Class SiteModel 网站防护
 *
 * @package app\common\model
 * @author Teddy Sun <sgsheg@163.com>
 */
class SiteModel extends BaseModel
{
    protected $esIndex = 'user_app';

    protected $esType = 'type';

    ///------------------------- 域名类型 -------------------------------

    const USER_APP_TYPE_NONE   = 0;   // 未接入
    const USER_APP_TYPE_SINGLE = 1;   // 独享型
    const USER_APP_TYPE_SHARED = 2;   // 共享型
    const USER_APP_TYPE_PORT   = 3;   // 应用型
    // 冗余常量
    const DOMAIN_TYPE_NONE     = 0;   // 未接入
    const DOMAIN_TYPE_SINGLE   = 1;   // 独享型
    const DOMAIN_TYPE_SHARED   = 2;   // 共享型
    const DOMAIN_TYPE_PORT     = 3;   // 非网站类型
    //------------------------- 域名状态 -------------------------------

    const DOMAIN_STATUS_CREATED    = 0;   // 用户已提交，待审核
    const DOMAIN_STATUS_APPROVED   = 1;   // 已审核，待接入
    const DOMAIN_STATUS_LINKING    = 2;   // 正在接入
    const DOMAIN_STATUS_LINKED     = 3;   // 已接入，未修改DNS解析
    const DOMAIN_STATUS_NORMAL     = 4;   // 正常
    const DOMAIN_STATUS_LINK_ERR   = 5;   // 接入错误
    const DOMAIN_STATUS_DELETING   = 6;   // 正在删除
    const DOMAIN_STATUS_DELETE_ERR = 7;   // 删除异常
    //------------------------- Port 状态 -------------------------------

    const PORT_STATUS_LINING     = 1;   // 接入中
    const PORT_STATUS_NORMAL     = 2;   // 正常
    const PORT_STATUS_LINK_ERR   = 3;   // 接入失败
    const PORT_STATUS_DELETE_ERR = 4;   // 删除失败

    //------------------------- Port 状态 -------------------------------

    //------------------------- 域名前缀 -------------------------------

    const DOMAIN_PREFIX_HD = 'hdverify';

    //------------------------- 域名前缀 -------------------------------

    const DOMAIN_CNAME_TAIL = '.hd.vedasec.cn';

    const DOMAIN_DYNAMIC_TAIL = '-dynamic';
}
