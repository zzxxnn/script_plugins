<?php

namespace app\common\model;

use app\index\model\BaseModel;

/**
 * Class SupportModel 销售支持|技术支持
 *
 * @package app\common\model
 * @author Teddy Sun <sgsheg@163.com>
 */
class SupportModel extends BaseModel
{
    protected $esIndex = 'user_support';

    protected $esType = 'type';

    // 支持类型
    const supportType = [
        1 => '销售支持',
        2 => '技术支持',
    ];
    // 冗余字段status
    const supportStatus = [
        1 => '正常',
        2 => '不正常'
    ];
}
