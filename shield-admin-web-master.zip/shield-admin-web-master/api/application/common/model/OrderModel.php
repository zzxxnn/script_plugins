<?php

namespace app\common\model;

use app\index\model\BaseModel;

/**
 * Class OrderModel 订单模型
 *
 * @package app\common\model
 * @author Teddy Sun <sgsheg@163.com>
 */
class OrderModel extends BaseModel
{
    protected $esIndex = 'user_order';

    protected $esType = 'type';

    //订单状态
    const ORDER_STATUS_CREATED = 0;
    const ORDER_STATUS_PAID    = 1;
    const ORDER_STATUS_TRASHED = 2;

    # 状态组合
    const statusArray = [
        self::ORDER_STATUS_CREATED => '未支付',
        self::ORDER_STATUS_PAID    => '已支付',
        self::ORDER_STATUS_TRASHED => '已作废',
    ];

    //订单类型
    const ORDER_TYPE_RECHARGE = 1;
    const ORDER_TYPE_PAID     = 2;
    const ORDER_TYPE_RENEWAL  = 3;
    const ORDER_TYPE_UPGRADE  = 4;

    # 类型组合
    const typeArray = [
        self::ORDER_TYPE_RECHARGE => '充值',
        self::ORDER_TYPE_PAID     => '消费',
        self::ORDER_TYPE_RENEWAL  => '续费',
        self::ORDER_TYPE_UPGRADE  => '升级'
    ];

    //支付方式
    const ORDER_PAY_TYPE_ALIPAY     = 1; // 支付宝支付
    const ORDER_PAY_TYPE_WX         = 2; // 微信支付
    const ORDER_PAY_TYPE_REMAINNING = 3; // 余额支付

    const ORDER_HD = 1;
}
