<?php

namespace app\common\model;

use app\index\model\BaseModel;

/**
 * Class SystemLogModel 系统日志表
 *
 * @package app\common\model
 * @author Teddy Sun <sgsheg@163.com>
 */
class SystemLogModel extends BaseModel
{
    protected $table = 'system_logs';

    protected $autoWriteTimestamp = 'datetime';

    protected $resultSetType = 'collection';

    public function getCreateTimeAttr($time)
    {
        return $time;
    }

    public function getUpdateTimeAttr($time)
    {
        return $time;
    }
}
