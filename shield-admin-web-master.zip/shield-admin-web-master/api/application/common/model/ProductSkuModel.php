<?php
/**
 * Created by PhpStorm.
 * User: 叶肖肖
 * Date: 2018/07/06
 * Time: 13:59
 */

namespace app\common\model;


use app\client\model\BaseModel;

class ProductSkuModel extends BaseModel
{
    protected $esIndex = 'product_skus';

    protected $esType = 'type';
}