<?php
/**
 * Created by PhpStorm.
 * User: 叶肖肖
 * Date: 2018/07/06
 * Time: 13:59
 */

namespace app\common\model;

use app\client\model\BaseModel;

class ProductModel extends BaseModel
{

    protected $esIndex = 'products';

    protected $esType = 'type';

    //------------------------- Product 状态 -------------------------------

    const PRODUCT_ON_SALE = 1; // 上架
    const PRODUCT_OFF_SALE = 2; // 下架

    //------------------------- Product 属性类型 -------------------------------

    const PRODUCT_ATTRIBUTE_TYPE_DISCRETE = '离散属性';
    const PRODUCT_ATTRIBUTE_TYPE_DISCRETE_CHARGE = '离散计费属性';
    const PRODUCT_ATTRIBUTE_TYPE_AFTER_USE_CHARGE = '用后计费属性';
    const PRODUCT_ATTRIBUTE_TYPE_CONTINUOUS_CHARGE = '连续计费属性';
    const PRODUCT_ATTRIBUTE_TYPE_RATIO_CHARGE = '倍率计费属性';

}