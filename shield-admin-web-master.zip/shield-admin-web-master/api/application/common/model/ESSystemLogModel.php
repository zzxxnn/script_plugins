<?php

namespace app\common\model;

use app\index\model\BaseModel;

class ESSystemLogModel extends BaseModel
{
    protected $esIndex = 'system-log-';

    protected $esType = 'type';

    //------------------------- 日志属性 -------------------------------
    const ES_SYSTEM_LOG_STATUS_INFO = 'info';
    const ES_SYSTEM_LOG_STATUS_NOTICE = 'notice';
    const ES_SYSTEM_LOG_STATUS_ERROR = 'error';

    //------------------------- 日志类型 -------------------------------
    const ES_SYSTEM_LOG_TYPE_CREATE = 'create';
    const ES_SYSTEM_LOG_TYPE_DELETE = 'delete';
    const ES_SYSTEM_LOG_TYPE_UPDATE = 'update';
    const ES_SYSTEM_LOG_TYPE_SELECT = 'select';

    const ES_SYSTEM_LOG_TYPE_ARRAY = [
        self::ES_SYSTEM_LOG_TYPE_CREATE => '增加',
        self::ES_SYSTEM_LOG_TYPE_DELETE => '删除',
        self::ES_SYSTEM_LOG_TYPE_UPDATE => '修改',
        self::ES_SYSTEM_LOG_TYPE_SELECT => '查询'
    ];

    //------------------------- 日志类型 -------------------------------
    const ES_SYSTEM_LOG_SYSTEM_CLIENT = 'client';
    const ES_SYSTEM_LOG_SYSTEM_INDEX = 'index';

    const ES_SYSTEM_LOG_SYSTEM_ARRAY = [
        self::ES_SYSTEM_LOG_SYSTEM_CLIENT => '用户系统',
        self::ES_SYSTEM_LOG_SYSTEM_INDEX => '管理系统',
    ];


    //------------------------- 日志前缀 -------------------------------
    const ES_SYSTEM_LOG_PREFIX_HD = 'sl';

    //------------------------- 日志操作类型 -------------------------------
    const ES_SYSTEM_LOG_OPERATE_TYPE_RECHARGE = 'recharge';

    public function setESIndex($esIndex)
    {
        $this->esIndex .= $esIndex;
    }
}