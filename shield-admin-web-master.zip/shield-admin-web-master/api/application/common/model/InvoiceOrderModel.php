<?php

namespace app\common\model;

use think\Model;

class InvoiceOrderModel extends Model
{

    protected $table = 'invoice_orders';

    protected $resultSetType = 'collection';

    protected $autoWriteTimestamp = 'datetime';
}
