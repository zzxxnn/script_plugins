<?php

namespace app\common\model;

use app\common\traits\BaseModel;
use think\Model;

class UserModel extends Model
{
    use BaseModel;

    protected $table = 'users';

    protected $resultSetType = 'collection';

    protected $autoWriteTimestamp = 'datetime';

    protected $hidden = [
        'password',
        'update_time'
    ];

    const ADMIN_ROLE = 0;
    const USER_ROLE  = 1;

    //冗余角色名称
    protected static $RoleArray = [
        0 => '管理员',
        1 => '普通用户'
    ];

    //对status字段进行类型处理
    protected $type = [
        'id'                   => 'integer',
        'agent_id'             => 'integer',
        'email_verify_status'  => 'integer',
        'mobile_verify_status' => 'integer',
        'id_verify_status'     => 'integer',
    ];

    const SAFE_EMAIL_STATUS_UNVERIFIED = 0;
    const SAFE_EMAIL_STATUS_VERIFIED = 1;

    const SAFE_PHONE_STATUS_UNVERIFIED = 0;
    const SAFE_PHONE_STATUS_VERIFIED = 1;

    const USER_REAL_NAME_UNVERIFIED = 0;
    const USER_REAL_NAME_VERIFIED = 1;

    protected $append = ['agent_name', 'role_name', 'img_url'];

    public function getCreateTimeAttr($time)
    {
        return $time;
    }

    public function getUpdateTimeAttr($time)
    {
        return $time;
    }

    /**
     * 用户属于管理商
     *
     * @return \think\model\relation\BelongsTo
     */
    public function agent()
    {
        return $this->belongsTo('UserModel', 'agent_id', 'id');
        //return $this->belongsTo('AgentModel', 'agent_id');
    }

    /**
     * 用户管理多个订单
     *
     * @return \think\model\relation\HasMany
     */
    //public function orders()
    //{
    //    return $this->hasMany('Order', 'user_id');
    //}

    /**
     * 获取代理商模型
     *
     * @return string
     */
    public function getAgentNameAttr()
    {
        return $this->agent->user_email ?? '';
    }

    /**
     * 用户类型
     *
     * @return mixed|string
     */
    public function getRoleNameAttr()
    {
        return self::$RoleArray[$this->getAttr('role')] ?? '未知';
    }

    public function getImgUrlAttr()
    {
        $request = \think\Request::instance();

        return $request->domain().'/'.$this->getAttr('avatar');
    }
}
