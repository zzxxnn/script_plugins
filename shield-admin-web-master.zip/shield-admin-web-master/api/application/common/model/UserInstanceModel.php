<?php

namespace app\common\model;

use app\index\model\BaseModel;

/**
 * 用户实例
 *
 * Class UserInstanceModel
 *
 * @package app\common\model
 */
class UserInstanceModel extends BaseModel
{
    protected $esIndex = 'user_instance';

    protected $esType = 'type';

    #实例状态
    const STATUS_CREATED         = 0;
    const STATUS_ACTIVATED       = 1;
    const STATUS_OVERDUE         = 2;
    const DDOS_STATUS_DELETE_ERR = 4;
    #实例状态
    const statusArray = [
        self::STATUS_CREATED         => '未激活',
        self::STATUS_ACTIVATED       => '已激活',
        self::STATUS_OVERDUE         => '已过期',
        self::DDOS_STATUS_DELETE_ERR => '删除失败',
    ];
    #实例类型
    const INSTANCE_TYPE_SHARED = 1;
    const INSTANCE_TYPE_SINGLE = 2;
    const INSTANCE_TYPE_PORT   = 3;
    #实例类型
    const typeArray =[
        self::INSTANCE_TYPE_SHARED => '共享型',
        self::INSTANCE_TYPE_SINGLE => '独享型',
        self::INSTANCE_TYPE_PORT   => '应用型',
    ];
    #实例线路
    // 海外线路
    const INSTANCE_LINE_OVERSEA = 0;
    // 电信线路
    const INSTANCE_LINE_DX = 1;
    // 联通线路
    const INSTANCE_LINE_LT = 2;
    // 电信/联通 双线
    const INSTANCE_LINE_DX_LT = 3;
    // 移动线路
    const INSTANCE_LINE_YD = 4;
    // 电信/移动 双线
    const INSTANCE_LINE_DX_YD = 5;
    // 移动/联通 双线
    const INSTANCE_LINE_YD_LT = 6;
    // 移动/联通/电信 三线
    const INSTANCE_LINE_YD_LT_DX = 7;
    // BGP 线路
    const INSTANCE_LINE_BGP = 8;
    // 电信/联通/BGP 三线
    const INSTANCE_LINE_DX_LT_BGP = 11;

    public static $instanceLines = [
        self::INSTANCE_LINE_OVERSEA   => '海外',
        self::INSTANCE_LINE_DX        => '电信',
        self::INSTANCE_LINE_LT        => '联通',
        self::INSTANCE_LINE_DX_LT     => '电信、联通',
        self::INSTANCE_LINE_YD        => '移动',
        self::INSTANCE_LINE_DX_YD     => '电信、移动',
        self::INSTANCE_LINE_YD_LT     => '移动、联通',
        self::INSTANCE_LINE_YD_LT_DX  => '移动、联通和电信',
        self::INSTANCE_LINE_BGP       => 'BGP',
        self::INSTANCE_LINE_DX_LT_BGP => '电信、联通和BGP',
    ];

    //不同线路类型实例对应的IP线路个数
    public static $instanceLineCounts = [
        '0' => 1,  //海外
        '1' => 1,  //电信
        '2' => 1,  //联通
        '3' => 2,  //电信、联通
        '4' => 1,  //移动
        '5' => 2,  //电信、移动
        '6' => 2,  //联通、移动
        '7' => 3,  //电信、联通、移动
        '8' => 1,  //BGP
        '11'=> 3   //电信、联通、BGP
    ];

    //------------------------- 用户实例可选线路 -------------------------------

    //------------------------- 用户实例可选地域 -------------------------------

    const INSTANCE_AREA_BEIJING = 11; // 北京
    const INSTANCE_AREA_TIANJIN = 12; //天津
    const INSTANCE_AREA_HEBEI   = 13; //河北

    public static $instanceAreas = [
        '11' => '北京',
        '12' => '天津',
        '13' => '河北',
        '14' => '山西',
        '15' => '内蒙古',
        '21' => '辽宁',
        '22' => '吉林',
        '23' => '黑龙江',
        '31' => '上海',
        '32' => '江苏',
        '33' => '浙江',
        '34' => '安徽',
        '35' => '福建',
        '36' => '江西',
        '37' => '山东',
        '41' => '河南',
        '42' => '湖北',
        '43' => '湖南',
        '44' => '广东',
        '45' => '广西',
        '46' => '海南',
        '50' => '重庆',
        '51' => '四川',
        '52' => '贵州',
        '53' => '云南',
        '54' => '西藏',
        '61' => '陕西',
        '62' => '甘肃',
        '63' => '青海',
        '64' => '宁夏',
        '65' => '新疆',
        '71' => '台湾',
        '81' => '香港',
        '91' => '澳门'
    ];
}