<?php

namespace app\common\model;

use think\Model;
use app\common\traits\BaseModel;

class InvoiceModel extends Model
{

    use BaseModel;

    protected $table = 'invoices';

    protected $resultSetType = 'collection';

    protected $autoWriteTimestamp = 'datetime';

    // 发票类型
    const INVOICE_TYPE_NORMAL = 0;
    const INVOICE_TYPE_PRIVATE = 1;

    // 审批状态
    const INVOICE_STATUS_READY = 0;   // 待提交
    const INVOICE_STATUS_SUBMITTED  = 1;  // 已提交
    const INVOICE_STATUS_REVIEWING = 2; // 审批通过
    const INVOICE_STATUS_TRACKING = 3; // 快递中
    const INVOICE_STATUS_FINISH = 4;  // 已完成(收到发票)
    const INVOICE_STATUS_REJECT = 5;  // 已拒绝

    // C端订单列表使用开票状态
    const INVOICE_STATUS_CLIENT_ARR = [
        self::INVOICE_STATUS_READY     => '开票',
        self::INVOICE_STATUS_SUBMITTED => '开票中',
        self::INVOICE_STATUS_REVIEWING => '开票中',
        self::INVOICE_STATUS_TRACKING  => '开票中',
        self::INVOICE_STATUS_FINISH    => '已开票',
        self::INVOICE_STATUS_REJECT    => '已拒绝',
    ];
    // B端订单列表使用开票状态
    const INVOICE_STATUS_INDEX_ARR = [
        self::INVOICE_STATUS_READY     => '待申请',
        self::INVOICE_STATUS_SUBMITTED => '待审批',
        self::INVOICE_STATUS_REVIEWING => '已通过',
        self::INVOICE_STATUS_TRACKING  => '快递中',
        self::INVOICE_STATUS_FINISH    => '已完成',
        self::INVOICE_STATUS_REJECT    => '已拒绝',
    ];

    // 发票内容
    const INVOICE_CONTENT = '技术服务费';

    // 发票申请号前缀
    const INVOICE_UUID_PREFIX = 1;

    public function orders()
    {
        //return $this->hasMany(InvoiceOrderModel::class);
        return $this->hasMany('InvoiceOrderModel', 'invoice_id',
            'id')->field('id, invoice_id, order_id, order_type, content, fee, final_fee');
    }

    public function logs()
    {
        return $this->hasMany('InvoiceLogModel', 'invoice_id', 'id')->field('id, status, create_time');
    }
}
