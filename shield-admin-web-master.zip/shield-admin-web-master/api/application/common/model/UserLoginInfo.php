<?php

namespace app\common\model;

use app\common\traits\BaseModel;
use think\Model;

/**
 * Class UserLoginInfo 登录日志记录表
 *
 * @package app\common\model
 * @author Teddy Sun <sgsheg@163.com>
 */
class UserLoginInfo extends Model
{
    use BaseModel;

    protected $table = 'user_login_info';

    protected $resultSetType = 'collection';

    public function getLoginTimeAttr($time)
    {
        return $time;
    }

    // 常量: 密码错误0|密码正确2
    const PASSWORD_RIGHT = 0;
    const PASSWORD_WRONG = 2;
}
