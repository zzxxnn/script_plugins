<?php

namespace app\common\repository;

use app\client\service\Auth;
use app\common\model\InvoiceLogModel;
use app\common\model\InvoiceModel;
use app\common\model\InvoiceOrderModel;
use app\common\model\OrderModel;
use think\db\Query;

class InvoiceRepository extends BaseRepository
{

    protected $invoice_log_model = null;

    protected $invoice_order_model = null;

    public function __construct()
    {
        $this->model = new InvoiceModel();

        $this->invoice_log_model = new InvoiceLogModel();

        $this->invoice_order_model = new InvoiceOrderModel();

    }

    /**
     * 申请开票
     *
     * @param $data
     * @param $current_system
     *
     * @return InvoiceModel|bool
     * @throws \app\common\exception\RepositoryException
     */
    public function save($data, $current_system)
    {
        $invoice = $this->model->create(array_merge($data['invoice'],
            [ 'system' => $current_system, 'status' => InvoiceModel::INVOICE_STATUS_SUBMITTED ]));

        if ($invoice) {
            $invoice_log = $this->invoice_log_model->create([
                'invoice_id' => $invoice->id,
                'status'     => InvoiceModel::INVOICE_STATUS_SUBMITTED
            ]);
            if ($invoice_log) {
                foreach ($data['orders'] as $order) {
                    $save_data = [
                        "user_id"        => $data['invoice']['user_id'],
                        "user_email"     => $data['invoice']['user_email'],
                        'invoice_id'     => $invoice->id,
                        'invoice_uuid'   => $invoice->uuid,
                        'invoice_log_id' => $invoice_log->id,
                        'status'         => InvoiceModel::INVOICE_STATUS_SUBMITTED,
                        'system'         => $current_system,
                    ];
                    $this->invoice_order_model->create(array_merge($order, $save_data));

                    $data['invoice_status'] = InvoiceModel::INVOICE_STATUS_SUBMITTED;
                    ( new OrderRepository() )->update($data, $order['order_id']);
                }

                return $invoice;
            }

        }

        return false;
    }

    /**
     * 开票详情
     *
     * @param $id
     *
     * @return array|bool|false|\PDOStatement|string|\think\Model
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function getDetail($id)
    {
        $invoice = InvoiceModel::where('id', $id)->find();
        if ( ! $invoice) {
            return false;
        }
        if ($invoice->logs && $invoice->orders) {
            $orders = [];
            $amount = 0;
            foreach ($invoice->orders as $order) {
                $order['order_type'] = OrderModel::typeArray[$order['order_type']] ?? '未知';
                $orders[]            = $order;
                if ( ! empty($order->final_fee)) {
                    $amount += $order->final_fee;
                } elseif ( ! empty($order->fee)) {
                    $amount += $order->fee;
                }
            }
            $invoice->orders = $orders;

            return array_merge($invoice->toArray(), [ 'order_total_amount' => $amount ]);
        }

        return false;
    }

    /**
     * 开票列表
     *
     * @param $from
     * @param $size
     * @param $must
     *
     * @return mixed
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function getList($from, $size, $must)
    {
        $query         = InvoiceModel::join('invoice_orders',
            'invoice_orders.invoice_id = invoices.id')->order('invoices.create_time', 'desc')->field([ 'invoices.*' ])->where($must);
        $total_query   = clone $query;
        $invoice_list  = $query->page($from.','.$size)->select();
        $invoice_total = $total_query->count();
        $result        = [];
        foreach ($invoice_list as $value) {
            $amount = 0;
            $orders = InvoiceOrderModel::where('invoice_id', $value->id)->select();
            if ($orders) {
                foreach ($orders as $order) {
                    if ( ! empty($order->final_fee)) {
                        $amount += $order->final_fee;
                    } elseif ( ! empty($order->fee)) {
                        $amount += $order->fee;
                    }
                }
            }
            $result[] = [
                'id'          => $value->id,
                'uuid'        => $value->uuid,
                'user_email'  => $value->user_email,
                'status'      => $value->status,
                'create_time' => $value->create_time,
                'amount'      => $amount
            ];
        }
        $invoices = [
            'list'  => $result,
            'total' => $invoice_total
        ];

        return $invoices;
    }

    /**
     * 审批发票通过
     *
     * @param $data
     *
     * @return bool
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \app\common\exception\RepositoryException
     */
    public function agree($data)
    {
        $invoice = InvoiceModel::find($data['id']);
        if ( ! $invoice) {
            return false;
        }
        $invoice->status = InvoiceModel::INVOICE_STATUS_REVIEWING;
        if ($invoice->save()) {

            $this->changeOrdersAndLogsStatus($invoice, InvoiceModel::INVOICE_STATUS_REVIEWING);

            return true;
        }

        return false;
    }

    /**
     * 审批发票快递
     *
     * @param $data
     *
     * @return bool
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \app\common\exception\RepositoryException
     */
    public function track($data)
    {
        $invoice = InvoiceModel::find($data['id']);
        if ( ! $invoice) {
            return false;
        }
        $invoice->track_ship_id = $data['track_ship_id'];
        $invoice->track_company = $data['track_company'];
        $invoice->ivc_numbers   = $data['ivc_numbers'];
        $invoice->status        = InvoiceModel::INVOICE_STATUS_TRACKING;
        if ($invoice->save()) {

            $this->changeOrdersAndLogsStatus($invoice, InvoiceModel::INVOICE_STATUS_TRACKING);

            return true;
        }

        return false;
    }

    /**
     * 审批发票 收到发票
     *
     * @param $data
     *
     * @return bool
     * @throws \app\common\exception\RepositoryException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function finish($data)
    {
        $invoice = InvoiceModel::find($data['id']);
        if ( ! $invoice) {
            return false;
        }
        $invoice->status = InvoiceModel::INVOICE_STATUS_FINISH;
        if ($invoice->save()) {

            $this->changeOrdersAndLogsStatus($invoice, InvoiceModel::INVOICE_STATUS_FINISH);

            return true;
        }

        return false;
    }

    /**
     * 审批发票拒绝
     *
     * @param $data
     *
     * @return bool
     * @throws \app\common\exception\RepositoryException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function reject($data)
    {
        $invoice = InvoiceModel::find($data['id']);
        if ( ! $invoice) {
            return false;
        }
        $invoice->description = $data['description'];
        $invoice->status      = InvoiceModel::INVOICE_STATUS_REJECT;
        if ($invoice->save()) {

            $this->changeOrdersAndLogsStatus($invoice, InvoiceModel::INVOICE_STATUS_REJECT);

            return true;
        }

        return false;
    }

    /**
     * @param $invoice
     * @param $status
     *
     * @return bool
     * @throws \app\common\exception\RepositoryException
     */
    private function changeOrdersAndLogsStatus($invoice, $status)
    {
        foreach ($invoice->orders as $order) {
            $order->status = $status;
            $order->save();

            $data['invoice_status'] = $status;
            ( new OrderRepository() )->update($data, $order->order_id);
        }
        $result = $this->invoice_log_model->create([
            'invoice_id' => $invoice->id,
            'status'     => $status
        ]);

        return true;
    }
}
