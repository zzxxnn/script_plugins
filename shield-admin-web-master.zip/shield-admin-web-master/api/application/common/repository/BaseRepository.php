<?php

namespace app\common\repository;

/**
 *
 * Class BaseRepository
 * @package app\common
 */
abstract class BaseRepository
{
    protected $model = null;
}