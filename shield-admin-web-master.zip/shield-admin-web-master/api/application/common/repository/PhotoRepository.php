<?php

namespace app\common\repository;

use app\agent\model\AgentPhotoModel;
use app\index\model\ApprovePhotoModel;

/**
 * Class PhotoRepository 图片
 *
 */
class PhotoRepository extends BaseRepository
{
    //public function __construct()
    //{
    //    $this->approve_photo_model = new ApprovePhotoModel();
    //}

    /**
     * 上传图片
     *
     * @param $upload_type
     * @param $type
     * @param $path
     *
     * @return string
     */
    public function uploadPhoto($path, $upload_type = null, $type = null)
    {
        $photo = ajax_upload_avatar($path);

        $avatarThumb = '';
        //生成缩略图
        if (!empty($upload_type)) {
            if ($upload_type == 'real_name_auth') {
                if (in_array($type, [AgentPhotoModel::PHOTO_TYPE_ID_CARD_FRONT, AgentPhotoModel::PHOTO_TYPE_ID_CARD_BACK, AgentPhotoModel::PHOTO_TYPE_ID_CARD_WITH_PERSON])) {
                    $avatarThumb = crop_image($photo, 242, 146);
                }elseif ($type == AgentPhotoModel::PHOTO_TYPE_BUSINESS_LICENSE ) {
                    $avatarThumb = crop_image($photo, 405, 578);
                }
            }
        }

        return Finalsuccess([ 'data' => $avatarThumb ? $avatarThumb : $photo ]);
    }


}