<?php

namespace app\common\repository;

use app\common\model\UserModel;
use app\client\service\Auth;
use app\common\service\LogService;
use Carbon\Carbon;

/**
 * Class UserRepository B和C端登录
 *
 * @package app\common\repository
 * @author Teddy Sun <sgsheg@163.com>
 */
class UserRepository
{
    protected $user;

    public function __construct()
    {
        $this->user = new UserModel();
    }

    /**
     * 用户通过邮箱登录 默认为C端用户登录,role为0为管理员登录1为普通用户
     *
     * @param $user
     * @return int
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function doEmail($user, $role = 1)
    {
        $result = $this->user->where(['email' => $user['email'], 'role' => $role])->find();

        if (! empty($result)) {
            $comparePasswordResult = password_verify($user['password'], $result['password']);
            if ($comparePasswordResult) {

                $data = [
                    'last_login_time' => Carbon::now()->toDateTimeString(),
                    'last_login_ip'   => get_client_ip(0, true),
                ];
                $this->user->where('id', $result['id'])->update($data);

                return 0;
            }
                //插入记录到user_login_time

            return LogService::writeLoginError($result['id'], 'app\common\model\UserModel');
        }

        return 2;
    }

    /**
     * 使用username登录平台
     *
     * @param $user
     * @param int $role
     * @return int
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function doUserName($user, $role = 0)
    {
        $result = $this->user->where('username', $user['username'])->where('role', $role)->find();

        if (! empty($result)) {
            $comparePasswordResult = password_verify($user['password'], $result['password']);
            if ($comparePasswordResult) {

                $data = [
                    'last_login_time' => Carbon::now()->toDateTimeString(),
                    'last_login_ip'   => get_client_ip(0, true),
                ];
                $this->user->where('id', $result['id'])->update($data);

                return 0;
            }

            return 1;
        }

        return 2;
    }

    /**
     * 修改数据
     *
     * @param $user
     * @param null $userEmail
     * @return boolean
     */
    public function editData($user, $userEmail = null)
    {
        !$userEmail && $userEmail = Auth::id();

        //允许更新字段[头像\安全邮箱\手机号\验证状态]
        $field = 'real_name,id_number,id_verify_status,avatar,safe_email,email_verify_status,mobile,mobile_verify_status';

        $result = $this->user->allowField($field)->save($user, ['email' => $userEmail]);
        if ($result) {
            //$userInfo = $this->where('email', $userEmail)->find();
            //todo:更新session
        }

        return $result !== false;
    }

    /**
     * 获取用户头像
     */
    public function getAvatar()
    {
        return $this->user->avatar;
    }

    /**
     * 根据传入的条件进行查询 无结果为1: 有结果为0
     */
    public function findExist($condition = [])
    {
        $result = $this->user->where($condition)->find();

        if (empty($result)) {
            return 1;
        }

        return 0;
    }

    public function find($condition = [])
    {
        return $this->user->where($condition)->find();
    }

    /**
     * 插入新的数据
     *
     * @param $data
     * @return false|int
     */
    public function insertData($data)
    {
        return $this->user->save($data);
    }
}