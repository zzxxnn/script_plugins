<?php

namespace app\common\repository;

use app\index\model\UserInstanceModel;
use app\index\repository\Repository;

/**
 * Class InstanceRepository
 *
 * @package app\common\repository
 * @author Teddy Sun <sgsheg@163.com>
 */
class InstanceRepository extends Repository
{
    public function model()
    {
        return UserInstanceModel::class;
    }
}