<?php

namespace app\common\repository;

use app\common\model\ESSystemLogModel;

class SystemLogRepository extends BaseRepository
{

    public function __construct()
    {
        $this->model = new ESSystemLogModel();
        //$this->model->setESIndex(date('Y-m-d'));
    }

    /**
     * 获取日志列表
     * @param array $filter
     * @param int   $from
     * @param null  $size
     *
     * @return array
     * @throws \Exception
     */
    public function getList($filter = [], $from = 0, $size = null)
    {
        $this->model->setESIndex('*');

        return $this->model->esSearch($filter, $from, $size);
    }

    /**
     * 获取日志数量
     *
     * @param array $filter
     * @return null|string
     * @throws \Exception
     */
    public function count($filter = [])
    {
        return $this->model->esCountDocs($filter);
    }
}
