<?php

namespace app\common\repository;

use app\common\model\InvoiceModel;
use app\common\model\InvoiceOrderModel;
use app\common\model\OrderModel;
use app\common\service\MailService;
use app\common\service\NotifierService;
use app\index\repository\Repository;
use app\index\validate\OrderValidate;

/**
 * Class OrderRepository
 *
 * @package app\common\repository
 * @author  Teddy Sun <sgsheg@163.com>
 */
class OrderRepository extends Repository
{

    public function model()
    {
        return OrderModel::class;
    }

    /**
     * 获取订单列表
     *
     * @param array $filter
     * @param int   $from
     * @param null  $size
     *
     * @return array
     * @throws \Exception
     */
    public function getOrderList($filter = [], $from = 0, $size = null)
    {
        $result = [];
        $orders = $this->makeModel()->esSearch($filter, $from, $size);
        foreach ($orders as $key => &$order) {
            $invoice    = InvoiceOrderModel::where('order_id', $order['id'])->find();
            $invoice_id = '';
            if ($invoice) {
                $invoice_id = $invoice->invoice_id;
            }
            $invoice_status         = '';
            $invoice_display_status = '';
            if ($order['status'] == OrderModel::ORDER_STATUS_PAID) {
                $invoice_status         = '开票';
                $invoice_display_status = '待申请';
                if (isset($order['invoice_status']) && ! empty($invoice_id)) {
                    $invoice_status         = InvoiceModel::INVOICE_STATUS_CLIENT_ARR[$order['invoice_status']];
                    $invoice_display_status = InvoiceModel::INVOICE_STATUS_INDEX_ARR[$order['invoice_status']];
                }
            }
            $result[] = [
                'uid'                    => $order['uid'],
                'oid'                    => $order['id'],
                'type'                   => $order['type'],
                'type_attr'              => OrderModel::typeArray[$order['type']] ?? '未知',
                'create_time'            => format_time(strtotime($order['create_time'])),
                'status'                 => $order['status'],
                'status_attr'            => OrderModel::statusArray[$order['status']] ?? '未知',
                'fee'                    => $order['fee'],
                'final_fee'              => $this->getFinalFee($order),
                'invoice_id'             => $invoice_id,
                'invoice_status'         => $invoice_status,
                'invoice_display_status' => $invoice_display_status,
                'invoice_content'        => InvoiceModel::INVOICE_CONTENT
            ];
        }

        return $result;
    }

    public function getInvoiceOrderDetail($order_id)
    {
        $order = $this->makeModel()->esGetById($order_id);
        if ( ! $order) {
            return false;
        }
        $invoice    = InvoiceOrderModel::where('order_id', $order_id)->find();
        $invoice_id = '';
        if ($invoice) {
            $invoice_id = $invoice->id;
        }
        $invoice_status = '';
        if ($order['status'] == OrderModel::ORDER_STATUS_PAID) {
            $invoice_status = '开票';
            if (isset($order['invoice_status']) && ! empty($invoice_id)) {
                $invoice_status = InvoiceModel::INVOICE_STATUS_CLIENT_ARR[$order['invoice_status']];
            }
        }
        $result = [
            'uid'             => $order['uid'],
            'oid'             => $order_id,
            'type'            => $order['type'],
            'type_attr'       => OrderModel::typeArray[$order['type']] ?? '未知',
            'create_time'     => format_time(strtotime($order['create_time'])),
            'status'          => $order['status'],
            'status_attr'     => OrderModel::statusArray[$order['status']] ?? '未知',
            'fee'             => $order['fee'],
            'final_fee'       => $this->getFinalFee($order),
            'invoice_id'      => $invoice_id,
            'invoice_status'  => $invoice_status,
            'invoice_content' => InvoiceModel::INVOICE_CONTENT
        ];

        return $result;
    }

    /**
     * 获取订单详情
     *
     * @param integer $orderId 订单id
     *
     * @return mixed
     * @throws \app\common\exception\RepositoryException
     */
    public function getOrderDetail($orderId)
    {
        $order = $this->makeModel()->esGetById($orderId);
        if ( ! $order) {
            return false;
        }

        $order['order_id']    = $orderId + 0;
        $order['final_fee']   = $this->getFinalFee($order);
        $order['create_time'] = format_time(strtotime($order['create_time']));
        if (isset($order['start_date'])) {
            $order['start_date'] = format_time(strtotime($order['start_date']));
        }
        if (isset($order['end_date'])) {
            $order['end_date'] = format_time(strtotime($order['end_date']));
        }
        if (isset($order['product_sku_id'])) {
            $order['product_sku_id'] += 0;
        }
        if (isset($order['discount'])) {
            $order['discount'] += 0;
        }
        //fix: 订单中竟然包含password
        if (isset($order['password'])) {
            unset($order['password']);
        }
        if (isset($order['product_id'])) {
            $order['product_id'] += 0;
        }

        if (isset($order['remind_time'])) {
            $order['remind_time'] = format_time(strtotime($order['remind_time']));
        }

        ! empty($order['pay_time']) && $order['pay_time'] = format_time(strtotime($order['pay_time']));

        ! empty($order['type']) && $order['type_attr'] = OrderModel::typeArray[$order['type']] ?? '未知';
        ! empty($order['status']) && $order['status_attr'] = OrderModel::statusArray[$order['status']] ?? '未知';

        return $order;
    }

    /**
     * @param $order
     *
     * @return mixed
     */
    private function getFinalFee($order)
    {
        if (isset($order['final_fee'])) {
            $finalFee = $order['final_fee'];
        } else {
            $finalFee = $order['fee'];
        }

        return $finalFee + 0;
    }

    /**
     * 获取用户消费总额（B端使用）
     *
     * @param integer $id 用户id
     *
     * @return int
     * @throws \app\common\exception\RepositoryException
     */
    public function getUserAmountTotal($id)
    {
        $filter['query']['bool']['must'][] = [ 'term' => [ 'uid.keyword' => $id ] ];
        $filter['aggs']['sum_fee']['sum']  = [ 'field' => 'fee' ];
        $order                             = $this->makeModel()->esAggsSearch($filter);
        if ($order) {
            return $order['aggs']['sum_fee']['value'];
        }

        return 0;
    }

    /**
     * @param $id
     *
     * @return mixed
     * @throws \app\common\exception\RepositoryException
     */
    public function getUserOrdersById($id)
    {
        $filter['query']['bool']['must']        = [
            [ 'term' => [ 'uid.keyword' => $id ] ],
            [ 'term' => [ 'status' => OrderModel::ORDER_STATUS_PAID ] ]
        ];
        $filter['sort']['last_update']['order'] = 'desc';
        $filter['from']                         = 0;
        $filter['size']                         = 5;

        return $this->makeModel()->esSearch($filter);
    }

    /**
     * @param $data
     * @param $order
     *
     * @return bool
     * @throws \Exception
     * @throws \PHPMailer\PHPMailer\Exception
     */
    public function sendMessages($data, $order, $smsTemplate, $emailTemplate)
    {
        foreach ($data as $key => $send) {
            switch ($key) {
                case 'user':
                    if ($this->checkDataAndSend($send, $order, $smsTemplate, $emailTemplate)) {
                        continue 1;
                    }
                    break;
                case 'other':
                    foreach ($send as $k => $other) {
                        if ($this->checkDataAndSend($other, $order, $smsTemplate, $emailTemplate)) {
                            continue 1;
                        }
                    }
                    break;

                case 'support':
                    if ($this->checkDataAndSend($send, $order, $smsTemplate, $emailTemplate)) {
                        continue 2;
                    }
                    break;

                case 'sale':
                    if ($this->checkDataAndSend($send, $order, $smsTemplate, $emailTemplate)) {
                        continue 2;
                    }
                    break;
                default:
                    return true;
            }
        }

        return true;
    }

    /**
     * @param        $data
     * @param        $order
     * @param string $smsTemplate
     *
     * @return bool|string
     * @throws \PHPMailer\PHPMailer\Exception
     */
    private function checkDataAndSend(
        $data,
        $order,
        $smsTemplate = NotifierService::SMS_ORDER_CHANGE,
        $emailTemplate = MailService::ORDER_CHANGE
    ) {
        $user     = [
            'email'  => isset($data['email']) ? $data['email'] : '',
            'mobile' => isset($data['mobile']) ? $data['mobile'] : '',
        ];
        $validate = new OrderValidate();

        if ( ! $validate->scene('send')->check($user)) {
            return Finalfail(REP_CODE_PARAMS_INVALID, $validate->getError());
        }

        if (isset($user['email']) && ! empty($user['email'])) {
            //send
            $result = MailService::send($user['email'], $order['order_id'], $emailTemplate);
            if ( ! $result) {
                return false;
            }
        }
        if (isset($user['mobile']) && ! empty($user['mobile'])) {
            $result = NotifierService::sendSms($user['mobile'], [ 'order' => $order['order_id'] ], $smsTemplate);
            if ( ! $result) {
                return false;
            }
        }

        return true;
    }

    /**
     * 新增充值订单
     *
     * @param $data
     *
     * @return array|bool
     * @throws \Exception
     */
    public function createRechargeOrder($data)
    {
        $order  = [
            'uid'         => $data['uid'],
            'type'        => $data['type'],
            'fee'         => $data['fee'],
            'final_fee'   => $data['fee'], //优惠后充值金额 todo:和client/OrderRepository[processOrderInfo]函数重复
            'status'      => $data['status'],
            'create_time' => gmt_withTZ(),
            'pay_time'    => null, // 支付时间,
            'detail'      => []
        ];
        $result = ( new OrderModel() )->esAdd($order, self::generateOrderId());

        if ($result['result'] == 'created') {
            return [ 'id' => $result['_id'] ];
        }

        return false;
    }

    /**
     * 生成订单号,长度
     *
     */
    private function generateOrderId()
    {
        do {
            // 标识 + （年 + 日 + 月 + 时 + 分） + 随机码
            $orderId = OrderModel::ORDER_HD.date('ymdHi').rand(100, 999);
            $result  = ( new OrderModel() )->esGetById($orderId);
        } while ($result);

        return $orderId;
    }
}
