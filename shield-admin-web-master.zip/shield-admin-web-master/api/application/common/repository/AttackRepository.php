<?php

namespace app\common\repository;

use app\index\model\AttackLogModel;
use app\index\repository\Repository;

/**
 * Class AttackRepository 攻击
 *
 * @package app\common\repository
 * @author Teddy Sun <sgsheg@163.com>
 */
class AttackRepository extends Repository
{
    public function model()
    {
        return AttackLogModel::class;
    }
}