<?php

namespace app\common\validate;

use app\client\service\Auth;
use app\common\model\InvoiceOrderModel;
use app\common\model\OrderModel;
use app\common\repository\OrderRepository;
use think\Validate;

class InvoiceValidator extends Validate
{

    protected $rule = [
        'invoice.uuid'              => 'require|number|length:4',
        'invoice.ivc_type'          => 'require|number|in:0,1',
        'invoice.ivc_title'         => 'require',
        "invoice.ivc_tax_id"        => 'require|alphaNum|max:20',
        "invoice.ivc_address"       => 'require',
        "invoice.ivc_mobile"        => 'require|number|max:20',
        "invoice.ivc_bank"          => 'require|chsAlphaNum',
        "invoice.ivc_account"       => 'require|number|max:20',
        'invoice.consignee_name'    => 'require',
        'invoice.consignee_address' => 'require',
        'invoice.consignee_mobile'  => 'require|mobile',
        'orders'                    => 'require|array|checkOrders|checkInvoice',
        'id'                        => 'require',
        'description'               => 'require',
        'track_ship_id'             => 'require',
        'track_company'             => 'require',
        'ivc_numbers'               => 'require'
    ];

    protected $message = [
        'invoice.uuid.require'              => '发票申请号不能为空',
        'invoice.uuid.number'               => '发票申请号只能为数字',
        'invoice.uuid.length'               => '发票申请号长度只能为14位',
        'invoice.ivc_type.require'          => '发票类型不能为空',
        'invoice.ivc_type.number'           => '发票类型只能数字',
        'invoice.ivc_type.in'               => '发票类型错误',
        'invoice.ivc_title.require'         => '发票抬头不能为空',
        "invoice.ivc_tax_id.require"        => '纳税人识别码不能为空',
        "invoice.ivc_tax_id.alphaNum"       => '纳税人识别码只能为字母和数字',
        "invoice.ivc_tax_id.max"            => '纳税人识别码不能超过20位',
        "invoice.ivc_address.require"       => '注册地址不能为空',
        "invoice.ivc_mobile.require"        => '注册电话不能为空',
        "invoice.ivc_mobile.number"         => '注册电话格式错误',
        "invoice.ivc_mobile.max"            => '注册电话格式错误',
        "invoice.ivc_bank.require"          => '开户银行不能为空',
        "invoice.ivc_bank.chsAlphaNum"      => '开户银行只能是汉字、字母和数字',
        "invoice.ivc_account.require"       => '银行账户不能为空',
        "invoice.ivc_account.number"        => '银行账户必须为数字',
        "invoice.ivc_account.max"           => '银行账户不能超过20位',
        'invoice.consignee_name.require'    => '收件人不能为空',
        'invoice.consignee_address.require' => '收件地址不能为空',
        'invoice.consignee_mobile.require'  => '收件人电话不能为空',
        'invoice.consignee_mobile.mobile'   => '收件人电话格式错误',
        'orders.require'                    => '未开票订单不能为空',
        'orders.array'                      => '未开票订单格式错误',
        'orders.checkOrders'                => '所选订单不存在/订单金额不正确，或所选订单并未支付',
        'orders.checkInvoice'               => '所选订单已申请发票，不能重复申请',
        'id'                                => '申请ID不能为空',
        'description.require'               => '拒绝理由不能为空',
        'track_ship_id.require'             => '快递单号不能为空',
        'track_company.require'             => '快递公司不能为空',
        'ivc_numbers.require'               => '发票号不能为空'
    ];

    protected $scene = [
        'normal_invoice'  => [
            'uuid',
            'invoice.ivc_type',
            'invoice.ivc_title',
            'invoice.consignee_name',
            'invoice.consignee_address',
            'invoice.consignee_mobile',
            'orders'
        ],
        'private_invoice' => [
            'uuid',
            'invoice.ivc_type',
            'invoice.ivc_title',
            "invoice.ivc_tax_id",
            "invoice.ivc_address",
            "invoice.ivc_mobile",
            "invoice.ivc_bank",
            "invoice.ivc_account",
            'invoice.consignee_name',
            'invoice.consignee_address',
            'invoice.consignee_mobile',
            'orders'
        ],
        'agree_invoice'   => [
            'id'
        ],
        'track_invoice'   => [
            'id',
            'track_ship_id',
            'track_company',
            'ivc_numbers'
        ],
        'finish_invoice'  => [
            'id'
        ],
        'reject_invoice'  => [
            'id',
            'description'
        ]
    ];

    protected function mobile($value)
    {
        return is_cellphone_number($value);
    }

    /**
     * @param $value
     *
     * @param $rule
     * @param $data
     *
     * @return bool
     * @throws \app\common\exception\RepositoryException
     */
    protected function checkOrders($value)
    {
        $order_ids                           = array_column($value, 'order_id');
        $filter['query']['bool']['filter'][] = [ 'terms' => [ '_id' => array_column($value, 'order_id') ] ];
        $orders                              = ( new OrderRepository() )->getOrderList($filter);
        if (count($orders) == count($order_ids)) {
            $validate = false;
            foreach ($orders as $order) {
                if ($order['status'] != OrderModel::ORDER_STATUS_PAID) {
                    break;
                }
                foreach ($value as $item) {
                    if ($order['oid'] == $item['order_id'] && $order['fee'] == $item['fee'] && $order['final_fee'] == $item['final_fee']) {
                        $validate = true;
                    }
                }
                // 无论原价还是改价后价格均与数据库中不同时，跳出循环
                if ( ! $validate) {
                    break;
                }
            }
            if ( ! $validate) {
                return false;
            }

            return true;
        }

        return false;
    }

    protected function checkInvoice($value)
    {
        $order_ids     = array_column($value, 'order_id');
        $invoice_order = InvoiceOrderModel::where("order_id", "in", $order_ids)->where('user_email',
            Auth::id())->find();
        if ($invoice_order) {
            return false;
        }

        return true;
    }
}
