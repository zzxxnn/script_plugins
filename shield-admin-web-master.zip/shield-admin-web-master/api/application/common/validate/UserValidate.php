<?php

namespace app\common\validate;

use think\Validate;

/**
 * Class UserValidate
 *
 * @package app\common\validate
 * @author Teddy Sun <sgsheg@163.com>
 */
class UserValidate extends Validate
{
    protected $rule = [
        'captcha'  => 'require',
        'username' => 'require',
        'password' => 'require|min:8|max:32',
        'code'     => 'require',
    ];

    protected $field = [

    ];

    protected $message = [
        'username.require' => '用户名不能为空',
        'password.require' => '密码不能为空',
        'password.max'     => '密码不能超过32个字符',
        'password.min'     => '密码不能小于6个字符',
        'captcha.require'  => '验证码不能为空',
        'code.require'     => '验证码不能为空',
    ];

    protected $scene = [
        'agent-login'    => ['username', 'password', 'captcha'],
        'agent-register' => ['username', 'password', 'captcha'],
        'delete'         => '',
    ];
}