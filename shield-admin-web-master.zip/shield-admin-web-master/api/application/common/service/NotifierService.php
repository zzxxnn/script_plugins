<?php

namespace app\common\service;

use extend\submail\Submail;
use think\Log;

/**
 * Class NotifierService 短信通知
 *
 * @package app\common\service
 * @author Teddy Sun <sgsheg@163.com>
 */
class NotifierService
{
    private static $submail;

    // 以下随机字符串为submail平台的ID，如需新增模板，请在https://www.mysubmail.com上进行申请
    const SMS_USER_REGISTER = 'sbkmZ3'; //用户注册
    const SMS_ORDER_CHANGE  = 'yTfRB';  //订单改价
    const SMS_ORDER_CREATED = 'RP5l64'; //订单创建
    const SMS_USER_RECHARGE = 'SfXwL3'; //用户充值
    const SMS_INSTANCE_TWO_WEEKS  = '';  //实例2周
    const SMS_INSTANCE_ONE_WEEK   = '';  //实例1周
    const SMS_INSTANCE_ONE_MONTH  = '';  //实例1月
    const SMS_INSTANCE_HALF_MONTH = '';  //实例半个月

    /**
     * 发送短信
     *
     * @param $to
     * @param array $data
     * @param string $templateId
     * @return bool
     */
    public static function sendSms($to, $data = [], $templateId)
    {
        $result  = self::getInstance()->sendSms($to, $data, $templateId);
        $success = $result['status'] ?? null;

        if ($success !== 'success') {
            Log::error('SMS Send Error, '.json_encode($result));

            return false;
        }

        return true;
    }

    private static function getInstance()
    {
        if (! self::$submail) {
            self::$submail = new Submail();
        }

        return self::$submail;
    }
}