<?php

namespace app\common\service;

use PHPMailer\PHPMailer\PHPMailer;
use think\Config;
use think\Env;

/**
 * Class MailService 邮件服务
 *
 * @package app\common\service
 * @author Teddy Sun <sgsheg@163.com>
 */
class MailService
{
    const FORGET        = 'forget';
    const SAFE_MAIL     = 'safemail';
    const ORDER_CHANGE  = 'order_change';
    const ORDER_CREATED = 'order_created';
    const USER_RECHARGE = 'user_recharge';
    const INSTANCE_TWO_WEEKS  = 'instance_two_weeks';
    const INSTANCE_ONE_WEEK   = 'instance_one_week';
    const INSTANCE_ONE_MONTH  = 'instance_one_month';
    const INSTANCE_HALF_MONTH = 'instance_half_month';

    # 邮件模板目录
    const TEMPLATE_PATH = '../../common/view/template/';

    /**
     * 邮件发送
     *
     * @param string $address
     * @param string $token
     * @param string $type
     * @return null
     * @throws \PHPMailer\PHPMailer\Exception
     */
    public static function send($address, $token, $type)
    {
        //加载common模块配置
        Config::load(APP_PATH.'common/config.php');
        $content = self::mailContent($type, $token);
        $title   = self::mailTitle($type);

        return self::excute($address, $title, $content);
    }

    /**
     * @param string $type
     * @return string
     */
    public static function mailTitle($type)
    {
        $mailTitle = '';
        switch ($type) {
            case self::FORGET:
                $mailTitle = '密码找回';
                break;
            case self::SAFE_MAIL:
                $mailTitle = '安全邮箱验证';
                break;
            case self::ORDER_CHANGE:
                $mailTitle = '快去支付订单吧';
                break;
            case self::ORDER_CREATED:
                $mailTitle = '订单创建成功';
                break;
            case self::USER_RECHARGE:
                $mailTitle = '充值成功';
                break;
            case self::INSTANCE_TWO_WEEKS:
                $mailTitle = '实例到期提醒';
                break;
            case self::INSTANCE_ONE_WEEK:
                $mailTitle = '客户实例将要过期,请及时联系客户';
                break;
            case self::INSTANCE_ONE_MONTH:
                $mailTitle = '实例到期提醒';
                break;
            case self::INSTANCE_HALF_MONTH:
                $mailTitle = '年付实例客户将要过期,请及时联系客户';
                break;
            default:
                break;
        }

        return $mailTitle;
    }

    /**
     * @param string $type 发送类型
     * @param string $token
     * @return mixed
     */
    public static function mailContent($type, $token = '')
    {
        $mailContent = '';
        switch ($type) {
            case self::FORGET:
                $url         = request()->domain().'/password_reset'.'/'.$token;
                $mailContent = view(self::TEMPLATE_PATH .'forget_pwd_mail', ['reset_pwd_url' => $url])->getContent();
                break;
            case self::SAFE_MAIL:
                $mailContent = view(self::TEMPLATE_PATH . 'safe_pwd_mail', ['safe_token' => $token])->getContent();
                break;
            case self::ORDER_CHANGE:
                $orderUrl = 'http://' . env('CLIENT_URL') . '/order/payInfo/' . $token;
                $mailContent = view(self::TEMPLATE_PATH . self::ORDER_CHANGE, ['orderId' => $token, 'orderUrl' => $orderUrl])->getContent();
                break;
            case self::ORDER_CREATED:
                $orderUrl = 'http://' . env('CLIENT_URL') . '/order/payInfo/' . $token;
                $mailContent = view(self::TEMPLATE_PATH . self::ORDER_CREATED, ['orderId' => $token, 'orderUrl' => $orderUrl])->getContent();
                break;
            case self::USER_RECHARGE:
                $user_url = 'http://' . env('CLIENT_URL');
                $mailContent = view(self::TEMPLATE_PATH . self::USER_RECHARGE, ['user_url' => $user_url])->getContent();
                break;
            case self::INSTANCE_TWO_WEEKS:
                $instanceUrl = 'http://' . env('CLIENT_URL') . '/high';
                $mailContent = view(self::INSTANCE_TWO_WEEKS, ['instanceId' => $token, 'instanceUrl' => $instanceUrl])->getContent();
                break;
            case self::INSTANCE_ONE_WEEK:
                $mailContent = view(self::INSTANCE_ONE_WEEK, ['instance' => $token, ])->getContent();
                break;
            case self::INSTANCE_ONE_MONTH:
                $instanceUrl = 'http://' . env('CLIENT_URL') . '/high';
                $mailContent = view(self::INSTANCE_ONE_MONTH, ['instanceId' => $token, 'instanceUrl' => $instanceUrl])->getContent();
                break;
            case self::INSTANCE_HALF_MONTH:
                $mailContent = view(self::INSTANCE_HALF_MONTH, ['instance' => $token, ])->getContent();
                break;
            default:
                break;
        }

        return $mailContent;
    }

    /**
     * 执行发送邮件
     *
     * @param string $to 接收邮箱
     * @param string $title 邮件标题
     * @param string $content 邮件内容
     * @return bool
     * @throws \PHPMailer\PHPMailer\Exception
     */
    public static function excute($to, $title, $content)
    {
        $mail            = new PHPMailer;
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->SMTPAuth    = true;
        $mail->Host        = Env::get('Mail_Host', 'smtp.exmail.qq.com');
        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer'       => false,
                'verify_peer_name'  => false,
                'allow_self_signed' => true,
            ],
        ];

        $mail->SMTPSecure = Env::get('Mail_SMTPSecure', 'ssl');
        $mail->Port       = Env::get('Mail_Port', 465);
        $mail->Hostname   = Env::get('Mail_Hostname', 'http://www.veda.com');
        $mail->CharSet    = Env::get('Mail_CharSet', 'UTF-8');
        $mail->FromName   = Env::get('Mail_FromName', '卫达安全');
        $mail->Username   = Env::get('Mail_Username', 'hd@veda.com');
        $mail->Password   = Env::get('Mail_Password', '5LZ2GZ4LkqihF5kV');
        $mail->From       = Env::get('Mail_From', 'hd@veda.com');
        $mail->isHTML(true);
        $mail->addAddress($to, Env::get('Mail_addAddress', 'veda在线通知'));
        $mail->Subject = $title;
        $mail->Body    = $content;

        $status = $mail->send();

        // Debug模式下，返回发送成功
        return $status ? true : false;
    }
}