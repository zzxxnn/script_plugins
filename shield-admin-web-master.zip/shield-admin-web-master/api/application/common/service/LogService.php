<?php

namespace app\common\service;

use app\common\model\UserLoginInfo;
use Carbon\Carbon;
use think\Db;
use think\Env;

/**
 * Class LogService
 *
 * @package app\common\service
 * @author Teddy Sun <sgsheg@163.com>
 */
class LogService
{
    /**
     * 获取数据操作对象
     *
     */
    protected static function db()
    {
        return Db::name('system_logs');
    }

    /**
     * 写入操作日志
     *
     * @param string $action
     * @param string $content
     * @return bool
     */
    public static function write($action = '行为', $content = '内容描述')
    {
        $request = request();
        $node    = strtolower(join('/', [$request->module(), $request->controller(), $request->action()]));
        $user    = session('user_auth');
        //todo:B端登录使用的是id?
        if (isset($user['id'])) {
            $email = $user['id'];
        }
        if (isset($user['uid'])) {
            $email = $user['uid'];
        }
        $data = [
            'ip'      => $request->ip(),
            'node'    => $node,
            'action'  => $action,
            'content' => $content,
            'email'   => $email.'',
        ];

        return self::db()->insert($data) !== false;
    }

    /**
     * @param $userId
     * @param string $model
     * @return int
     */
    public static function writeLoginError($userId, $model = 'app\\common\\model\\UserModel')
    {
        $loginTimes     = Env::get('Login_Times') ?? 5;
        $loginTimeLimit = Env::get('Login_Time_Limit') ?? 30;

        //将登录失败信息记录到user_login_info中
        $data   = [
            'user_id'                => $userId,
            'login_ip'               => request()->ip(),
            'pass_wrong_time_status' => UserLoginInfo::PASSWORD_WRONG,
            'model'                  => $model,
            'login_time'             => Carbon::now()->toDateTimeString(),
        ];
        $result = self::checkPassWrongTime($userId, $model, $loginTimes, $loginTimeLimit);
        //已经超过了直接返回最终结局
        if (1 !== $result) {
            return $result;
        }

        if (UserLoginInfo::create($data)) {
            return self::checkPassWrongTime($userId, $model, $loginTimes, $loginTimeLimit);
        }

        return 4;
    }

    /**
     * @param $userId
     * @param $model
     * @param $min
     * @param $wTime
     * @return int
     */
    protected static function checkPassWrongTime($userId, $model, $min, $wTime)
    {
        $user = $model::find($userId);
        if (! $user) {
            return 2;   //账号不存在
        }

        $where = [
            'user_id'                => $userId,
            'model'                  => $model,
            'login_ip'               => request()->ip(),
            'pass_wrong_time_status' => UserLoginInfo::PASSWORD_WRONG,
        ];

        $betweenWhere = [Carbon::now()->subMinutes($wTime)->toDateTimeString(), Carbon::now()->toDateTimeString()];
        $records      = Db::table('user_login_info')->where($where)->whereBetween('login_time', $betweenWhere)->count();

        //登录次数大于了规定的次数
        if ($records && $records >= $min) {
            //锁定账号
            //if ($user->update(['user_status' => 0])) {
                return 3;
            //}
        }

        return 1;
    }
}