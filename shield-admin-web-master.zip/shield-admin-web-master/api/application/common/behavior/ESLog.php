<?php

namespace app\common\behavior;

use app\client\controller\BaseController;
use app\common\exception\client\PermissionDenyException;
use app\common\model\AgentModel;
use app\common\model\UserModel;
use app\common\service\MockDataService;
use app\common\model\ESSystemLogModel;
use app\index\service\Auth as AuthIndex;
use app\client\service\Auth as AuthClient;
use app\agent\service\Auth as AuthAgent;
use think\Request;

class ESLog
{

    /**
     * @param $params
     *
     * @throws \Exception
     */
    public function run(&$params)
    {
        // 单元测试进行日志记录
        if (is_phpunit_testing()) {
            return;
        }

        try {
            $response_data = $params->getData();
            $request_data = request()->param();
            if ($response_data) {
                $template = $this->getSystemLogTemplate($response_data);
                if ($template) {
                    if (!empty($template['params'])) {
                        $content = $template['content'];
                        foreach ($template['params'] as $param) {
                            if (isset($request_data[$param])) {
                                $content = str_replace("{" . $param . "}", $request_data[$param], $content);
                            } else {
                                $bind_param = request()->__get($param);
                                $content = str_replace("{" . $param . "}", $bind_param, $content);
                            }
                        }
                        if (!empty($content)) {
                            $template['content'] = $content;
                            $this->record($response_data, $template);
                        }
                    } else {
                        $this->record($response_data, $template);
                    }
                }
            }
        } catch (\Exception $e) {
            $this->errorHandle($e);
        }
    }

    /**
     * 获取日志模板
     *
     * @param $response_data
     *
     * @return array|bool
     * @throws \Exception
     */
    private function getSystemLogTemplate($response_data)
    {
        if (isset($response_data['errcode'])) {
            return MockDataService::filter('SystemLogTemplate', $this->getPath(), $response_data['errcode']);
        }

        return false;
    }

    /**
     * 记录日志
     *
     * @param $response_data
     * @param $template
     *
     * @return array|mixed
     * @throws \Exception
     */
    private function record($response_data, $template)
    {
        $system = $this->getSystem();
        $data = [
            'method'         => request()->method(),
            "operator"       => $this->getOperator(),
            'path'           => $this->getPath(),
            'ip'             => request()->ip(),
            'system'         => $this->getSystem(),
            "operator_type"  => $template['name'],
            "module"         => $template['module'],
            'content'        => $template['content'],
            'request_type'   => $template['type'],
            'request_status' => $template['status'],
            'request_url'    => request()->pathinfo(),
            'request_body'   => input(),
            'reponse_data'   => $response_data,
            'create_time'    => gmt_withTZ(),
            'update_time'    => gmt_withTZ(),
        ];
        if ($system == 'client') {
            $user = UserModel::where('email', AuthClient::id())->find();
            if ($user && !empty($user->agent_id)) {
                $agent = AgentModel::find($user->agent_id);
                if ($agent) {
                    $data['agent'] = $agent->user_email;
                }
            }
        }

        $model = new ESSystemLogModel();
        $model->setESIndex(date('Y-m-d'));
        $result = $model->esAdd($data);

        return $result['result'] == 'created' ? true : false;
    }

    private function getOperator()
    {
        $system = $this->getSystem();
        if ($system == 'index') {
            return AuthIndex::id();
        } elseif ($system == 'client') {
            return AuthClient::id();
        } elseif ($system == 'agent') {
            return AuthAgent::id();
        }

        return '';
    }

    /**
     * 获取当前执行方法的路径
     * @return string
     */
    private function getPath()
    {
        return join('/', [request()->module(), request()->controller(), request()->action()]);
    }

    /**
     * 获取当前系统
     * @return string
     */
    private function getSystem()
    {
        if (current_domain() == env('BACKGROUND_URL')) {
            return 'index';
        } elseif (current_domain() == env('CLIENT_URL')) {
            return 'client';
        } elseif (current_domain() == env('AGENT_URL')) {
            return 'agent';
        }

        return '';
    }

    private function errorHandle(\Exception $e)
    {
        (new BaseController())->errorHandle($e);
    }
}