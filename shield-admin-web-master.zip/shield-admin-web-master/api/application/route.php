<?php

use think\Route;

Route::rest([
    'create' => ['GET', '/new', 'new'],         // new
    'save'   => ['POST', '', 'create'],         // create
    'read'   => ['GET', '/:id', 'show'],        // show
    'edit'   => ['PUT', '/:id', 'update'],      // update
    'delete' => ['DELETE', '/:id', 'destroy'],  // destroy
]);

Route::group(['domain' => env('BACKGROUND_URL')], function () {
    require APP_PATH.'index/route.php';
});
Route::group(['domain' => env('CLIENT_URL')], function () {
    require APP_PATH.'client/route.php';
});
Route::group(['domain' => env('AGENT_URL')], function () {
    require APP_PATH.'agent/route.php';
});

if (current_domain() === env('BACKGROUND_URL')) {
    Route::miss('index/Index/index');
} elseif (current_domain() === env('CLIENT_URL')) {
    Route::miss('client/Index/index');
}elseif(current_domain() === env('AGENT_URL')){
    Route::miss('agent/IndexController/index');
} else {
    require APP_PATH.'index/route.php';
    Route::miss('index/Index/index');
}
