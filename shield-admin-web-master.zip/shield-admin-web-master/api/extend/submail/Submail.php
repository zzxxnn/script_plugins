<?php namespace extend\submail;

use extend\submail\lib\MessageXSend;

/**
 * Created by PhpStorm.
 * User: WangSF
 * Date: 2018/6/13
 * Time: 15:33
 */
class Submail
{
    protected $submail = null;

    private $config = null;

    public function __construct()
    {
        $this->config = config('submail');
    }

    /**
     * 发送短信
     *
     * @param $to
     * @param array $data
     * @param string $tempId
     * @return mixed
     */
    public function sendSms($to, $data = [], $tempId = '')
    {
        $submail = new MessageXSend($this->config);
        // 设置发送人
        $submail->SetTo($to);
        // 设置发送模版ID
        $submail->SetProject($tempId);
        // 设置模版变量
        foreach ($data as $key => $item) {
            $submail->AddVar($key, $item);
        }

        return $submail->xsend();
    }

}