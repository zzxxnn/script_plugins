<?php

/*
|--------------------------------------------------------------------------------------
|  Task File
|--------------------------------------------------------------------------------------
|
| This file basically registers a new task to be executed by Crunz
| To get the list of all frequency and constraint method, you may
| go to this link: https://github.com/lavary/crunz#scheduling-frequency-and-constraints
|
*/

use Crunz\Schedule;

$scheduler = new Schedule();

# 订单24小时内不支持自动修改状态为取消状态
$scheduler->run('php think run:order')
          ->description('执行订单取消任务')
          //->in('f:\workplace\shield-admin-web\api')
          ->in('/usr/share/nginx/html/shield-admin-web/api')
          ->everyMinute()
          //->appendOutputTo('f:\order.log');
          ->timezone('Asia/Shanghai')
          ->appendOutputTo('/var/log/shield-admin-web/order.log');


# 执行实例检测
$scheduler->run('php think run:instance')
    ->description('执行实例检测')
    //->in('f:\workplace\shield-admin-web\api')
    ->in('/usr/share/nginx/html/shield-admin-web/api')
    ->everyHour()
    ->preventOverlapping()
    ->timezone('Asia/Shanghai')
    //->appendOutputTo('f:\instance.log');
    ->appendOutputTo('/var/log/shield-admin-web/instance.log');

return $scheduler;
