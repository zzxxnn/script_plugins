#! /bin/bash

function throw_error() {
    [ z$1 == z ] || echo $1
    exit 1
}

BUILD_START=$(date +%s)

echo "Start Build By: `git log -1 --pretty=format:%cn`"

ROOT=$PWD

DST_NAME=`date '+%Y-%m-%d_%H-%M-%S'`_web_${CI_COMMIT_TAG}

DST=${RELEASE_DIR}/${DST_NAME}

DST_ZIP=${DST}.tar.gz

mkdir -p $DST

# 1. agent web

echo "agent admin web build start ...."
cd $ROOT/view/agent/admin

if [ ! -d node_modules ]; then
    echo "node_modules extra start ...."
    tar -xf $NODE_MODULES_PATH_AGENT_ADMIN  || throw_error
    echo "node_modules extra finish"
fi

yarn build || throw_error
echo "agent admin web build finish"

echo "agent front web build start ...."
cd $ROOT/view/agent/front

if [ ! -d node_modules ]; then
    echo "node_modules extra start ...."
    tar -xf $NODE_MODULES_PATH_AGENT_FRONT  || throw_error
    echo "node_modules extra finish"
fi

yarn build || throw_error
echo "agent front web build finish"

# 2. admin web

echo "admin web build start ...."
cd $ROOT/view/index

if [ ! -d node_modules ]; then
    echo "node_modules extra start ...."
    tar -xf $NODE_MODULES_PATH_ADMIN  || throw_error
    echo "node_modules extra finish"
fi

npm run build || throw_error
echo "admin web build finish"

# 3. client web

echo "client web build start ...."
cd $ROOT/view/client

if [ ! -d node_modules ]; then
    echo "node_modules extra start ...."
    tar -xf $NODE_MODULES_PATH_CLIENT || throw_error
    echo "node_modules extra finish"
fi

npm run build || throw_error
echo "client web build finish"

# 4. PHP Library
cd $ROOT/api

if [ ! -d thinkphp ]; then
    echo "Preparing the ThinkPHP library..."
    tar -xf $PHP_THINKPHP_LIBRARY || throw_error
    echo "ThinkPHP library failed."
fi

echo "Preparing the vendor library..."
tar -xf $PHP_VENDOR_LIBRARY || throw_error
echo "Vendor library failed."

echo "Finish PHP library"

# 5. package web
echo "start package web ...."
cp -r $ROOT/api $DST/

# env production
if [ ! -f .env.production ]; then
    touch $DST/api/.env.production
fi
echo -e '\nAPP_VERSION='$CI_COMMIT_TAG >> $DST/api/.env.production

# env test
if [ ! -f .env.test ]; then
    touch $DST/api/.env.test
fi
echo -e '\nAPP_VERSION='$CI_COMMIT_TAG >> $DST/api/.env.test

cd $DST

cd ..

tar -czvf $DST_ZIP $DST_NAME

rm -rf $DST

echo "package web finish."