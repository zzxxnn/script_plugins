#!/bin/bash
SOURCE_DIR=${PWD##*/}
TMP_DIR=${SOURCE_DIR}_tmp 
ZIP_FILE=${TMP_DIR}.tar.gz

#APP_VERSION
latestTag=$(git describe --tags)

cd ..

# remove .git
mkdir $TMP_DIR
cp -r $SOURCE_DIR/.git $TMP_DIR/
cp -r $SOURCE_DIR/api $TMP_DIR/
# rm -rf ${TMP_DIR}/.git
# rm -rf ${TMP_DIR}/.gitignore
rm -rf ${TMP_DIR}/release.sh

# env
touch ${TMP_DIR}/api/.env
echo -e 'ES_HOST=123.133.84.201,123.133.84.202,123.133.84.203
ES_USER=elastic
ES_PASSWORD=znkA6H5NnS
ZK_HOST=123.133.84.201:2181,123.133.84.202:2181,123.133.84.202:2181
Host=smtp.exmail.qq.com
SMTPSecure=ssl
Port=465
Hostname=http://www.veda.com
CharSet=UTF-8
FromName=卫达安全
Username=hd@veda.com
Password=5LZ2GZ4LkqihF5kV
From=hd@veda.com
addAddress=veda在线通知

APP_DEBUG=true
ES_DEBUG=true
ZK_DEBUG=true

SUBMAIL_APP_ID=24130
SUBMAIL_APP_KEY=3f974b73915dfad0bd8e92642a39b182
SUBMAIL_SIGN_TYPE=normal
SUBMAIL_SERVER=https://api.mysubmail.com
Client=http://anti-ddos.vedasec.net/

WX_PAY_MATCH_ID=1507790591
WX_PAY_APP_ID=wx4a2cdf4c3bc90cd7
WX_PAY_APP_KEY=heJs7MHIkyYn6C8epkjEhfZHNNqO8kuL
WX_PAY_NOTIFY_URL=http://anti-ddos.vedasec.net/v1/pay/notify
WX_PAY_URL_EXPIRE=60

CLIENT_URL = shield.client.vedasec.net
BACKGROUND_URL = shield.admin.vedasec.net
AGENT_URL = shield.agent.vedasec.net

DB_HOST = localhost
DB_NAME = ShieldDB
DB_USERNAME = root
DB_PASSWORD = 1qaz@WSX

Login_Times = 5
Login_Time_Limit = 30

INSTANCE_REMIND_YEAR_CUSTOMER = 30
INSTANCE_REMIND_YEAR_SUPPORT = 15
INSTANCE_REMIND_CUSTOMER = 14
INSTANCE_REMIND_SUPPORT = 7

APP_VERSION='$latestTag > ${TMP_DIR}/api/.env

tar -czvf $ZIP_FILE $TMP_DIR

scp -P 22018 $ZIP_FILE root@123.133.84.200:/usr/share/nginx/html/
rm -rf $ZIP_FILE
rm -rf $TMP_DIR

ssh -p 22018 root@123.133.84.200 "
cd /usr/share/nginx/html
tar -xf $ZIP_FILE
rm -rf $ZIP_FILE
cp -rf ${SOURCE_DIR}/api/runtime ${TMP_DIR}/api/
chown -R nginx ${TMP_DIR}/api/runtime
chown -R nginx ${TMP_DIR}/api/public
chcon -R -t httpd_sys_rw_content_t ${TMP_DIR}/api/runtime
rm -r $SOURCE_DIR
mv $TMP_DIR $SOURCE_DIR
"
