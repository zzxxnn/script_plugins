<template>
  <div class="login-error">
    <span class="icon-error"></span>
    <span class="notice">{{ errMsg }}</span>
  </div>
</template>
<style scoped lang="scss">
.login-error {
  margin: 0 auto;
  margin-bottom: 16px;
  padding: 2px 10px;
  color: #f15532;
  text-align: left;
  font-size: 14px;
  border: 1px solid #f15532;
  background-color: #feeeeb;
  box-sizing: border-box;
}
.icon-error {
  display: inline-block;
  width: 16px;
  height: 16px;
  background: url('~@/assets/img/icon-error.svg');
  background-position: 0 0;
  background-size: 16px 16px;
  vertical-align: -3px;
}
.notice {
  padding: 4px 8px;
}
</style>
<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class VFormError extends Vue {
  @Prop() private errMsg!: string;
}
</script>

