<template>
  <div class="footer p-t-10 p-b-10">
    &copy;2016-2018&nbsp;&nbsp;&nbsp;&nbsp;北京卫达信息技术有限公司版权所有
  </div>
</template>
<style scoped lang="scss">
.footer {
  position: fixed;
  bottom: 0;
  width: 100%;
  color: #fff;
  font-size: 12px;
  text-align: center;
  background-color: #100206;
}
</style>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component
export default class VFooter extends Vue {}
</script>