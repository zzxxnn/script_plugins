<template>
  <div class="header p-l-30 p-r-30 p-t-10 p-b-10">
    <VLogoTitle></VLogoTitle>
  </div>
</template>
<style scoped lang="scss">
.header {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  width: 100%;
  color: #fff;
  font-size: 12px;
  border-bottom: 2px solid red;
  background-color: rgba(16, 2, 6, .5);
  box-sizing: border-box;
}
</style>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import VLogoTitle from '@/components/VLogoTitle.vue';

@Component({
  components: {
    VLogoTitle,
  },
})
export default class VFooter extends Vue {}
</script>