const path = require('path')
const fs = require('fs')
const host = 'http://agent.shield.com'

function resolve (dir) {
  return path.resolve(__dirname, dir)
}

let config = {
  css: {
    loaderOptions: {
      sass: {
        data: fs.readFileSync(resolve('src/assets/css/common/var.scss'), 'utf-8')
      }
    }
  },

  chainWebpack: config => {
    config.resolve.alias
      .set('assets',resolve('src/assets'))
      .set('icons', resolve('src/assets/img/icons'))
  },
}

if (process.env.NODE_ENV === 'production') {
  config = {

    ...config,

    baseUrl: '/agent/admin',
  
    outputDir: path.posix.join('../../../api/public/agent/admin'),
  
    pages: {
      index: {
        // entry for the page
        entry: 'src/main.ts',
        // the source template
        template: 'public/index.html',
        favicon: 'public/agent.ico',
        // output as dist/index.html
        filename: resolve('../../../api/application/agent/view/index/index.html'),
        // when using title option,
        // template title tag needs to be <title><%= htmlWebpackPlugin.options.title %></title>
        title: '代理商管理'
      },
    },
  }
} else { // 开发环境配置
  config = {
    ...config,
    
    devServer: {
      publicPath: '/',
      port: 8081,
      open: true,
      historyApiFallback: true,
      allowedHosts: [
        'agent.shield.com',
        'localhost',
      ],
      proxy: {
        "/v1": {
          target: host,
          secure: false,
          changeOrigin: true
        },
        "/avatar": {
          target: host,
          secure: false,
          changeOrigin: true
        },
      }
    },

    baseUrl: '/',
  
    outputDir: resolve('../../../api/public/agent/admin'),
   
  }
}
module.exports = config
