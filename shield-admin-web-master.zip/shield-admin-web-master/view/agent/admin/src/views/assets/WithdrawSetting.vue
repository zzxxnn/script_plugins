<template>
  <div class="withdraw-setting">
   <Card>
       <VUser :text="formData.email" :avatar="formData.avatar"></VUser>
       <div>
          <ul class="m-t-25">
            <li class="m-b-25"><label>开户行：</label> {{formData.bank?formData.bank:'-'}}</li>
            <li class="m-b-25"><label>开户名：</label>{{formData.bank_account?formData.bank_account:'-'}}</li>
            <li class="m-b-25"><label>账号：</label>{{formData.bank_card?formData.bank_card:'-'}}</li>
            <li class="m-b-25 tc"><Button type="primary" size="small" @click="changeInfo">信息修改</Button></li>
          </ul>
       </div>
   </Card>
   <Modal
    v-model="isShowModal"
    :title="'修改信息'"
    :closable="false"
    @on-ok="update('updateForm')"
    @on-cancel="cancel('updateForm')"
    >
    <Spin fix v-if="isSubmitting">
        <Icon type="load-c" size=38 class="spin-icon-load"></Icon>
        <div>保存中...</div>
    </Spin>
    <div style="margin:0 auto;width:320px;">
        <VUser :text="formData.email" :avatar="formData.avatar"></VUser>
        <Form
        :model="formData"
        label-position="right"
        ref="updateForm"
        :label-width="70"
        :rules="rules"
        style="width: 350px;margin: 0 auto;"
        class="m-t-30">
            <FormItem label="开户行：" prop="bank">
                <Input v-model="formData.bank"></Input>
            </FormItem>
            <FormItem label="开户名：" prop="bank_account">
                <Input v-model="formData.bank_account"></Input>
            </FormItem>
            <FormItem label="账号：" prop="bank_card">
                <Input v-model="formData.bank_card"></Input>
            </FormItem>
        </Form>
    </div>
    <div slot="footer">
        <Button @click="cancel('updateForm')">取消</Button>
        <Button type="primary" @click="onChangeInfo('updateForm')">确认</Button>
    </div>
    </Modal>
  </div>
</template>
<style lang="scss">
@import '@/assets/css/withdrawSetting.scss';
</style>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import VUser from '@/components/VUser.vue';
import WithDrawInfoService from '@/services/WithDrawInfo';
import IndexService from '@/services/Index';
import { WithDrawInfoModel, WithDrawInfoResponse } from '@/typings/withdraw';
import { IndexModel, IndexResponse } from '@/typings/index';

@Component({
  components: {
      VUser,
  },
})
export default class WithdrawSetting extends Vue {
    private rules: any = {
        bank: [
          {required: true, message: '开户行不能为空', trigger: 'blur'},
        ],
        bank_account: [
          {required: true, message: '开户名不能为空', trigger: 'blur'},
        ],
        bank_card: [
          {required: true, message: '账号不能为空', trigger: 'blur'},
        ],
    };
    private formData: WithDrawInfoModel = {
        avatar: '',
        bank: '',
        bank_account: '',
        bank_card: '',
        email: '',
    };
    private isShowModal: boolean = false;
    private isSubmitting: boolean = false;
    private agentId: number = 0;

    public created() {
        this.getData();
        this.getId();
    }

    get query() {
        return {
            bank: this.formData.bank,
            bank_account: this.formData.bank_account,
            bank_card: this.formData.bank_card,
        };
    }

    public changeInfo() {
        this.isShowModal = true;
    }

    public async getData() {
      try {
        const res: WithDrawInfoResponse = await WithDrawInfoService.getData<WithDrawInfoResponse>();
        if (res.errcode === 0) {
          this.formData = res.data;
        }
      } catch (err) {
          this.$Message.error({
            content: '请求数据异常！',
            duration: 3,
          });
      }
    }

    public async getId() {
      try {
        const res: IndexResponse = await IndexService.getData<IndexResponse>();
        if (res.errcode === 0) {
          this.agentId = res.data.id;
        }
      } catch (err) {
          this.$Message.error({
            content: '请求数据异常！',
            duration: 3,
          });
      }
    }
    public onChangeInfo(name) {
        const updateForm =  this.$refs[name] as HTMLFormElement;
        updateForm.validate((valid: any) => {
          if (!valid) {
            return;
          }
          this.update();
        });
    }
    public async update() {
          try {
            this.isSubmitting = true;
            const res: WithDrawInfoResponse = await WithDrawInfoService.updateData<WithDrawInfoResponse>(
                this.query,
                this.agentId,
            );
            if (res.errcode === 0) {
                this.isSubmitting = false;
                this.isShowModal = false;
                this.getData();
                setTimeout(() => {
                this.$Message.success({
                    content: '修改成功',
                    duration: 3,
                });
                }, 1500);
            }
          } catch (err) {
            this.isSubmitting = false;
            this.$Message.error({
                content: '请求数据异常！',
                duration: 3,
            });
          }
    }
    public cancel(name) {
      this.isShowModal = false;
      setTimeout(() => {
        const form = this.$refs[name] as HTMLFormElement;
        form.resetFields();
        this.getData();
      }, 0);
    }
}
</script>
