<template>
  <div class="withdraw">
    <Card>
        <h3 class="tc m-b-20">发票及完税证明（个人）快递信息</h3>
        <Form
          ref="formValidate"
          :model="formValidate"
          :label-width="100"
          :rules="rules"
          style="width: 400px;margin:0 auto;">
        <FormItem label="快递公司：" prop="express_company">
            <Input v-model="formValidate.express_company" placeholder="请输入快递公司"></Input>
        </FormItem>
        <FormItem label="快递单号：" prop="express_number">
            <Input v-model="formValidate.express_number" placeholder="请输入快递单号"></Input>
        </FormItem>
        <FormItem label="发票号：" prop="invoice_number">
            <Input v-model="formValidate.invoice_number" placeholder="请输入发票号"></Input>
        </FormItem>
        <FormItem>
            <Radio-group v-model="formValidate.proof">
                <Radio :label="1">不包含完税证明</Radio>
                <Radio :label="2">包含完税证明</Radio>
            </Radio-group>
        </FormItem>
       <FormItem label="提现金额：" prop="amount">
            <Input v-model="formValidate.amount" placeholder="请输入提现金额"></Input>
            <div class="clearfix"><p class="fl" style="color: #999999;">可提现金额￥{{cashAll}}</p><span class="fr m-r-45 cash-btn" style="color: #2d8cf0" @click="allCash">全部提现</span></div>
        </FormItem>
        <FormItem label="输入密码：" prop="password">
            <Input v-model="formValidate.password" placeholder="请输入密码" type="password"></Input>
        </FormItem>
        <FormItem class="tc" style="margin-left: -80px;">
            <Button type="primary" size="small" @click="onChangeInfo">提交</Button>
        </FormItem>
    </Form>
    </Card>
  </div>
</template>

<style lang="scss">
@import '@/assets/css/withdraw.scss';
</style>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import CashInfoService from '@/services/CashInfo';
import AgentService from '@/services/Agent';
import { AgentModel, AgentResponse } from '@/typings/agent';

interface CashInfoModel {
  express_company: string;
  express_number: string;
  invoice_number: string;
  proof: number;
  amount: string;
  password: string;
}

interface CashInfoResponse {
  errcode: number;
  errmsg: string;
}
@Component({
  components: {
  },
})
export default class Withdraw extends Vue {
    private rules: any = {
        express_company: [
          {required: true, message: '开户行不能为空', trigger: 'blur'},
        ],
        express_number: [
          {required: true, message: '快递公司不能为空', trigger: 'blur'},
        ],
        invoice_number: [
          {required: true, message: '快递单号不能为空', trigger: 'blur'},
        ],
        proof: [
          {required: true, message: '请选择完税证明', trigger: 'change'},
        ],
        amount: [
          {required: true, message: '提现金额不能为空', trigger: 'blur'},
        ],
        password: [
          {required: true, message: '密码不能为空', trigger: 'blur'},
        ],
    };

    private formValidate: CashInfoModel = {
        express_company: '',
        express_number: '',
        invoice_number: '',
        proof: 1,
        amount: '',
        password: '',
    };

    private cashAll: number = 0;

    public created() {
      this.getData();
    }

    public async getData() {
      try {
        const res: AgentResponse = await AgentService.getAgent<AgentResponse>();
        if (res.errcode === 0) {
          this.cashAll = res.data.cash_all;
        }

      } catch (err) {
        this.$Message.error({
            content: '请求数据异常！',
            duration: 3,
        });
      }
    }

    public onChangeInfo() {
        const formValidate = this.$refs.formValidate as HTMLFormElement;
        formValidate.validate((valid: any) => {
          if (!valid) {
            return false;
          }
          this.onSubmit();
        });
    }

    public allCash() {
      this.formValidate.amount = this.cashAll.toString();
    }

    public async onSubmit() {
        try {
            const res: CashInfoResponse = await CashInfoService.addData<CashInfoResponse>(this.formValidate);
            if (res.errcode === 0) {
            setTimeout(() => {
                this.$router.push('/assets');
                this.$Message.success({
                content: '提现成功',
                duration: 3,
                });
            }, 1500);
            } else {
                this.$Message.error(res.errmsg);
            }
        } catch (err) {
          this.$Message.error({
            content: '请求数据异常！',
            duration: 3,
          });
        }
    }
}
</script>
