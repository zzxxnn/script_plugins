<template>
  <div class="assets">
      <Card>
        <Row>
            <Col span="6"><VUser :avatar="agent.img_url" :text="agent.user_email" class="v-user"></VUser></Col>
            <Col span="6"><VCheck :title="'可提现余额'" :content="agent.cash_confirmed" @click="checkOut"></VCheck></Col>
            <Col span="6"><VCheck :title="'已提现总额'" :content="agent.cash_has_been" @click="checkOut"></VCheck></Col>
            <Col span="6"><VCheck :title="'待确认总额'" :content="agent.cash_all" @click="checkOut"></VCheck></Col>
        </Row>
      </Card>
      <div class="table-title">
          <p>近期提现记录列表</p>
      </div>
      <Card>
          <Table :columns="columns" :data="tableData"></Table>
          <div class="tc m-t-20">
            <Page :total="total"
                show-sizer
                :page-size-opts="sizeOpts"
                show-total
                size="small"
                @on-page-size-change="handlePageSizeChange"
                @on-change="handleChangePage">
            </Page>
          </div>
      </Card>
  </div>
</template>
<style lang="scss">
@import '@/assets/css/assets.scss';
</style>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import VCheck from '@/components/VCheck.vue';
import VUser from '@/components/VUser.vue';
import { AgentModel, AgentResponse } from '@/typings/agent';
import { AssetModel, AssetsModel, AssetsResponse } from '@/typings/assets';
import AgentService from '@/services/Agent';
import AssetsService from '@/services/Assets';

@Component({
  components: {
      VCheck,
      VUser,
  },
  filters: {
      RMB(val: number) {
          return '￥' + val;
      },
  },
})
export default class Assets extends Vue {
    private columns = [
        {
            title: '日期',
            key: 'create_time',
        },
        {
            title: '提现金额',
            key: 'amount',
        },
        {
            title: '提现账号',
            key: 'agent_name',
        },
        {
            title: '余额',
            key: 'after_amount',
        },
    ];

    private sizeOpts: number[] = [10, 20, 30, 40, 50];

    private agent: object = {
        id: '',
        user_email: '',
        img_url: '',
        cash_confirmed: 0,
        cash_has_been: 0,
        cash_all: 0,
        user_type: '1',
    };

    private tableData: object[] = [];
    private total: number = 0;
    private curPage: number = 1;
    private size: number = 10;

    public created() {
        this.getAgent();
        this.getAssets();
    }

    get query(): object {
        return {
            _from: this.curPage,
            _size: this.size,
        };
    }

    public handlePageSizeChange(size) {
        this.size = size;
        this.curPage = 1;
        this.getAssets();
    }
    public handleChangePage(from) {
        this.curPage = from;
        this.getAssets();
    }
    public async getAgent() {
        try {
            const res: AgentResponse = await AgentService.getAgent<AgentResponse>();
            this.agent = res.data;
        } catch (err) {
            this.$Message.error({
                content: '请求数据异常！',
                duration: 3,
            });
        }
    }

    public async getAssets() {
        try {
            const res: AssetsResponse = await AssetsService.getList<AssetsResponse>(this.query);
            this.tableData = res.data.list;
            this.total = res.data.total;
        } catch (err) {
            this.$Message.error({
                content: '请求数据异常！',
                duration: 3,
            });
        }
    }
    // TODO:
    private checkOut() {
        return '';
    }
}
</script>
