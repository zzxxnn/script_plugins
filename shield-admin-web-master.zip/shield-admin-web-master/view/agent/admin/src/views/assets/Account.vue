<template>
  <div class="home">
    account
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component({
  components: {
  },
})
export default class Account extends Vue {}
</script>
