<template>
  <div>
    <router-view/>
  </div>
</template>
<style lang="scss">

</style>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component({
  components: {
  },
})
export default class Index extends Vue {}
</script>
