<template>
<div class="msg-center">
  <Tabs type="card" :animated="false">
    <TabPane label="推送公告">
      <MsgList :data="gonggaoData" @onChangeSize="handleChangeSize1" @onChangePage="handleChangePage1"></MsgList>
    </TabPane>
    <TabPane label="告警信息">
      <MsgList :data="alertData" @onChangeSize="handleChangeSize2" @onChangePage="handleChangePage2"></MsgList>
    </TabPane>
    <TabPane label="市场活动">
      <MsgList :data="activityData" @onChangeSize="handleChangeSize3" @onChangePage="handleChangePage3"></MsgList>
    </TabPane>
  </Tabs>
</div>
</template>

<style lang="scss">
@import '@/assets/css/msgCenter.scss';
</style>

<script lang="ts">
import { Component, Provide, Vue } from 'vue-property-decorator';
import { MessageModel, MessageResponse } from '@/typings/message';
import MsgList from './MsgList.vue';
import MessageService from '@/services/Message';

@Component({
  components: {
    MsgList,
  },
})

export default class ProductInfo extends Vue {
    private single: boolean = false;

    private gonggaoData: object[] = [];

    private alertData: object[] = [];

    private activityData: object[] = [];

    private size1: number = 10;
    private size2: number = 10;
    private size3: number = 10;

    private from1: number = 1;
    private from2: number = 1;
    private from3: number = 1;

    private type: number = 1;

    public created() {
      this.getData();
    }

    get query() {
      return {
        _from: this['from' + this.type],
        _size: this['size' + this.type],
      };
    }

    public handleChangeSize1(size: number) {
      this.size1 = size;
      this.from1 = 1;
      this.type = 1;
      this.getData();
    }

    public handleChangeSize2(size: number) {
      this.size2 = size;
      this.from2 = 1;
      this.type = 2;
      this.getData();
    }

    public handleChangeSize3(size: number) {
      this.size3 = size;
      this.from3 = 1;
      this.type = 3;
      this.getData();
    }

    public handleChangePage1(from: number) {
      this.from1 = from;
      this.type = 1;
      this.getData();
    }

    public handleChangePage2(from: number) {
      this.from2 = from;
      this.type = 2;
      this.getData();
    }

    public handleChangePage3(from: number) {
      this.from3 = from;
      this.type = 3;
      this.getData();
    }

    public async getData() {
      try {
        const res: MessageResponse = await MessageService.getData<MessageResponse>(this.query);
        if (res.errcode === 0) {
          this.gonggaoData = res.data.filter((item: any) => {
              return item.type === 1;
          });
          this.alertData = res.data.filter((item: any) => {
              return item.type === 2;
          });
          this.activityData = res.data.filter((item: any) => {
              return item.type === 3;
          });
        }
      } catch (err) {
          this.$Message.error({
            content: '请求数据异常！',
            duration: 3,
          });
      }
    }
}
</script>
