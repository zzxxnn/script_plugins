<template>
  <Card :bordered="false">
    <p slot="title">
      <span class="m-l-10" style="font-size: 12px;">未读消息（10/10）</span>
    </p>
    <div class="msgs clearfix" v-for="item in data">
      <div class="fl check">
        <!-- <Checkbox v-model="item.id"></Checkbox> -->
        <i class="no-read m-l-5" v-show="item.status == 'unread'"></i>
      </div>
      <div class="fl m-l-10">
          <Icon type="android-notifications-none" class="m-r-10"></Icon>
          <ul>
              <li class="title">
                {{item.title}}
                <samp class="m-l-15">{{item.create_time}}</samp>
              </li>
              <li class="cont">{{item.content}}</li>
          </ul>
      </div>
      <div class="fr">
        <router-link :to="`/msgCenter/detail/${item.id}`">
          <Button size="small" type="primary">查看</Button>
        </router-link>
      </div>
    </div>
    <div class="tc m-t-20">
      <Page :total="data.length"
            show-sizer
            show-total
            size="small"
            :page-size-opts="sizeOptions"
            @on-page-size-change="handleChangeSize"
            @on-change="handleChangePage">
      </Page>
    </div>
  </Card>
</template>

<script lang="ts">
import { Component, Prop, Emit, Vue } from 'vue-property-decorator';

@Component
export default class MsgList extends Vue {

  @Prop()
  private data!: object[];

  private sizeOptions: number[] = [10, 20, 30, 40, 50];

  @Emit('onChangeSize')
  public handleChangeSize(val: number) {
    return;
  }

  @Emit('onChangePage')
  public handleChangePage(val: number) {
    return;
  }
}
</script>
