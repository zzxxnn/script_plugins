<template>
  <div class="msg-center user-detail">
    <div class="table-title m-b-20">
        <p class="clearfix">{{message.type_name}}<router-link to="/msgCenter/list" class="fr">返回</router-link></p>
    </div>
    <Card class="m-b-30">
        <p slot="title">{{message.type_name}}</p>
        <Row class="p-t-20">
            <Col span="24" class="basic tc">
                <h3>{{message.title}}</h3>
                <ul>
                    <li>&nbsp;&nbsp;{{message.content}}&nbsp;&nbsp;{{message.create_time}}</li>
                </ul>
            </Col>
        </Row>
    </Card>
  </div>
</template>

<style lang="scss">
@import '@/assets/css/userDetail.scss';
@import '@/assets/css/msgCenter.scss';
</style>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { MessageModel, MessageResponse } from '@/typings/message';
import VUser from '@/components/VUser.vue';
import MessageService from '@/services/Message';

@Component({
  components: {
      VUser,
  },
})
export default class Userlist extends Vue {
    private message: object = {};

    public created() {
        this.getData();
    }

    get msgId(): string {
        return this.$route.params.id;
    }

    public async getData() {
      try {
        const res: MessageResponse = await MessageService.getDetail<MessageResponse>(this.msgId);
        if (res.errcode === 0) {
          this.message = res.data;
        }
      } catch (err) {
          this.$Message.error({
            content: '请求数据异常！',
            duration: 3,
          });
      }
    }
}
</script>
