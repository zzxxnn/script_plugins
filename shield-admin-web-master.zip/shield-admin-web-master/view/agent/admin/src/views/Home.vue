<template>
  <div class="home">
     <Card class="m-b-20">
        <Row>
            <Col span="6"><VUser :text="account" :avatar="userData.img_url" class="v-user"></VUser></Col>
            <Col span="6"><VCheck :title="'用户数量'" :content="`￥${userData.user_number}`" @click="checkOut"></VCheck></Col>
            <Col span="6"><VCheck :title="'用户余额'" :content="`￥${userData.cash_all}`" @click="checkOut"></VCheck></Col>
            <Col span="6"><VCheck :title="'可提现余额'" :content="`￥${userData.cash_all}`" @click="checkOut"></VCheck></Col>
        </Row>
      </Card>
      <Card class="m-b-20 techInfo">
          <Row>
              <Col span="12" class="border">
                <h3 class="m-b-20">技术支持</h3>
                <ul class="p-l-20 tc">
                    <li class="m-r-20">张三</li>
                    <li class="m-r-20">
                        <Icon type="ios-telephone-outline" class="m-r-5" style="font-size: 20px;color: #54a669;"></Icon>18800000000
                    </li>
                    <li class="p-r-30"><img src="~assets/img/qq-chat.png"></li>
                </ul>
              </Col>
              <Col span="12">
                <h3 class="m-b-20 p-l-10">销售支持</h3>
                <ul class="tc">
                    <li class="m-r-20">张三</li>
                    <li class="m-r-20">
                        <Icon type="ios-telephone-outline" class="m-r-5" style="font-size: 20px;color: #54a669;"></Icon>18800000000
                    </li>
                    <li><img src="~assets/img/qq-chat.png"></li>
                </ul>
              </Col>
          </Row>
      </Card>
      <Row :gutter="20" class="m-b-20">
          <Col span="12">
            <Card :bordered="false">
                <p slot="title">近期用户充值情况</p>
                <div class="tr">
                    <Button type="primary" size="small">查看</Button>
                </div>
                <LinesChart :id="'chart1'"></LinesChart>
            </Card>
          </Col>
          <Col span="12">
            <Card :bordered="false">
                <p slot="title">用户增长情况</p>
                <div class="tr">
                    <Button type="primary" size="small">查看</Button>
                </div>
                <LinesChart :id="'chart2'"></LinesChart>
            </Card>
          </Col>
      </Row>
      <Row :gutter="20" class="m-b-20">
          <Col span="12">
            <Card :bordered="false">
                <p slot="title">近期用户购买实例情况</p>
                <div class="tr">
                    <Button type="primary" size="small">查看</Button>
                </div>
                <LinesChart :id="'chart3'"></LinesChart>
            </Card>
          </Col>
          <Col span="12">
            <Card :bordered="false">
                <p slot="title">近期用户受攻击情况</p>
                <div class="tr">
                    <Button type="primary" size="small">查看</Button>
                </div>
                <LinesChart :id="'chart4'"></LinesChart>
            </Card>
          </Col>
      </Row>
  </div>
</template>

<style lang="scss">
@import '@/assets/css/home.scss';
</style>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import VCheck from '@/components/VCheck.vue';
import VUser from '@/components/VUser.vue';
import LinesChart from '@/components/LinesChart.vue';
import IndexService from '@/services/Index';
import { AgentModel, AgentResponse } from '@/typings/agent';

@Component({
  components: {
      VCheck,
      VUser,
      LinesChart,
  },
})
export default class Home extends Vue {
    private userData: object = {
      user_number: 0,
      cash_all: 0,
      user_email: '',
      mobile: '',
      img_url: '',
    };
    private email: string = '';
    private mobile: string = '';
    public created() {
      this.getData();
    }

    get account(): string {
        return this.email ? this.email : this.mobile;
    }

    public async getData() {
      try {
        const res: AgentResponse = await IndexService.getData<AgentResponse>();
        if (res.errcode === 0) {
          this.userData = res.data;
          this.email = res.data.user_email;
          this.mobile = res.data.mobile;
        }

      } catch (err) {
        this.$Message.error({
            content: '请求数据异常！',
            duration: 3,
        });
      }
    }
    public checkOut() {
        return '';
    }
}
</script>
