<template>
  <Card class="p-t-20">
    <VUser :text="userEmail" :avatar="imgUrl" />
    <Row class="m-t-40">
      <Col :xs="{ span: 22, offset: 1 }"
           :sm="{ span: 12, offset: 6 }"
           :md="{ span: 8, offset: 8 }"
           :lg="{ span: 6, offset: 9 }">
        <Form :model="formData"
              label-position="left"
              :label-width="70"
              :rules="rules"
              ref="passForm">
          <FormItem label="原密码" class="m-b-30" prop="old_password">
              <Input type="password" v-model="formData.old_password"></Input>
          </FormItem>
          <FormItem label="新密码" class="m-b-30" prop="new_password">
              <Input type="password" v-model="formData.new_password"></Input>
          </FormItem>
          <FormItem label="确认密码" class="m-b-30" prop="confirm_password">
              <Input type="password" v-model="formData.confirm_password"></Input>
          </FormItem>
          <FormItem class="tc">
              <Button type="primary" @click="onChangePassword">确认修改</Button>
          </FormItem>
        </Form>
      </Col>
    </Row>

  </Card>
</template>
<style lang="scss">

</style>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import VUser from '@/components/VUser.vue';
import PasswordService from '@/services/Password';
import AgentService from '@/services/Agent';
import { PasswordModel, PasswordResponse } from '@/typings/password';
import { reg } from '@/utils/index';
import { AgentResponse, AgentModel } from '@/typings/agent';

type validatorFun = (rule: any, value: any, next: (err?: Error) => void) => void;

@Component({
  components: {
    VUser,
  },
})
export default class PwdReset extends Vue {

    private initFormData: PasswordModel = {
        old_password: '',
        new_password: '',
        confirm_password: '',
    };

    private formData: PasswordModel = {...this.initFormData};
    private userEmail: string = '';
    private imgUrl: string = '';

    private validateOldPwd: validatorFun | null = null;

    private validateNewPwd: validatorFun | null = null;

    private validateConfirmPwd: validatorFun | null = null;

    private rules: object = {};

    public setupValidators() {
        this.validateOldPwd = (rule, value, next) => {
            if (!value) {
                next(new Error('原密码不能为空'));
                return;
            }
            if (!reg.validatePassword(value)) {
                next(new Error('密码格式不正确'));
            } else {
                next();
            }
        };

        this.validateNewPwd = (rule, value, next) => {
            if (!value) {
                next(new Error('新密码不能为空'));
                return;
            }
            if (!reg.validatePassword(value)) {
                next(new Error('密码格式不正确'));
            } else {
                next();
            }
        };

        this.validateConfirmPwd = (rule, value, next) => {
            if (!value) {
                next(new Error('原密码不能为空'));
                return;
            }
            if (!reg.validatePassword(value)) {
                next(new Error('密码格式不正确'));
            } else if (value !== this.formData.new_password) {
                next(new Error('确认密码和新密码不一致'));
            } else {
                next();
            }
        };

        this.rules = {
            old_password: [{validator: this.validateOldPwd, trigger: 'blur'}],
            new_password: [{validator: this.validateNewPwd, trigger: 'blur'}],
            confirm_password: [{validator: this.validateConfirmPwd, trigger: 'blur'}],
        };
    }

    public created() {
        this.getAgent();
        this.setupValidators();
    }

    public async getAgent() {
        try {
            const res: AgentResponse = await AgentService.getAgent<AgentResponse>();
            if (res.errcode === 0) {
            this.userEmail = res.data.user_email;
            this.imgUrl = res.data.img_url;
            }

        } catch (err) {
            this.$Message.error({
                content: '请求数据异常！',
                duration: 3,
            });
        }
    }
    public onChangePassword() {
        const passForm = this.$refs.passForm as HTMLFormElement;
        passForm.validate((valid: boolean) => {
            if (!valid) {
                return;
            }
            this.updatePassword();
        });
    }

    public async updatePassword() {
        try {
            const res: PasswordResponse = await PasswordService.update<PasswordResponse>(this.formData);
            if (res.errcode === 0) {
                setTimeout(() => {
                this.$Message.success({
                    content: '修改成功',
                    duration: 3,
                });
                }, 1500);
            } else {
                this.$Message.error({
                        content: res.errmsg,
                        duration: 3,
                    });
                }
        } catch (err) {
            this.$Message.error({
                content: '请求数据异常！',
                duration: 3,
            });
        }
    }


}
</script>

