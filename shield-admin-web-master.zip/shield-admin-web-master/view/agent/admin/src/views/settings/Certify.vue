<template>
  <div>
    <CardVerifyForm v-if="userType === 1"/>
    <LicenceVerifyForm v-else/>
  </div>
</template>
<style lang="scss">

</style>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import CardVerifyForm from './CardVerifyForm.vue';
import LicenceVerifyForm from './LicenceVerifyForm.vue';
import AgentService from '@/services/Agent';
import { AgentModel, AgentResponse } from '@/typings/agent';
@Component({
  components: {
    CardVerifyForm,
    LicenceVerifyForm,
  },
})
export default class Certify extends Vue {
    private userType: number = 1;
    public created() {
        this.getAgent();
    }
    public async getAgent() {
        try {
            const res: AgentResponse = await AgentService.getAgent<AgentResponse>();
            if (res.errcode === 0) {
                this.userType = Number(res.data.user_type);
            }

        } catch (err) {
            this.$Message.error({
                content: '请求数据异常！',
                duration: 3,
            });
        }
    }
}
</script>

