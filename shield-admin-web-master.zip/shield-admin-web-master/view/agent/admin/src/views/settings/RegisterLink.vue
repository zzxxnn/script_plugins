<template>
  <Card class="register-link p-t-20 tc">
    <VUser :avatar="avatar" :text="account" />
    <div class="m-t-50 m-b-50">
      <span class="gray-text m-r-30">
        客户注册链接
      </span>
      <a class="gray-text m-r-30" style="text-decoration: underline;">
        {{link}}
      </a>
      <a class="copy" :data-clipboard-text="link">
        复制
      </a>
    </div>
  </Card>
</template>
<style lang="scss">
.register-link {
  .gray-text {
    color: $gray;
  }
  .copy {
    color: $blue;
    text-decoration: underline;
  }
}
</style>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import Clipboard from 'clipboard';
import VUser from '@/components/VUser.vue';
import { AgentModel, AgentResponse } from '@/typings/agent';
import { ProfileModel, ProfileResponse } from '@/typings/profile';
import AgentService from '@/services/Agent';
import ProfileService from '@/services/Profile';

@Component({
  components: {
    VUser,
  },
})
export default class RegisterLink extends Vue {

  private avatar: string = '';
  private email: string = '';
  private phone: string = '';
  private link: string = '';

  public created() {
    this.getData();

    const clipboard = new Clipboard('.copy');

    clipboard.on('success', (e) => {
      this.$Message.success({
        content: '复制成功！',
      });
      e.clearSelection();
    });
  }

  get account(): string {
    return this.email ? this.email : this.phone;
  }

  public async getData() {
    try {
      const agent: AgentResponse = await AgentService.getAgent<AgentResponse>();

      const profileRes: ProfileResponse = await ProfileService.getData<ProfileResponse>(agent.data.id);

      const profile: ProfileModel = profileRes.data as ProfileModel;

      this.avatar = profile.img_url;

      this.email = profile.user_email;

      this.phone = profile.mobile;

      this.link = profile.client_register_url ? profile.client_register_url : '暂无';

    } catch (err) {
      this.$Message.error({
          content: '请求数据异常！',
          duration: 3,
      });
    }
  }
}
</script>

