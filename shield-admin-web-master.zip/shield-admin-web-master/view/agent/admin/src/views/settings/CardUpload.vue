<template>
    <div class="card-upload tc">
        <div :style="{backgroundImage:'url(' + uploadImg + ')'}" class="upload-img"></div>
        <p class="m-t-5">{{desc}}</p>
        <div class="m-t-20">
        <Button class="m-r-10" @click="upload">点击上传</Button>
        <Upload
            ref="upload"
            :multiple="false"
            :show-upload-list="false"
            :before-upload="handleUpload"
            :on-success="onUploadSuccess"
            :on-error="onUploadError"
            :data="uploadData"
            action="/v1/photo/upload"
            style="display:inline-block">
            <Button type="text" class="file-broswer">
                <Icon type="folder" class="m-r-10"></Icon>浏览
            </Button>
        </Upload>
        </div>
    </div>
</template>
<style lang="scss">
.card-upload {
  padding: 15px 20px;
  border: 1px solid $bg-color;
  border-radius: 4px;
  width: auto;
  overflow: hidden;
  .upload-img {
    margin: 0 auto;
    width: 242px;
    height: 146px;
    background-size: cover;
  }
  p {
    color: $gray;
  }
  .file-broswer {
    color: $blue;
    &:hover {
      border-color: $blue;
    }
  }
}
</style>
<script lang="ts">
import { Component, Prop, Vue, Emit} from 'vue-property-decorator';
import card1 from 'assets/img/settings/card1.png';
import card2 from 'assets/img/settings/card2.png';
import card3 from 'assets/img/settings/card3.png';
import UploadService from '@/services/Upload';
import { UploadModel, UploadResponse } from '@/typings/upload';

interface ImageDict {
    [key: string]: string;
}
@Component
export default class CardUpload extends Vue {

  @Prop(
    {
      default: 'card1',
    },
  )
  public img!: string;

  @Prop()
  public desc!: string;

  @Prop()
  public type!: number;

  private file: any = null;

  private images: ImageDict = {
    card1,
    card2,
    card3,
  };
  private uploadImg: string = this.images[this.img];
  private uploadData: UploadModel = {
    file: '',
    type: this.type,
  };

  public handleUpload(file: any) {
    this.file = file;
    this.uploadData.file = file.url;
    const upload = this.$refs.upload as any;
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.addEventListener('load', () => {
      this.uploadImg = reader.result;
    });

    return false;
  }
  @Emit('handleIdCard')
  public onUploadSuccess(res: any) {
      if (res.errcode !== 0) {
        this.$Message.error(res.errmsg);
    } else {
        this.$Message.success('上传成功');
        this.uploadImg = res.data;
        const upload = this.$refs.upload as HTMLFormElement;
        upload.clearFiles();
    }
  }

  public onUploadError(err) {
    this.$Message.error('上传失败，请检查后重试');
  }
  public upload() {
    if (this.file === null) {
        this.$Message.error('请先选择照片再上传');
        return;
    }
    const upload =  this.$refs.upload as HTMLFormElement;
    upload.post(this.file);
  }
}
</script>
