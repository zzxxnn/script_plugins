<template>
  <Card>
    <Row class="m-t-40">
      <Col :xs="{ span: 22, offset: 1 }"
           :sm="{ span: 12, offset: 6 }"
           :md="{ span: 10, offset: 7 }"
           :lg="{ span: 8, offset: 8 }">

        <Form ref="cardForm"
            :model="cardFormData"
            inline
            align="center">
          <FormItem prop="id">
              <Input type="text"
                     v-model="cardFormData.id_number"
                     placeholder="统一社会信用代码"
                     style="width: 210px"></Input>
          </FormItem>

          <FormItem>
              <Button type="primary" @click="handleCardFormSubmit('cardForm')">确认</Button>
          </FormItem>
        </Form>
      </Col>
    </Row>

    <div class="licence-block">
      <Row class="m-t-50 m-b-100" :gutter="64">
        <Col :xs="{ span: 24 }"
            :sm="{ span: 24 }"
            :md="{ span: 12, offset: 6 }"
            :lg="{ span: 12, offset: 6 }"
            class="m-b-30">
          <LicenceUpload desc="（营业执照）" :type="4" @handleCard="handleCard"/>
        </Col>

      </Row>
    </div>

  </Card>
</template>
<style lang="scss">
@import '@/assets/css/common/helper.scss';
.licence-block {
  width: 980px;
  margin: 0 auto;
  @include tablet {
    width: 100%;
  }
}
</style>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import LicenceUpload from './LicenceUpload.vue';
import { AgentModel, AgentResponse } from '@/typings/agent';
import { ProfileAuthModel, ProfileAuthResponse } from '@/typings/profile';
import AgentService from '@/services/Agent';
import ProfileService from '@/services/Profile';

@Component({
  components: {
    LicenceUpload,
  },
})
export default class LicenceVerifyForm extends Vue {

  private cardFormData: ProfileAuthModel = {
    id_number: '',
    photos: [],
  };

  public handleCard(pic) {
    this.cardFormData.photos.push({
      name: pic.data,
      type: 4,
    });
  }

  public async handleCardFormSubmit() {
    if (this.cardFormData.id_number === '') {
      this.$Message.error({
          content: '请输入统一社会信用代码',
          duration: 3,
      });
      return false;
    }
    if (this.cardFormData.photos.length !== 1) {
      this.$Message.error({
          content: '请完成统一社会信用代码照片上传再认证',
          duration: 3,
      });
      return false;
    }
    try {
      const agent: AgentResponse = await AgentService.getAgent<AgentResponse>();
      const res: ProfileAuthResponse = await ProfileService.authenticName<ProfileAuthResponse>(
        agent.data.id,
        this.cardFormData,
      );
      if (res.errcode === 0) {
        this.$Message.success('认证成功');
      } else {
        this.$Message.error({
          content: res.errmsg,
          duration: 3,
      });
      }
    } catch (err) {
      this.$Message.error({
          content: '请求数据异常！',
          duration: 3,
      });
    }
  }
}
</script>
