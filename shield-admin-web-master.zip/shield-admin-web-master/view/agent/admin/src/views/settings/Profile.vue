<template>
  <div>
    <Card class="p-t-20">
      <VUser :avatar="this.profile.img_url" :text="this.profile.user_email" />
      <VList :data="listData" />
    </Card>
  </div>
</template>
<style lang="scss">

</style>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import VUser from '@/components/VUser.vue';
import VList from '@/components/VList.vue';
import { AgentModel, AgentResponse } from '@/typings/agent';
import { ProfileModel, ProfileResponse } from '@/typings/profile';
import AgentService from '@/services/Agent';
import ProfileService from '@/services/Profile';

type profileTuple = [string, string];

@Component({
  components: {
    VUser,
    VList,
  },
})
export default class Profile extends Vue {

  private profile: ProfileModel = {
    img_url: '',
    user_email: '',
    mobile: '',
    id_number: '',
    company: '',
    client_register_url: '',
  };

  private keyLabels: object = {
    user_email: '电子邮件',
    mobile: '电话号码',
    id_number: '身份证',
    company: '公司信息',
    client_register_url: '客户注册链接',
  };

  get listData(): profileTuple[] {
    const keyLabels = this.keyLabels;

    return Object.keys(this.profile).reduce((arr: profileTuple[], key: string): profileTuple[] => {
      if (key !== 'img_url') {
        if (key === 'client_register_url') {
          if (!this.profile[key]) {
            this.profile[key] = '暂无';
          }
        }
        arr.push([keyLabels[key], this.profile[key]]);
      }
      return arr;
    }, []);
  }

  public created() {
    this.getData();
  }

  public async getData() {
    try {
      const agent: AgentResponse = await AgentService.getAgent<AgentResponse>();

      const profile: ProfileResponse = await ProfileService.getData<ProfileResponse>(agent.data.id);

      this.profile = profile.data;
    } catch (err) {
      this.$Message.error({
          content: '请求数据异常！',
          duration: 3,
      });
    }
  }

}
</script>

