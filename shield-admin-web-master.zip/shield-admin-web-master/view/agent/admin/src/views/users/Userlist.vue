<template>
  <div class="user-list">
    <div class="table-title m-b-20">
        <p>用户管理</p>
    </div>
    <Card>
        <div class="m-b-50">
            <Form ref="formInline" :model="searchData" :label-width="80" inline>
                <FormItem label="用户名">
                    <Input type="text" v-model="searchData.username" placeholder="请输入用户名"></Input>
                </FormItem>
                <FormItem label="注册日期：">
                    <DatePicker type="date" placeholder="请选择注册日期" v-model="searchData.create_time"></DatePicker>
                </FormItem>
                <FormItem label="账户余额：">
                    <Input type="text" v-model="searchData.account" placeholder="请输入账户余额"></Input>
                </FormItem>
                <FormItem label="消费总额：">
                    <Input type="text" v-model="searchData.total_spend" placeholder="请输入消费总额"></Input>
                </FormItem>
                <FormItem label="已购买高防实例个数：" :label-width="140">
                    <Input type="text" v-model="searchData.total_instance" placeholder="请输入已购买高防实例个数"></Input>
                </FormItem>
            </Form>
            <div class="tc m-b-20">
                <Button type="primary" class="m-r-20">重置</Button>
                <Button type="primary" icon="ios-search">搜索</Button>
            </div>
        </div>
        <Table :columns="columns1" :data="data1"></Table>
        <div class="tc m-t-20">
            <Page :total="total"
            :page-size-opts="sizeOpts"
            show-sizer
            show-total
            size="small"
            @on-change="onChange"
            @on-page-size-change="onChangeSize"></Page>
        </div>
    </Card>
  </div>
</template>

<style lang="scss">
@import '@/assets/css/userList.scss';
</style>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import UserInfoService from '@/services/UserInfo';

interface UserInfoModel {
    username: string;
    create_time: string;
    account: string;
    total_spend: string;
    total_instance: string;
}

interface UserInfoModels {
    list: UserInfoModel;
    total: number;
}

interface UserInfoResponse {
  errcode: number;
  errmsg: string;
  data: UserInfoModels;
}

@Component({
  components: {
  },
})
export default class Userlist extends Vue {
    private columns1 = [{
        title: '用户名',
        key: 'username',
        align: 'center',
        render: (h: any, params) => {
            return h('div', params.row.username ? params.row.username : params.row.email);
        },
    },
    {
        title: '注册日期',
        key: 'create_time',
        align: 'center',
    },
    {
        title: '账户余额',
        key: 'account',
        align: 'center',
    },
    {
        title: '消费总额',
        key: 'total_spend',
        align: 'center',
    },
    {
        title: '已购买高防实例个数',
        key: 'total_instance',
        align: 'center',
    },
    {
        title: '用户详情',
        key: 'user_info',
        width: 150,
        align: 'center',
        render: (h: any, params) => {
            return h('div', [
                h('router-link', {
                    attrs: {
                        to: `/users/UserDetail/${params.row.id}`,
                    },
                    style: {
                        marginRight: '5px',
                        textDecoration: 'underline',
                    },
                }, '详情'),
            ]);
        },
    }];
    private sizeOpts: number[] = [10, 20, 30, 40, 50];
    private data1: any = [];
    private total: number = 0;
    private searchData = {
        username: '',
        create_time: '',
        account: '',
        total_spend: '',
        total_instance: '',
    };

    private from: number = 1;
    private size: number = 10;

    public created() {
        this.getData();
    }

    get query(): object {
        return {
            _from: this.from,
            _size: this.size,
        };
    }

    public onChange(val) {
        this.from = val;
        this.getData();
    }
    public onChangeSize(val) {
        this.size = val;
        this.from = 1;
        this.getData();
    }

    public async getData() {
      try {
        const res: UserInfoResponse = await UserInfoService.getData<UserInfoResponse>(this.query);
        if (res.errcode === 0) {
          this.data1 = res.data.list;
          this.total = res.data.total;
        }
      } catch (err) {
          this.$Message.error({
            content: '请求数据异常！',
            duration: 3,
          });
      }
    }
}
</script>
