<template>
  <div class="user-detail">
    <Card class="m-b-30">
        <p slot="title">{{user.username}}用户详细信息</p>
        <Row>
            <Col span="12"><VUser :text="user.email" :avatar="user.img_url" class="v-user"></VUser></Col>
            <Col span="12" class="basic">
                <h3>基本信息</h3>
                <ul>
                    <li>手机号码：{{user.mobile?user.mobile:'-'}}</li>
                    <li>注册账号：{{user.email?user.email:'-'}}</li>
                    <li>身份证号：{{user.id_number?user.id_number:'-'}}</li>
                    <li>公司信息：卫达</li>
                </ul>
            </Col>
        </Row>
    </Card>

    <Tabs type="card"  @on-click="onChangeType">
        <TabPane label="高防实例列表">
            <Card>
                <Table :columns="columns1" :data="dataList"></Table>
                <div class="tc m-t-20">
                    <Page :total="total" show-sizer show-total size="small" @on-change="onChange"
                    @on-page-size-change="onChangeSize"></Page>
                </div>
            </Card>
        </TabPane>
        <TabPane label="受攻击情况记录">
            <Card>
                <Table :columns="columns2" :data="dataList"></Table>
                <div class="tc m-t-20">
                    <Page :total="total" show-sizer show-total size="small" @on-change="onChange"
                    @on-page-size-change="onChangeSize"></Page>
                </div>
            </Card>
        </TabPane>
        <TabPane label="消费记录">
            <Card>
                <Table :columns="columns1" :data="dataList"></Table>
                <div class="tc m-t-20">
                    <Page :total="total" show-sizer show-total size="small" @on-change="onChange"
                    @on-page-size-change="onChangeSize"></Page>
                </div>
            </Card>
        </TabPane>
    </Tabs>
  </div>
</template>

<style lang="scss">
@import '@/assets/css/userDetail.scss';
</style>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import VUser from '@/components/VUser.vue';
import UserInfoService from '@/services/UserInfo';
interface UserDetailModel {
    img_url: string;
    email: string;
    mobile: string;
    id_number: string;
    username: string;
}

interface UserDetailResponse {
  errcode: number;
  errmsg: string;
  user: UserDetailModel;
  total: number;
  data: object[];
}

@Component({
  components: {
      VUser,
  },
})
export default class Userlist extends Vue {
    private columns1 = [{
        title: '实例ID',
        key: 'id',
    },
    {
        title: '实例类型',
        key: 'type',
    },
    {
        title: '地区',
        key: 'area',
    },
    {
        title: '高防IP',
        key: 'high_ip',
    },
    {
        title: '启用时间',
        key: 'start_time',
    },
    {
        title: '结束时间',
        key: 'end_time',
    },
    {
        title: '预购保底防护带宽',
        key: 'base_bandwidth',
    },
    {
        title: '弹性防护带宽',
        key: 'bandwidth',
    }];

    private columns2 = [{
        title: '时间',
        key: 'time',
    },
    {
        title: '金额',
        key: 'fee',
    },
    {
        title: '余额',
        key: 'balance',
    }];

    private columns3 = [{
        title: '时间',
        key: 'time',
    },
    {
        title: '峰值带宽',
        key: 'summit_bandwidth',
    },
    {
        title: '持续时间',
        key: 'last_time',
    },
    {
        title: '攻击类型',
        key: 'attack_type',
    }];

    private from: number = 1;
    private size: number = 10;
    private user: object = {};
    private dataList: object[] = [];
    private total: number = 0;
    private type: string = 'instance';

    public created() {
        this.getData();
    }

    get userId(): string {
        return this.$route.params.id;
    }

    get query(): object {
        return {
            type: this.type,
            _from: this.from,
            _size: this.size,
        };
    }

    public onChangeType(type) {
        switch (type) {
          case 0:
            this.type = 'instance';
            break;
          case 1:
            this.type = 'attack';
            break;
          case 2:
            this.type = 'customer';
            break;
          default:
            this.type = 'instance';
        }
        this.getData();
    }

    public onChange(val) {
        this.from = val;
        this.getData();
    }
    public onChangeSize(val) {
        this.size = val;
        this.getData();
    }

    public async getData() {
      try {
        const res: UserDetailResponse = await UserInfoService.getDetail<UserDetailResponse>(this.userId, this.query);
        if (res.errcode === 0) {
          this.user = res.user;
          this.dataList = res.data;
          this.total = res.total;
        }
      } catch (err) {
          this.$Message.error({
            content: '请求数据异常！',
            duration: 3,
          });
      }
    }
}
</script>
