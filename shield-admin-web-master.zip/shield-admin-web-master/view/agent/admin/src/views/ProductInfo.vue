<template>
  <Card :bordered="false" class="product-info">
      <p slot="title">产品资料</p>
      <ul class="p-l-25 download-list">
        <li :class="{'m-b-10': index !== listData.length - 1}" v-for="(item, index) in listData" :key="item.name">
          <span class="m-r-30">
            {{item.name}}
            <a :href="item.url" target="_blank">浏览</a>
          </span>
          <i class="icon iconfont icon-download blue vc"></i>
          <a :href="item.url" :download="item.url | download">
            下载
          </a>
        </li>
      </ul>
  </Card>
</template>

<style scoped lang="scss">
@import '@/assets/css/productInfo.scss';

a {
  color: $blue;
}
</style>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { ProductInfoModel, ProductInfoResponse } from '@/typings/productInfo';
import ProductInfoService from '@/services/ProductInfo';

@Component({
  filters: {
    download(val) {
      return val.slice(val.lastIndexOf('_') + 1);
    },
  },
})
export default class ProductInfo extends Vue {

  private listData: object[] = [];

  public created() {
    this.getData();
  }

  public async getData() {
    try {
      const res: ProductInfoResponse = await ProductInfoService.getData<ProductInfoResponse>();

      if (res.errcode === 0) {
        this.listData = res.list;
      }
    } catch (err) {
      this.$Message.error({
        content: '请求数据异常！',
        duration: 3,
      });
    }
  }
}
</script>
