// 用户名（只能包含数字/字母/下划线，8-16位）：
// 密码（必须是包含数字和字母的8-16位字符串）：/^(?=.*[0-9].*)(?=.*[a-zA-Z].*).{8,16}$/

const usernameReg = /^[A-Za-z0-9\-\_]+$/;
const passwordReg = /^(?=.*[0-9].*)(?=.*[a-zA-Z].*).{8,16}$/;
const phoneReg = /^1(?:3\d|4[4-9]|5[0-35-9]|6[67]|7[013-8]|8\d|9\d)\d{8}$/;
const emailReg = /^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/;

interface IReg {
  validateUsername(val: string): boolean;
  validatePassword(val: string): boolean;
}
class Reg implements IReg {

  public validateUsername(val: string): boolean {
    return usernameReg.test(val);
  }

  public validatePassword(val: string): boolean {
    return passwordReg.test(val);
  }

  public validatePhone(val: string): boolean {
    return phoneReg.test(val);
  }

  public validateEmail(val: string): boolean {
    return emailReg.test(val);
  }
}

export default new Reg();
