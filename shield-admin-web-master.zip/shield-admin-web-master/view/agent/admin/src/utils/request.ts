import axios, { Canceler } from 'axios';
import Vue, { VueConstructor } from 'vue';
import NProgress from 'nprogress';
import 'nprogress/nprogress.css';

interface IPromiseArr {
  [key: string]: Canceler;
}

let cancel: Canceler;
const promiseArr: IPromiseArr = {};
const CancelToken = axios.CancelToken;

axios.defaults.baseURL = '/v1';
// 设置默认请求头
axios.defaults.headers = {
  'X-Requested-With': 'XMLHttpRequest',
};
axios.defaults.timeout = 10000;

// 请求拦截器
axios.interceptors.request.use((config) => {
  // 发起请求时，取消掉当前正在进行的相同请求
  if (promiseArr[config.url!]) {
    promiseArr[config.url!]('操作取消');
    promiseArr[config.url!] = cancel;
  } else {
    NProgress.start();
    promiseArr[config.url!] = cancel;
  }
  return config;
}, (err) => {
  return Promise.reject(err);
});

// 响应拦截器即异常处理
axios.interceptors.response.use((res) => {
  NProgress.done();
  return res;
}, (err) => {
  if (err && err.errcode) {
    Vue.prototype.$Message.error({
      content: err.errmsg,
    });
  }

  return Promise.resolve(err.response);
});

export class Request {
  // get请求
  public get<T>(url: string, param?: any): Promise<T> {
    return new Promise((resolve, reject) => {
      axios({
        method: 'get',
        url,
        params: param,
        cancelToken: new CancelToken((c) => {
          cancel = c;
        }),
      }).then((res) => {
        const data = res.data as T;
        resolve(data);
      });
    });
  }

  // post请求
  public post<T>(url: string, param?: any): Promise<T> {
    return new Promise((resolve, reject) => {
      axios({
        method: 'post',
        url,
        data: param,
        cancelToken: new CancelToken((c) => {
          cancel = c;
        }),
      }).then((res) => {
        const data = res.data as T;
        resolve(data);
      });
    });
  }

  public put<T>(url: string, param?: any): Promise<T> {
    return new Promise((resolve, reject) => {
      axios({
        method: 'put',
        url,
        data: param,
        cancelToken: new CancelToken((c) => {
          cancel = c;
        }),
      }).then((res) => {
        const data = res.data as T;
        resolve(data);
      });
    });
  }
}

// export default {
//   install: (vue: VueConstructor) => {
//     Vue.prototype.$Message.config({
//       top: 50,
//       duration: 3,
//     });
//     Object.defineProperty(vue.prototype, '$http', { value: new Request() });
//   },
// };

export default new Request();
