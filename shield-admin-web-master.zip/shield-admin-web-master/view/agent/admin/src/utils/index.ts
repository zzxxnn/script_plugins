import reg from './reg';

export function getQuery(name: string): null | string {
  const regexp = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
  const r = window.location.search.substr(1).match(regexp);
  if (r !== null) {
    return unescape(r[2]);
  } else {
    return null;
  }
}
export {
  reg,
};

