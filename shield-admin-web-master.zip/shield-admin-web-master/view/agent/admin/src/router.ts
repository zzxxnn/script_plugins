import Vue from 'vue';
import Router from 'vue-router';

Vue.use(Router);

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '',
      name: 'home',
      component: () => import('./views/Home.vue') as any,
    },
    {
      path: '/assets',
      component: () => import('./views/assets/Index.vue') as any,
      children: [
        {
          path: '',
          name: 'assets',
          component: () => import('./views/assets/Assets.vue') as any,
        },
        {
          path: 'withdraw',
          name: 'withdraw',
          component: () => import('./views/assets/Withdraw.vue') as any,
        },
        {
          path: 'withdrawSetting',
          name: 'withdrawSetting',
          component: () => import('./views/assets/WithdrawSetting.vue') as any,
        },
      ],
    },
    {
      path: '/users',
      component: () => import('./views/users/Index.vue') as any,
      children: [
        {
          path: '',
          name: 'users',
          component: () => import('./views/users/Userlist.vue') as any,
        },
        {
            path: 'userList',
            name: 'userList',
            component: () => import('./views/users/Userlist.vue') as any,
        },
        {
            path: 'userDetail/:id',
            name: 'userDetail',
            component: () => import('./views/users/UserDetail.vue') as any,
        },
      ],
    },
    {
      path: '/productInfo',
      name: 'productInfo',
      component: () => import('./views/ProductInfo.vue') as any,
    },
    {
        path: '/msgCenter',
        component: () => import('./views/message/Index.vue') as any,
        children: [
            {
                path: '',
                name: 'msgCenter',
                component: () => import('./views/message/MsgCenter.vue') as any,
            },
            {
                path: 'list',
                name: 'list',
                component: () => import('./views/message/MsgCenter.vue') as any,
            },
            {
              path: 'Detail/:id',
              name: 'Detail',
              component: () => import('./views/message/MsgDetail.vue') as any,
            },
          ],
    },
    {
      path: '/settings',
      component: () => import('./views/settings/Index.vue') as any,
      children: [
        {
          path: '',
          name: 'settings',
          component: () => import('./views/settings/Profile.vue') as any,
        },
        {
          path: 'profile',
          name: 'profile',
          component: () => import('./views/settings/Profile.vue') as any,
        },
        {
          path: 'certify',
          name: 'certify',
          component: () => import('./views/settings/Certify.vue') as any,
        },
        {
          path: 'pwdReset',
          name: 'pwdReset',
          component: () => import('./views/settings/PwdReset.vue') as any,
        },
        {
          path: 'registerLink',
          name: 'registerLink',
          component: () => import('./views/settings/RegisterLink.vue') as any,
        },
      ],
    },
  ],
});
