import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    login: {is_login: false, uemail: '', img_url: ''},
  },
  mutations: {
    EDIT_NOTE(state, text) {
        state.login = text;
    },
  },
  actions: {

  },
});
