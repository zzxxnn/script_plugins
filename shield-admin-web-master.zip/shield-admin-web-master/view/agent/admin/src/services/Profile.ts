import $http from '@/utils/request';

class ProfileService {
  public getData<T>(id: string): Promise<T> {
    return $http.get<T>(`/profile/${id}`, null);
  }
  public authenticName<T>(id: string, params): Promise<T> {
    return $http.post<T>(`/profile/${id}/real-name-authentication`, params);
  }
}

export default new ProfileService();
