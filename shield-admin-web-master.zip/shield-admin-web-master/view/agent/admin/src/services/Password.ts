import $http from '@/utils/request';

class PasswordService {
  public update<T>(params: object): Promise<T> {
    return $http.put(`/password`, params);
  }
}

export default new PasswordService();
