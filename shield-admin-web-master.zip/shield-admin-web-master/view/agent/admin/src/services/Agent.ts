import $http from '@/utils/request';

class AgentService {
  public getAgent<T>(): Promise<T> {
    return $http.get<T>('/agent', null);
  }
}

export default new AgentService();
