import $http from '@/utils/request';

class MessageService {
  public getData<T>(params): Promise<T> {
    return $http.get('/message', params);
  }

  public getDetail<T>(id): Promise<T> {
    return $http.get(`/message/${id}`, null);
  }
}

export default new MessageService();
