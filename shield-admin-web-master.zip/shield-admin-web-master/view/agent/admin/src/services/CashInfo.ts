import $http from '@/utils/request';

class CashInfoService {
  public getData() {
    return $http.get('/cash', null);
  }
  public addData<T>(params: object): Promise<T> {
    return $http.post('/cash', params);
  }
}

export default new CashInfoService();
