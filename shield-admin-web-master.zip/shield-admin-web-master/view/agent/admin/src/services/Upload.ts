import $http from '@/utils/request';

class UploadService {
  public update<T>(params: object): Promise<T> {
    return $http.post(`/photo/upload`, params);
  }
}

export default new UploadService();
