import $http from '@/utils/request';

class SessionService {
  public logout<T>(): Promise<T> {
    return $http.post<T>('/logout');
  }
}

export default new SessionService();
