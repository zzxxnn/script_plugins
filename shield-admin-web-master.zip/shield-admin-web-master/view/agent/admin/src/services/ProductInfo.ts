import $http from '@/utils/request';

class ProductInfoService {
  public getData<T>(): Promise<T> {
    return $http.get<T>('/product-information', null);
  }
}

export default new ProductInfoService();
