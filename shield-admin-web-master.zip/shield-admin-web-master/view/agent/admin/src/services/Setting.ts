import $http from '@/utils/request';

class SettingService {
  public getProfile<T>(query: object): Promise<T> {
    return $http.get('/user', query);
  }
}

export default new SettingService();
