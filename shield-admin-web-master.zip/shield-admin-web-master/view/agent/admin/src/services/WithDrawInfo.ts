import $http from '@/utils/request';

class WithDrawInfoService {
  public getData<T>(): Promise<T> {
    return $http.get('/withdraw', null);
  }

  public updateData<T>(params: object, id): Promise<T> {
    return $http.put(`/withdraw/${id}`, params);
  }
}

export default new WithDrawInfoService();
