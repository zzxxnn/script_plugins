import $http from '@/utils/request';

class AssetsService {
  public getList<T>(query: object): Promise<T> {
    return $http.get<T>('/cash', query);
  }
}

export default new AssetsService();
