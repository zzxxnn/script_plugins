import $http from '@/utils/request';

class UserInfoService {
  public getData<T>(query: object): Promise<T> {
    return $http.get('/user', query);
  }
  public getDetail<T>(id: string, query: object): Promise<T> {
    return $http.get(`/user/${id}`, query);
  }
}

export default new UserInfoService();
