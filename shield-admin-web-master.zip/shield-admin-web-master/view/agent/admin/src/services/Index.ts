import $http from '@/utils/request';

class IndexService {
  public getData<T>(): Promise<T> {
    return $http.get('/agent', null);
  }
}

export default new IndexService();
