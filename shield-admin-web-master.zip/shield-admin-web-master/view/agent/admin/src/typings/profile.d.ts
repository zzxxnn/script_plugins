export interface ProfileModel {
  img_url: string;
  user_email: string;
  mobile: string;
  id_number: string;
  company: string;
  client_register_url?: string;
}

export interface ProfileResponse {
  data: ProfileModel;
}
export interface ProfilePhotoModel {
  name: string;
  type: number;
}

export interface ProfileAuthModel {
  id_number: string;
  photos: ProfilePhotoModel[];
}

export interface ProfileAuthResponse {
  errmsg: string;
  errcode: number;
}
