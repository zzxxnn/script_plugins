export interface PasswordModel {
    old_password: string;
    new_password: string;
    confirm_password: string;
  }

export interface PasswordResponse {
    errcode: number;
    errmsg: string;
  }

