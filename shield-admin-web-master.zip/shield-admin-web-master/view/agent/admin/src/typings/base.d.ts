export interface IResponse {
  errcode: number;
  errmsg: string;
  data?: any;
}
