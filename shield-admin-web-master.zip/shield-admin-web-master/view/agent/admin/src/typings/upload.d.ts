export interface UploadModel {
    file: string;
    type: number;
  }

export interface UploadResponse {
    errcode: number;
    errmsg: string;
    data: string;
  }

