export interface AssetModel {
  agent_id: number;
  amount: string;
  after_amount: string;
  agent_name: string;
  cash_sn: string;
  create_time: string;
  express_company: string;
  express_number: string;
  id: number;
  invoice_number: string;
  proof: number;
  status: number;
  status_name: string;
  update_time: string;
}

export interface AssetsModel {
  list: AssetModel[];
  total: number;
}

export interface AssetsResponse {
  data: AssetsModel;
}
