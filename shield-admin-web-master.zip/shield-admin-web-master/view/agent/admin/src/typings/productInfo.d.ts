export interface ProductInfoModel {
  name: string;
  url: string;
}

export interface ProductInfoResponse {
  errcode: number;
  errmsg: string;
  list: ProductInfoModel[];
}
