export interface IndexModel {
    id: number;
  }
export interface IndexResponse {
    errcode: number;
    errmsg: string;
    data: IndexModel;
  }
