declare module 'nprogress' {
  const NProgress: any;
  export default NProgress;
}
