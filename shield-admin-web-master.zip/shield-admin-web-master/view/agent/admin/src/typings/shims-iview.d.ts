declare module 'iview' {
  const Iview: any
  export default Iview
}