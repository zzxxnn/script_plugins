export interface MessageModel {
  id: number;
  title: string;
  content: string;
  type: number;
  type_name: string;
  status: string;
  create_time: string;
}

export interface MessageResponse {
  errcode: number;
  errmsg: string;
  data: MessageModel[];
}
