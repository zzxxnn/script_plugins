export interface AgentModel {
  id: string;
  user_email: string;
  img_url: string;
  cash_confirmed: number;
  cash_has_been: number;
  cash_all: number;
  user_type: string;
  user_number: number;
  mobile: string;
}
export interface AgentResponse {
  errcode: number;
  errmsg: string;
  data: AgentModel;
}
