export interface WithDrawInfoModel {
  avatar: string;
  bank: string;
  bank_account: string;
  bank_card: string;
  email: string;
}

export interface WithDrawInfoResponse {
  errcode: number;
  errmsg: string;
  data: WithDrawInfoModel;
}

