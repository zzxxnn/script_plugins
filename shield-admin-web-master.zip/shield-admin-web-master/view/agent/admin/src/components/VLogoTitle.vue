<template>
  <div class="logo-title">
    <img src="@/assets/img/logo.png" class="logo">
    <h1 class="title m-l-10">幻盾云代理商系统</h1>
  </div>
</template>
<style scoped lang="scss">
.logo-title {
  display: inline-block;
}
.logo {
  width: 40px;
}
.title {
  display: inline;
  margin: 0;
  font-size: 20px;
  color: #fff;
  vertical-align: middle;
}
</style>
<script type="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component
export default class VLogoTitle extends Vue {}
</script>