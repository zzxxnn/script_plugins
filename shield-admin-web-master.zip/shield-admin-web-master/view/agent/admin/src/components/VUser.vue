<template>
  <div class="tc">
    <div class="avatar m-b-10">
      <img :src="avatar">
    </div>
    <p>{{text}}</p>
  </div>
</template>
<style scoped lang="scss">
.avatar {
  margin: 0 auto;
  width: 64px;
  height: 64px;
  overflow: hidden;
  img {
    width: 100%;
    border-radius: 50%;
  }
}
p {
  line-height: 1;
  color: $gray;
}
</style>
<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import defaultAvatar from '@/assets/img/default-avatar.png';

@Component
export default class VUser extends Vue {

  @Prop({
    default: defaultAvatar,
  })
  public avatar?: string;

  @Prop({
    default: '无',
  })
  public text?: string;

}
</script>
