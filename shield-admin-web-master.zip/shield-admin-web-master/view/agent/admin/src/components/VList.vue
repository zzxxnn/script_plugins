<template>
  <ul class="m-t-30 m-l-30 m-r-30 m-b-30">
    <li v-for="(item, index) in data" 
        :key="index" 
        class="clearfix p-t-10 p-b-10">
      <h3 class="fl p-l-40">{{item[0]}}：</h3>
      <p class="fl p-l-15">{{item[1]}}</p>
    </li>
  </ul>
</template>
<style scoped lang="scss">
ul {
  border-bottom: 1px solid $bg-color;
  li {
    border-top: 1px solid $bg-color;
    h3 {
      width: 30%;
      color: $black;
      font-size: 14px;
    }
    p {
      width: 70%;
    }
  }
}
</style>
<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class VList extends Vue {

  @Prop({
    type: Array,
    default: () => [
        ['电话号码', 12345678910],
        ['身份证', 3398422392309203],
        ['电子邮件', 'test@veda.com'],
        ['公司信息', '北京卫达信息技术有限公司'],
        ['客户注册链接', 'sfdxxxaabbb@veda.com'],
      ],
  })
  public data!: any[];

}
</script>
