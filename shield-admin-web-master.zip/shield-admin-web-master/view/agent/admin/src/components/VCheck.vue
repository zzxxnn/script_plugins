<template>
  <div class="check-card">
      <p class="m-b-15">{{title}}</p>
      <h3 class="m-b-15">{{content}}</h3>
      <Button type="primary" size="small" @click="checkOut">查看</Button>
  </div>
</template>
<style scoped lang="scss">
@import '@/assets/css/common/helper.scss';
.check-card {
    background: #FFFFFF;
    text-align:  center;
    p {
        font-size: 12px;
        color: #535353;
    }
    h3 {
        font-size: 16px;
        color: #535353;
    }
}
</style>
<script lang="ts">
import { Component, Vue, Prop, Emit } from 'vue-property-decorator';
@Component
export default class VCheck extends Vue {
    @Prop({
        default: ' ',
    })
    private title!: string;

    @Prop({
        default: ' ',
    })
    private content!: string;

    @Emit('click')
    private checkOut() {
        return '';
    }
}
</script>
