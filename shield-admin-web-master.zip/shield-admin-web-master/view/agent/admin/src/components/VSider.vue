<template>
  <Sider class="vsider" width="160">
    <Menu :active-name="activeName"
          width="auto"
          :open-names="openNames"
          @on-select="handleMenuSelect"
          ref="sideMenu">
        <MenuItem name="/">
            <i class="icon iconfont icon-home"></i>
            <span>首页</span>
        </MenuItem>
        <Submenu name="assets">
            <template slot="title">
                <i class="icon iconfont icon-assets"></i>
                <span>资产管理</span>
            </template>
            <MenuItem name="/assets">资产查询</MenuItem>
            <MenuItem name="/assets/withdrawSetting">提现账号设置</MenuItem>
            <MenuItem name="/assets/withdraw">提现</MenuItem>
        </Submenu>
        <Submenu name="users">
            <template slot="title">
                <i class="icon iconfont icon-users"></i>
                <span>用户管理</span>
            </template>
            <MenuItem name="/users/userList">用户列表</MenuItem>
        </Submenu>
        <MenuItem name="/productInfo">
            <i class="icon iconfont icon-product"></i>
            <span>产品资料</span>
        </MenuItem>
        <MenuItem name="/logs">
            <i class="icon iconfont icon-log"></i>
            <span>日志管理</span>
        </MenuItem>
        <MenuItem name="/msgCenter/list">
            <i class="icon iconfont icon-msg"></i>
            <span>消息管理</span>
        </MenuItem>
        <Submenu name="settings">
            <template slot="title">
                <i class="icon iconfont icon-setting"></i>
                <span>设置</span>
            </template>
            <MenuItem name="/settings/profile">个人资料</MenuItem>
            <MenuItem name="/settings/certify">实名认证</MenuItem>
            <MenuItem name="/settings/pwdReset">密码重置</MenuItem>
            <MenuItem name="/settings/registerLink">客户注册链接查询</MenuItem>
        </Submenu>
    </Menu>
  </Sider>
</template>
<style lang="scss">
.vsider {
    background-color: $primary-color;

    .ivu-menu-item,
    .ivu-menu-submenu-title {
        padding-left: 40px !important;
        padding-right: 12px !important;
    }

    .ivu-menu-submenu .ivu-menu-item {
        padding-left: 57px !important;
    }

    .menu-item span {
        display: inline-block;
        overflow: hidden;
        width: 69px;
        text-overflow: ellipsis;
        white-space: nowrap;
        vertical-align: bottom;
        transition: width .2s ease .2s;
    }
    .menu-item i {
        transform: translateX(0px);
        transition: font-size .2s ease, transform .2s ease;
        vertical-align: middle;
        font-size: 16px;
    }
    .collapsed-menu {
        span {
            width: 0px;
            transition: width .2s ease;
        }
        i {
            transform: translateX(5px);
            transition: font-size .2s ease .2s, transform .2s ease .2s;
            vertical-align: middle;
            font-size: 22px;
        }
    }

}
</style>
<script lang="ts">
import { Component, Watch, Vue } from 'vue-property-decorator';

@Component
export default class VSider extends Vue {

    private activeName: string = '';

    private openNames: string[]  = [];

    @Watch('$route')
    public onRouteChanged(val: any, oldVal: any) {
        const path = val.path;
        if (path === '/users') {
            this.activeName = '/users/userList';
        } else if (path === '/assets') {
            this.activeName = '/assets';
        } else if (path === '/settings') {
            this.activeName = '/settings/profile';
        } else {
            this.activeName = path;
        }

        if (path.indexOf('users') !== -1) {
            this.openNames = ['users'];
        } else if (path.indexOf('assets') !== -1) {
            this.openNames = ['assets'];
        } else if (path.indexOf('settings') !== -1) {
            this.openNames = ['settings'];
        } else {
            this.openNames = [];
        }

        this.$nextTick(() => {
            const sideMenu: any = this.$refs.sideMenu;
            sideMenu.updateOpened();
            sideMenu.updateActiveName();
        });
    }

    public handleMenuSelect(path: string) {
        this.$router.push(path);
    }
}
</script>
