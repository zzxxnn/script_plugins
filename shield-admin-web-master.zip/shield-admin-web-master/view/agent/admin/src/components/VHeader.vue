<template>
  <div class="header">
    <Header>
      <router-link to="/">
        <VLogoTitle></VLogoTitle>
      </router-link>
      <div class="fr">
        <span class="m-r-15">{{userEmail}}</span>
        <a href="#" class="m-r-20">
          <img class="user-img" :src="imgUrl">
        </a>
        <a @click.prevent="handleLogout">
          <img class="logout-img" src="@/assets/img/icon-logout.png">
        </a>
      </div>
    </Header>
  </div>
</template>
<style scoped lang="scss">
.header {
  width: 100%;
  color: #fff;
  font-size: 12px;
  border-bottom: 2px solid red;
  background-color: $primary-color;

  .user-img {
    width: 27px;
  }
  .logout-img {
    width: 17px;
  }
}
</style>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { IResponse } from '@/typings/base';
import SessionService from '@/services/Session';
import VLogoTitle from '@/components/VLogoTitle.vue';
import AgentService from '@/services/Agent';
import { AgentModel, AgentResponse } from '@/typings/agent';

@Component({
  components: {
    VLogoTitle,
  },
})
export default class VHeader extends Vue {
  private userEmail: string = '';
  private imgUrl: string = '';
  public created() {
      this.getAgent();
  }

  public async handleLogout() {
    try {
      const res: IResponse = await SessionService.logout<IResponse>();

      if (res.errcode === 0) {
        window.location.href = '/user/login';
      }
    } catch (err) {
      this.$Message.error({
        content: '请求数据异常！',
        duration: 3,
      });
    }
  }
  public async getAgent() {
    try {
        const res: AgentResponse = await AgentService.getAgent<AgentResponse>();
        if (res.errcode === 0) {
            this.userEmail = res.data.user_email;
            this.imgUrl = res.data.img_url;
        }

    } catch (err) {
        this.$Message.error({
            content: '请求数据异常！',
            duration: 3,
        });
    }
  }
}
</script>
