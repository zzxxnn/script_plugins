<template>
    <div>
        <div :id="id" style="height: 400px;"></div>
    </div>
</template>

<style lang="scss">
@import '@/assets/css/assets.scss';
</style>
<script lang="ts">
import { Component, Vue, Prop} from 'vue-property-decorator';

import G2 from '@antv/g2';

@Component({
  components: {

  },
})
export default class LinesChart extends Vue {
    @Prop({
        default: ' ',
    })
    private id!: string;

    private data = [{
        time: '7月1日',
        sales: 38,
        }, {
        time: '7月2日',
        sales: 52,
        }, {
        time: '7月3日',
        sales: 61,
        }, {
        time: '7月4日',
        sales: 145,
        }, {
        time: '7月5日',
        sales: 48,
        }, {
        time: '7月6日',
        sales: 38,
        }, {
        time: '7月7日',
        sales: 38,
        }, {
        time: '7月8日',
        sales: 38,
        }];

    public initLine() {
        const chart = new G2.Chart({
        container: this.id,
        forceFit: true,
        height: 400,
        });
        chart.source(this.data);
        chart.tooltip({
            crosshairs: {
                type: 'y',
            },
        });
        chart.scale('sales', {
        tickInterval: 20,
        });
        chart.line().position('time*sales').color('#b6ed8f').shape('smooth');
        chart.point().position('time*sales').color('#b6ed8f').size(4).shape('circle').style({
            stroke: '#fff',
            lineWidth: 1,
        });
        chart.render();
    }

    public mounted() {
        this.initLine();
    }
}
</script>

