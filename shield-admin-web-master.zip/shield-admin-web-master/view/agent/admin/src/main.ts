import 'babel-polyfill';
import Vue from 'vue';
import iView from 'iview';
import 'iview/dist/styles/iview.css';
import '@/assets/css/iview.app.scss';
import '@/assets/css/common/reset.scss';
import '@/assets/css/common/helper.scss';
import '@/assets/font/iconfont.css';
import '@/assets/css/app.scss';
// import LoginService from '@/services/Login';
// import { AgentModel, AgentResponse } from '@/typings/agent';
import router from './router';
import store from './store';
import App from './App.vue';
import axios from 'axios';

Vue.config.productionTip = false;

Vue.use(iView);

new Vue({
    router,
    store,
    render: (h) => h(App),
}).$mount('#app');
