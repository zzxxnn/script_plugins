<template>
    <div class="app">
      <div class="layout">
        <Layout>
            <VHeader></VHeader>
            <Layout class="ivu-layout-has-sider">
                <VSider></VSider>
                <Layout :style="{padding: '24px'}">
                    <Content>
                        <router-view/>
                    </Content>
                </Layout>
            </Layout>
        </Layout>
      </div>
    </div>
</template>

<style lang="scss">

</style>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import VHeader from '@/components/VHeader.vue';
import VSider from '@/components/VSider.vue';

@Component({
  components: {
    VHeader,
    VSider,
  },
})
export default class App extends Vue {}
</script>
