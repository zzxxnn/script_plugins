<?php

use think\migration\Seeder;

class AddPassiveReconnConfigSeeder extends Seeder
{
    /**
     * 添加被动回链配置
     */
    public function run()
    {
        $config = [
            [
                'src_ip'    =>  '10.122.2.2',
                'dst_ip'    =>  '10.11.22.1,10.11.22.21,10.11.23.1/24',
                'dst_ip_ids'=>  '1',    
                'priv_ip'   =>  '1.1.1.1',
                'username'  =>  'test',
                'protocol'  =>  'UDP',
                'src_port'  =>  '3000',
                'dst_port'  =>  '1000',
                'real_port' =>  '81'
            ],
            [
                'src_ip'    =>  '10.122.2.3',
                'dst_ip'    =>  '10.22.25.1/24',
                'dst_ip_ids'=>  '2',    
                'priv_ip'   =>  '1.1.1.2',
                'username'  =>  'vedasec',
                'protocol'  =>  'TCP',
                'src_port'  =>  '564',
                'dst_port'  =>  '456',
                'real_port' =>  '881'
            ]
        ];

        $table = $this->table('passive_reconn_config');
        $table->insert($config)->save();
    }
}