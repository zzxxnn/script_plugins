<?php

use think\migration\Seeder;

class AddGplusEquipmentsSeeder extends Seeder
{
    /**
     * 添加前端机 “G+” 设备信息
     */
    public function run()
    {

        $configJson = file_get_contents(__DIR__ . DS . '..' .DS. 'datas' . DS . 'GplusInit.json');
        $configArray = json_decode($configJson, true);
        $config = [];

        if($configArray){

            foreach($configArray as $k => $i){
                $tmp['g_plus_ip'] = $k;
                $tmp['g_ips'] = implode(',', $i);
                $config[] = $tmp;
            }

            $table = $this->table('gplus_equipments');
            $table->insert($config)->save();

        }
    }
}