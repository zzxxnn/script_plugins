<?php

use think\migration\Seeder;

class AddDisguiseIpPoolSeeder extends Seeder
{
    /**
     * 添加伪装原型池数据
     */
    public function run()
    {
        $config = [
            [
                'ip'    =>  '10.11.22.1,10.11.22.21,10.11.23.1/24',
                'note'  =>  'test1',
                'used'  =>  1
            ],
            [
                'ip'    =>  '10.22.25.1/24',
                'note'  =>  'test2',
                'used'  =>  1
            ],
            [
                'ip'    =>  '192.168.25.22',
                'note'  =>  'test3',
                'used'  =>  0
            ],
            [
                'ip'    =>  '192.168.25.23,192.168.25.24,192.168.25.25',
                'note'  =>  '',
                'used'  =>  0
            ],
            [
                'ip'    =>  '192.168.22.1/24',
                'note'  =>  '',
                'used'  =>  0
            ],
            [
                'ip'    =>  '192.168.26.1/24,192.168.27.11',
                'note'  =>  '',
                'used'  =>  0
            ]
        ];

        $table = $this->table('disguise_ip_pool');
        $table->insert($config)->save();
    }
}
