<?php

use think\migration\Seeder;

class AddCommonConfigSeeder extends Seeder
{
    /**
     * 添加公用配置表数据
     */
    public function run()
    {
        $config = [
            [
                'name'          =>  'virtual_vpn',
                'json_content'  =>  '{"ip":"1.1.1.1", "port":90, "protocol":"UDP"}'
            ],
            [
                'name'  =>  'private_ip_range',
                'value' =>  '2.2.2.2/24'
            ],
            [
                'name'          =>  'g_upload_rule',
                'json_content'  =>  '{"ip":"1.1.1.1", "port":90, "username":"admin", "password":"123", "filepath":"/usr/test"}'
            ]
        ];

        $table = $this->table('common_config');
        $table->insert($config)->save();
    }
}