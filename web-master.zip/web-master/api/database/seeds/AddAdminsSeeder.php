<?php

use think\migration\Seeder;
use think\helper\Hash;

class AddAdminsSeeder extends Seeder
{
    /**
     * 写入用户表信息
     */
    public function run()
    {
        $admins = [
            [
                'account'   =>  'admin',
                'password'  =>  Hash::make('veda2017', 'bcrypt'),
            ]
        ];

        $adminTable = $this->table('admins');
        $adminTable->insert($admins)->save();
    }
}