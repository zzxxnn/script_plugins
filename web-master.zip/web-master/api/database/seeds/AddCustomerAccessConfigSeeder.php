<?php

use think\migration\Seeder;

class AddCustomerAccessConfigSeeder extends Seeder
{
    /**
     * 写入用户接入信息
     */
    public function run()
    {
        $config = [
            [
                'username'      =>  'test',
                'private_ip'    =>  '1.1.1.1',
                'disguise_ip'   =>  '192.168.25.22',
                'disguise_ip_ids' => '3',
                'ip_change_time'=>   30000,
                'protocol'      =>  'TCP'
            ],
            [
                'username'      =>  'vedasec',
                'private_ip'    =>  '1.1.1.2',
                'disguise_ip'   =>  '192.168.25.23,192.168.25.24,192.168.25.25',
                'disguise_ip_ids' => '4',
                'ip_change_time'=>   60,
                'protocol'      =>  'UDP'
            ],
            [
                'username'      =>  'admin',
                'private_ip'    =>  '1.1.1.3',
                'disguise_ip'   =>  '192.168.22.1/24|192.168.26.1/24,192.168.27.11',
                'disguise_ip_ids' => '5,6',
                'ip_change_time'=>   100000,
                'protocol'      =>  'TCP'
            ]
        ];

        $table = $this->table('customer_access_config');
        $table->insert($config)->save();
    }
}