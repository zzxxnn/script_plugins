<?php

use think\migration\Migrator;
use think\migration\db\Column;

class CreateAdminsTable extends Migrator
{
    /**
     * 用户表
     */
    public function change()
    {
        $admins = $this->table('admins');
        $admins->addColumn('account', 'string', ['limit' => 50,'comment' => '用户名'])
            ->addColumn('password', 'string', ['comment' => '密码'])
            ->addColumn('create_time', 'timestamp', ['default' => 'CURRENT_TIMESTAMP'])
            ->addColumn('last_login_time', 'timestamp', [
                'null'    => true,
                'default' => null
            ])
            ->create();
    }
}
