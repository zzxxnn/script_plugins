<?php

use think\migration\Migrator;
use think\migration\db\Column;

class CommonConfig extends Migrator
{
    /**
     * 创建公用配置表
     */
    public function change()
    {
        $table = $this->table('common_config');
        $table->addColumn('name', 'string', ['limit' => 255, 'comment' => '配置项名称'])
            ->addColumn('value', 'string', [
                'limit'   => 255,
                'null'    => true,
                'default' => null,
                'comment' => '配置值'
            ])
            ->addColumn('json_content', 'text', [
                'null'    => true,
                'default' => null,
                'comment' => 'json配置值'
            ])
            ->addTimestamps()
            ->create();
    }
}
