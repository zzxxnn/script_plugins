<?php

use think\migration\Migrator;
use think\migration\db\Column;

class CreateDisguiseIpPool extends Migrator
{
    /**
     * 被动回链配置表
     */
    public function change()
    {
        $table = $this->table('disguise_ip_pool');
        $table->addColumn('ip', 'string', ['limit' => 255, 'comment' => '伪装原型IP，任意IP格式，多个使用逗号隔开'])
            ->addColumn('note', 'string', [
                'limit'   => 255, 
                'null'    => true,
                'default' => null,
                'comment' => '备注信息'
            ])
            ->addColumn('used', 'integer', [
                'limit'   => 1, 
                'default' => 0,
                'comment' => '0代表未占用，1为已占用'
                ])
            ->addTimestamps()
            ->create();
    }
}
