<?php

use think\migration\Migrator;
use think\migration\db\Column;
use Phinx\Db\Adapter\MysqlAdapter;

class CreateCustomerAccessConfig extends Migrator
{
    /**
     * 用户接入配置表
     */
    public function change()
    {
        $table = $this->table('customer_access_config');
        $table->addColumn('username', 'string', ['limit' => 20, 'comment' => '用户名'])
            ->addColumn('private_ip', 'string', ['limit' => 20, 'comment' => '私有IP'])
            ->addColumn('disguise_ip', 'string', ['limit' => 255, 'comment' => '伪装原型池IP'])
            ->addColumn('disguise_ip_ids', 'string', ['limit' => 255, 'comment' => '伪装原型池ID'])
            ->addColumn('disguise_port', 'integer', [
                'limit' => MysqlAdapter::INT_REGULAR, 
                'null' => true, 
                'default' => null,
                'comment' => '伪装端口'
            ])
            ->addColumn('protocol', 'string', ['limit' => 255, 'comment' => '协议'])
            ->addColumn('ip_change_time', 'integer', [
                'limit' => MysqlAdapter::INT_REGULAR, 
                'null' => true, 
                'default' => null,
                'comment' => '变换间隔，单位秒'
            ])
            ->addColumn('locked', 'integer', [
                'limit'   => 1,
                'default' => 0,
                'comment' => '锁定状态，0为未锁定，1为锁定，默认为0',
            ])
            ->addTimestamps()
            ->create();
    }
}
