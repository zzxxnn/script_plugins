<?php

use think\migration\Migrator;
use think\migration\db\Column;
use Phinx\Db\Adapter\MysqlAdapter;

class CreatePassiveReconnConfig extends Migrator
{
    /**
     * 被动回链配置表
     */
    public function change()
    {
        $table = $this->table('passive_reconn_config');
        $table->addColumn('src_ip', 'string', [
            'limit' => 50,
            'null' => true,
            'default' => null,
            'comment' => '源IP'
            ])
            ->addColumn('dst_ip', 'string', ['limit' => 255, 'comment' => '目的IP'])
            ->addColumn('dst_ip_ids', 'string', ['limit' => 255, 'comment' => '伪装原型池ID(目的IP的ID)'])
            ->addColumn('priv_ip', 'string', ['limit' => 50, 'comment' => '私有IP'])
            ->addColumn('username', 'string', ['limit' => 50, 'comment' => '私有IP对应的用户'])
            ->addColumn('protocol', 'string', ['limit' => 50, 'comment' => '协议类型'])
            ->addColumn('src_port', 'string', [
                'limit' => 50,
                'null' => true,
                'default' => null,
                'comment' => '源端口'
            ])
            ->addColumn('dst_port', 'string', ['limit' => 50, 'comment' => '目的端口'])
            ->addColumn('real_port', 'string', ['limit' => 50, 'comment' => '真实端口'])
            ->addTimestamps()
            ->create();
    }
}
