<?php

use think\migration\Migrator;
use think\migration\db\Column;
use Phinx\Db\Adapter\MysqlAdapter;

class CreateGplusEquipments extends Migrator
{
    /**
     * 前端机 “G+” 设备表
     */
    public function change()
    {
        $table = $this->table('gplus_equipments');
        $table->addColumn('g_plus_ip', 'string', ['limit' => 50, 'comment' => '前端机IP'])
            ->addColumn('g_ips', 'text', [
                'limit' => MysqlAdapter::TEXT_REGULAR,
                'null'    => true,
                'default' => null,
                'comment' => 'G设备ip，逗号为分隔符'
            ])
            ->addTimestamps()
            ->create();
    }
}
