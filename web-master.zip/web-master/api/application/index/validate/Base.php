<?php

namespace app\index\validate;

use think\Validate;
use app\index\traits\CommonValidates;

class Base extends Validate
{
    use CommonValidates;

    /**
     * Validate父类构造函数
     * @access public
     * @param array $rules 验证规则
     * @param array $message 验证提示信息
     * @param array $field 验证字段描述信息
     */
    public function __construct(array $rules = [], $message = [], $field = [])
    {
        parent::__construct($rules, $message, $field);
    }
}
