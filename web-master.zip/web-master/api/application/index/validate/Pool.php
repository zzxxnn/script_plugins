<?php

namespace app\index\validate;

class Pool extends Base
{
    protected $rule = [
        'ip'        =>  'require|multiMixedIp:ip,range,mask',
        'note'      =>  'chsDash|max:60',
        'ids'       =>  'require|array|min:1'
    ];

    protected $field = [
        'ip'    =>  '伪装IP',
        'note'  =>  '备注信息',
        'ids'   =>  '记录ID'
    ];

    protected $message  =   [
        'ip.multiMixedIp'   => '伪装IP格式有误'
    ];
    
    protected $scene = [
        'save'      =>  ['ip', 'note'],
        'delete'    =>  ['ids']
    ];

}
