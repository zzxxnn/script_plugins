<?php

namespace app\index\validate;

class Reconnection extends Base
{
    protected $rule = [
        'src_ip'    =>  'mixedIps:ip,mask',
        'priv_ip'   =>  'require|mixedIps:ip,mask',
        'dst_ip_ids'=>  'require|multiInt:,',
        'protocol'  =>  'require|in:TCP,UDP,TCP/UDP',
        'src_port'  =>  'port:32768,65535',
        'dst_port'  =>  'require|mixedPorts:32768,65535',
        'real_port' =>  'require|port:1,65535',
        'ids'       =>  'require|array|min:1'
    ];

    protected $field = [
        'src_ip'    =>  '源IP',
        'priv_ip'   =>  '私有IP',
        'dst_ip_ids'=>  '伪装原型池ID',
        'protocol'  =>  '协议类型',
        'src_port'  =>  '源端口',
        'dst_port'  =>  '伪装端口',
        'real_port' =>  '真实端口',
        'ids'       =>  '记录ID'
    ];

    protected $message  =   [
        'src_port.port'         => '源端口无效',
        'dst_port.mixedPorts'   => '伪装端口无效',
        'real_port.port'        => '真实端口无效',
        'src_ip.mixedIps'       => '源IP无效',
        'priv_ip.mixedIps'      => '私有IP无效',
        'dst_ip_ids.multiInt'   => '伪装原型池ID无效'
    ];
    
    protected $scene = [
        'save'      =>  ['src_ip', 'priv_ip', 'dst_ip_ids', 'protocol', 'src_port', 'dst_port', 'real_port'],
        'delete'    =>  ['ids']
    ];
}
