<?php

namespace app\index\validate;

class Connection extends Base
{
    protected $rule = [
        'username'   =>  'require|alphaDash|length:4,20|banWords:ca,ta,server,index,serial,dh1024,dh2048,dh4096',
        'd_ip_ids'   =>  'require|multiInt:,',
        'change_time'=>  'require|integer|>:0',
        'protocol'   =>  'require|in:TCP,UDP,TCP/UDP',
        'ids'        =>  'require|array|min:1'
    ];

    protected $field = [
        'username'   =>  '用户名',
        'p_ip'       =>  '私有IP',
        'd_ip_ids'   =>  '伪装原型池ID',
        'change_time'=>  'IP变换间隔',
        'ids'        =>  '记录ID'
    ];

    protected $message  =   [
        'username.banWords'   => '用户名不可使用',
        'd_ip_ids.multiInt'   => '伪装原型池ID无效'
    ];
    
    protected $scene = [
        'save'      =>  ['username', 'd_ip_ids', 'change_time', 'protocol'],
        'update'    =>  ['d_ip_ids', 'change_time', 'protocol'],
        'delete'    =>  ['ids']
    ];
}
