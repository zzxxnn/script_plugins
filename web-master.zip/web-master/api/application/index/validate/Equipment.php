<?php

namespace app\index\validate;

class Equipment extends Base
{
    protected $rule = [
        'g_plus_ip' =>  'require|ip',
        'g_ips'     =>  'require|multiMixedIp:ip',
        'ids'       =>  'require|array|min:1'
    ];

    protected $field = [
        'g_plus_ip' =>  '前端机IP',
        'g_ips'     =>  'G设备IP',
        'ids'       =>  '记录ID'
    ];

    protected $message  =   [
        'g_ips.multiMixedIp'   => 'G设备IP无效',
    ];
    
    protected $scene = [
        'save'      =>  ['g_plus_ip', 'g_ips'],
        'update'    =>  ['g_plus_ip', 'g_ips'],
        'delete'    =>  ['ids']
    ];
}
