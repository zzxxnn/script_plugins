<?php

namespace app\index\validate;

use think\Validate;

class Admin extends Base
{
    protected $rule = [
        'account'    =>  'require',
        'password'   =>  'require',
        'captcha'    =>  'require|alphaNum',
        'old_pwd'    =>  'require',
        'new_pwd'    =>  'require|password',
        
    ];

    protected $field = [
        'account'    =>  '用户名',
        'password'   =>  '密码',
        'captcha'    =>  '验证码',
        'old_pwd'    =>  '旧密码',
        'new_pwd'    =>  '新密码',
    ];

    protected $message  =   [
        'new_pwd.password'   => '新密码复杂度低',
    ];
    
    protected $scene = [
        'login'      =>  ['account', 'password', 'captcha'],
        'update_pwd' =>  ['old_pwd', 'new_pwd']
    ];
}
