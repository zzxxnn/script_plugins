<?php

namespace app\index\validate;

class Geqp extends Base
{
    protected $rule = [
        'ip'        =>  'require|ip',
        'port'      =>  'require|port',
        'username'  =>  'require',
        'filepath'  =>  'require'
    ];

    protected $field = [
        'ip'        =>  '上传服务器IP地址',
        'port'      =>  '上传服务器端口',
        'username'  =>  '用户名',
        'filepath'  =>  '规则文件路径'
    ];

    protected $message = [
        'port.port' => '上传服务器端口无效',
    ];
    
    protected $scene = [
        'update'    =>  ['ip', 'port', 'username', 'password', 'filepath']
    ];
}
