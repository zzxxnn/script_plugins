<?php

namespace app\index\validate;

use think\Validate;

class Vpn extends Base
{
    protected $rule = [
        'v_vpn_ip'          =>  'require|ip',
        'v_vpn_port'        =>  'require|port',
        'v_vpn_protocol'    =>  'require|in:TCP,UDP,TCP/UDP',
        'p_ip_range'        =>  'require|ipMask'
    ];

    protected $field = [
        'v_vpn_ip'          =>  '虚拟vpnIP',
        'v_vpn_port'        =>  '虚拟vpn端口',
        'v_vpn_protocol'    =>  '虚拟vpn协议',
        'p_ip_range'        =>  '私有ip段'
    ];

    protected $message  =   [
        'v_vpn_port.port'   => '虚拟vpn端口无效',
        'p_ip_range.ipMask' => '私有ip段无效'
    ];
    
    protected $scene = [
        'update_vvpn'       =>  ['v_vpn_ip', 'v_vpn_port', 'v_vpn_protocol'],
        'update_privateip'  =>  ['p_ip_range']
    ];
}
