<?php

use think\Route;

Route::get([
    'logs/ipconversion'      => 'index/logs.IpConversion/index',
    'logs/ipconversion/:id'  => 'index/logs.IpConversion/read'
]);