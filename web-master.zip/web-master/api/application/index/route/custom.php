<?php

use think\Route;

Route::get([
    'connection/privateips'     =>  'index/custom.Privateip/index',
    'connections'               =>  'index/custom.Connection/index',
    'connection/cert/:id'       =>  'index/custom.Cert/download',
    'custom/state'             =>  'index/custom.State/index'
]);

Route::post([
    'connection'        =>  'index/custom.Connection/save'
]);

Route::put([
    'connection/:id'            =>  'index/custom.Connection/update',
    'connection/offline/:id'    =>  'index/custom.Connection/offline',
    'connection/lock/:id'       =>  'index/custom.Connection/lock',
    'connection/unlock/:id'     =>  'index/custom.Connection/unlock'
]);

Route::delete([
    'connections'       =>  'index/custom.Connection/bulkDelete'
]);