<?php

use think\Route;

Route::get([
    'loginfo'       =>  'index/Session/index',
]);
Route::post([
    'login'         =>  'index/Session/create',
]);
Route::delete([
    'logout'        =>  'index/Session/delete'
]);
