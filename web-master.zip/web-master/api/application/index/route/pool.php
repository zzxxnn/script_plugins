<?php

use think\Route;

Route::get([
    'pool/ips'      => 'index/pool.DisguiseIpPool/index',
    'pool/usableips'=> 'index/pool.UsableIp/index',
    'pool/file'     => 'index/pool.File/download'
]);

Route::post([
    'pool/ip'       => 'index/pool.DisguiseIpPool/save',
    'pool/file'     => 'index/pool.File/upload'
]);

Route::delete([
    'pool/ips'      =>  'index/pool.DisguiseIpPool/bulkDelete'
]);
