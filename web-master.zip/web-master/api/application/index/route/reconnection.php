<?php

use think\Route;

Route::get([
    'reconnections'    =>  'index/Reconnection/index'
]);

Route::post([
    'reconnection'    =>  'index/Reconnection/save'
]);

Route::delete([
    'reconnections'    =>  'index/Reconnection/bulkDelete'
]);

