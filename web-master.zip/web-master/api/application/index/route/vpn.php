<?php

use think\Route;

Route::get([
    'vpn/settings'      =>  'index/vpn.Settings/index',
]);

Route::put([
    'vpn/privateip'     =>  'index/vpn.Privateip/update',
    'vpn/virtualvpn'    =>  'index/vpn.Virtualvpn/update'
]);