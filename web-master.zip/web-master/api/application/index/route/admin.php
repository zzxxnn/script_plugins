<?php

use think\Route;

Route::put([
    'password'       =>  'index/admin.Password/update',
]);
