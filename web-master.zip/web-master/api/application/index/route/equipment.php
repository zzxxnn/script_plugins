<?php

use think\Route;

Route::get([
    'gplus/equipments'      =>  'index/gplus.Equipment/index',
    'g/uploadrule'          =>  'index/geqp.UploadRule/index',
    'gplus/state'           => 'index/gplus.State/index',
    'gplus/state/detail/:id'=> 'index/gplus.State/read',
    'g/log/:id'             => 'index/geqp.AliveLogs/read',
    'g/ip/list'             => 'index/geqp.Lists/index',
    'gplus/ip/list'         => 'index/gplus.Lists/index'
]);

Route::post([
    'gplus/equipment'     =>  'index/gplus.Equipment/save'
]);

Route::put([
    'gplus/equipment/:id' =>  'index/gplus.Equipment/update',
    'g/uploadrule'        =>  'index/geqp.UploadRule/update'
]);

Route::delete([
    'gplus/equipments'    =>  'index/gplus.Equipment/bulkDelete'
]);

