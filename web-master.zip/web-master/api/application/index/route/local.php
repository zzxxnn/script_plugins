<?php

use think\Route;

Route::get([
    'local/state'      => 'index/local.State/index',
]);