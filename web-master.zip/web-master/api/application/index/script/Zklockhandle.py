from kazoo.client import KazooClient
from kazoo.exceptions import NoNodeError
import sys
zk = KazooClient(hosts='127.0.0.1')

path = sys.argv[1]
filepath = sys.argv[2]
with open(filepath) as f:
	data = f.read()

zk.start()
with zk.Lock(path, 'init'):
	try:
		zk.set(path, data)
	except Exception as e:
		if type(e) == NoNodeError:
			zk.create(path, data)
	else:
		pass
	finally:
		pass
zk.stop()