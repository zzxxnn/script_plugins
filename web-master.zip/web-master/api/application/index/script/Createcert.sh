USERNAME=$1
STORE_PATH=$2
$VPN_IP=$3
$VPN_PORT=$4
OPEN_VPN_PATH=/etc/openvpn/easy-rsa/2.0

rm -rf ${OPEN_VPN_PATH}/keys/$USERNAME
cd $OPEN_VPN_PATH && echo export KEY_CN="$USERNAME" >> vars
cd $OPEN_VPN_PATH && source ${OPEN_VPN_PATH}/vars && ${OPEN_VPN_PATH}/pkitool $USERNAME
cd $OPEN_VPN_PATH && sed -i '$d' vars

sed "42c remote $VPN_IP $VPN_PORT" /etc/openvpn/client.ovpn
cp /etc/openvpn/client.ovpn ${OPEN_VPN_PATH}/keys/$USERNAME.ovpn
echo cert $USERNAME.crt >> ${OPEN_VPN_PATH}/keys/$USERNAME.ovpn
echo key $USERNAME.key >> ${OPEN_VPN_PATH}/keys/$USERNAME.ovpn
cd ${OPEN_VPN_PATH}/keys && tar -cvf $USERNAME.tar ta.key ca.crt ca.key $USERNAME.crt $USERNAME.csr $USERNAME.key $USERNAME.ovpn >/dev/null
mkdir -p ${STORE_PATH}
mv ${OPEN_VPN_PATH}/keys/$USERNAME.tar ${STORE_PATH}
rm -f $USERNAME.*