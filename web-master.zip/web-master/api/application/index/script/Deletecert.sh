USERNAME=$1
OPEN_VPN_PATH=/etc/openvpn/easy-rsa/2.0/

rm -rf ${OPEN_VPN_PATH}/keys/$USERNAME.*
