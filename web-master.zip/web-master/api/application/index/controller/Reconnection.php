<?php

namespace app\index\controller;

use app\index\model\PassiveReconnect as ReconnectionModel;
use app\index\validate\Reconnection as ReconnectionValidate;
use app\index\service\DisguiseIpPool as PoolService;
use app\index\service\Connection as ConnectionService;
use app\index\service\Reconnection as ReconnectionService;
use app\index\service\Colligation as ColligationService;

/**
 * 回连配置控制器
 *
 * @package app\index\controller
 */
class Reconnection extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];
    
    /**
     * 获取回连配置
     *
     * @SWG\Get(
     *      path="/reconnections",
     *      tags={"Reconnection 被动回连配置"},
     *      summary="获取回连配置",
     *      @SWG\Parameter(name="page", in="query", required=false, type="integer", description="页码，默认为1"),
     *      @SWG\Parameter(name="size", in="query", required=false, type="integer", description="显示行数，默认为10"),
     *      @SWG\Response(
     *          response="200",
     *          description="回连配置",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object",
     *              example={"list":{{"id":3,"src_ip":"1","dst_ip":"10.22.25.1/24","dst_ip_ids":"2","priv_ip":"1.11.1.11",
     *              "protocol":"TCP","src_port":"1","dst_port":"32768:32768","real_port":"11","row_id":1}},"total":1})
     *          )
     *      )
     * )
     *
     * @param app\index\model\ReconnectionModel
     * @return \think\Response
     */
    public function index(ReconnectionModel $model)
    {
        $page = input('get.page', 1);
        $size = input('get.size', 10);

        $total = $model->count();
        $list = $model->page($page, $size)->select();

        return send_success(['list' => $list, 'total' => $total]);
    }

    /**
     * 添加回连配置
     *
     * @SWG\Post(
     *      path="/reconnection",
     *      tags={"Reconnection 被动回连配置"},
     *      summary="添加回连配置",
     *      @SWG\Parameter(
     *         name="body",
     *         in="body",
     *         description="回连配置",
     *         required=true,
     *         @SWG\Schema(
     *              @SWG\Property(property="src_ip", type="string", example="1.1.1.1 or 1.1.1.1/24", description="源IP"),
     *              @SWG\Property(property="dst_ip_ids", type="string", example="1,2,3", description="伪装原型池的ID,列表获取,多个逗号隔开"),
     *              @SWG\Property(property="priv_ip", type="string", example="2.2.2.2", description="私有IP"),
     *              @SWG\Property(property="protocol", type="string", example="TCP", description="协议类型, TCP 或 UDP"),
     *              @SWG\Property(property="src_port", type="string", example="1234", description="源端口,范围是[32768, 65535]"),
     *              @SWG\Property(property="dst_port", type="string", example="1234 or 10000:10030", description="伪装端口,范围是[32768, 65535],支持端口范围"),
     *              @SWG\Property(property="real_port", type="string", example="1234", description="真实端口,范围是[1, 65535]")
     *         )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param  app\index\model\ReconnectionModel
     * @param  app\index\validate\ReconnectionValidate
     * @return \think\Response
     *
     */
    public function save(ReconnectionValidate $validator, ReconnectionModel $model)
    {
        $data = $this->request->only(['src_ip', 'priv_ip', 'dst_ip_ids', 'protocol', 'src_port', 'dst_port', 'real_port'], 'post');
        $data['src_ip'] = input('src_ip', '');

        if (!$validator->scene('save')->check($data)) {
            return send_error($validator->getError());
        }
        
        // 校验重复条件
        if (!is_null($model->scope('sameSipProtDport', $data['src_ip'], $data['protocol'], $data['dst_port'])->find())) {
            return send_error('配置重复');
        }

        // 检查伪装原型ip是否存在或被占用
        if (!PoolService::checkUsableDisguiseIp($data['dst_ip_ids'])) {
            return send_error('此伪装原型IP不可用');
        }

        // 根据伪装id获取伪装原型ip
        $disguise_ip = PoolService::getDisguiseIpById($data['dst_ip_ids']);

        // 根据私有IP获取用户名
        $username = ConnectionService::getUsernameByPip($data['priv_ip']);
        if (empty($username)) {
            return send_error('此私有IP不可用');
        }

        $config = [
            'src_ip'     =>  isset($data['src_ip']) ? $data['src_ip'] : '',
            'dst_ip'     =>  implode('|', $disguise_ip),
            'dst_ip_ids' =>  $data['dst_ip_ids'],
            'priv_ip'    =>  $data['priv_ip'],
            'username'   =>  $username,
            'protocol'   =>  $data['protocol'],
            'src_port'   =>  isset($data['src_port']) ? $data['src_port'] : '',
            'dst_port'   =>  $data['dst_port'],
            'real_port'  =>  $data['real_port']
        ];

        // 同步zk添加
        if (!ReconnectionService::zkHandle(ReconnectionService::ZK_RULE_ADD, $config)) {
            return send_error('添加失败');
        }

        if ($model->save($config)) {
            // 将此伪装原型IP标记为已占用
            PoolService::updateDisguiseIpStatus($data['dst_ip_ids'], 1);

            if (!ColligationService::allConfs()) {
                return send_error('前端机初始化配置更新失败');
            }

            return send_success();
        }
        return send_error('添加失败');
    }

    /**
     * 删除回连配置
     *
     * 由于底层配置iptables，无法使用记录id来标识某一条记录，需要根据id找到记录所在行号。
     * 清空操作 {"ids":["all"]} 即可
     *
     * @SWG\Delete(
     *      path="/reconnections",
     *      tags={"Reconnection 被动回连配置"},
     *      summary="批量删除回连配置",
     *      @SWG\Parameter(
     *          name="body",
     *          in="body",
     *          description="删除元素id,若清空，ids数组只有一个元素 all",
     *          required=true,
     *          @SWG\Schema(
     *              @SWG\Property(property="ids", type="object", example={1,2,4}, description="记录ID")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param  app\index\model\ReconnectionModel
     * @param  app\index\validate\ReconnectionValidate
     * @return \think\Response
     *
     */
    public function bulkDelete(ReconnectionValidate $validator, ReconnectionModel $model)
    {
        $ids = $this->request->delete('ids/a');
    
        if (!$validator->scene('delete')->check(['ids' => $ids])) {
            return send_error($validator->getError());
        }

        // 清空
        if ($ids[0] === 'all') {
            return $this->clear() ? send_success() : send_error('清空失败');
        }

        $configs = $model->all($ids);
        if (empty($configs)) {
            return send_success();
        }

        $ids = [];      // 有效的记录id
        $dstIpIds = []; // 所删除记录中包含的伪装原型id
        foreach ($configs as $tmp) {
            $ids[] = $tmp->id;
            $tmp = explode(',', $tmp->dst_ip_ids);
            $dstIpIds = array_merge($dstIpIds, $tmp);
        }
        $rowIds = ReconnectionService::getRowIdById($ids); // 行号id,用于zk删除

        // 同步zk删除
        if (!ReconnectionService::zkHandle(ReconnectionService::ZK_RULE_DELETE, $rowIds)) {
            return send_error('删除失败');
        }

        if ($model->destroy($ids) >= 0) {
            // 将此伪装原型IP标记为未占用
            PoolService::updateDisguiseIpStatus(array_unique($dstIpIds), 0);

            if (!ColligationService::allConfs()) {
                return send_error('前端机初始化配置更新失败');
            }

            return send_success();
        } else {
            return send_error('删除失败');
        }
    }

    /**
     * 清空回连配置
     *
     * @return Boolean
     */
    private function clear()
    {
        // 同步zk清空
        if (!ReconnectionService::zkHandle(ReconnectionService::ZK_RULE_CLEAR, [])) {
            return false;
        }

        if (ReconnectionModel::where('id', '>', 0)->delete() >= 0) {
            // 将此伪装原型IP标记为未占用
            PoolService::updateDisguiseIpStatus('all', 0);
            
            if (!ColligationService::allConfs()) {
                return send_error('前端机初始化配置更新失败');
            }

            return true;
        } else {
            return false;
        }
    }
}
