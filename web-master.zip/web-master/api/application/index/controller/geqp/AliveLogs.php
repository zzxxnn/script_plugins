<?php

namespace app\index\controller\geqp;

use app\index\controller\Base;
use app\index\repository\GStatusRepository;

/**
 * 前端机状态
 *
 * @package app\index\controller\geqp
 */
class AliveLogs extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];

    /**
     * 获取前端机状态详情
     *
     * @SWG\Get(
     *      path="/g/log/{id}",
     *      tags={"G G设备"},
     *      summary="获取G设备保活日志",
     *      @SWG\Parameter(name="id", in="path", required=true, type="integer", description="G设备IP"),
     *      @SWG\Parameter(name="page", in="query", required=false, type="integer", description="页码"),
     *      @SWG\Parameter(name="size", in="query", required=false, type="integer", description="查询个数"),
     *      @SWG\Parameter(name="start_time", in="query", required=false, type="string", description="开始时间"),
     *      @SWG\Parameter(name="end_time", in="query", required=false, type="string", description="结束时间"),
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object",
     *              example={"data":{{"g_time":"2018-08-11 09:57:00","g_status":"up"}},"total":1})
     *          )
     *      )
     * )
     *
     * @return \think\Response
     */
    public function read(GStatusRepository $repository, $id)
    {
        $page = input('get.page', 1);
        $size = input('get.size', 10);
        $startTime = input('get.start_time', null);
        $endTime = input('get.end_time', null);

        $list = $repository->searchAliveLogs($id, $page, $size, $startTime, $endTime);
        return send_success(['list' => $list['data'], 'total' => $list['total']]);
    }
}