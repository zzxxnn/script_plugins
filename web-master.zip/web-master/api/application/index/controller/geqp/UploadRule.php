<?php

namespace app\index\controller\geqp;

use app\index\controller\Base;
use app\index\model\CommonConfig as CommonConfigModel;
use app\index\validate\Geqp as GeqpValidate;

/**
 * G设备规则上传配置
 *
 * @package app\index\controller\geqp
 */
class UploadRule extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];

    /**
     * 获取G设备规则上传配置
     *
     * @SWG\Get(
     *      path="/g/uploadrule",
     *      tags={"G G设备"},
     *      summary="获取G设备规则上传配置",
     *      @SWG\Response(
     *          response="200",
     *          description="伪装原型池IP",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object",
     *              example={"ip":"1.1.1.1","port":80,"username":"test","password":"******","filepath":"/usr/test"})
     *          )
     *      )
     * )
     *
     * @return \think\Response
     */
    public function index()
    {
        $jsonContent = CommonConfigModel::getByName(CommonConfigModel::G_UPLOAD_RULE_COLUMN_NAME) 
        ? json_decode(CommonConfigModel::getByName(CommonConfigModel::G_UPLOAD_RULE_COLUMN_NAME)->json_content, true) : '';
        if ($jsonContent) {
            $jsonContent['password'] = "";
        }
        return send_success($jsonContent);
    }

    /**
     * 更新G设备规则上传配置
     *
     * @SWG\Put(
     *      path="/g/uploadrule",
     *      tags={"G G设备"},
     *      summary="更新G设备规则上传配置",
     *      @SWG\Parameter(
     *          name="body",
     *          in="body",
     *          description="前端机信息",
     *          required=true,
     *          @SWG\Schema(
     *              @SWG\Property(property="ip", type="string", example="10.113.14.251", description="上传服务器IP"),
     *              @SWG\Property(property="port", type="integer", example=9005, description="上传服务器端口"),
     *              @SWG\Property(property="username", type="string", example="test", description="用户名"),
     *              @SWG\Property(property="password", type="string", example="123456", description="密码"),
     *              @SWG\Property(property="filepath", type="string", example="/usr/test", description="规则文件路径")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @return \think\Response
     *
     */
    public function update(GeqpValidate $validator, CommonConfigModel $model)
    {
        $data = $this->request->only(['ip', 'port', 'username', 'password', 'filepath'], 'put');

        if (! $validator->scene('update')->check($data)) {
            return send_error($validator->getError());
        }

        if (isset($data['password'])) {
            $data['password'] = trim($data['password']);
            if (empty($data['password'])) {
                $jsonContent = CommonConfigModel::getByName(CommonConfigModel::G_UPLOAD_RULE_COLUMN_NAME) 
                ? json_decode(CommonConfigModel::getByName(CommonConfigModel::G_UPLOAD_RULE_COLUMN_NAME)->json_content, true) : '';
                $data['password'] = $jsonContent['password'];
            }
        }

        $updateData = [
            'json_content' => json_encode($data),
            'update_time'  => date('Y-m-d H:i:s', time())
        ];
        if ($model->where('name', CommonConfigModel::G_UPLOAD_RULE_COLUMN_NAME)->update($updateData) >= 0) {
            return send_success();
        }
        return send_error('保存失败');
    }
}
