<?php

namespace app\index\controller\geqp;

use app\index\controller\Base;
use app\index\model\GplusEquipments as GplusModel;

/**
 * 获取G设备IP列表
 *
 * @package app\index\controller\gplus
 */
class Lists extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];
    
    /**
     * 获取前端机"G+"IP列表
     *
     * @SWG\Get(
     *      path="/g/ip/list",
     *      tags={"G G设备"},
     *      summary="获取G设备IP列表",
     *      @SWG\Response(
     *          response="200",
     *          description="G设备IP信息",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object",
     *              example={"172.21.63.148","172.21.63.149"})
     *          )
     *      )
     * )
     *
     * @return \think\Response
     *
     */
    public function index(GplusModel $model)
    {
        $list = $model->field('g_ips')->select();
        $ips = [];
        foreach ($list as $tmp) {
            $tmp = explode(',', $tmp->g_ips);
            $ips = array_merge($ips, $tmp);
        }

        return send_success(['list' => array_values(array_unique($ips))]);
    }
}
