<?php

namespace app\index\controller;

use app\index\model\Admin as AdminModel;
use app\index\validate\Admin as AdminValidate;
use app\index\service\Auth as AuthService;
use think\helper\Hash;

/**
 * Class Session Controller
 *
 * @package app\index\controller
 */
class Session extends Base
{
    /**
     * 获取登录信息
     *
     * @SWG\Get(
     *      path="/loginfo",
     *      tags={"Auth 登录信息"},
     *      summary="获取登录信息",
     *      @SWG\Response(
     *          response="200",
     *          description="登录信息",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object", example={"id":2,"account":"admin","login_time":"2018-06-13 17:39:21"})
     *          )
     *      )
     * )
     *
     * @return \think\Response
     */
    public function index()
    {
        if ($this->request->isGet()) {
            $user = AuthService::user();
            if (is_null($user)) {
                return send_error("未登录");
            }
            return send_success($user);
        }
    }

    /**
     * 登录
     *
     * @SWG\Post(
     *      path="/login",
     *      tags={"Auth 登录信息"},
     *      summary="登录",
     *      @SWG\Parameter(
     *         name="body",
     *         in="body",
     *         description="登录信息",
     *         required=true,
     *         @SWG\Schema(
     *              @SWG\Property(property="account", type="string", example="admin"),
     *              @SWG\Property(property="password", type="string", example="veda2017"),
     *              @SWG\Property(property="captcha", type="string", example="1234")
     *         )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param  \think\AdminValidate $velidator
     * @return \think\Response
     */
    public function create(AdminValidate $velidator)
    {
        if ($this->request->isPost()) {
            $data = input();
            if (!$velidator->scene('login')->check($data)) {
                return send_error($velidator->getError());
            }

            if (!captcha_check($data['captcha'])) {
                return send_error('验证码错误');
            }

            $admin = AdminModel::where('account', $data['account'])->find();
            if (!$admin) {
                return send_error('账号不存在');
            }

            if (!Hash::check($data['password'], $admin->password, 'bcrypt')) {
                return send_error('账号或密码错误');
            }

            $auth = [
                'id'        =>  $admin->id,
                'account'   =>  $data['account'],
                'login_time'=>  date('Y-m-d H:i:s')
            ];
            AuthService::login($auth);

            return send_success();
        }
    }

    /**
     * 注销
     *
     * @SWG\Delete(
     *      path="/logout",
     *      tags={"Auth 登录信息"},
     *      summary="注销",
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     * @return \think\Response
     */
    public function delete()
    {
        AuthService::logout();
        return send_success();
    }
}
