<?php

namespace app\index\controller\logs;

use app\index\controller\Base;
use app\index\repository\IpConvLogsRepository;

/**
 * 日志
 *
 * @package app\index\controller\logs
 */
class IpConversion extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];
    
    /**
     * 获取ip变换日志
     *
     * @SWG\Get(
     *      path="/logs/ipconversion",
     *      tags={"Logs 日志"},
     *      summary="获取ip变换日志",
     *      @SWG\Parameter(name="page", in="query", required=false, type="integer", description="页码，默认为1"),
     *      @SWG\Parameter(name="size", in="query", required=false, type="integer", description="显示行数，默认为10"),
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object",
     *              example={"list":{{"time":"2018-07-26 15:52:21","int_ip":"0","ip":"192.168.31.141",
     *              "cam_ip":"192.168.31.200","priv_ip":"10.9.0.12","username":"test"}},"total":0})
     *          )
     *      )
     * )
     *
     * @return \think\Response
     *
     */
    public function index(IpConvLogsRepository $repository)
    {
        $page = input('get.page', 1);
        $size = input('get.size', 10);

        $from = ($page - 1) * $size;
        $logs = $repository->getIpConversionLogs($from, $size);

        return send_success(['list' => $logs['data'], 'total' => $logs['total']]);
    }

    /**
     * 获取ip变换日志详情
     *
     * @SWG\Get(
     *      path="/logs/ipconversion/{id}",
     *      tags={"Logs 日志"},
     *      summary="获取ip变换日志详情",
     *      @SWG\Parameter(name="id", in="path", required=true, type="string", description="私有ip"),
     *      @SWG\Parameter(name="page", in="query", required=false, type="integer", description="页码，默认为1"),
     *      @SWG\Parameter(name="size", in="query", required=false, type="integer", description="显示行数，默认为10"),
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object",
     *              example={"list":{{"cam_ip":"9.5.168.192","time":"2018-07-18 14:32:41"}},"total":1})
     *          )
     *      )
     * )
     *
     * @return \think\Response
     */
    public function read(IpConvLogsRepository $repository, $id)
    {
        $page = input('get.page', 1);
        $size = input('get.size', 10);

        $from = ($page - 1) * $size;
        $logs = $repository->getIpConversionLogDetail($id, $from, $size);

        return send_success(['list' => $logs['data'], 'total' => $logs['total']]);
    }
}
