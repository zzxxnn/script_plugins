<?php

namespace app\index\controller\gplus;

use app\index\controller\Base;
use app\index\model\GplusEquipments as GplusModel;
use app\index\validate\Equipment as EqpValidator;

/**
 * 前端机配置
 *
 * @package app\index\controller\gplus
 */
class Equipment extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];
    
    /**
     * 获取前端机"G+"列表
     *
     * @SWG\Get(
     *      path="/gplus/equipments",
     *      tags={"G+ 前端机"},
     *      summary="获取前端机列表",
     *      @SWG\Parameter(name="page", in="query", required=false, type="integer", description="页码，默认为1"),
     *      @SWG\Parameter(name="size", in="query", required=false, type="integer", description="显示行数，默认为10"),
     *      @SWG\Response(
     *          response="200",
     *          description="前端机信息",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object",
     *              example={"list":{{"id":1,"g_plus_ip":"10.113.14.250","g_ips":"172.21.63.148,172.21.63.149"}},"total":1})
     *          )
     *      )
     * )
     *
     * @return \think\Response
     *
     */
    public function index()
    {
        $page = input('get.page', 1);
        $size = input('get.size', 10);

        $total = GplusModel::count();
        $list  = GplusModel::page($page, $size)->select();

        return send_success(['list' => $list, 'total' => $total]);
    }

    /**
     * 添加前端机"G+"
     *
     * @SWG\Post(
     *      path="/gplus/equipment",
     *      tags={"G+ 前端机"},
     *      summary="添加前端机信息",
     *      @SWG\Parameter(
     *          name="body",
     *          in="body",
     *          description="前端机信息",
     *          required=true,
     *          @SWG\Schema(
     *              @SWG\Property(property="g_plus_ip", type="string", example="10.113.14.251", description="前端机IP"),
     *              @SWG\Property(property="g_ips", type="string", example="1.1.1.1,1.1.1.2", description="G设备IP，多个IP使用逗号隔开")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param   app\index\model\GplusEquipments $model
     * @param   app\index\validate\Equipment    $validator
     * @return  \think\Response
     */
    public function save(EqpValidator $validator, GplusModel $model)
    {
        $data = $this->request->only(['g_plus_ip', 'g_ips'], 'post');

        if (! $validator->scene('save')->check($data)) {
            return send_error($validator->getError());
        }

        if (! is_null($model->where('g_plus_ip', $data['g_plus_ip'])->find())) {
            return send_error('配置重复');
        }

        $model->data($data);

        if ($model->save()) {
            return send_success();
        } else {
            return send_error('添加失败');
        }
    }

    /**
     * 更新前端机"G+"
     *
     * @SWG\Put(
     *      path="/gplus/equipment/{id}",
     *      tags={"G+ 前端机"},
     *      summary="更新前端机信息",
     *      @SWG\Parameter(name="id", in="path", required=true, type="integer", description="记录ID"),
     *      @SWG\Parameter(
     *          name="body",
     *          in="body",
     *          description="前端机信息",
     *          required=true,
     *          @SWG\Schema(
     *              @SWG\Property(property="g_plus_ip", type="string", example="10.113.14.251", description="前端机IP"),
     *              @SWG\Property(property="g_ips", type="string", example="1.1.1.1,1.1.1.2", description="G设备IP，多个IP使用逗号隔开")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param   app\index\model\GplusEquipments $model
     * @param   app\index\validate\Equipment    $validator
     * @param   Int  $id
     * @return  \think\Response
     */
    public function update(EqpValidator $validator, GplusModel $model, $id)
    {
        $data = $this->request->only(['g_plus_ip', 'g_ips'], 'put');

        if (! $validator->scene('update')->check($data)) {
            return send_error($validator->getError());
        }

        $gPlusEqp = $model->get($id);
        if (empty($gPlusEqp)) {
            return send_error('配置不存在');
        }

        if (! is_null($model->where('id', '<>', $id)->where('g_plus_ip', $data['g_plus_ip'])->find())) {
            return send_error('配置重复');
        }

        $gPlusEqp->g_plus_ip = $data['g_plus_ip'];
        $gPlusEqp->g_ips = $data['g_ips'];

        if ($gPlusEqp->save() >= 0) {
            return send_success();
        } else {
            return send_error('更新失败');
        }
    }

    /**
     * 删除前端机"G+"
     *
     * @SWG\Delete(
     *      path="/gplus/equipments",
     *      tags={"G+ 前端机"},
     *      summary="批量删除前端机",
     *      @SWG\Parameter(
     *          name="body",
     *          in="body",
     *          description="删除记录id",
     *          required=true,
     *          @SWG\Schema(
     *              @SWG\Property(property="ids", type="object", example={1,2,3}, description="记录ID")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param   app\index\model\GplusEquipments $model
     * @param   app\index\validate\Equipment    $validator
     * @return \think\Response
     */
    public function bulkDelete(EqpValidator $validator, GplusModel $model)
    {
        $ids = $this->request->delete('ids/a');
    
        if (!$validator->scene('delete')->check(['ids' => $ids])) {
            return send_error($validator->getError());
        }

        if ($model->destroy($ids) > 0) {
            return send_success();
        } else {
            return send_error('删除失败');
        }
    }
}
