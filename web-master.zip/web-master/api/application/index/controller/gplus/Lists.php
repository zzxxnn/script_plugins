<?php

namespace app\index\controller\gplus;

use app\index\controller\Base;
use app\index\model\GplusEquipments as GplusModel;

/**
 * 获取前端机IP列表
 *
 * @package app\index\controller\gplus
 */
class Lists extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];
    
    /**
     * 获取前端机"G+"IP列表
     *
     * @SWG\Get(
     *      path="/gplus/ip/list",
     *      tags={"G+ 前端机"},
     *      summary="获取前端机IP列表",
     *      @SWG\Response(
     *          response="200",
     *          description="前端机信息",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object",
     *              example={"list":{{"id":1,"g_plus_ip":"10.113.14.250","g_ips":"172.21.63.148,172.21.63.149"}},"total":1})
     *          )
     *      )
     * )
     *
     * @return \think\Response
     *
     */
    public function index(GplusModel $model)
    {
        $list = $model->field('g_plus_ip')->select();
        $list = array_map(function ($tmp) {
            return $tmp['g_plus_ip'];
        }, $list);

        return send_success(['list' => $list]);
    }
}
