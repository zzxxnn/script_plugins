<?php

namespace app\index\controller\gplus;

use app\index\controller\Base;
use app\index\repository\GplusStatusRepository;
use app\index\repository\GStatusRepository;
use app\index\model\GplusEquipments as GplusModel;

/**
 * 前端机状态
 *
 * @package app\index\controller\gplus
 */
class State extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];

    /**
     * 获取前端机"G+"列表
     *
     * @SWG\Get(
     *      path="/gplus/state",
     *      tags={"G+ 前端机"},
     *      summary="获取前端机状态列表",
     *      @SWG\Parameter(name="page", in="query", required=false, type="integer", description="页码，默认为1"),
     *      @SWG\Parameter(name="size", in="query", required=false, type="integer", description="显示行数，默认为10"),
     *      @SWG\Response(
     *          response="200",
     *          description="前端机状态信息",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object",
     *              example={"list": {{"g_plus_ip": "10.113.14.250","g_plus_status": "down","g_plus_time": "2018-08-07 10:19:10",
     *              "g_ips": {{"g_ip": "172.21.63.148","g_status": "down"},{"g_ip": "172.21.63.149","g_status": "down"}}}},"total": 1})
     *          )
     *      )
     * )
     *
     * @return \think\Response
     *
     */
    public function index(GStatusRepository $repository)
    {
        $page = input('get.page', 1);
        $size = input('get.size', 10);

        $total = GplusModel::count();
        $list  = GplusModel::page($page, $size)->select();
        if ($list) {
            $list = array_map(function ($tmp) {
                return [
                    'g_plus_ip' => $tmp['g_plus_ip'],
                    'g_ips' => explode(',', $tmp['g_ips'])
                ];
            }, $list);
    
            $list = $repository->aggregateAliveLogs($list);
        }

        return send_success(['list' => $list, 'total' => $total]);
    }
    
    /**
     * 获取前端机状态详情
     *
     * 最近1小时，时间周期类型为：1，2
     * 最近12小时，时间周期类型为：2，3，4，5
     * 最近1天，时间周期类型为：3，4，5
     * 最近3天，时间周期类型为：4，5，6
     * 最近1周，时间周期类型为：6，7
     * 最近15天，时间周期类型为：6，7
     * 最近1个月，时间周期类型为：6，7
     *
     * @SWG\Get(
     *      path="/gplus/state/detail/{id}",
     *      tags={"G+ 前端机"},
     *      summary="获取前端机状态详情",
     *      @SWG\Parameter(name="id", in="path", required=true, type="integer", description="前端机ip"),
     *      @SWG\Parameter(name="range", in="query", required=false, type="integer", description="最近时间区间，默认为1，1：最近1小时，2：12小时，
     *      3：1天，4：3天，5：1周，6：15天，7：30天"),
     *      @SWG\Parameter(name="cycle", in="query", required=false, type="integer", description="日志周期，默认为1，1：30秒，2：1分钟，
     *      3：15分钟，4：30分钟，5：1小时，6：12小时，7：1天"),
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object",
     *              example={"list":{{"out_net_rx":0,"ip":"192.168.31.141","net_total_tx":0.21,"out_net_tx":0,"net_total_rx":0,"time":"2018-07-26 15:22:10",
     *              "disk_capa":52403200,"in_net_rx":0,"mem_free":211656,"in_net_tx":0.21,"uptime":21628.17,"mem_total":15145936,"disk_avail":24527484,
     *              "in_net_name":"eth1_1","cpu_load":1.45,"out_net_name":"eth0_1"}},"total":1})
     *          )
     *      )
     * )
     *
     * @return \think\Response
     */
    public function read(GplusStatusRepository $repository, $id)
    {
        $rangeType = input('get.range', 1);
        $cycleType = input('get.cycle', 1);

        $list = $repository->getGplusStatusLogs($id, $rangeType, $cycleType);
        return send_success($list);
    }
}
