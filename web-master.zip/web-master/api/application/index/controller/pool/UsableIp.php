<?php

namespace app\index\controller\pool;

use app\index\controller\Base;
use app\index\service\DisguiseIpPool as PoolService;

class UsableIp extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];

    /**
     * 获取伪装原型池
     *
     * @SWG\Get(
     *      path="/pool/usableips",
     *      tags={"Pool 伪装原型IP池"},
     *      summary="获取可用伪装原型池IP列表",
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object",
     *              example={{"id":2,"ip":"10.22.25.1/24","note":"test"}})
     *          )
     *      )
     * )
     *
     * @return  \think\Response
     */
    public function index()
    {
        return send_success(PoolService::getUsableDisguiseIps());
    }
}
