<?php

namespace app\index\controller\pool;

use app\index\controller\Base;
use app\index\model\DisguiseIpPool as PoolModel;
use app\index\service\Excel as ExcelService;
use app\index\validate\Pool as PoolValidate;

/**
 * 伪装原型池导入导出
 *
 * @package app\index\controller\pool
 */
class File extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];

    /**
     * 导出伪装原型ip excel文件
     *
     * @SWG\Get(
     *      path="/pool/file",
     *      tags={"Pool 伪装原型IP池"},
     *      summary="导出伪装原型ip文件",
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @return \think\Response
     *
     */
    public function download()
    {
        $data = PoolModel::all();
        $data = array_map(function ($tmp) {
            return [$tmp->ip, $tmp->note];
        }, $data);

        ExcelService::create($data, '伪装原型池'.date('YmdHis', time()));
    }
    
    /**
     * 导入伪装原型ip excel文件
     *
     * @SWG\Post(
     *      path="/pool/file",
     *      tags={"Pool 伪装原型IP池"},
     *      summary="导入伪装原型ip文件",
     *      @SWG\Parameter(name="file", in="formData", required=true, type="file", description="伪装原型池excel文件，xls格式"),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param  app\index\model\PoolModel        $model
     * @param  app\index\validate\PoolValidate  $validator
     * @return \think\Response
     *
     */
    public function upload(PoolValidate $validator, PoolModel $model)
    {
        $file = request()->file('file');
        if (!$file) {
            return send_error('导入文件为空');
        }

        $info = $file->validate([
            'size' => ExcelService::EXCEL_FILE_MAX_SIZE
        ])->move(ROOT_PATH . 'public' . DS . 'uploads');

        if (!$info) {
            return send_error('文件无效');
        }

        $datas = ExcelService::parse($info->getPathname());
        if (empty($datas)) {
            return send_error('导入内容为空');
        }

        // 已存在伪装IP
        $existIps = [];
        foreach ($model->all() as $tmp) {
            $existIps[$tmp->ip] = '';
        }

        // 校验并去掉表中重复数据
        $saveList = [];
        foreach ($datas as &$data) {
            if (!$validator->scene('save')->check(['ip'=>$data[0], 'note'=>isset($data[1]) ? $data[1] : null])) {
                return send_error($validator->getError());
            }

            if (!isset($existIps[$data[0]])) {
                $saveList[] = [
                    'ip'    => $data[0],
                    'note'  => $data[1]
                ];
            }
        }

        if (empty($saveList) || $model->saveAll($saveList) > 0) {
            return send_success();
        } else {
            return send_error('导入失败');
        }
    }
}
