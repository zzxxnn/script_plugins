<?php

namespace app\index\controller\pool;

use app\index\controller\Base;
use app\index\model\DisguiseIpPool as PoolModel;
use app\index\validate\Pool as PoolValidate;
use app\index\service\Connection as ConnectionService;
use app\index\service\DisguiseIpPool as PoolService;

/**
 * 伪装原型池控制器
 *
 * @package app\index\controller\pool
 */
class DisguiseIpPool extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];

    /**
     * 获取伪装原型池
     *
     * @SWG\Get(
     *      path="/pool/ips",
     *      tags={"Pool 伪装原型IP池"},
     *      summary="获取伪装原型池IP列表",
     *      @SWG\Parameter(name="page", in="query", required=false, type="integer", description="页码，默认为1"),
     *      @SWG\Parameter(name="size", in="query", required=false, type="integer", description="显示行数，默认为10"),
     *      @SWG\Response(
     *          response="200",
     *          description="伪装原型池IP",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object",
     *              example={"list":{{"id":1,"ip":"1.1.1.1,1.1.1.2","note":"test"},{"id":2,"ip":"10.22.25.1/24","note":"test"}},"total":1})
     *          )
     *      )
     * )
     *
     * @param   app\index\model\PoolModel   $model
     * @return  \think\Response
     */
    public function index(PoolModel $model)
    {
        $page = input('get.page', 1);
        $size = input('get.size', 10);

        $total = $model->count();
        $list = $model->page($page, $size)->select();

        return send_success(['list' => $list, 'total' => $total]);
    }

    /**
     * 添加伪装原型池
     *
     * @SWG\Post(
     *      path="/pool/ip",
     *      tags={"Pool 伪装原型IP池"},
     *      summary="添加伪装原型池IP",
     *      @SWG\Parameter(
     *          name="body",
     *          in="body",
     *          description="伪装原型池",
     *          required=true,
     *          @SWG\Schema(
     *              @SWG\Property(property="ip", type="string", example="1.1.1.1,1.1.1.2/24,1.1.1.1-1.1.1.10",
     *              description="IP、IP掩码、IP范围，多个使用逗号隔开"),
     *              @SWG\Property(property="note", type="string", example="测试", description="备注信息，最多50字")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param  app\index\model\PoolModel        $model
     * @param  app\index\validate\PoolValidate  $validator
     * @return \think\Response
     *
     */
    public function save(PoolModel $model, PoolValidate $validator)
    {
        $data = $this->request->only(['ip', 'note'], 'post');

        if (! $validator->scene('save')->check($data)) {
            return send_error($validator->getError());
        }

        if ($model->where('ip', $data['ip'])->find()) {
            return send_error('配置重复，添加失败');
        }

        if ($model->save($data)) {
            return send_success();
        }

        return send_error('添加失败');
    }

    /**
     * 删除伪装原型池
     *
     * 清空操作 {"ids":["all"]} 即可
     *
     * @SWG\Delete(
     *      path="/pool/ips",
     *      tags={"Pool 伪装原型IP池"},
     *      summary="批量删除伪装原型池IP",
     *      @SWG\Parameter(
     *          name="body",
     *          in="body",
     *          description="删除记录id",
     *          required=true,
     *          @SWG\Schema(
     *              @SWG\Property(property="ids", type="object", example={1,2,3}, description="记录ID")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param  app\index\model\PoolModel        $model
     * @param  app\index\validate\PoolValidate  $validator
     * @return \think\Response
     *
     */
    public function bulkDelete(PoolModel $model, PoolValidate $validator)
    {
        $ids = $this->request->delete('ids/a');
    
        if (!$validator->scene('delete')->check(['ids' => $ids])) {
            return send_error($validator->getError());
        }

        // 清空
        if ($ids[0] === 'all') {
            return $this->clear() ? send_success() : send_error('清空失败');
        }

        // 将要删除的伪装ip
        $ips = array_map(function ($tmp) {
            return $tmp->ip;
        }, $model->all($ids));
        if (empty($ips)) {
            return send_success();
        }

        // 正在使用的伪装ip
        $usedIps = PoolService::getUsedDisguiseIps();

        // 可删除的伪装ip
        $deleteIps = array_filter($ips, function ($tmp) use ($usedIps) {
            return !in_array($tmp, $usedIps);
        });
        if (empty($deleteIps)) {
            return send_success();
        }

        if ($model->where('ip', 'in', $deleteIps)->delete() >= 0) {
            return send_success();
        } else {
            return send_error('删除失败');
        }
    }

    /**
     * 清空原型池IP
     * 用户接入与回连配置所使用的伪装ip不可删除
     *
     * @return Boolean
     */
    private function clear()
    {
        // 正在使用的伪装ip
        $usedIps = PoolService::getUsedDisguiseIps();

        if (empty($usedIps)) {
            if (PoolModel::where('id', '>', 0)->delete() >= 0) {
                return true;
            }
        } else {
            if (PoolModel::where('ip', 'not in', $usedIps)->delete() >= 0) {
                return true;
            }
        }
        
        return false;
    }
}
