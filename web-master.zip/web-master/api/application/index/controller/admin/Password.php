<?php

namespace app\index\controller\admin;

use app\index\controller\Base;
use app\index\validate\Admin as AdminValidate;
use app\index\model\Admin as AdminModel;
use app\index\service\Auth as AuthService;
use think\helper\Hash;

/**
 * 管理员密码修改
 *
 * @package app\index\controller\pool
 */
class Password extends Base
{
    protected $beforeActionList = [
        'is_login'  =>  ['only'=>'update']
    ];

    /**
     * 修改密码
     *
     * @SWG\Put(
     *      path="/password",
     *      tags={"Admin 管理员"},
     *      summary="管理员修改密码",
     *      @SWG\Parameter(
     *          name="body",
     *          required=true,
     *          in="body",
     *          description="修改密码",
     *          @SWG\Schema(
     *              @SWG\Property(property="old_pwd", type="string", example="veda2017"),
     *              @SWG\Property(property="new_pwd", type="string", example="veda2018"),
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     * 
     * @param  \think\AdminValidate $validator
     * @return \think\Response
     */
    public function update(AdminValidate $validator)
    {

        $data = $this->request->only(['old_pwd', 'new_pwd'], 'put');
        if (!$validator->scene('update_pwd')->check($data)) {
            return send_error($validator->getError());
        }

        $id = AuthService::id();
        $admin = AdminModel::get($id);

        if (!Hash::check($data['old_pwd'], $admin->password, 'bcrypt')) {
            return send_error("原密码错误");
        }

        $admin->password = Hash::make($data['new_pwd'], 'bcrypt');
        if ($admin->save()) {
            return send_success();
        } else {
            return send_error('修改失败');
        }
    }
}
