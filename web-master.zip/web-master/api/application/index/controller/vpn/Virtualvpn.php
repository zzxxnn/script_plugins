<?php

namespace app\index\controller\vpn;

use app\index\controller\Base;
use app\index\validate\Vpn as VpnValidate;
use app\index\model\CommonConfig as CommonConfigModel;
use app\index\service\Vpn as VpnService;
use app\index\service\Geqp as GeqpService;
use app\index\service\Colligation as ColligationService;

/**
 * VPN配置 虚拟VPN 控制器
 *
 * @package app\index\controller\vpn
 */
class Virtualvpn extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];

    /**
     * 更新VPN配置中虚拟vpn
     *
     * @SWG\Put(
     *      path="/vpn/virtualvpn",
     *      tags={"Vpn VPN配置"},
     *      summary="修改虚拟vpn配置",
     *      @SWG\Parameter(
     *         name="body",
     *         in="body",
     *         description="VPN配置:虚拟vpn",
     *         required=true,
     *         @SWG\Schema(
     *              @SWG\Property(property="v_vpn_ip", type="string", example="1.1.1.1", description="虚拟vpnIP"),
     *              @SWG\Property(property="v_vpn_port", type="string", example="8081", description="虚拟vpn端口"),
     *              @SWG\Property(property="v_vpn_protocol", type="string", example="TCP", description="虚拟vpn协议，TCP UDP")
     *         )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param  app\index\validate\Vpn $validator
     * @param  app\index\model\CommonConfigModel  $model
     * @return \think\Response
     */
    public function update(VpnValidate $validator, CommonConfigModel $model)
    {
        $data = $this->request->only(['v_vpn_ip', 'v_vpn_port', 'v_vpn_protocol'], 'put');

        if (!$validator->scene('update_vvpn')->check($data)) {
            return send_error($validator->getError());
        }

        // 同步zk配置
        if (!VpnService::zkHandle(['v_vpn' => $data['v_vpn_ip']])) {
            return send_error('保存失败');
        }

        $jsonContent = [
            'ip'          =>  $data['v_vpn_ip'],
            'port'        =>  $data['v_vpn_port'],
            'protocol'    =>  $data['v_vpn_protocol']
        ];
        
        if ($model->where('name', CommonConfigModel::VPN_COLUMN_NAME)->update([
            'json_content' => json_encode($jsonContent),
            'update_time' => date('Y-m-d H:i:s')
        ])) {
            if (!GeqpService::rewriteGConfig()) {
                return send_error('保存失败，G设备规则重写失败');
            }

            if (!ColligationService::allConfs()) {
                return send_error('前端机初始化配置更新失败');
            }

            return send_success();
        }
        return send_error('保存失败');
    }
}
