<?php

namespace app\index\controller\vpn;

use app\index\controller\Base;
use app\index\validate\Vpn as VpnValidate;
use app\index\model\CommonConfig as CommonConfigModel;
use app\index\model\AccessConfig as AccessConfigModel;
use app\index\service\Vpn as VpnService;
use app\index\service\Connection as ConnectionService;
use app\index\service\Colligation as ColligationService;

/**
 * VPN配置 私有ip网段 控制器
 *
 * @package app\index\controller\vpn
 */
class Privateip extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];
    
    /**
     * 更新VPN配置中私有网段配置
     *
     * @SWG\Put(
     *      path="/vpn/privateip",
     *      tags={"Vpn VPN配置"},
     *      summary="修改私有IP网段配置",
     *      @SWG\Parameter(
     *         name="body",
     *         in="body",
     *         description="VPN配置:私有IP网段配置",
     *         required=true,
     *         @SWG\Schema(
     *              @SWG\Property(property="p_ip_range", type="string", example="1.1.1.1/24", description="私有IP网段")
     *         )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param  app\index\validate\Vpn $validator
     * @param  app\index\model\CommonConfigModel  $model
     * @return \think\Response
     *
     */
    public function update(VpnValidate $validator, CommonConfigModel $model)
    {
        $data = $this->request->only(['p_ip_range'], 'put');

        if (!$validator->scene('update_privateip')->check($data)) {
            return send_error($validator->getError());
        }

        $ipInfo = parse_ip($data['p_ip_range']);
        if ($ipInfo['start'] !== $ipInfo['ip']) {
            return send_error('私有IP段起始IP应为：'.$ipInfo['start']);
        }

        // 原私有ip段配置
        $PrivateIpRange = CommonConfigModel::getByName(CommonConfigModel::PRIVATE_IP_COLUMN_NAME)
        ? CommonConfigModel::getByName(CommonConfigModel::PRIVATE_IP_COLUMN_NAME)->value : '';

        if ($PrivateIpRange === $data['p_ip_range']) { // 未修改
            return send_success();
        }

        $ipInfo = parse_ip($data['p_ip_range']);
        if ($ipInfo['host'] < AccessConfigModel::count()) {
            return send_error('私有IP段分配用户不足');
        }

        $updateData = [
            'value' => $data['p_ip_range'],
            'update_time' => date('Y-m-d H:i:s', time())
        ];

        // 同步zk配置
        if (!VpnService::zkHandle(['priv_ip_seg' => $data['p_ip_range']])) {
            return send_error('保存失败');
        }

        if ($model->where('name', CommonConfigModel::PRIVATE_IP_COLUMN_NAME)->update($updateData)) {
            // 重新分配用户的私有ip
            if (!ConnectionService::reassignPrivateIp($data['p_ip_range'])) {
                return send_error('用户私有IP重新分配失败');
            }

            if (!ColligationService::allConfs()) {
                return send_error('前端机初始化配置更新失败');
            }

            return send_success();
        }
        return send_error('保存失败');
    }
}
