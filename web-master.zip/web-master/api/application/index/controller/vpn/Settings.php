<?php

namespace app\index\controller\vpn;

use app\index\controller\Base;
use app\index\model\CommonConfig as CommonConfigModel;
use app\index\validate\Vpn as VpnValidate;

/**
 * VPN配置 控制器
 *
 * @package app\index\controller\vpn
 */
class Settings extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];

    /**
     * 获取VPN配置
     *
     * @SWG\Get(
     *      path="/vpn/settings",
     *      tags={"Vpn VPN配置"},
     *      summary="获取VPN配置",
     *      @SWG\Response(
     *          response="200",
     *          description="VPN配置",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object",example={"v_vpn_ip":"1.1.1.1",
     *              "v_vpn_port":"9001","v_vpn_protocol":"TCP","p_ip_range":"2.2.2.2/24"})
     *          )
     *      )
     * )
     *
     * @return \think\Response
     */
    public function index()
    {
        $json = [
            'v_vpn_ip'          =>  '',
            'v_vpn_port'        =>  '',
            'v_vpn_protocol'    =>  '',
            'p_ip_range'        =>  ''
        ];

        // 虚拟vpn配置
        $jsonContent = CommonConfigModel::getByName(CommonConfigModel::VPN_COLUMN_NAME) 
        ? json_decode(CommonConfigModel::getByName(CommonConfigModel::VPN_COLUMN_NAME)->json_content) : '';

        if (! empty($jsonContent)) {
            $json['v_vpn_ip'] = isset($jsonContent->ip) ? $jsonContent->ip : '';
            $json['v_vpn_port'] = isset($jsonContent->port) ? $jsonContent->port : '';
            $json['v_vpn_protocol'] = isset($jsonContent->protocol) ? $jsonContent->protocol : '';
        }
        
        // 私有ip段配置
        $json['p_ip_range'] = CommonConfigModel::getByName(CommonConfigModel::PRIVATE_IP_COLUMN_NAME) 
        ? CommonConfigModel::getByName(CommonConfigModel::PRIVATE_IP_COLUMN_NAME)->value : '';

        return send_success($json);
    }
}
