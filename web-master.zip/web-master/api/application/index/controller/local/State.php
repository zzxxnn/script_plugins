<?php

namespace app\index\controller\local;

use app\index\controller\Base;

/**
 * 本机状态
 *
 * @package app\index\controller\local
 */
class State extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];
    
    /**
     * 获取本机状态
     *
     * @SWG\Get(
     *      path="local/state",
     *      tags={"Local 本机信息"},
     *      summary="获取本机状态",
     *      @SWG\Parameter(name="page", in="query", required=false, type="integer", description="页码，默认为1"),
     *      @SWG\Parameter(name="size", in="query", required=false, type="integer", description="显示行数，默认为10"),
     *      @SWG\Response(
     *          response="200",
     *          description="",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object",
     *              example={"list":{},"total":0})
     *          )
     *      )
     * )
     *
     * @return \think\Response
     * 
     * @todo 获取ES数据
     */
    public function index(){
        $page = input('get.page', 1);
        $size = input('get.size', 10);

        $total = 0;
        $list  = [];

        return send_success(['list' => $list, 'total' => $total]);
    }

}
