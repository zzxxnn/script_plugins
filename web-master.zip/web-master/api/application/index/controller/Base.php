<?php

namespace app\index\controller;

use think\Controller;
use think\Request;
use app\index\service\Auth as AuthService;

class Base extends Controller
{
    /**
     * 父类构造方法
     * @access public
     * @param Request $request Request 对象
     */
    public function __construct(Request $request = null)
    {
        parent::__construct($request);
    }

    // 登录状态拦截
    public function is_login()
    {
        if (!AuthService::isLogin()) {
            exit_msg("需要登录");
        }
    }
}
