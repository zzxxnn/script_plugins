<?php

namespace app\index\controller\custom;

use app\index\controller\Base;
use app\index\model\AccessConfig as AccessConfigModel;
use app\index\validate\Connection as ConnectionValidate;
use app\index\service\Connection as ConnectionService;
use app\index\service\DisguiseIpPool as PoolService;
use app\index\service\Reconnection as ReconnectionService;
use app\index\service\Geqp as GeqpService;
use app\index\service\Colligation as ColligationService;
use app\index\repository\UserStatusRepository;

/**
 * 用户接入控制器
 *
 * @package app\index\controller
 */
class Connection extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];

    /**
     * 获取用户接入配置列表
     *
     * @SWG\Get(
     *      path="/connections",
     *      tags={"Connection 用户接入"},
     *      summary="获取用户接入配置",
     *      @SWG\Parameter(name="page", in="query", required=false, type="integer", description="页码，默认为1"),
     *      @SWG\Parameter(name="size", in="query", required=false, type="integer", description="显示行数，默认为10"),
     *      @SWG\Parameter(name="filter", in="query", required=false, type="string", description="查询条件，用户名或私有IP，模糊查询"),
     *      @SWG\Response(
     *          response="200",
     *          description="用户接入配置",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object",
     *              example={"list":{{"id":3,"username":"test","private_ip":"1.1.11.1","disguise_ip":"192.168.22.1/24|192.168.26.1/24,192.168.27.11",
     *              "disguise_ip_ids": "5,6","ip_change_time":123,"protocol":"UDP","locked":0,"online":1}},"total":1})
     *          )
     *      )
     * )
     *
     * @param  \app\index\model\AccessConfigModel  $model
     * @param  \app\index\model\UserStatusRepository  $repository
     * @return \think\Response
     *
     */
    public function index(AccessConfigModel $model, UserStatusRepository $repository)
    {
        $page = input('get.page', 1);
        $size = input('get.size', 10);

        $filter = input('get.filter', null);
        if ($filter) {
            $total = $model->where('username|private_ip', 'LIKE', $filter.'%')->count();
            $list = $model->where('username|private_ip', 'LIKE', $filter.'%')->order('id desc')->page($page, $size)->select();
        } else {
            $total = $model->count();
            $list = $model->order('id desc')->page($page, $size)->select();
        }

        // 在线用户状态
        $onlineStatus = $repository->searchUserOnlineStatus();
        foreach ($list as $tmp) {
            $tmp->online = isset($onlineStatus[$tmp->username]) ? $onlineStatus[$tmp->username] : 0;
        }
        
        return send_success(['list' => $list, 'total' => $total]);
    }

    /**
     * 添加用户接入配置
     *
     * @SWG\Post(
     *      path="/connection",
     *      tags={"Connection 用户接入"},
     *      summary="添加用户接入配置",
     *      @SWG\Parameter(
     *         name="body",
     *         in="body",
     *         description="用户接入配置",
     *         required=true,
     *         @SWG\Schema(
     *              @SWG\Property(property="username", type="string", example="test", description="用户名"),
     *              @SWG\Property(property="protocol", type="string", example="TCP", description="协议，TCP UDP TCP/UDP 三种"),
     *              @SWG\Property(property="d_ip_ids", type="string", example="1,2,3", description="伪装原型池的ID,列表获取"),
     *              @SWG\Property(property="change_time", type="integer", example=1234, description="IP变换时间")
     *         )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param  \app\index\validate\Connection  $validator
     * @param  \app\index\model\AccessConfigModel  $model
     * @return \think\Response
     *
     * @todo 伪装端口待加入
     */
    public function save(ConnectionValidate $validator, AccessConfigModel $model)
    {
        $data = $this->request->only(['username', 'd_ip_ids', 'change_time', 'protocol'], 'post');

        if (!$validator->scene('save')->check($data)) {
            return send_error($validator->getError());
        }

        // 用户名不可重复
        if (!is_null($model->where('username', $data['username'])->find())) {
            return send_error('用户名已存在');
        }

        // 检查伪装原型ip是否存在或被占用
        if (!PoolService::checkUsableDisguiseIp($data['d_ip_ids'])) {
            return send_error('伪装原型IP不可用');
        } else {
            // 获取伪装原型ip
            $disguise_ip = PoolService::getDisguiseIpById($data['d_ip_ids']);
        }

        // 自动分配私有IP
        $private_ip = ConnectionService::assignPrivateIp();
        if (empty($private_ip)) {
            return send_error('暂无可用私有IP');
        }

        $userConfig = [
            'username'          =>  $data['username'],
            'private_ip'        =>  $private_ip,
            'disguise_ip'       =>  implode('|', $disguise_ip),
            'disguise_ip_ids'   =>  $data['d_ip_ids'],
            'protocol'          =>  $data['protocol'],
            'ip_change_time'    =>  $data['change_time']
        ];

        // 生成证书
        if (!ConnectionService::genCert($data['username'])) {
            return send_error('添加失败');
        }

        $model->data($userConfig);
        if (!$model->save()) {
            return send_error('添加失败，数据库操作失败');
        }

        // 同步Zookeeper
        if (!ConnectionService::zkHandle(ConnectionService::ZK_USER_ADD, $userConfig)) {
            return send_error('添加失败，ZK操作失败');
        }

        if (!GeqpService::rewriteGConfig()) {
            return send_error('添加失败，G设备规则重写失败');
        }

        if (!ColligationService::allConfs()) {
            return send_error('前端机初始化配置更新失败');
        }
        
        return send_success(['id' => $model->id]);
    }

    /**
     * 修改用户接入配置信息
     *
     * @SWG\Put(
     *      path="/connection/{id}",
     *      tags={"Connection 用户接入"},
     *      summary="修改用户接入配置",
     *      @SWG\Parameter(name="id", in="path", required=true, type="integer", description="记录ID"),
     *      @SWG\Parameter(
     *         name="body",
     *         in="body",
     *         description="用户接入配置",
     *         required=true,
     *         @SWG\Schema(
     *              @SWG\Property(property="d_ip_ids", type="string", example="1,2,3", description="伪装原型池的ID,列表获取"),
     *              @SWG\Property(property="protocol", type="string", example="TCP", description="协议，TCP UDP TCP/UDP 三种"),
     *              @SWG\Property(property="change_time", type="integer", example=1234, description="IP变换时间")
     *         )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param  \app\index\validate\Connection       $validator
     * @param  \app\index\model\AccessConfigModel   $model
     * @param  int  $id
     * @return \think\Response
     *
     */
    public function update(ConnectionValidate $validator, AccessConfigModel $model, $id)
    {
        $data = $this->request->only(['d_ip_ids', 'change_time', 'protocol'], 'put');

        if (!$validator->scene('update')->check($data)) {
            return send_error($validator->getError());
        }

        $user = $model->get($id);
        if (!$user) {
            return send_error('配置不存在');
        }

        // 检查伪装原型ip是否存在或被占用
        if (!PoolService::checkUsableDisguiseIp($data['d_ip_ids'])) {
            return send_error('此伪装原型IP不可用');
        }

        // 获取伪装原型ip
        $disguise_ip = PoolService::getDisguiseIpById($data['d_ip_ids']);
        
        $userConfig = [
            'username'          =>  $user->username,
            'private_ip'        =>  $user->private_ip,
            'disguise_ip'       =>  implode('|', $disguise_ip),
            'disguise_ip_ids'   =>  $data['d_ip_ids'],
            'protocol'          =>  $data['protocol'],
            'ip_change_time'    =>  $data['change_time']
        ];

        if (!$model->allowField(['disguise_ip','disguise_ip_ids','protocol','ip_change_time'])->save($userConfig, ['id' => $id])) {
            return send_error('更新失败，数据库操作失败');
        }
        
        if (!ConnectionService::zkHandle(ConnectionService::ZK_USER_UPDATE, $userConfig)) {
            return send_error('更新失败，ZK操作失败');
        }

        if (!GeqpService::rewriteGConfig()) {
            return send_error('更新失败，G设备规则重写失败');
        }

        if (!ColligationService::allConfs()) {
            return send_error('前端机初始化配置更新失败');
        }

        return send_success();
    }

    /**
     * 批量删除用户接入配置
     *
     * @SWG\Delete(
     *      path="/connections",
     *      tags={"Connection 用户接入"},
     *      summary="批量删除用户接入配置",
     *      @SWG\Parameter(
     *          name="body",
     *          in="body",
     *          description="删除的记录ID数组",
     *          required=true,
     *          @SWG\Schema(
     *              @SWG\Property(property="ids", type="object", example={1,2}, description="记录ID数组")
     *          )
     *      ),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param  \app\index\validate\Connection  $validator
     * @param  \app\index\model\AccessConfigModel  $model
     * @return \think\Response
     *
     * 删除接入用户->删除回连配置->解除回连配置占用的原型池
     */
    public function bulkDelete(ConnectionValidate $validator, AccessConfigModel $model)
    {
        $ids = $this->request->delete('ids/a');
    
        if (!$validator->scene('delete')->check(['ids' => $ids])) {
            return send_error($validator->getError());
        }

        $users = $model->all($ids);
        if (empty($users)) {
            return send_error('无此用户');
        }
        $model->destroy($ids);

        $userConfig = []; // zk交互数据
        $usernames = [];  // 获取删除接入用户名
        foreach ($users as $tmp) {
            $userConfig[] = ['user' => $tmp->username, 'priv_ip' => $tmp->private_ip];
            $usernames[] = $tmp->username;
        }

        // 删除证书
        if (!ConnectionService::delCert($usernames)) {
            return send_error('删除证书失败');
        }

        // 同步Zookeeper
        if (!ConnectionService::zkHandle(ConnectionService::ZK_USER_DELETE, $userConfig)) {
            return send_error('删除失败，ZK操作失败');
        }

        // 删除用户回连配置
        if (!ReconnectionService::deleteReconnByUsername($usernames)) {
            return send_error('此用户回连配置删除失败');
        }

        if (!GeqpService::rewriteGConfig()) {
            return send_error('删除失败，G设备规则重写失败');
        }

        if (!ColligationService::allConfs()) {
            return send_error('前端机初始化配置更新失败');
        }
        
        return send_success();
    }

    /**
     * 强制用户下线
     *
     * @SWG\Put(
     *      path="/connection/offline/{id}",
     *      tags={"Connection 用户接入"},
     *      summary="强制用户下线",
     *      @SWG\Parameter(name="id", in="path", required=true, type="integer", description="记录ID"),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param  \app\index\model\AccessConfigModel  $model
     * @return \think\Response
     */
    public function offline(UserStatusRepository $repository, AccessConfigModel $model, $id)
    {
        $user = $model->get($id);
        if (!$user) {
            return send_error('用户不存在');
        }

        // 判断用户是否在线
        $onlineState = $repository->searchOnlineStateByUsername($user->username);
        if ($onlineState === 0) {
            return send_error('用户不在线');
        }

        $userInfo = [
            'user'       => $user->username,
            'priv_ip'    => $user->private_ip
        ];

        if (!ConnectionService::zkHandle(ConnectionService::ZK_USER_OFFLINE, $userInfo)) {
            return send_error('操作失败');
        }

        return send_success();
    }

    /**
     * 锁定用户
     *
     * @SWG\Put(
     *      path="/connection/lock/{id}",
     *      tags={"Connection 用户接入"},
     *      summary="锁定用户",
     *      @SWG\Parameter(name="id", in="path", required=true, type="integer", description="记录ID"),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param  \app\index\model\AccessConfigModel  $model
     * @return \think\Response
     */
    public function lock(AccessConfigModel $model, $id)
    {
        $user = $model->get($id);
        if (!$user) {
            return send_error('用户不存在');
        }

        // 判断用户是否在锁定状态
        if (1 === $user->locked) {
            return send_error('用户已锁定');
        }

        $userInfo = [
            'user'       => $user->username,
            'priv_ip'    => $user->private_ip
        ];

        if (!ConnectionService::zkHandle(ConnectionService::ZK_USER_LOCK, $userInfo)) {
            return send_error('操作失败');
        }

        $user->locked = 1;
        if ($user->save()) {
            return send_success();
        }
        return send_error('操作失败');
    }

    /**
     * 解锁用户
     *
     * @SWG\Put(
     *      path="/connection/unlock/{id}",
     *      tags={"Connection 用户接入"},
     *      summary="解锁用户",
     *      @SWG\Parameter(name="id", in="path", required=true, type="integer", description="记录ID"),
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @param  \app\index\model\AccessConfigModel  $model
     * @return \think\Response
     */
    public function unlock(AccessConfigModel $model, $id)
    {
        $user = $model->get($id);
        if (!$user) {
            return send_error('用户不存在');
        }

        // 判断用户是否在解锁状态
        if (0 === $user->locked) {
            return send_error('用户已解锁');
        }

        $userInfo = [
            'user'       => $user->username,
            'private_ip' => $user->private_ip
        ];

        if (!ConnectionService::zkHandle(ConnectionService::ZK_USER_UNLOCK, $userInfo)) {
            return send_error('操作失败');
        }

        $user->locked = 0;
        if ($user->save()) {
            return send_success();
        }
        return send_error('操作失败');
    }
}
