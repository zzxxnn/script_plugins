<?php

namespace app\index\controller\custom;

use app\index\controller\Base;
use app\index\model\AccessConfig as AccessConfigModel;

/**
 * 用户证书
 *
 * @package app\index\controller
 */
class Cert extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];

    /**
     * 下载用户证书
     *
     * @SWG\Get(
     *      path="/connection/cert/{id}",
     *      tags={"Connection 用户接入"},
     *      summary="下载用户证书",
     *      @SWG\Response(response="200", description="", ref="#/definitions/Success")
     * )
     *
     * @return \think\Response
     *
     */
    public function download($id)
    {
        $data = AccessConfigModel::get($id);
        if (!$data) {
            return send_error('用户不存在');
        }

        if (file_exists(USERS_CERT_SAVE_PATH . $data->username . ".tar")) {
            download_file(USERS_CERT_SAVE_PATH, $data->username . ".tar");
        } else {
            return send_error('此用户无证书');
        }
    }
}
