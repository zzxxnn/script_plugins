<?php

namespace app\index\controller\custom;

use app\index\controller\Base;
use app\index\repository\UserStatusRepository;

/**
 * 客户状态,在线人数
 *
 * @package app\index\controller\custom
 */
class State extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];

    /**
     * 获取登录用户总数与在线用户数
     *
     * @SWG\Get(
     *      path="/custom/state",
     *      tags={"用户状态"},
     *      summary="获取用户登录数量",
     *      @SWG\Response(
     *          response="200",
     *          description="获取用户登录数量",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object",
     *              example={"online_user_counts":1,"total_user_counts":1010})
     *      )
     * )
     * )
     *
     * @return \think\Response
     *
     */
    public function index(UserStatusRepository $repository)
    {
        $onlineUserCount = $repository->searchOnlineUsers();
        $totalUserCount = $repository->searchAllUsers();
        return send_success(['online_user_counts' => $onlineUserCount, 'total_user_counts' => $totalUserCount]);
    }
}
