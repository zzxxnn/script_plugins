<?php

namespace app\index\controller\custom;

use app\index\controller\Base;
use app\index\service\Connection as ConnectionService;

class Privateip extends Base
{
    protected $beforeActionList = [
        'is_login'
    ];
    
    /**
     * 获取用户与私有IP
     *
     * @SWG\Get(
     *      path="/connection/privateips",
     *      tags={"Connection 用户接入"},
     *      summary="获取接入用户与私有IP列表",
     *      @SWG\Response(
     *          response="200",
     *          description="用户与私有IP",
     *          @SWG\Schema(
     *              @SWG\Property(property="success", type="boolean", example=true),
     *              @SWG\Property(property="data", type="object",
     *              example={{"username":"test","private_ip":"1.1.1.1"},{"username":"vedasec","private_ip":"1.1.1.2"}})
     *          )
     *      )
     * )
     *
     * @return \think\Response
     *
     */
    public function index()
    {
        return send_success(ConnectionService::getUsernamePipMapping());
    }
}
