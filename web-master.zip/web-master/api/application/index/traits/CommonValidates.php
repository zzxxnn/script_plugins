<?php

namespace app\index\traits;

use think\Validate;

trait CommonValidates
{
    /**
     *  整数字符串,以","隔开
     *  如：1,2,3,4
     *
     * @param   Mixed   $value  待校验参数
     * @param   Mixed   $rule   分隔符,默认为英文逗号
     * @param   Mixed   $data   requestData
     * @return  Boolean
     */
    protected function multiInt($value, $rule = ',', $data = null)
    {
        $integers = explode($rule, $value);
        $valid = array_filter($integers, function ($item) {
            return Validate::is($item, 'integer');
        });
        return count($integers) === count($valid);
    }

    /**
     *  验证密码复杂度 长度至少为8位 包括数字、字母大小写
     *  如：veda2018
     *
     * @param   Mixed   $value  待校验参数
     * @param   Mixed   $rule   规则
     * @param   Mixed   $data   requestData
     * @return  Boolean
     */
    protected function password($value, $rule = null, $data = null)
    {
        return Validate::length($value, '8,16') && Validate::regex($value, '/[0-9]/') && Validate::regex($value, '/[a-zA-Z]/');
    }

    /**
     *  IP与端口 ip:port
     *  如：1.1.1.1:80
     *
     * @param   Mixed   $value  待校验参数
     * @param   Mixed   $rule   规则
     * @param   Mixed   $data   requestData
     * @return  Boolean
     */
    protected function ipWithPort($value, $rule = null, $data = null):bool
    {
        $ipPort = explode(':', $value);
        return Validate::length($ipPort, 2) && Validate::is($ipPort[0], 'ip') && $this->port($ipPort[1]);
    }

    /**
     * IP与掩码 ip/mask
     * 如：1.1.1.1/24
     *
     * @param   Mixed   $value  待校验参数
     * @param   Mixed   $rule   掩码范围， 默认1-32，自定义必须在此范围内，逗号隔开
     * @param   Mixed   $data   requestData
     * @return  Boolean
     */
    protected function ipMask($value, $rule = null, $data = null):bool
    {
        $maskRange = empty($rule) ? [1,32] : explode(',', $rule);
        $ipMask = explode('/', $value);
        return Validate::length($ipMask, 2) && Validate::is($ipMask[0], 'ip') && Validate::is($ipMask[1], 'number')
            && Validate::regex($ipMask[1], '/^[0-9]+$/') && Validate::between($ipMask[1], $maskRange);
    }

    /**
     * IP范围
     * 如：1.1.1.1-1.1.1.10
     *
     * @param   Mixed   $value  待校验参数
     * @param   Mixed   $rule   规则
     * @param   Mixed   $data   requestData
     * @return  Boolean
     */
    protected function ipRange($value, $rule = null, $data = null):bool
    {
        $ipRange = explode('-', $value);
        return Validate::length($ipRange, 2) && Validate::is($ipRange[0], 'ip') && Validate::is($ipRange[1], 'ip')
            && (ip2long($ipRange[1]) > ip2long($ipRange[0]));
    }
    
    /**
     * IP IP/MASK 或 IP范围
     * 如：1.1.1.1 或 1.1.1./24 或 1.1.1.1-1.1.1.12
     *
     * @param   Mixed   $value  待校验参数
     * @param   Mixed   $rule   规则 默认选择ip、mask、range三种格式。自定义多格式逗号隔开 如 ip,mask
     * @param   Mixed   $data   requestData
     * @return  Boolean
     */
    protected function mixedIps($value, $rule = null, $data = null):bool
    {
        $ipFormats = empty($rule) ? ['ip', 'mask', 'range'] : explode(',', $rule);
        $flag = false;

        foreach ($ipFormats as $format) {
            if (false === $flag) {
                switch ($format) {
                    case 'ip':
                        $flag = Validate::is($value, 'ip');
                    break;
                    case 'mask':
                        $flag = $this->ipMask($value);
                    break;
                    case 'range':
                        $flag = $this->ipRange($value);
                    break;
                    default:
                        $flag = false;
                    break;
                }
            } else {
                break;
            }
        }
        return $flag;
    }

    /**
     * 多个使用逗号隔开的 IP IP/MASK 或 IP范围
     * 如：1.1.1.1, 1.1.1./24
     *
     * @param   Mixed   $value  待校验参数
     * @param   Mixed   $rule   规则 默认选择ip、mask、range三种格式。自定义多格式逗号隔开 如 ip,mask
     * @param   Mixed   $data   requestData
     * @return  Boolean
     */
    protected function multiMixedIp($value, $rule, $data):bool
    {
        $ips = explode(',', $value);
        $validIps = array_filter($ips, function ($ip) use ($rule) {
            return $this->mixedIps($ip, $rule);
        });

        return count($ips) === count($validIps);
    }

    /**
     *  端口
     *  如：80
     *
     * @param   Mixed   $value  待校验参数
     * @param   Mixed   $rule   端口范围 逗号隔开 如：123,333
     * @param   Mixed   $data   requestData
     * @return  Boolean
     */
    protected function port($value, $rule = null, $data = null):bool
    {
        $range = $rule ? explode(',', $rule) : [0, 65535];
        return Validate::regex($value, '/^[0-9]+$/') && Validate::between($value, $range);
    }
    
    /**
     * 单个端口 或 端口范围
     * 如：80 或 8081:8082
     *
     * @param   Mixed   $value  待校验参数
     * @param   Mixed   $rule   端口范围 逗号隔开 如：123,333
     * @param   Mixed   $data   requestData
     * @return  Boolean
     */
    protected function mixedPorts($value, $rule = null, $data = null):bool
    {
        $ports = \explode(':', $value);
        if (count($ports) === 2 && $ports[0] !== $ports[1]) {
            $ports = array_filter($ports, function ($item) use ($rule) {
                return $this->port($item, $rule, null);
            });
            return count($ports) === 2;
        }

        return $this->port($ports[0], $rule, null);
    }

    /**
     * 数组中每个元素必须包含某些字段
     * 如：[['ip' => '1.1.1.1', 'port' => '80']] 数组中元素必须包含ip与port
     *
     * @param   Mixed   $value  待校验参数
     * @param   String  $rule   必须包含的元素，逗号隔开 如：ip,port
     * @param   Mixed   $data   requestData
     * @return  Boolean
     */
    protected function arrayHas($value, $rule, $data = null):bool
    {
        $fields = explode(',', $rule);
        foreach ($value as $tmp) {
            foreach ($fields as $field) {
                if (!isset($tmp[$field])) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * 列出禁用词语，转换为小写字母进行比较
     *
     * @param   Mixed   $value  待校验参数
     * @param   Mixed   $rule   禁用词语，逗号隔开 如：admin,test
     * @param   Mixed   $data   requestData
     * @return  Boolean
     */
    protected function banWords($value, $rule, $data):bool
    {
        $rule = explode(',', $rule);
        return (bool)!in_array(strtolower($value), $rule);
    }
}
