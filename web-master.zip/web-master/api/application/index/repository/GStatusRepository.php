<?php

namespace app\index\repository;

class GStatusRepository extends BaseRepository
{
    const DEIVCE_ALIVE_MARK = 'up';
    const DEIVCE_DOWN_MARK = 'down';

    protected $esIndex = 'bfd-status-*';
    protected $esType = 'type';

    /**
     * 获取最新前端机保活日志
     *
     * @return array
     */
    public function getRecentGplusStatus()
    {
        $aggs = [
            'aggs' => [
                'gplus_ip_filter' => [
                    'terms' => [
                        'field' => 'data.ip.keyword',
                        'size' => 10000
                    ],
                    "aggs" =>  [
                        "gplus_top_hits" =>  [
                            "top_hits" =>  [
                                "sort" =>  [
                                    [
                                        "data.gplus_time" =>  [
                                            "order" =>  "desc"
                                        ]
                                    ]
                                ],
                                "size" =>  1
                            ]
                        ]
                    ]
                ]
            ]
        ];

        $datas = self::esAggsSearch($aggs);
        $datas = $datas['aggs'] ?? [];
        if (empty($datas)) {
            return [];
        }

        $datas = array_map(function ($tmp) {
            return $tmp['gplus_top_hits']['hits']['hits'][0]['_source']['data'];
        }, $datas['gplus_ip_filter']['buckets']);

        $status = [];
        $gPlusWaitingTime = 60*5; // 前端机超时时间
        $nowTime = time();
    
        foreach ($datas as $tmp) {
            $status[$tmp['ip']] = [
                'gplus_status' => $nowTime - strtotime($tmp['gplus_time']) > $gPlusWaitingTime ? self::DEIVCE_DOWN_MARK : self::DEIVCE_ALIVE_MARK,
                'gplus_time' => format_time(strtotime($tmp['gplus_time']))
            ];
        }
        
        return $status;
    }

    /**
     * 获取最新G设备保活日志
     *
     * @return array
     */
    public function getRecentGStatus()
    {
        $aggs = [
            'aggs' => [
                'gplus_ip_filter' => [
                    'terms' => [
                        'field' => 'data.ip.keyword',
                        'size' => 10000
                    ],
                    "aggs" =>  [
                        'g_ip_filter' => [
                            'terms' => [
                                'field' => 'data.g_ip.keyword',
                                'size' => 10000
                            ],
                            "aggs" =>  [
                                "g_top_hits" =>  [
                                    "top_hits" =>  [
                                        "sort" =>  [
                                            [
                                                "data.gplus_time" =>  [
                                                    "order" =>  "desc"
                                                ]
                                            ]
                                        ],
                                        "size" =>  1
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            ]
        ];

        $datas = self::esAggsSearch($aggs);
        $datas = $datas['aggs'] ?? [];
        if (empty($datas)) {
            return [];
        }

        $status = [];
        $datas = $datas['gplus_ip_filter']['buckets'];

        foreach ($datas as $tmp) {
            if ($tmp['g_ip_filter']['buckets']) {
                foreach ($tmp['g_ip_filter']['buckets'] as $e) {
                    $e = $e['g_top_hits']['hits']['hits'][0]['_source']['data'];
                    $status[$tmp['key']][$e['g_ip']] = [
                        'g_status' => $e['g_status'],
                        'gplus_time' => $e['gplus_time'],
                        'gplus_ip' => $e['ip']
                    ];
                }
            }
        }

        return $status;
    }

    /**
     * 分析整理保活日志信息
     *
     * @param   array   $list
     * @return  array   $list
     */
    public function aggregateAliveLogs($list)
    {
        $gPlusStatus = $this->getRecentGplusStatus();
        $gStatus = $this->getRecentGStatus();

        foreach ($list as &$each) {
            // 不存在此前端机状态日志，则其下g设备不在线
            if (! isset($gPlusStatus[$each['g_plus_ip']])) {
                $each['gplus_status'] = self::DEIVCE_DOWN_MARK;
                $each['gplus_time'] = '';
                foreach ($each['g_ips'] as &$ip) {
                    $tmp = [];
                    $tmp['g_ip'] = $ip;
                    $tmp['g_status'] = self::DEIVCE_DOWN_MARK;
                    $ip = $tmp;
                }
                continue;
            }

            // 前端机时间与状态
            $each['gplus_status'] = $gPlusStatus[$each['g_plus_ip']]['gplus_status'];
            $each['gplus_time'] = $gPlusStatus[$each['g_plus_ip']]['gplus_time'];

            foreach ($each['g_ips'] as &$ip) {
                $tmp = [];
                $tmp['g_ip'] = $ip;
                // 前端机离线，其下g设备都不在线
                if ($each['gplus_status'] === self::DEIVCE_DOWN_MARK || !isset($gStatus[$each['g_plus_ip']][$ip])) {
                    $tmp['g_status'] = self::DEIVCE_DOWN_MARK;
                    $ip = $tmp;
                    continue;
                }

                if (isset($gStatus[$each['g_plus_ip']][$ip])) {
                    if ($gStatus[$each['g_plus_ip']][$ip]['gplus_ip'] != $each['g_plus_ip']) {
                        $tmp['g_status'] = self::DEIVCE_DOWN_MARK;
                    } elseif (strtotime($each['gplus_time']) - strtotime($gStatus[$each['g_plus_ip']][$ip]['gplus_time']) > 60) {
                        $tmp['g_status'] = self::DEIVCE_DOWN_MARK;
                    } else {
                        $tmp['g_status'] = $gStatus[$each['g_plus_ip']][$ip]['g_status'];
                    }
                    $ip = $tmp;
                }
            }
        }

        return $list;
    }

    /**
     * 查询保活日志历史记录
     *
     * @param [type] $ip
     * @param [type] $from
     * @param [type] $size
     * @param [type] $startTime
     * @param [type] $endTime
     * @return void
     */
    public function searchAliveLogs($ip, $from, $size, $startTime, $endTime)
    {
        $filter = [
            'query' => [
                'bool' => [
                    'filter' => [
                        [
                            'term' => [
                                'data.g_ip.keyword' => $ip
                            ]
                        ]
                    ]
                ]
            ],
            'sort'  => [
                [
                    'data.gplus_time' => [
                        'order' => 'desc'
                    ]
                ]
            ]
        ];

        $range = [];

        if ($startTime) {
            $range['gte'] = gmt_withTZ(strtotime($startTime));
        }

        if ($endTime) {
            $range['lte'] = gmt_withTZ(strtotime($endTime));
        }

        if ($range) {
            $filter['query']['bool']['filter'][] = [
                'range' => [
                    'data.gplus_time' => $range
                ]
            ];
        }

        $datas = self::esSearch($filter, $from, $size);
        $datas['data'] = array_map(function ($tmp) {
            $log = [
                'g_time' => format_time(strtotime($tmp['data']['g_time'])),
                'g_status' => $tmp['data']['g_status']
            ];
            return $log;
        }, $datas['data']);

        return $datas;
    }
}
