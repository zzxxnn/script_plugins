<?php

namespace app\index\repository;

use app\index\traits\EsQuery;

class BaseRepository
{
    use EsQuery;
}
