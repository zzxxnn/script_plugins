<?php

namespace app\index\repository;

class GplusStatusRepository extends BaseRepository
{
    protected $esIndex = 'gplus-device-status-*';
    protected $esType = 'type';

    /**
     * 获取某一个前端机状态日志折线图
     *
     * @param   string  $ip          前端机ip
     * @param   int     $rangeType   时间区间类型
     * @param   int     $cycleType   时间间隔类型
     * @return  array   $gplusStatus 状态日志
     */
    public function getGplusStatusLogs($ip, $rangeType, $cycleType)
    {
        $timeRange = $this->timeRange($rangeType);
        $startTime = $timeRange['startTime'];
        $endTime = $timeRange['endTime'];

        $aggs = [
            'gplus_date_range' => [
                'date_range' => [
                    'field' => 'data.time',
                    'ranges' => [
                        [
                            "to" => $endTime,
                            "from" => $startTime
                        ]
                    ]
                ],
                'aggs' => [
                    'gplus_ip_filter' => [
                        'filter' => [
                            'term' => ['data.ip.keyword' => $ip]
                        ],
                        'aggs' => [
                            "gplus_histogram" => [
                                "date_histogram" => [
                                    "field" => "data.time",
                                    "interval" => $this->getCycle($cycleType),
                                    "format" => "yyyy-MM-dd HH:mm:ss",
                                    "min_doc_count" =>  0,
                                    "time_zone" =>  "+08:00"
                                ],
                                "aggs" =>  [
                                    "gplus_top_hits" =>  [
                                        "top_hits" =>  [
                                            "sort" =>  [
                                                [
                                                    "data.time" =>  [
                                                        "order" =>  "desc"
                                                    ]
                                                ]
                                            ],
                                            "size" =>  1
                                        ]
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            ]
        ];

        $datas = self::esAggsSearch(['aggs' => $aggs]);
        $datas = $datas['aggs'] ?? [];
        $gplusStatus = [];

        $gplus_data_range_datas = $datas['gplus_date_range']['buckets'][0] ?? [];
        if (empty($gplus_data_range_datas) || $gplus_data_range_datas['doc_count'] == 0) {
            return $gplusStatus;
        }

        $gplus_ip_filter_datas = $gplus_data_range_datas['gplus_ip_filter'] ?? [];
        if (empty($gplus_ip_filter_datas) || $gplus_ip_filter_datas['doc_count'] == 0) {
            return $gplusStatus;
        }

        $gplus_histogram_datas = $gplus_ip_filter_datas['gplus_histogram']['buckets'];

        foreach ($gplus_histogram_datas as $tmp) {
            if ($tmp['doc_count'] == 0) {
                $statusInit = $this->getStatusTempData($ip);
                $statusInit['time'] = $tmp['key_as_string'];
                $gplusStatus[] = $statusInit;
            } else {
                $time = $tmp['key_as_string'];
                $tmp = $tmp['gplus_top_hits']['hits']['hits'][0]['_source']['data'];
                $tmp['time'] = $time;
                $gplusStatus[] = $tmp;
            }
        }

        return $this->parseStatusLogs($gplusStatus, $ip, $startTime, $endTime, $cycleType);
    }

    /**
     * 将查询出的状态日志与时间节点对应
     *
     * @param string $ip
     * @param string $startTime
     * @param string $endTime
     * @param int    $cycleType
     * @return void
     */
    private function parseStatusLogs($gplusStatus, $ip, $startTime, $endTime, $cycleType)
    {
        $timeNodes = $this->getTimeNode($startTime, $endTime, $cycleType);

        foreach ($timeNodes as &$node) {
            foreach ($gplusStatus as $tmp) {
                if ($tmp['time'] === $node) {
                    $node = $tmp;
                    continue;
                }
            }

            if (!is_array($node)) {
                $statusInit = $this->getStatusTempData($ip);
                $statusInit['time'] = $node;
                $node = $statusInit;
            }
        }

        return $timeNodes;
    }

    /**
     * 根据时间区间类别获取开始与结束时间
     *
     * @param   int     $rangType
     * @return  array   ['startTime','endTime']
     */
    private function timeRange($rangType)
    {
        $endTime = strtotime('now');
        $mapping = [
            '1' => '-1 hour',
            '2' => '-12 hour',
            '3' => '-1 day',
            '4' => '-3 day',
            '5' => '-1 week',
            '6' => '-15 day',
            '7' => '-1 month'
        ];

        $timeInterval = isset($mapping[$rangType]) ? $mapping[$rangType] : '-1 hour';
        $startTime = gmt_withTZ(strtotime($timeInterval, $endTime));
        $endTime = gmt_withTZ($endTime);
        return compact('startTime', 'endTime');
    }
    
    /**
     * 根据周期类型获取时间周期
     *
     * @param   int     $cycleType
     * @return  string
     */
    private function getCycle($cycleType)
    {
        $mapping = [
            '1' => '30s',
            '2' => '1m',
            '3' => '15m',
            '4' => '30m',
            '5' => '1h',
            '6' => '12h',
            '7' => '1d'
        ];

        return isset($mapping[$cycleType]) ? $mapping[$cycleType] : '10s';
    }

    /**
     * 空状态时间节点数据结构
     *
     * @param string $ip
     * @return void
     */
    private function getStatusTempData($ip)
    {
        return [
            'ip' => $ip,
            'out_net_rx' => 0,
            'net_total_tx' => 0,
            'out_net_tx' => 0,
            'net_total_rx' => 0,
            'time' => '',
            'disk_capa' => 0,
            'in_net_rx' => 0,
            'mem_free' => 0,
            'in_net_tx' => 0,
            'uptime' => 0,
            'mem_total' => 0,
            'disk_avail' => 0,
            'in_net_name' => 'eth1_1',
            'cpu_load' => 0,
            'out_net_name' => 'eth0_1'
        ];
    }

    /**
     * 根据时间段与时间周期，计算时间节点
     *
     * @param   string  $startTime
     * @param   string  $endTime
     * @param   int     $cycleType
     * @return  array   $nodes
     */
    private function getTimeNode($startTime, $endTime, $cycleType)
    {
        $nodes = [];
        switch ($cycleType) {
            case '1':
                $second = date('s', strtotime($startTime));
                if ($second >= 0 && $second < 30) {
                    $second = 0;
                } elseif ($second >= 30 && $second < 59) {
                    $second = 30;
                }
                $startTime = strtotime(date('Y-m-d H:i:'.$second, strtotime($startTime)));

                $second = date('s', strtotime($endTime));
                if ($second >= 0 && $second < 30) {
                    $second = 0;
                } elseif ($second >= 30 && $second < 59) {
                    $second = 30;
                }
                $endTime = strtotime(date('Y-m-d H:i:'.$second, strtotime($endTime)));

                do {
                    $nodes[] = date('Y-m-d H:i:s', $startTime);
                    $startTime = strtotime('+30 Second', $startTime);
                } while ($startTime <= $endTime);

                break;
            case '2':
                $startTime = strtotime(date('Y-m-d H:i:00', strtotime($startTime)));
                $endTime = strtotime(date('Y-m-d H:i:00', strtotime($endTime)));

                do {
                    $nodes[] = date('Y-m-d H:i:s', $startTime);
                    $startTime = strtotime('+60 Second', $startTime);
                } while ($startTime <= $endTime);

                break;
            case '3':
                $minute = date('i', strtotime($startTime));
                if ($minute >= 0 && $minute < 15) {
                    $minute = 0;
                } elseif ($minute >= 15 && $minute < 30) {
                    $minute = 15;
                } elseif ($minute >= 30 && $minute < 45) {
                    $minute = 30;
                } elseif ($minute >= 45 && $minute < 59) {
                    $minute = 45;
                }
                $startTime = strtotime(date('Y-m-d H:'.$minute.':00', strtotime($startTime)));

                $minute = date('i', strtotime($endTime));
                if ($minute >= 0 && $minute < 15) {
                    $minute = 0;
                } elseif ($minute >= 15 && $minute < 30) {
                    $minute = 15;
                } elseif ($minute >= 30 && $minute < 45) {
                    $minute = 30;
                } elseif ($minute >= 45 && $minute < 59) {
                    $minute = 45;
                }
                $endTime = strtotime(date('Y-m-d H:'.$minute.':00', strtotime($endTime)));

                do {
                    $nodes[] = date('Y-m-d H:i:s', $startTime);
                    $startTime = strtotime('+15 Minute', $startTime);
                } while ($startTime <= $endTime);

                break;
            case '4':
                $minute = date('i', strtotime($startTime));
                if ($minute >= 0 && $minute < 30) {
                    $minute = 0;
                } elseif ($minute >= 30 && $minute < 59) {
                    $minute = 30;
                }
                $startTime = strtotime(date('Y-m-d H:'.$minute.':00', strtotime($startTime)));

                $minute = date('i', strtotime($endTime));
                if ($minute >= 0 && $minute < 30) {
                    $minute = 0;
                } elseif ($minute >= 30 && $minute < 59) {
                    $minute = 30;
                }
                $endTime = strtotime(date('Y-m-d H:'.$minute.':00', strtotime($endTime)));

                do {
                    $nodes[] = date('Y-m-d H:i:s', $startTime);
                    $startTime = strtotime('+30 Minute', $startTime);
                } while ($startTime <= $endTime);
                break;
            case '5':
                $startTime = strtotime(date('Y-m-d H:00:00', strtotime($startTime)));
                $endTime = strtotime(date('Y-m-d H:00:00', strtotime($endTime)));

                do {
                    $nodes[] = date('Y-m-d H:i:s', $startTime);
                    $startTime = strtotime('+1 hour', $startTime);
                } while ($startTime <= $endTime);

                break;
            case '6':
                $hour = date('H', strtotime($startTime));
                if ($hour >= 0 && $hour < 12) {
                    $hour = 0;
                } elseif ($hour >= 12 && $hour < 23) {
                    $hour = 12;
                }
                $startTime = strtotime(date('Y-m-d '.$hour.':00:00', strtotime($startTime)));

                $hour = date('H', strtotime($endTime));
                if ($hour >= 0 && $hour < 12) {
                    $hour = 0;
                } elseif ($hour >= 12 && $hour < 23) {
                    $hour = 12;
                }
                $endTime = strtotime(date('Y-m-d '.$hour.':00:00', strtotime($endTime)));

                do {
                    $nodes[] = date('Y-m-d H:i:s', $startTime);
                    $startTime = strtotime('+12 Hour', $startTime);
                } while ($startTime <= $endTime);

                break;
            case '7':
                $startTime = strtotime(date('Y-m-d 00:00:00', strtotime($startTime)));
                $endTime = strtotime(date('Y-m-d 00:00:00', strtotime($endTime)));

                do {
                    $nodes[] = date('Y-m-d H:i:s', $startTime);
                    $startTime = strtotime('+1 Day', $startTime);
                } while ($startTime <= $endTime);

                break;
            default:
                $nodes = [];
                break;
        }
        return $nodes;
    }
}
