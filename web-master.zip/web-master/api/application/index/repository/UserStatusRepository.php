<?php

namespace app\index\repository;

class UserStatusRepository extends BaseRepository
{
    protected $esIndex = 'user-online-logs-*';
    protected $esType = 'type';

    /**
     * 查询用户在线状态
     *
     * @return  array   $datas  列表数据
     */
    public function searchUserOnlineStatus()
    {
        self::setESIndex('user-online-status');

        $filter = [
            'sort'  => [
                [
                    'data.time' => [
                        'order' => 'desc'
                    ]
                ]
            ]
        ];
        $datas = self::esSearch($filter, 0, 10000);
        
        $mapping = [];
        foreach ($datas['data'] as $tmp) {
            $mapping[$tmp['data']['username']] = $tmp['data']['online'];
        }

        return $mapping;
    }

    /**
     * 查询所有在线用户数量
     *
     * @return int
     */
    public function searchOnlineUsers()
    {
        self::setESIndex('user-online-status');

        $filter = [
            'query' => [
                'term' => [
                    'data.online' => 1
                ]
            ]
        ];
        
        $datas = self::esSearch($filter);
        return $datas ? $datas['total'] : 0;
    }

    /**
     * 查询所有上过线的用户的数量
     *
     * @return int
     */
    public function searchAllUsers()
    {
        self::setESIndex('user-online-status');
        
        $datas = self::esSearch([]);
        return $datas ? $datas['total'] : 0;
    }

    /**
     * 根据用户名查询用户在线状态
     *
     * @param   string    $username
     * @return  int
     */
    public function searchOnlineStateByUsername($username)
    {
        self::setESIndex('user-online-status');
        
        $datas = self::esGetById($username);
        return $datas ? $datas['data']['online'] : 0;
    }
}
