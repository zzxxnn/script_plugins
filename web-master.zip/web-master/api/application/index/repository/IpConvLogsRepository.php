<?php

namespace app\index\repository;

use app\index\service\Connection as ConnectionService;

class IpConvLogsRepository extends BaseRepository
{
    protected $esIndex = 'ip-conversion-logs-*';
    protected $esType = 'type';

    /**
     * 获取用户私有IP变换日志最新信息表
     *
     * @param   int     $from   开始
     * @param   int     $size   取出数据个数
     * @return  array   $datas  列表数据
     */
    public function getIpConversionLogs($from, $size)
    {
        self::setESIndex('ip-conversion-recent-logs');

        $filter = [
            'sort'  => [
                [
                    'data.time' => [
                        'order' => 'desc'
                    ]
                ]
            ]
        ];

        $datas = self::esSearch($filter, $from, $size);
        if ($datas) {
            foreach ($datas['data'] as &$log) {
                $tmp = $log['data'];
                $tmp['time'] = format_time(strtotime($tmp['time']));
                $log = $tmp;
            }

            $unamePipMapping = ConnectionService::getUsernamePipMapping();

            $datas['data'] = array_map(function ($tmp) use ($unamePipMapping) {
                foreach ($unamePipMapping as $map) {
                    if ($map['private_ip'] === $tmp['priv_ip']) {
                        $tmp['username'] = $map['username'];
                    }
                }
                if (!isset($tmp['username'])) {
                    $tmp['username'] = '';
                }
                return $tmp;
            }, $datas['data']);
        } else {
            $datas = [
                'data' => [],
                'total'=> 0
            ];
        }
        
        return $datas;
    }

    /**
     * 获取某一个用户私有IP变换日志
     *
     * @param   string  $ip     私有IP
     * @param   int     $from   开始
     * @param   int     $size   取出数据个数
     * @return  array   $datas  列表数据
     */
    public function getIpConversionLogDetail($ip, $from, $size)
    {
        $filter = [
            'query' => [
                'bool' => [
                    'filter' => [
                        [
                            'term' => [
                                'data.priv_ip.keyword' => $ip
                            ]
                        ],
                        [
                            'range' =>[
                                'data.time' => [
                                    'lte' => 'now',         // 最大时间
                                    'gte' => 'now-30d'      // 最小时间
                                ]
                            ]
                        ]
                    ]
                ]
            ],
            'sort'  => [
                [
                    'data.time' => [
                        'order' => 'desc'
                    ]
                ]
            ]
        ];

        $datas = self::esSearch($filter, $from, $size);
     
        if ($datas) {
            foreach ($datas['data'] as &$log) {
                $tmp['cam_ip'] = $log['data']['cam_ip'];
                $tmp['time'] = format_time(strtotime($log['data']['time']));
                $log = $tmp;
            }
        } else {
            $datas = [
                'data' => [],
                'total'=> 0
            ];
        }

        return $datas;
    }
}
