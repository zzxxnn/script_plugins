<?php

namespace app\index\model;

class DisguiseIpPool extends Base
{
    protected $pk = 'id';

    protected $table = 'disguise_ip_pool';

    protected $autoWriteTimestamp = 'timestamp';

    protected $hidden = ['used', 'create_time', 'update_time'];
}
