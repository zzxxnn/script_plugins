<?php

namespace app\index\model;

class GplusEquipments extends Base
{
    protected $pk = 'id';

    protected $table = 'gplus_equipments';

    protected $autoWriteTimestamp = 'timestamp';

    protected $hidden = ['create_time', 'update_time'];
}
