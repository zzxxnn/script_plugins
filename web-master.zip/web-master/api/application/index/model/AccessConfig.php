<?php

namespace app\index\model;

class AccessConfig extends Base
{
    protected $pk = 'id';

    protected $table = 'customer_access_config';

    protected $autoWriteTimestamp = 'timestamp';

    protected $hidden = ['create_time', 'update_time'];
}
