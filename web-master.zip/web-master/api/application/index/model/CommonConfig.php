<?php

namespace app\index\model;

class CommonConfig extends Base
{
    const TABLE = 'common_config';
    const VPN_COLUMN_NAME = 'virtual_vpn';
    const PRIVATE_IP_COLUMN_NAME = 'private_ip_range';
    const G_UPLOAD_RULE_COLUMN_NAME = 'g_upload_rule';

    protected $pk = 'id';

    protected $table = self::TABLE;

    protected $autoWriteTimestamp = 'timestamp';

    protected $hidden = ['create_time', 'update_time'];
}
