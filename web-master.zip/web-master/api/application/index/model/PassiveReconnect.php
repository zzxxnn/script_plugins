<?php

namespace app\index\model;

/**
 * 被动回连配置模型
 */
class PassiveReconnect extends Base
{
    protected $pk = 'id';

    protected $table = 'passive_reconn_config';

    protected $autoWriteTimestamp = 'timestamp';

    protected $hidden = ['create_time', 'update_time'];

    // 加入行号查询
    protected function scopeListWithRowNum($query, $page, $row)
    {
        $query->table('passive_reconn_config p,(SELECT @rowno := 0) t')
            ->field('p.*, @rowno :=@rowno + 1 as row_id')->order('p.id ASC')
            ->page($page, $row);
    }

    // 获取记录ID与行号的对应信息
    protected function scopeIdRowMap($query)
    {
        $query->table('passive_reconn_config p,(SELECT @rowno := 0) t')
            ->field('p.id, @rowno :=@rowno + 1 as row_id')->order('p.id ASC');
    }

    // 搜索源ip 协议 与 目的端口符合的结果
    protected function scopeSameSipProtDport($query, $srcIp, $protocol, $dstPort)
    {
        $query->where(['src_ip' => $srcIp, 'protocol' => $protocol, 'dst_port' => $dstPort]);
    }

    // // 替换协议名称
    // public function getProtocolAttr($value)
    // {
    //     $protName = [6 => 'TCP', 17 => 'UDP'];
    //     return $protName[$value];
    // }

    // // 替换协议名称
    // public function setProtocolAttr($value)
    // {
    //     $protocol = ['TCP' => 6, 'UDP' => 17];
    //     return $protocol[$value];
    // }
}
