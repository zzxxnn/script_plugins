<?php

namespace app\index\model;

class Admin extends Base
{
    protected $pk = 'id';

    protected $table = 'admins';
}
