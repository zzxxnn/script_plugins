<?php

namespace app\index\model;

use think\Model;

class Base extends Model
{
    public function __construct($data = [])
    {
        parent::__construct($data);
    }
}
