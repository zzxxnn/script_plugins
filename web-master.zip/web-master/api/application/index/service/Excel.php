<?php

namespace app\index\service;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xls as XlsWriter;
use PhpOffice\PhpSpreadsheet\Reader\Xls as XlsReader;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Worksheet\ColumnCellIterator;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use think\Exception;

class Excel
{
    const EXCEL_FILE_EXT = 'xls'; // excel文件类型与后缀名

    const EXCEL_FILE_MAX_SIZE = 10485760; //excel文件最大字节

    const EXCEL_FILE_MIME_TPYE = ['application/kswps', 'application/kset','application/ksdps',
    'application/vnd.ms-excel','application/excel','application/msexcel']; // excle mimetype

    /**
     * 生成xls文件并下载
     *
     * @param   Mixed   $datas  导出数据
     * @param   String  $datas  文件名
     * @return  void
     */
    public static function create($datas, $fileName)
    {
        $spreadsheet = new Spreadsheet;
        $sheet = $spreadsheet->getActiveSheet();
        foreach ($datas as $key => $data) {
            for ($i=0; $i < count($data); $i++) {
                $sheet->getCellByColumnAndRow($i+1, $key+1)->setValue($data[$i]);
                $sheet->getStyleByColumnAndRow($i+1, $key+1)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT)->setVertical(Alignment::VERTICAL_CENTER);
            }
        }
        
        // $columnCellIterator = new ColumnCellIterator($sheet, 1, 'A', 'C');
        // $writer = new Xls($spreadsheet);
        // return $writer->save($fileName.'.xls');
        // header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');//告诉浏览器输出07Excel文件
        header('Content-Type:application/vnd.ms-excel');//输出Excel03版本文件
        header('Content-Disposition: attachment;filename="'. $fileName .'.xls"');//告诉浏览器输出浏览器名称
        header('Cache-Control: max-age=0');//禁止缓存

        $writer = new XlsWriter($spreadsheet);
        $writer->save('php://output');

        $spreadsheet->disconnectWorksheets(); // 释放内存
        unset($spreadsheet);
    }


    /**
     * 解析xls文件，返回解析数据
     *
     * @param   String  $filePath  文件名
     * @return  Array   $datas     解析后的数据
     */
    public static function parse(string $filePath):array
    {
        if (!file_exists($filePath)) {
            return [];
        }

        $datas = [];
        $reader = new XlsReader();
        
        // 忽略格式与空值
        $reader->setReadDataOnly(true)->getReadEmptyCells(false);

        // 读取excel中sheet的概况：行列数、sheet名
        $info = $reader->listWorksheetInfo($filePath);

        // 加载
        $spreadsheet = $reader->load($filePath);
        $sheet = $spreadsheet->getSheetByName($info[0]['worksheetName']);

        // 读取信息
        for ($i=1; $i <= $info[0]['totalRows']; $i++) {
            $tmp = [];
            for ($r=1; $r <= $info[0]['totalColumns']; $r++) {
                $tmp[] = $sheet->getCellByColumnAndRow($r, $i)->getValue();
            }
            $datas[] = $tmp;
        }

        $spreadsheet->disconnectWorksheets();
        unset($spreadsheet);

        @unlink($filePath);
        return $datas;
    }
}
