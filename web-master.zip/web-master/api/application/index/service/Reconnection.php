<?php

namespace app\index\service;

use app\index\model\PassiveReconnect as ReconnectModel;
use app\index\service\DisguiseIpPool as PoolService;
use app\index\service\Zookeeper as ZkService;
use app\index\service\Gplus as GplusService;
use think\Exception;

class Reconnection
{
    const ZK_RULE_ADD = 'add_rules';
    const ZK_RULE_DELETE = 'del_rules';
    const ZK_RULE_CLEAR = 'clear_rules';

    /**
     * 根据记录id取得行号id,用于zk删除
     *
     * @param   array   $ids
     * @return  array   $rowIds
     */
    public static function getRowIdById($ids)
    {
        $rowIds = [];
        $model = new ReconnectModel;
        $queryRes = $model->scope('idRowMap')->select();
        
        // 取得数据库表中记录id与行号row_id的对应关系
        $mapping = [];
        foreach ($queryRes as $res) {
            $tmp = $res->toArray();
            $mapping[$tmp['id']] = $tmp['row_id'];
        }

        // 根据记录id取得行号rowIds
        foreach ($ids as $id) {
            if (isset($mapping[$id])) {
                $rowIds[] = $mapping[$id];
            }
        }

        return $rowIds;
    }
    
    /**
     * 根据用户名删除回连配置,并将解除伪装原型的占用
     *
     * @param   array   $usernames
     * @return  boolean
     */
    public static function deleteReconnByUsername(array $usernames)
    {
        if (!$usernames) {
            return false;
        }

        $configs = ReconnectModel::where('username', 'in', $usernames)->select();
        if (empty($configs)) {
            return true;
        }

        // 获取配置中的伪装原型id 与 记录id
        foreach ($configs as $tmp) {
            $dstIpIds[] = $tmp->dst_ip_ids;
            $configIds[] = $tmp->id;
        }

        // 下发zk删除回连配置
        if (!self::zkHandle(self::ZK_RULE_DELETE, self::getRowIdById($configIds))) {
            return false;
        }

        if (ReconnectModel::where('username', 'in', $usernames)->delete()) {
            // 将此伪装原型IP标记为未占用
            PoolService::updateDisguiseIpStatus(implode(',', $dstIpIds), 0);

            return true;
        }
        return false;
    }

    /**
     * zookeeper 操作
     *
     * @param   string $handle 操作类型
     * @param   array  $config 写入数据
     * @return  boolean
     */
    public static function zkHandle($handle, $config)
    {
        $data['type'] = $handle;
        $data['data'] = [];

        switch ($handle) {
            case self::ZK_RULE_ADD:
                $data['data'] = [
                    'sip'       => $config['src_ip'],
                    'cip'       => preg_split("/,|\|/", $config['dst_ip']),
                    'priv_ip'   => $config['priv_ip'],
                    'proto'     => $config['protocol'],
                    'sport'     => $config['src_port'],
                    'cport'     => $config['dst_port'],
                    'rport'     => $config['real_port']
                ];
            break;
            case self::ZK_RULE_DELETE:
                foreach ($config as $tmp) {
                    $data['data'][] = ['rule_no' => (int)$tmp];
                }
            break;
            case self::ZK_RULE_CLEAR:
                $data['data'] = [];
            break;
            default:
            break;
        }
        
        $timestamp = msectime();
        $zkNode = array_map(function ($item) use ($timestamp) {
            return ZkService::ZK_CONF_BASE_PATH . '/' . $item . '/' . $timestamp;
        }, GplusService::getGplusList());

        return (new ZkService)->zkSetDataMultiPath($zkNode, $data);
    }
}
