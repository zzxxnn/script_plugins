<?php

namespace app\index\service;

use app\index\model\AccessConfig as AccessConfigModel;
use app\index\model\PassiveReconnect as ReconnectModel;
use app\index\model\CommonConfig as CommonConfigModel;
use app\index\service\Zookeeper as ZkService;
use think\Exception;
use think\Log;

class Colligation
{
    /**
     * 更新前端机初始配置信息
     *
     * @return boolean
     */
    public static function allConfs()
    {
        $config = [];

        // 用户接入配置
        $users = AccessConfigModel::all();
        if ($users) {
            foreach ($users as &$user) {
                $user = [
                    "user"    => $user->username,
                    "priv_ip" => $user->private_ip,
                    "cam_ip"  => preg_split("/,|\|/", $user->disguise_ip),
                    "interval"=> (int)$user->ip_change_time,
                ];
            }

            $config[] = [
                'type' => 'add_user',
                'data' => $users
            ];
        }

        // 回连配置
        $reconnections = ReconnectModel::all();
        if ($reconnections) {
            foreach ($reconnections as &$conn) {
                $conn = [
                    'sip'       => $conn->src_ip,
                    'cip'       => preg_split("/,|\|/", $conn->dst_ip),
                    'priv_ip'   => $conn->priv_ip,
                    'proto'     => $conn->protocol,
                    'sport'     => $conn->src_port,
                    'cport'     => $conn->dst_port,
                    'rport'     => $conn->real_port
                ];

                $config[] = [
                    'type' => 'add_rules',
                    'data' => $conn
                ];
            }
        }

        $vpnConf = [];

        // 虚拟vpn配置
        $jsonContent = CommonConfigModel::getByName(CommonConfigModel::VPN_COLUMN_NAME)
        ? json_decode(CommonConfigModel::getByName(CommonConfigModel::VPN_COLUMN_NAME)->json_content) : '';

        if (!empty($jsonContent) && isset($jsonContent->ip) && !empty($jsonContent->ip)) {
            $vpnConf['v_vpn'] = $jsonContent->ip;
        }

        // 私有ip段配置
        $data = CommonConfigModel::getByName(CommonConfigModel::PRIVATE_IP_COLUMN_NAME)
        ? CommonConfigModel::getByName(CommonConfigModel::PRIVATE_IP_COLUMN_NAME)->value : '';
        if ($data) {
            $vpnConf['priv_ip_seg'] = $data;
        }
        
        $config[] = [
            'type' => 'vpn_cfg',
            'data' => $vpnConf
        ];
        
        if (empty($config)) {
            return true;
        }

        $tmpFile = ROOT_PATH . 'public/tmp/g_def_conf_file';
        file_put_contents($tmpFile, json_encode($config));
        exec('python ' . BASH_SCRIPT_PATH . '/Zklockhandle.py' . ' ' .ZkService::ZK_DEFAULT_CONF_PATH . ' ' . $tmpFile, $result, $status);
        if($status !== 0){
            Log::info('Zklockhandle.py failed!');
            return false;
        }
        return true;
    }
}
