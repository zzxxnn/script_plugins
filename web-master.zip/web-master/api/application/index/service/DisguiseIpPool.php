<?php

namespace app\index\service;

use app\index\model\DisguiseIpPool as PoolModel;
use app\index\model\AccessConfig as AccessConfigModel;
use think\Exception;

class DisguiseIpPool
{
    /**
     * 根据伪装原型id 获取对应的ip
     *
     * @param   string  $ids    多个id字符串,逗号分隔符
     * @return  array   $ips    伪装原型ip
     */
    public static function getDisguiseIpById($ids):array
    {
        $ips = [];
        $data = PoolModel::all($ids);
        if (!$data) {
            return $ips;
        }
        foreach ($data as $tmp) {
            $ips[] = $tmp->ip;
        }
        return $ips;
    }

    /**
     * 获取未被占用的伪装原型IP
     *
     * @return Array $list
     */
    public static function getUsableDisguiseIps():array
    {
        $list = PoolModel::all(['used' => 0]);
        $list = array_map(function ($tmp) {
            return ['id' => $tmp->id,'ip' => $tmp->ip,'note' => $tmp->note];
        }, $list);

        return $list;
    }

    /**
     * 根据原型池的id查看改原型池是否占用
     *
     * @param   String  $ids    原型池的id
     * @return  Boolean
     */
    public static function checkUsableDisguiseIp(string $ids):bool
    {
        $data = PoolModel::all($ids);
        if (!$data) {
            return false;
        }
        if (count($data) !== count(explode(',', $ids))) {
            return false;
        }
        
        foreach ($data as $tmp) {
            if (1 === $tmp->used) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * 更新伪装原型IP占用状态
     *
     * @param   String|Array    $ids    伪装原型ID 如:1,2,3 或 [1,2,3]  如果为all则全部更改
     * @param   Int             $status 0为取消占用 1为占用
     * @return  void
     */
    public static function updateDisguiseIpStatus($ids, int $status)
    {
        if ($ids === 'all') {
            PoolModel::where('id', '>', 0)->update(['used' => $status]);
        } else {
            PoolModel::where('id', 'in', $ids)->update(['used' => $status]);
        }
    }

    /**
     * 获取用户接入选用的伪装IP 与 回连配置中已占用的伪装IP
     *
     * @return  array   @usedIps
     */
    public static function getUsedDisguiseIps():array
    {
        $usedIps = [];
        
        // 用户接入的伪装IP
        $datas = AccessConfigModel::all();
        if (!empty($datas)) {
            foreach ($datas as $data) {
                $usedIps[] = $data->disguise_ip;
            }
        }

        // 回连配置中所使用的伪装ip
        foreach (PoolModel::where('used', 1)->select() as $tmp) {
            $usedIps[] = $tmp->ip;
        }

        return array_merge(array_unique($usedIps));
    }
}
