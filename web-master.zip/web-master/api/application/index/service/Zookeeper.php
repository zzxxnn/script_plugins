<?php

namespace app\index\service;

use \think\Log;
use ZookeeperConnectionException;

class Zookeeper
{
    // zookeeper path配置
    const ZK_CONF_BASE_PATH = '/ybzc/server';
    const ZK_DEFAULT_CONF_PATH = '/ybzc/server/def_config';

    // zookeeper 实例
    public static $zkInstance = null;
    public $zkZcl = [
        ['perms'  => \Zookeeper::PERM_ALL, 'scheme' => 'world', 'id' => 'anyone']
    ];

    // 获取zookeeper实例
    protected static function zkInstance()
    {
        try {
            if (is_null(self::$zkInstance)) {
                $zkHost = config('zookeeper.host');
                self::$zkInstance = new \Zookeeper($zkHost);
            }

            return self::$zkInstance;
        } catch (\ZookeeperConnectionException $e) {
            Log::info('初始化Zookeeper连接失败。zkhost："'.$zkHost.'"。');
        }
    }

    /**
     * 创建ZK的Node节点
     * 如果节点嵌套多层，则递归创建
     *
     * @param   string  $path
     * @param   array   $acl
     * @return  bool
     * @throws  \Exception
     */
    public function zkCreateNode($path, $acl = null)
    {
        try {
            $acl = $acl ?: $this->zkZcl;
            // 检查当前ZK节点是否存在
            if (!empty($path) && !self::zkInstance()->exists($path)) {
                // 去掉首个 '/' 之前的路径为下次需要生成的路径
                $newPath = substr($path, 0, strrpos($path, '/'));
                // 递归的创建ZK节点
                $this->zkCreateNode($newPath);
                if (!empty($path) && !self::zkInstance()->create($path, '', $acl)) {
                    Log::info('创建ZK节点失败。节点："'.$path.'"。');
                    return false;
                }
            }

            return true;
        } catch (\Exception $e) {
            Log::info('创建ZK节点失败。节点："'.$path.'"。');
            return false;
        }
    }

    /**
     * 将数据写入ZK节点
     *
     * @param   string  $path
     * @param   string  $data
     * @return  bool
     */
    public function zkSetData($path, $data = '')
    {
        try {
            // 检查zk连接状态
            if (!self::zkInstance() || !self::zkInstance()->getState()) {
                return false;
            }

            //检查node 是否存在，不存在的话，先创建
            if (!self::zkInstance()->exists($path) && !$this->zkCreateNode($path)) {
                return false;
            }

            $data = is_string($data) ? $data : json_encode($data, 320);
            if (!self::zkInstance()->set($path, $data)) {
                Log::info('数据写入ZK节点失败。节点："'.$path.'"，数据：'.json_encode($data, 320));
                return false;
            }

            return true;
        } catch (\Exception $e) {
            Log::info('数据写入ZK节点失败。节点："'.$path.'"，数据：'.json_encode($data, 320));
            return false;
        }
    }

    /**
     * 将数据写入多个ZK节点
     *
     * @param   array   $path
     * @param   string  $data
     * @return  bool
     */
    public function zkSetDataMultiPath(array $path, $data)
    {
        if (!$path) {
            Log::info('ZK节点未指定。');
            return false;
        }

        if (is_array($path)) {
            foreach ($path as $each) {
                if (!$this->zkSetData($each, $data)) {
                    return false;
                }
            }
        }
        
        return true;
    }
}
