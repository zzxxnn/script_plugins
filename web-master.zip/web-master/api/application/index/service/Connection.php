<?php

namespace app\index\service;

use app\index\model\CommonConfig as CommonConfigModel;
use app\index\model\AccessConfig as AccessConfigModel;
use app\index\service\Zookeeper as ZkService;
use app\index\service\Gplus as GplusService;
use think\Exception;
use think\Log;

class Connection
{

    // 用户接入配置下发zk操作类型
    const ZK_USER_ADD    = "add_user";
    const ZK_USER_UPDATE = "update_user";
    const ZK_USER_DELETE = "del_user";
    const ZK_USER_OFFLINE= "user_offline";
    const ZK_USER_LOCK   = "user_lock";
    const ZK_USER_UNLOCK = "user_unlock";

    /**
     * 分配一个未使用的私有IP
     *
     * @return string $ip
     */
    public static function assignPrivateIp():string
    {
        try {
            $privateIp = '';

            $privateIpRange = CommonConfigModel::getByName(CommonConfigModel::PRIVATE_IP_COLUMN_NAME)->value;
            $ipInfo = parse_ip($privateIpRange);

            $configs = AccessConfigModel::all();
            if (empty($configs)) {
                $privateIp = ip2long($ipInfo['start']);
                while (($privateIp & 255) === 0 || ($privateIp & 255) === 255 || ($privateIp & 255) === 1) { // 去除0 1 与 255 的ip
                    $privateIp ++;
                }

                return long2ip($privateIp);
            } else {
                foreach ($configs as $config) {
                    $usedPriveteIp[ip2long($config->private_ip)] = 0;
                }
    
                for ($ip = ip2long($ipInfo['start']); $ip < ip2long($ipInfo['end']); $ip++) {
                    if (($ip & 255) == 0 || ($ip & 255) == 255 || ($ip & 255) === 1) { // 去除0 1 与 255 的ip
                        continue;
                    } elseif (isset($usedPriveteIp[$ip])) { // 已经分配过的ip
                        continue;
                    } else {
                        $privateIp = $ip;
                        break;
                    }
                }
                
                return empty($privateIp) ? '' : long2ip($privateIp);
            }
        } catch (\Exception $e) {
            return '';
        }
    }

    /**
     * 所有用户重新分配私有IP
     *
     * @param   string  $privateIpRange 私有ip段
     * @return  boolean
     */
    public static function reassignPrivateIp($privateIpRange):bool
    {
        $userConfigs = AccessConfigModel::all();
        if (empty($userConfigs)) {
            return true;
        }

        $ipInfo = parse_ip($privateIpRange);
        $ipStart = ip2long($ipInfo['start']);
        $saveConfigs = [];
        $delConfigs = [];

        foreach ($userConfigs as $tmp) {
            while (($ipStart & 255) == 0 || ($ipStart & 255) == 255 || ($ipStart & 255) === 1) { // 去除0 1 与 255 的ip
                $ipStart ++;
            }
            $tmp = $tmp->toArray();

            $delConfigs[] = [
                'user' => $tmp['username'],
                'priv_ip' => $tmp['private_ip']
            ];

            $tmp['private_ip'] = long2ip($ipStart);
            $saveConfigs[] = $tmp;
            $ipStart ++;
        }

        if (!self::zkHandle(self::ZK_USER_DELETE, $delConfigs)) { // 删除旧数据
            return false;
        }

        if (!self::zkHandle(self::ZK_USER_ADD, $saveConfigs)) { // 添加新数据
            return false;
        }

        if ((new AccessConfigModel)->saveAll($saveConfigs)) {
            return true;
        }
        return false;
    }

    /**
     * 获取用户名与其私有IP对应数组
     *
     * @return array
     */
    public static function getUsernamePipMapping():array
    {
        $list = [];
        $datas = AccessConfigModel::all();
        if (empty($datas)) {
            return $list;
        }

        foreach ($datas as $data) {
            array_push($list, ['username' => $data->username, 'private_ip' => $data->private_ip]);
        }
        
        return $list;
    }

    /**
     * 获取用户已接入的原型池IP
     *
     * @return array
     */
    public static function getUsedDisguiseIps():array
    {
        $list = [];
        $datas = AccessConfigModel::all();
        if (empty($datas)) {
            return $list;
        }

        foreach ($datas as $data) {
            $list[] = $data->disguise_ip;
        }
        
        return array_merge(array_unique($list));
    }

    /**
     * 根据私有IP获取用户名
     *
     * @return mixed
     */
    public static function getUsernameByPip(string $ip):string
    {
        $username = '';
        $data = AccessConfigModel::where('private_ip', $ip)->find();
        if (empty($data)) {
            return $username;
        }

        return $data->username;
    }

    /**
     * 生成证书
     *
     * @return boolean
     */
    public static function genCert($username)
    {
        $vpnConfig = CommonConfigModel::getByName(CommonConfigModel::VPN_COLUMN_NAME)
        ? json_decode(CommonConfigModel::getByName(CommonConfigModel::VPN_COLUMN_NAME)->json_content) : '';
        exec('/usr/bin/sh '. BASH_SCRIPT_PATH . 'Createcert.sh ' . $username . ' ' . USERS_CERT_SAVE_PATH . ' ' . $vpnConfig->ip . ' ' . $vpnConfig->port, $result, $status);
        if (0 !== $status) {
            Log::info('证书生成失败，用户：'.$username);
            return false;
        }
        return true;
    }

    /**
     * 删除证书
     *
     * @return boolean
     */
    public static function delCert($username)
    {
        if (is_array($username)) {
            foreach ($username as $name) {
                exec('/usr/bin/sh '. BASH_SCRIPT_PATH . 'Deletecert.sh ' . $name, $result, $status);
                if (0 !== $status) {
                    Log::info('证书删除失败，用户：'.$name);
                    return false;
                }
            }
        } else {
            exec('/usr/bin/sh '. BASH_SCRIPT_PATH . 'Deletecert.sh ' . $username, $result, $status);
            if (0 !== $status) {
                Log::info('证书删除失败，用户：'.$name);
                return false;
            }
        }
        return true;
    }

    /**
     * zookeeper 操作
     *
     * @param   string $handle 操作类型
     * @param   array  $config 写入数据
     * @return  boolean
     */
    public static function zkHandle($handle, $config)
    {
        $data['type'] = $handle;
        $data['data'] = [];

        switch ($handle) {
            case self::ZK_USER_ADD:
            case self::ZK_USER_UPDATE:
                if (count($config) === count($config, 1)) {
                    $data['data'][] = [
                        "user"    => $config['username'],
                        "priv_ip" => $config['private_ip'],
                        "cam_ip"  => preg_split("/,|\|/", $config['disguise_ip']),
                        "interval"=> (int)$config['ip_change_time']
                    ];
                } else {
                    foreach ($config as $tmp) {
                        $data['data'][] = [
                            "user"    => $tmp['username'],
                            "priv_ip" => $tmp['private_ip'],
                            "cam_ip"  => preg_split("/,|\|/", $tmp['disguise_ip']),
                            "interval"=> (int)$tmp['ip_change_time']
                        ];
                    }
                }
            break;
            case self::ZK_USER_DELETE:
            case self::ZK_USER_OFFLINE:
            case self::ZK_USER_LOCK:
            case self::ZK_USER_UNLOCK:
                $data['data'] = $config;
            break;
            default:
                return false;
            break;
        }
       
        $timestamp = msectime();
        $zkNode = array_map(function ($item) use ($timestamp) {
            return ZkService::ZK_CONF_BASE_PATH . '/' . $item . '/' . $timestamp;
        }, GplusService::getGplusList());

        return (new ZkService)->zkSetDataMultiPath($zkNode, $data);
    }
}
