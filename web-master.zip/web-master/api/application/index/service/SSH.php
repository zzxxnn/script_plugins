<?php

namespace app\index\service;

use \think\Log;

class SSH
{
    // SSH Host
    private $ssh_host;
    // SSH Port
    private $ssh_port = 22;
    // SSH Username
    private $ssh_auth_user;
    // SSH Private Key Passphrase (null == no passphrase)
    private $ssh_auth_pass;
    // SSH Connection
    private $connection = null ;

    public function __construct($sshIp, $sshPort, $sshUsername, $sshPassword)
    {
        $this->ssh_host = $sshIp;
        $this->ssh_port = $sshPort;
        $this->ssh_auth_user = $sshUsername;
        $this->ssh_auth_pass = $sshPassword;
        $this->connection = $this->connect();
    }

    private function connect()
    {
        /**
         * 临时设置超时时间为3秒
         * ssh2_connect() uses socket_connect(). socket_connect relies on the
         * php ini configuration parameter default_socket_timeout which is set by default to 60 seconds
         */
        $originalConnectionTimeout = ini_get('default_socket_timeout');
        ini_set('default_socket_timeout', 3);

        try {
            $this->connection = ssh2_connect($this->ssh_host, $this->ssh_port);
            if (!$this->connection) {
                Log::info('G设备规则上传服务器连接失败:"'.$this->ssh_host.'","'.$this->ssh_port.'"');
                ini_set('default_socket_timeout', $originalConnectionTimeout);
                return ;
            }
        } catch (\Exception $e) {
            Log::info('G设备规则上传服务器连接失败:"'.$this->ssh_host.'","'.$this->ssh_port.'"');
            ini_set('default_socket_timeout', $originalConnectionTimeout);
            return ;
        }

        try {
            if (!ssh2_auth_password($this->connection, $this->ssh_auth_user, $this->ssh_auth_pass)) {
                Log::info('G设备规则上传服务器连接失败，用户名或密码错误:"'.$this->ssh_auth_user.'","'.$this->ssh_auth_pass.'"');
                return ;
            }
        } catch (\Exception $e) {
            Log::info('G设备规则上传服务器连接失败，用户名或密码错误:"'.$this->ssh_auth_user.'","'.$this->ssh_auth_pass.'"');
            return ;
        }

        return $this->connection;
    }

    public function uploadFile($localFile, $originFile, $mode = 0644)
    {
        if (!$this->connection) {
            return false;
        }

        $stream=ssh2_scp_send($this->connection, $localFile, $originFile, $mode);
        if (!$stream) {
            Log::info('G设备规则上传文件失败：' . $tmpFileName);
            return false;
        }

        return true;
    }

    public function disconnect()
    {
        $this->connection = null;
    }

    public function __destruct()
    {
        $this->disconnect();
    }
}
