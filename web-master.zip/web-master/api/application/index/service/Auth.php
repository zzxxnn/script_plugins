<?php

namespace app\index\service;

use app\index\model\Admin as AdminModel;

class Auth
{
    const SESSION_INFO_KEY = 'user_auth';
    const SESSION_SIGN_KEY = 'user_auth_sign';

    /**
     * 返回登录信息
     *
     * @return Array|Null
     */
    public static function user()
    {
        return session(self::SESSION_INFO_KEY) ?: null;
    }

    /**
     * 获取当前登录id
     *
     * @return Mixed|Null
     */
    public static function id()
    {
        $userInfo = session(self::SESSION_INFO_KEY);
        return $userInfo ? $userInfo['id'] : null;
    }

    /**
     * 登录
     *
     * @param Array $auth 登录信息
     * @return Array
     * @throws Exception
     */
    public static function login($auth)
    {
        try {
            session(self::SESSION_INFO_KEY, $auth);
            session(self::SESSION_SIGN_KEY, auth_sign($auth));

            AdminModel::update(['id' => $auth['id'], 'last_login_time' => $auth['login_time']]);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    /**
     * 注销
     *
     * @return void
     */
    public static function logout()
    {
        try {
            session(self::SESSION_INFO_KEY, null);
            session(self::SESSION_SIGN_KEY, null);

            return;
        } catch (\Exception $e) {
            return;
        }
    }

    /**
     * 检查登陆状态
     *
     * @return Boolean
     */
    public static function isLogin()
    {
        return (bool)!empty(self::user());
    }
}
