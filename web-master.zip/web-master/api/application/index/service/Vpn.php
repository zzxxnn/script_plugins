<?php

namespace app\index\service;

use app\index\service\Zookeeper as ZkService;
use app\index\service\Gplus as GplusService;
use think\Exception;

class Vpn
{
    /**
     * zookeeper 操作
     *
     * @param   array  $config 写入数据
     * @return  boolean
     */
    public static function zkHandle($config)
    {
        $data['type'] = 'vpn_cfg';
        $data['data'] = [];

        if (isset($config['v_vpn'])) {
            $data['data']['v_vpn'] = $config['v_vpn'];
        } elseif (isset($config['priv_ip_seg'])) {
            $data['data']['priv_ip_seg'] = $config['priv_ip_seg'];
        } else {
            return false;
        }

        $timestamp = msectime();
        $zkNode = array_map(function ($item) use ($timestamp) {
            return ZkService::ZK_CONF_BASE_PATH . '/' . $item . '/' . $timestamp;
        }, GplusService::getGplusList());

        return (new ZkService)->zkSetDataMultiPath($zkNode, $data);
    }
}
