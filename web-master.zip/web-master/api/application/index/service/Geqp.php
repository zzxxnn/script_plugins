<?php

namespace app\index\service;

use app\index\model\CommonConfig as CommonConfigModel;
use app\index\model\AccessConfig as AccessConfigModel;
use app\index\model\PassiveReconnect as ReconnectModel;
use app\index\service\SSH as SSHSerice;
use think\Exception;
use think\Log;

/**
 * G设备Service
 */
class Geqp
{
    /**
     * 重写G设备规则文件
     *
     * @return void
     */
    public static function rewriteGConfig()
    {
        $GConfig = [];
        $configMould = [
            'sip'           =>  0,
            'sip_mask'      =>  0,
            'dip'           =>  0,
            'dip_mask'      =>  '255.255.255.255',
            'sport'         =>  0,
            'sport_mask_len'=>  0,
            'dport'         =>  0,
            'dport_mask_len'=>  0,
            'proto'         =>  0,
            'isp_id'        =>  1,
            'service_id'    =>  32
        ];

        $userConnections = AccessConfigModel::all();
        if ($userConnections) {
            foreach ($userConnections as $each) {
                $tmp = $configMould;
                $tmp['proto'] = protocol_number($each->protocol);

                $disguiseIps = [];
                foreach (preg_split("/,|\|/", $each->disguise_ip) as $ip) {
                    if (is_ip_mask($ip)) {
                        $ip = parse_ip($ip);
                        $tmp['dip'] = $ip['ip'];
                        $tmp['dip_mask'] = $ip['mask'];
                    } else {
                        $tmp['dip'] = $ip;
                    }

                    $GConfig[] = $tmp;
                }
            }
        }

        $reconncetions = ReconnectModel::all();
        if ($reconncetions) {
            foreach ($reconncetions as $each) {
                $tmp = $configMould;

                // 源ip 算出ip掩码
                if ($each->src_ip) {
                    $srcIpInfo = parse_ip($each->src_ip);
                    $tmp['sip'] = $srcIpInfo['ip'];
                    $tmp['sip_mask'] = $srcIpInfo['mask'];
                }

                // 源端口,算出端口掩码
                if ($each->src_port) {
                    $srcPortInfo = get_port_mask($each->src_port);
                    $tmp['sport'] = $srcPortInfo[0];
                    $tmp['sport_mask_len'] = $srcPortInfo[1];
                }

                // 目的端口,端口范围只取第一个端口,算出端口掩码
                if ($each->dst_port) {
                    if (strstr($each->dst_port, ":")) {
                        $dstPortInfo = get_port_mask(explode(':', $each->dst_port));
                    } else {
                        $dstPortInfo = get_port_mask($each->dst_port);
                    }
                    $tmp['dport'] = $dstPortInfo[0];
                    $tmp['dport_mask_len'] = $dstPortInfo[1];
                }

                $tmp['proto'] = protocol_number($each->protocol);

                $dstIps = [];
                foreach (preg_split("/,|\|/", $each->dst_ip) as $ip) {
                    if (is_ip_mask($ip)) {
                        $dstIps = array_merge($dstIps, parse_ip_mask($ip));
                    } else {
                        $dstIps[] = $ip;
                    }
                }
                $dstIps = array_unique($dstIps);

                foreach ($dstIps as $dip) {
                    $tmp['dip'] = $dip;
                    $GConfig[] = $tmp;
                }
            }
        }

        $vpnConfig = CommonConfigModel::getByName(CommonConfigModel::VPN_COLUMN_NAME)
        ? json_decode(CommonConfigModel::getByName(CommonConfigModel::VPN_COLUMN_NAME)->json_content) : '';
        if ($vpnConfig) {
            $tmp = $configMould;

            $tmp['dip'] = $vpnConfig->ip;

            $portInfo = get_port_mask($vpnConfig->port);
            $tmp['dport'] = 0;
            $tmp['dport_mask_len'] = 0;

            $tmp['proto'] = protocol_number($vpnConfig->protocol);
            $GConfig[] = $tmp;
        }

        if (!$GConfig) {
            Log::info('无上传内容');
            return false;
        }

        $GuploadRule = CommonConfigModel::getByName(CommonConfigModel::G_UPLOAD_RULE_COLUMN_NAME)
        ? json_decode(CommonConfigModel::getByName(CommonConfigModel::G_UPLOAD_RULE_COLUMN_NAME)->json_content, true) : '';
        if (!$GuploadRule) {
            Log::info('暂无G设备上传规则');
            return false;
        }

        $GConfigStr = '';
        foreach ($GConfig as $config) {
            $GConfigStr .= implode(',', $config) . "\n";
        }

        $tmpFileName = ROOT_PATH . 'public/tmp/g_conf_str_file';
        file_put_contents($tmpFileName, $GConfigStr);

        $ssh = new SSHSerice($GuploadRule['ip'], $GuploadRule['port'], $GuploadRule['username'], $GuploadRule['password']);
        return $ssh->uploadFile($tmpFileName, $GuploadRule['filepath']);
    }
}
