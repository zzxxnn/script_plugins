<?php 
use \think\Validate;

define('USERS_CERT_SAVE_PATH', ROOT_PATH . 'public' . DS . 'certs' . DS); // 用户证书保存路径
define('BASH_SCRIPT_PATH', APP_PATH . 'index' . DS . 'script' . DS); // bash脚本保存路径

if (!function_exists('auth_sign')) {
    /**
     * 对登录信息进行加密
     * @param   Array   $data
     * @return  String
     */
    function auth_sign($data)
    {
        $data = is_array($data) ? $data : (array)$data;
        ksort($data);
        $code = http_build_query($data);//将数组处理为url-encoded 请求字符串
        $sign = sha1($code);//进行散列算法
        return $sign;
    }
}

if (!function_exists('send_success')) {
    /**
     * 接口返回成功
     *
     * @param   Array   $data
     * @return  Object
     */
    function send_success($data = null)
    {
        $responce_data = ['success' => true];
        if (!is_null($data)) {
            $responce_data['data'] = $data;
        }
        return json($responce_data);
    }
}

if (!function_exists('send_error')) {
    /**
     * 接口返回格式化错误信息
     *
     * @param   String  $errmsg
     * @param   Array   $data
     * @return  Object
     */
    function send_error($errmsg = '', $data = null)
    {
        $responce_data = ['success' => false, 'errmsg' => $errmsg];
        if ($data) {
            $responce_data['data'] = $data;
        }
        return json($responce_data);
    }
}

if (!function_exists('exit_msg')) {
    /**
     * 结束并返回格式化错误信息
     *
     * @param   String  $errmsg
     * @param   Array   $data
     * @return  Object
     */
    function exit_msg($errmsg = '', $data = null)
    {
        $responce_data = ['success' => false, 'errmsg' => $errmsg];
        if ($data) {
            $responce_data['data'] = $data;
        }
        header("Content-Type: application/json");
        exit(json_encode($responce_data));
    }
}

if (!function_exists('get_port_mask')) {
    /**
     * 根据端口计算端口掩码
     *
     * @param   int     $port   端口
     * @return  array   [掩码(十进制),掩码(位)]
     */
    function get_port_mask($port)
    {
        if ($port == 65535) {
            return [65534,15];
        }
    
        $binPort = decbin($port);
        $maskCode = strpos($binPort, '0');
        $mask = ((1<<16) - 1) - ((1<<(16-$maskCode)) - 1);
        return [$mask,$maskCode];
    }
}

if (!function_exists('parse_ip')) {
    /**
     * 解析ip段，返回ip、掩码、网段开始ip与结束ip
     *
     * @param   String  $ip_str
     * @return  Array   [IP, 掩码, 开始ip, 结束ip, ip个数, 可为主机ip个数]
     */
    function parse_ip($ip_str)
    {
        $mask_len = 32;
        if (strpos($ip_str, "/") > 0) {
            list($ip_str, $mask_len) = explode("/", $ip_str);
        }

        if ($mask_len == 32) {
            $usableHost = ((ip2long($ip_str) & 255) === 0 || (ip2long($ip_str) & 255) === 255 || (ip2long($ip_str) & 255) === 1) ? 0 : 1;
            return ['ip' => $ip_str, 'mask' => '255.255.255.255', 'start' => $ip_str,
            'end' => $ip_str, 'count' => 1, 'host' => $usableHost];
        }

        $ip = ip2long($ip_str);
        $mask = 0xFFFFFFFF << (32 - $mask_len) & 0xFFFFFFFF;
        $ip_start = $ip & $mask;
        $ip_end = $ip | (~$mask) & 0xFFFFFFFF;
        $ip_count = $ip_end - $ip_start + 1;
        $host_ip_count = $ip_count < 256 ? $ip_count - 2 : $ip_count - $ip_count / 256 * 3;
        return ['ip' => long2ip($ip), 'mask' => long2ip($mask), 'start' => long2ip($ip_start),
        'end' => long2ip($ip_end), 'count' => $ip_count, 'host' => $host_ip_count];
    }
}

if (!function_exists('is_ip_mask')) {
    /**
     * 是否为ip/mask格式
     *
     * @param   String  $ipStr
     * @return  Boolean
     */
    function is_ip_mask($ipStr, $maskRange = [1,32])
    {
        $ipMask = explode('/', $ipStr);
        return Validate::length($ipMask, 2) && Validate::is($ipMask[0], 'ip') && Validate::is($ipMask[1], 'number')
        && Validate::regex($ipMask[1], '/^[0-9]+$/') && Validate::between($ipMask[1], $maskRange);
    }
}

if (!function_exists('parse_ip_mask')) {
    /**
     * 解析ip/mask 192.168.2.5/24
     * @param  string    $ip_mask  ip/mask 192.168.2.5/24
     * @return array     ip
     */
    function parse_ip_mask(String $ip_mask)
    {
        $ip_mask = explode('/', $ip_mask);
        $ip = $ip_mask[0];
        $mask = $ip_mask[1];
        $pro_ip_arr = [];

        if (!is_numeric($mask)) {
            return $pro_ip_arr;
        }
    
        $a = pow(2, (32-$mask)) - 1;
        $start_ip_long = ~(ip2long($ip) & $a) & ip2long($ip);
        $end_ip_long = $start_ip_long + $a;
    
        $tmp_ip_long = $start_ip_long;
        while ($tmp_ip_long <= $end_ip_long) {
            if (!(($tmp_ip_long & 255) == 0 || ($tmp_ip_long & 255) == 255)) {
                $pro_ip_arr[] = long2ip($tmp_ip_long);
            }
            $tmp_ip_long ++ ;
        }
    
        return $pro_ip_arr;
    }
}

if (!function_exists('protocol_number')) {
    /**
     * 根据协议返回协议号
     *
     * @param   String  $protocol
     * @return  Boolean
     */
    function protocol_number($protocol)
    {
        $protocol_number = [
            'TCP'   =>  6,
            'UDP'   =>  17,
            'TCP/UDP' => 0
        ];
        return $protocol_number[$protocol];
    }
}

if (!function_exists('msectime')) {
    /**
     * 返回当前的毫秒时间戳
     *
     * @return  Int     $msectime
     */
    function msectime()
    {
        list($msec, $sec) = explode(' ', microtime());
        return (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
    }
}

if (!function_exists('download_file')) {
    /**
     * 下载文件
     *
     * @param   String  $filePath
     * @param   String  $fileName
     * @return  void
     */
    function download_file($filePath, $fileName)
    {
        //以只读和二进制模式打开文件
        $file = $filePath . $fileName;
        if (! file_exists($file)) {
            exit();
        }

        if (! filesize($file)) {
            exit();
        }

        $steam = fopen($filePath . $fileName, "rb");

        Header("Content-type: application/octet-stream");
        Header("Accept-Ranges: bytes");
        Header("Accept-Length: " . filesize($file));
        Header("Content-Disposition: attachment; filename=" . $fileName);
        //读取文件内容并直接输出到浏览器
        echo fread($steam, filesize($file));
        fclose($steam);
        exit();
    }

    if (!function_exists('format_time')) {
        /**
         * 时间戳格式化
         *
         * @param string $time 时间戳
         * @param string $format 输出格式
         * @return false|string
         */
        function format_time($time = '', $format='Y-m-d H:i:s')
        {
            return !$time ? '' : date($format, (int)$time);
        }
    }

    if (!function_exists('gmt_withTZ')) {
        /**
         * 生成附带时区标志的 GMT 时间
         * example "2018-03-31T04:04:10.000Z"
         * @param null $timestamp
         * @return false|string
         */
        function gmt_withTZ($timestamp = null)
        {
            $timestamp = $timestamp ?: time();
    
            return gmdate('Y-m-d\TH:i:s.v\Z', $timestamp);
        }
    }
}
