<?php

use think\Route;

Route::group('v1', function () {
    require APP_PATH . '/index/route/auth.php';
    require APP_PATH . '/index/route/admin.php';
    require APP_PATH . '/index/route/custom.php';
    require APP_PATH . '/index/route/vpn.php';
    require APP_PATH . '/index/route/reconnection.php';
    require APP_PATH . '/index/route/pool.php';
    require APP_PATH . '/index/route/equipment.php';
    require APP_PATH . '/index/route/local.php';
    require APP_PATH . '/index/route/logs.php';
});

Route::rule([
    '__miss__' => 'index/Index/index'
]);
