<?php

ini_set("display_errors", "On");
error_reporting(E_ALL | E_STRICT);

// $file_path = "start";

// $arr = simplexml_load_file($file_path);

// $arr = json_decode(json_encode($arr),true);

// $interfaces = [];

// foreach ($arr["interfaces"]["interface"] as $key => $value) {
// 	if (isset($value["protocols"])){
// 		$interfaces[$value["name"]] = $value["protocols"]["ipv4"]["ipv4-address"]["address"];
// 	}
// }



// print_r($interfaces);

// exec ("env", $re);
// // exec ("ls", $re);
// foreach ($re as $re1){                 
// 	echo $re1."</br>";
// }
// if (!empty("")){
// 	echo "dfgdf";
// }

// $con_str = "eth0_0:192.168.9.32|eth1_0:192.168.2.32";
// $cc = explode("|", $aaaaa);
// echo $cc[1];

// $arr = [];
// $con_arr = explode("|", $con_str);
// foreach ($con_arr as $key => $value) {
// 	$tmp_arr = explode(":", $value);
// 	$arr[$tmp_arr[0]] = $tmp_arr[1];
// }
// print_r($arr);

// $qqq = "sadasd";
// $qqq_arr = explode(",", $qqq);
// foreach ($qqq_arr as $key => $value) {
// 	# code...echo $val
// 	echo $value;
// }

// echo substr("eth0_0",3,1);


// $aaa = "layer2";
// if ($aaa == "layer2") {
// 	echo "gfdfgdfsg";
// }
// $ip["ip"] = "fdgdfgdfg";
// print_r($ip);


// $ips = ["1.1.1.1","2.2.2.2","3.3.3.3"];

// print_r(array_merge(array_diff($ips, array("1.1.1.1"))));

// $ip = "10.168.10.198";
// $port = "8610";
// $type = "";
// $aa = $ip.",".$port.",".$type;
// echo $aa."</br>";
// print_r(explode(",", $aa));

// echo 1>2?"fsdf":"dfgdfg";


// function aaa(){
// 	bbb();
// 	if (!function_exists("bbb")){
// 		function bbb(){
// 			echo "dfdsfdsf";
// 		}
// 	}
	
// }

// aaa();


// $aaa = [];
// $aaa["aaa"] = "dfgdsf";
// echo @$aaa["ccc"];


// $aaaa[0] = [11 => "1111111"];
// $aaaa[1] = [22 => "2222222"];
// $aaaa[2] = [33 => "3333333"];


// echo json_encode(array_values($aaaa));

// $cc = [];
// $cc["111"] = [];

// array_push($cc["111"], ["111" => "1111"]);
// echo json_encode($cc);


// $rr = "214748364800";
// echo intval($rr)*10;


// exec("dfdsfdsf");

// echo "fgdfg";


// $aaa = ["aaa","bbb","ccc"];

// echo $aaa[0];

// phpinfo();



// use send_mail\SendMail;


// require_once("SendMail.php"); 

// $mail = new SendMail;

// $flag = $mail -> send_mail('2876722663@qq.com','veda','veda mail test');
// if($flag){
//     echo "发送邮件成功！";
// }else{
//     echo "发送邮件失败！";
// }


// $ssss = "1111111111111111";
// echo "aaaa".intval(doubleval($res_list[0]["conf_value"])/8/1024/1024);

// $ip_arr = ["2.2.2.2","3.3.3.3"];

// $c_list = array_map(function($ip){
//     return ['white' =>1,'ip'=>$ip];
// },$ip_arr);
// $conf_json = [];
// $conf_json["server_white"] = $c_list;

// echo json_encode($conf_json);






// print_r(o_exec("uroot python router -m eyIxOTIuMTY4LjEwLjEwIjp7ImRvIjoxfX0="));

// function o_exec($order){	
// 	$output=array();
// 	$status=0;
// 	exec($order,$output,$status);
// 	if($status){
// 		$result = "$order: error";
// 	}else if (!empty($output)) {
// 		$result = toUTF($output[0]);
// 	} else {
//         $status = 1;
// 		$result = "exec error";
// 	}
// 	return array("status" => $status,"result" => $result);
// }
// function toUTF($result){
// 	return PATH_SEPARATOR==":"?$result:iconv("GB2312","UTF-8",$result);
// }

// if (strstr("aaaaaaa", "sss")) {
// 	echo "dfgdsgdfg";
// }

// strstr("aaaaaaa", "aa");

// file_put_contents("/root/eeeeeee", "dfdsfdsfds");
// $tmp = [];
// foreach (["fdsf","ghfgh","gfdg"] as $key => $value) {
// 	$tmp["in"]["aaa"][] = "fdgdfgdf";
// 	$tmp["in"]["aaa"][] = "5545454";
// 	var_dump($tmp);
// 	$tmp["in"]["aaa"] = [];
	
// }

// echo time();

// $tmp["in"]["aaa"][] = "fdgdfgdf";
// $tmp["in"]["aaa"][] = "5545454";
// $tmp["in"]["aaa"] = [];
// var_dump($tmp);
// echo doubleval("20");
// $aaa = "";
// $aaaa = null;

// if (empty($aaa)){
// 	echo "dfdsfdsf";
// }

// if (empty($aaaa)){
// 	echo "dfdsfdsf";
// }

// $aaa[] = "gfhgfh";
// $aaa[] = "dfgdfgdfgdgdfgdf";

// var_dump($aaa);

// function PasswordHash($password) {
//     $password = md5(hash("sha1", $password));
//     return $password;
// }
// echo PasswordHash("veda2017");

// $conf_arr = ["2.2.2.2|5.5.5.5","4.4.4.4|5.5.5.5"];


// foreach ($conf_arr as $key => $value) {
//     $v_vpn_arr[] = explode("|", $value)[0];
//     $r_vpn_arr[] = explode("|", $value)[1];
// }


// foreach ($v_vpn_arr as $key => $value) {
// 	unset($v_vpn_arr[$key]);
//     if (in_array($value, $v_vpn_arr)){
//         Error("10007","重复添加");
//     }
// }
// foreach ($r_vpn_arr as $key => $value) {
// 	unset($r_vpn_arr[$key]);
//     if (in_array($value, $r_vpn_arr)){
//     	Error("10007","重复添加");
//     }
// }


// $redis = new \Redis();
// $redis->pconnect('127.0.0.1');
// $res = $redis->lPop('test_list');
// echo $res;
// if(array_key_exists("count", $res)){
// 	unset($res["count"]);
// }
// $uids = array_keys($res);
// var_dump($res);

// $aaa = "dfdsfds8";
// $aaa[strlen($aaa) - 1] = 0;
// echo $aaa;

// $result = [["conf_value" => "192.168.8.3|username|password|port|type|0"],["conf_value" => "192.168.8.3|username|password|port|type|0"]];
// foreach ($result as $key => $value) {
//             $each_ssh_con_arr = explode('|', $value["conf_value"]);
//             unset($each_ssh_con_arr[2]);
//             $res[] = implode("|", $each_ssh_con_arr);
//         }
// var_dump($res);

// $aa = ["111" => "aaa",
// 		"222" => "bbb"];
// $bb = json_encode($aa);
// echo "'\"".str_replace('"', '\\"',$bb)."\"'";
// echo str_replace('111', '4444',$bb);
// echo $bb;

// echo '\\"';

// $www = ["aaa","bbb","ccc"];
// echo json_encode($www)."</br>";
// $www = [];
// echo json_encode($www)."</br>";
// $www = ["ddasd"];
// echo json_encode($www)."</br>";
// echo array_pop($www);
// echo count($www);
// echo array_pop($www);
// echo count($www);
// echo array_pop($www);
// echo count($www);


// $qqq = "||";
// echo count(explode("|", $qqq));

// if(empty(0)){
// 	echo "1";
// }
// if(empty("")){
// 	echo "2";
// }
// if(empty(NULL)){
// 	echo "3";
// }
// function ip_parse($ip_str) {
//     $mark_len = 32;
//     if (strpos($ip_str, "/") > 0) {
//        list($ip_str, $mark_len) = explode("/", $ip_str);
//     }
//     $ip = ip2long($ip_str);
//     $mark = 0xFFFFFFFF << (32 - $mark_len) & 0xFFFFFFFF;
//     $ip_start = $ip & $mark;
//     $ip_end = $ip | (~$mark) & 0xFFFFFFFF;
//     return array($ip, $mark, $ip_start, $ip_end);
// }

// var_dump(ip_parse("1.1.1.1/24"));
// list($ip, $mark, $ip_start, $ip_end) = ip_parse("192.168.1.12/24");
// echo "IP地址 : ", long2ip($ip), "\n";
// echo "子网掩码: ", long2ip($mark), "\n";
// echo "IP段开始: ", long2ip($ip_start), "\n";
// echo "IP段结束: ", long2ip($ip_end), "\n";




// $ssh2 = ssh2_connect("192.168.16.182", "22");

// ssh2_auth_password($ssh2, 'root', '1qaz@WSX');

// ssh2_exec($ssh2, "service xl2tpd restart");





// if ($stream) {
// 	echo "success";
// }

//从远程服务器下载文件
// $stream=ssh2_scp_revc($ssh2, $remote_file, $local_file);
//返回值为返回值为bool值，true或false.


// $aaa = "
// sybase_data_seek(result_identifier, row_number)
// vbgdfgdfgdf
// dfgdfgf";

// $vpn_conf_str = "";
//     $vpn_conf_str .= "# Secrets for authentication using CHAP\n";
//     $vpn_conf_str .= "# client\tserver\tsecret\tIP addresses\n";
// echo $vpn_conf_str;

// if (""){
// 	echo "dsfdsf";
// }



// echo intval(time());

$redis = new \Redis();
$redis->pconnect('127.0.0.1');
$redis->hSet('G-status', $argv[1], json_encode(json_decode($argv[2],true)));




