# coding=utf-8

import logging, os, re, threading
import time, traceback, syslog, datetime
import random, time
import sys_info


def send_syslog(content, tag, type):
    syslog.openlog(tag, syslog.LOG_PID|syslog.LOG_INFO)
    syslog.syslog(type + " " + content)
    print type + " " + content
    syslog.closelog()



while True:
    timme = int(time.time())  
    if timme%30 == 0:
        info = sys_info.sys_info('127.0.0.1')
        info_arr = info.split(" ")
        info_arr[0] = '10.127.208.76'
        info = " ".join(info_arr)
        # print info
        #send sysinfo via syslog
        send_syslog(info, "report", "basic")
    time.sleep(1)