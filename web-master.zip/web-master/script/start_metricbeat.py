import socket, sys, os

def extern_ip(test_host):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect((test_host, 0))
    return s.getsockname()[0]

ip = sys.argv[1]

l_ip = extern_ip(ip)

cmd_cpu = "sed -i '114s/cpu_list.*/cpu_list_" + l_ip +  "\"/' metricbeat.yml"
cmd_memory = "sed -i '117s/memory_list.*/memory_list_" + l_ip +  "\"/' metricbeat.yml"
cmd_disk = "sed -i '120s/disk_list.*/disk_list_" + l_ip +  "\"/' metricbeat.yml"

os.system(cmd_cpu)
os.system(cmd_memory)
os.system(cmd_disk)

print "success!"