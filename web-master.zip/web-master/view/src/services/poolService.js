import xhr from './xhr/'

// 伪装原型池
class PoolService {
  getPool (page = 1, row = 10) {
    return xhr({
      url: `pool/ips?page=${page}&size=${row}`,
      method: 'GET'
    })
  }
  addPool (params) {
    return xhr({
      url: 'pool/ip',
      method: 'POST',
      contentType: 'json',
      body: params
    })
  }
  delPool (params) {
    return xhr({
      url: 'pool/ips',
      method: 'delete',
      body: params
    })
  }
  getUNUsePool(){
    return xhr({
      url: 'pool/usableips',
      method: 'GET'
    })
  }
}

// 实例化后再导出
export default new PoolService()
