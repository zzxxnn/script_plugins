import xhr from './xhr/'
class UserService {
  getUsers (page = 1, row = 10) {
    return xhr({
      url: 'connections',
      method: 'get',
      body: {
        page,
        row
      }
    })
  }

  addUser (params) {
    return xhr({
      url: 'connection',
      method: 'post',
      body: params
    })
  }

  updateUser (params, id) {
    return xhr({
      url: `connection/${id}`,
      method: 'put',
      body: params
    })
  }
  
  delUser (params) {
    return xhr({
      url: `connections`,
      method: 'delete',
      body: params
    })
  }

  getAllUsers () {
    return xhr({
      url: 'connection/privateips',
      method: 'get'
    })
  }

  offLineUser(id){
    return xhr({
      url: `connection/offline/${id}`,
      method: 'put'
    })
  }

  lockUser(id){
    return xhr({
      url: `connection/lock/${id}`,
      method: 'put'
    })
  }

  unlockUser(id){
    return xhr({
      url: `connection/unlock/${id}`,
      method: 'put'
    })
  }

}
export default new UserService()
