import xhr from './xhr'
class FrontService {
  getFront (page, row) {
    return xhr({
      url: `gplus/equipments?page=${page}&size=${row}`,
      method: 'get'
    })
  }
  
  delFront (params) {
    return xhr({
      url: 'gplus/equipments',
      method: 'delete',
      contentType: 'json',
      body: params
    })
  }

  addFront (params) {
    return xhr({
      url: 'gplus/equipment',
      method: 'post',
      contentType: 'json',
      body: params
    })
  }

  updateFront (params,id) {
    return xhr({
      url: `gplus/equipment/${id}`,
      method: 'put',
      contentType: 'json',
      body: params
    })
  }
}

export default new FrontService()
