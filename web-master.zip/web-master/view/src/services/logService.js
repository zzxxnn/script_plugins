import xhr from './xhr/'
class LogService {

  getIpChange(page = 1, row = 10, ip = '', time = ''){
    return xhr({
      url: 'logs/ipconversion',
      method: 'get',
      body: {
        page: page,
        size: row
      }
    })
  }

  getIpChangeDetail(page = 1, row = 10, ip = '', time = ''){

    return xhr({
      url: `logs/ipconversion/${ip}`,
      method: 'get',
      body: {
        page: page,
        size: row
      }
    })
  }

  getTotal(){
    return xhr({
      url: `custom/state`,
      method: 'get',
    })
  }

  getGLog(id = '', page = '', size = '', start_time = '', end_time = ''){
    return xhr({
      url: `g/log/${id}`,
      method: 'get',
      body: {
        page: page,
        size: size,
        start_time : start_time,
        end_time : end_time
      }
    })
  }

}
export default new LogService()
