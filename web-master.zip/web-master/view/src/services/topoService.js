import xhr from './xhr/'
class TopoService {
  getTopo () {
    return xhr({
      url: 'stats/dev?t=6&topo=true',
      method: 'get'
    })
  }

  getTopoStats () {
    return xhr({
      url: 'stats/dev?t=6',
      method: 'get'
    })
  }

  getFrontList (page = 1, row = 10) {
    return xhr({
      url: 'gplus/state',
      method: 'get',
      body: {
        page: page,
        size: row
      }
    })
  }
}

export default new TopoService()
