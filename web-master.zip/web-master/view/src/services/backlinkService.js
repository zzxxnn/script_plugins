import xhr from './xhr'
class BacklinkService {
  getBacklink (page, row) {
    return xhr({
      url: `reconnections?page=${page}&row=${row}`,
      method: 'get'
    })
  }

  addBacklink (link) {
    return xhr({
      url: 'reconnection',
      method: 'post',
      contentType: 'json',
      body: link
    })
  }

  delBacklink (ids) {
    return xhr({
      url: 'reconnections',
      method: 'delete',
      body: ids
    })
  }

  clearBacklink () {
    return xhr({
      url: 'reconnections',
      method: 'delete',
      body: {
        'ids': 'all'
      }
    })
  }

  getPriIP () {
    return xhr({
      url: 'uconnect/getpip',
      method: 'get'
    })
  }
}
export default new BacklinkService()
