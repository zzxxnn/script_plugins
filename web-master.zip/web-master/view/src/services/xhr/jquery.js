import { rootPath, errHandler } from './config'
import Vue from 'vue'
import messages from 'components/common/messages'
import store from '@/vuex/store'
import router from '@/router'
Vue.prototype.$t = function (val) {
  let firstKey = val.split('.')[0]
  let secondeKey = val.split('.')[1].toString()
  return messages.zh[firstKey][secondeKey] ? messages.zh[firstKey][secondeKey] : undefined
}

const xhr = ({ url, body = null, query = {}, method = 'get', other = {} }) => {
  const defer = $.Deferred()
  const params = _DEV_ ? {
    ...query,
    debug: true
  } : query

  let paramsStr = ''
  if (method.toLowerCase() === 'get') {
    params._ = Date.now()
    for(let k in params) {
      const dot = paramsStr ? '&' : '?'
      paramsStr += dot + `${k}=${params[k]}`
    }
  }

  if (method.toLowerCase() === 'post') {
    if (method.toLocaleLowerCase() === 'post') {
      body = JSON.stringify(body)
    }
    other.contentType = 'application/json'
  }

  $.ajax({
    type: method,
    url: rootPath + url + paramsStr,
    data: body,
    ...other
    // xhrFields: { // 跨域允许带上 cookie
    //   withCredentials: [域名]
    // },
    // crossDomain: true
  })
  .done(
    function(res){
      // if(!res.responseJSON.success){
      //   Vue.prototype.$message({
      //     showClose: true,
      //     message: res.responseJSON.errmsg,
      //     type: 'error',
      //     duration: 0
      //   })
      // }
      // defer.resolve(res.responseJSON)

      //--------------------------------------

      if(!res.success){

        if (res.errmsg == '需要登录') {
          router.push("/login")
          return defer.reject(res)
        }

        Vue.prototype.$message({
          showClose: true,
          message: res.errmsg,
          type: 'error',
          duration: 4000
        })
      }

      defer.resolve(res)
    }
  )
  .fail(
    function(res){

      // console.log(res)

      Vue.prototype.$message.close()
      let message = '服务异常或者检查网络, 请刷新重试'

      if (res.responseJSON && res.responseJSON.errmsg == '需要登录') {
        router.push("/login")
        return defer.reject(res)
      }
      
      Vue.prototype.$message({
        showClose: true,
        message: message,
        type: 'error',
        duration: 1000
      })

      if (/^5\d\d$/.test(res.status)) {
        return defer.reject(res)
      }

    }
  )
  return defer.promise()
}
export default xhr
