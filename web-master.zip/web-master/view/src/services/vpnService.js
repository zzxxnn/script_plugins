import xhr from './xhr'
class VPNService {

  getVPNSetting () {
    return xhr({
      url: 'vpn/settings',
      method: 'get'
    })
  }

  updateVPNSetting (params) {
    return xhr({
      url: 'vpn/virtualvpn',
      method: 'put',
      contentType: 'json',
      body: params
    })
  }

  updatePipSetting (params) {
    return xhr({
      url: 'vpn/privateip',
      method: 'put',
      contentType: 'json',
      body: params
    })
  }
}

export default new VPNService()
