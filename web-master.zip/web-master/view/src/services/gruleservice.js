import xhr from './xhr'
class GRuleService {
  getGRule () {
    return xhr({
      url: 'g/uploadrule',
      method: 'get'
    })
  }
  
  setGRule (params) {
    return xhr({
      url: 'g/uploadrule',
      method: 'put',
      contentType: 'json',
      body: params
    })
  }
}

export default new GRuleService()
