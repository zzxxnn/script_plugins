import xhr from './xhr/'
class CurrentService {
  getState (ip = '',range = '' ,cycle= '') {
    return xhr({
      url: `gplus/state/detail/${ip}`,
      method: 'get',
      body: {
        range: range,
        cycle: cycle
      }
    })
  }
  getFlow (type, IP = '') {
    if (IP === '' || IP === 'all') {
      return xhr({
        url: 'stats/flow?r=' + type,
        method: 'get'
      })
    }
    return xhr({
      url: 'stats/flow?r=' + type + '&ip=' + IP,
      method: 'get'
    })
  }
  getBlackHole () {
    return xhr({
      url: 'stats/black_hole'
    })
  }
  setTraction (ip) {
    return xhr({
      url: 'guide/set',
      method: 'post',
      body: {
        ip: ip,
        do: '1'
      }
    })
  }
}
export default new CurrentService()
