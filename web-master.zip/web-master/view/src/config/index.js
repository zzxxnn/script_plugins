export const titleMap = {
    '/control': '用户接入配置',
    '/control/netaddr': '网络地址配置',
    '/control/account_manage': '账户管理',
    '/control/control': '用户接入配置',
    '/control/user_info': '用户接入配置',
    '/control/vpnserver': 'VPN服务器配置',
    '/control/vpn_maped': 'VPN地址映射配置',
    '/control/connect_back': '被动回连配置',
    '/control/camouflage': '伪装原型池配置',
    '/control/grule': 'G设备规则上传配置',
    '/control/sys_status': '设备运行状态',
    '/control/linkinfo': '链路信息',
    '/control/g_status': 'G设备保活信息',
    '/control/vpn_setting': 'VPN配置',
    '/control/front_status': '前端机状态  红色ip表示Ｇ设备处于断开状态',
    '/control/user_log': 'ip变换日志',
    '/control/g_log': 'G设备保活日志',
    '/control/frontmgr': '前端机管理'
}

export default {
  titleMap
}
