<template>
  <div class="ctl-wrap">
      <el-aside :width="collapsed ? '56px' : '180px'"
                class="leftbar"
                :class="{ collapsed }">
        <el-menu router
                :default-active="$route.path"
                :collapse="collapsed"
                text-color="#bfcbd9"
                active-text-color="#409eff"
                background-color="#202a38">

          <el-submenu index="2">
            <template slot="title">
              <img src="/static/img/icon-conf.png" width="14" class="mr-sm">
              <span>系统配置</span>
            </template>
            <!-- <el-menu-item index="/control/netaddr">网络地址配置</el-menu-item> -->
            <el-menu-item index="/control/account_manage">账户管理</el-menu-item>
          </el-submenu>
          <el-submenu index="3">
            <template slot="title">
              <img src="/static/img/icon-conf.png" width="14" class="mr-sm">
              <span>业务配置</span>
            </template>
            <el-menu-item index="/control/user_info">用户接入配置</el-menu-item>
            <!-- <el-menu-item index="/control/vpnserver">VPN服务器配置</el-menu-item>
            <el-menu-item index="/control/vpn_maped">VPN地址映射配置</el-menu-item> -->
            <el-menu-item index="/control/vpn_setting">VPN配置</el-menu-item>
            <el-menu-item index="/control/connect_back">被动回连配置</el-menu-item>
            <el-menu-item index="/control/camouflage">伪装原型池配置</el-menu-item>
            <el-menu-item index="/control/grule">G设备规则上传配置</el-menu-item>
            <el-menu-item index="/control/frontmgr">前端机管理</el-menu-item>
          </el-submenu>
          <el-submenu index="4">
            <template slot="title">
              <img src="/static/img/icon-monitor.png" width="14" class="mr-sm">
              <span>实时监控</span>
            </template>
            <el-menu-item index="/control/sys_status">本机状态</el-menu-item>
            <el-menu-item index="/control/front_status">前端机状态</el-menu-item>
            <!-- <el-menu-item index="/control/user_status">用户状态</el-menu-item> -->
            <!-- <el-menu-item index="/control/user">G设备保活信息</el-menu-item> -->
          </el-submenu>
          <el-submenu index="1">
            <template slot="title">
              <img src="/static/img/icon-log.png" width="14" class="mr-sm">
              <span>日志</span>
            </template>
            <el-menu-item index="/control/user_log">ip变换日志</el-menu-item>
            <el-menu-item index="/control/g_log">G设备保活日志</el-menu-item>
          </el-submenu>
        </el-menu>
        <a class="toggle"
          @click="expand">
          <i class="el-icon-arrow-left"></i>
        </a>
      </el-aside>
      <div class="content">
        <el-card class="page-head-line">
            <h3>{{textTitle}}</h3>
        </el-card>
        <el-card>
            <router-view></router-view>
        </el-card>
      </div>
  </div>
</template>
<script>
import { titleMap } from 'config'
export default {
  data () {
    return {
      showIndex: null,
      run: false,
      load: false,
      online: false,
      collapsed: false,
      collapsedKey: 'HD_MENU_COLLAPSED'
    }
  },
  created () {
    const collapsed = window.localStorage.getItem(this.collapsedKey)
    this.collapsed = collapsed ? collapsed === 'true' : false
  },
  computed: {
    textTitle: function () {
        if (this.$route.path === '/control/user_log_detail') {
          return this.$route.query.username === undefined ? 'ip变换日志' : "用户: [  "　+ this.$route.query.username + "  ] ip变换日志"
        }else if (this.$route.path === '/control/sys_status') {
          return this.$route.query.ip === undefined ? titleMap[this.$route.path] : "设备: [ " + this.$route.query.ip + " ] 运行状态"
        }else{
          return titleMap[this.$route.path]
        }
    }
  },

  methods: {
    expand() {
      this.collapsed = !this.collapsed
      window.localStorage.setItem(this.collapsedKey, String(this.collapsed))
    },
    jumpTo (path) {
      this.$router.push(path)
    }
  }
}
</script>
<style lang="scss">
.ctl-wrap {
  display: flex;
  width: 100%;
  height: 100%;
  position: relative;
}

.content {
  flex: 1;
  padding: 20px;
}
</style>
