<template>

    <div class='glog'>
      <el-row>
        <el-col :span="24">
          <span>IP:&nbsp;&nbsp;
                <el-input v-model="queryip" style="width:220px;" placeholder="请输入要查询的g设备ip"></el-input>
                &nbsp;&nbsp;时间范围：&nbsp;&nbsp;
                <el-date-picker
                  v-model="timerange"
                  type="datetimerange"
                  :picker-options="pickerOptions2"
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  align="right">
                </el-date-picker>&nbsp;&nbsp;
                <el-button type='primary' @click="submitQuery" :loading="queryIsSubmitting" icon="el-icon-search">查询</el-button>
          </span>
        </el-col>
      </el-row>
      <div>
        <el-row>
          <el-col :span="12">
            <div>
              <el-table
              stripe
              border
              :data="userdetaillog">
                  <el-table-column label="G设备状态" align='center'>
                  <template slot-scope="scope">
                      {{ scope.row.g_status }}
                  </template>
                  </el-table-column>
                  <el-table-column label="时间" align='center'>
                  <template slot-scope="scope">
                      {{ scope.row.g_time }}
                  </template>
                  </el-table-column>
              </el-table>
            </div>
        </el-col>
        <el-col :span="12">
            <div>
                <el-table
                stripe
                border
                :data="userdetaillog1">
                    <el-table-column label="G设备状态" align='center'>
                        <template slot-scope="scope">
                            {{ scope.row.g_status }}
                        </template>
                    </el-table-column>
                    <el-table-column label="时间" align='center'>
                        <template slot-scope="scope">
                            {{ scope.row.g_time }}
                        </template>
                    </el-table-column>
                </el-table>
            </div>
        </el-col>
        </el-row>
        <div class="gstatus-page" style="text-align: center">
            <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="currentPage"
                :page-sizes="[10, 20, 50, 100]"
                :page-size="pagesize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalitem">
            </el-pagination>
        </div>
      </div>
    </div>

</template>
<script>

import logService from 'services/logService'
import {formatDate} from '../../../common/date.js'

export default {
    data () {
      return {
        p_ip: '',
        totaluser: 0,
        onlineuser: 0,
        alluserdetaillog: [],
        userdetaillog: [],
        userdetaillog1: [],
        currentPage: 1,
        totalitem: 10,
        pagesize: 20,
        queryIsSubmitting: false,
        pickerOptions2: {
          shortcuts: [{
            text: '最近一周',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
              picker.$emit('pick', [start, end]);
            }
          }, {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
              picker.$emit('pick', [start, end]);
            }
          }, {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
              picker.$emit('pick', [start, end]);
            }
          }]
        },
        timerange: '',
        queryip: ''

      }
    },
    created () {
      this.queryip = this.$route.query.g_ip
      if (this.queryip != undefined) {
        const end = new Date();
        const start = new Date();
        start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
        this.timerange = [start, end]
        this.pagemodify()
      }

    },
    mounted(){
      this.userdetaillog = [
      ]
      this.userdetaillog1 = [
      ]
      // this.pagemodify()
    },
    methods: {

      submitQuery () {
        console.log(this.queryip);
        if (!this.checkip(this.queryip)) {
          this.$message({
            message: 'IP格式错误',
            type: 'error'
          });
          this.queryip = ''
          return
        }
        if (this.timerange === '') {
          this.$message({
            message: '请选择时间',
            type: 'error'
          });
          // this.queryip = ''
          return
        }

        let start = formatDate(this.timerange[0], 'yyyy-MM-dd hh:mm:ss');
        let end = formatDate(this.timerange[1], 'yyyy-MM-dd hh:mm:ss');

        logService.getGLog(this.queryip, this.currentPage, this.pagesize, start, end).then(res => {
          if (res.success) {
            this.totalitem = res.data.total
            this.alluserdetaillog = res.data.list.map(item => {
              let ress = []
              ress.g_status = item.g_status
              ress.g_time = item.g_time
              return ress
            })
            this.userdetaillog = this.alluserdetaillog.slice(0, this.alluserdetaillog.length/2)
            this.userdetaillog1 = this.alluserdetaillog.slice(this.alluserdetaillog.length/2, this.alluserdetaillog.length)
          }
        }).always()
      },

      pagemodify () {
        this.submitQuery()
      },
      checkip (fip) {
        let reg = /^((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){3}(2[0-4]\d|25[0-5]|[01]?\d\d?)$/
        let status = reg.test(fip)
        if (!status) {
          return false
        }
        return true
      },
      handleSizeChange(val) {
        this.pagesize = val
        this.pagemodify()

      },
      handleCurrentChange(val) {
        this.currentPage = val
        this.pagemodify()
      },
      userdesc(username) {
        this.$router.push()
      }

    }

}
</script>

<style lang='scss' scoped>
.el-col{
  padding: 10px;
  // border: solid;
  // border-width: 2px;
  // border-color: red;
}
.log-card-top{
  height: 200px
}
// .userlog{
//     display: flex;
//     flex-wrap: wrap;
// }
</style>

