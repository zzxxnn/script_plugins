<template>
  <el-row>
    <el-col :span='24'>
      <div class='cpuheader'>
        <p><span>运行状态</span></p>
        <p>
          <!-- <span>
            <i v-if='!serverStatus' @click="serverStatus=!serverStatus" class="icon-vd-play"></i>
            <i v-else @click="serverStatus=!serverStatus" class="icon-vd-pause-20"></i>
            {{serverStatus ? '暂停' : '监控'}}
          </span>
          <el-button @click='getState(timeRange)' :disabled='serverStatus'>刷新</el-button> -->
          选择时间范围：
          <i class="el-icon-caret-left" @click="prebtn"></i>
          <span @click='changeRange'>{{rangeType(timeRange)}}</span>
          <i class="el-icon-caret-right" @click="nextbtn"></i>
        </p>
      </div>
      <div class="timerange">
        <p>时间范围：</p>
        <ul>
          <li><el-button @click="show(1)">最近1小时</el-button></li>
          <li><el-button @click="show(2)">最近12小时</el-button></li>
          <li><el-button @click="show(3)">最近24小时</el-button></li>
          <li><el-button @click="show(4)">最近3天</el-button></li>
          <li><el-button @click="show(5)">最近7天</el-button></li>
          <li><el-button @click="show(6)">最近15天</el-button></li>
          <li><el-button @click="show(7)">最近30天</el-button></li>
        </ul>
      </div>
      <div class="chart">
        <h3 style="text-align:center">设备CPU运行状态</h3>
        <percent :picData.sync='cpuData' :timeRange.sync="timeRange" :status='serverStatus'></percent>
      </div>
      <div class="chart">
        <h3 style="text-align:center">设备内存存储状态</h3>
        <memory :picData.sync='memoryData' :timeRange.sync="timeRange" :status='serverStatus' :total.sync='memoryTotal'></memory>
      </div>
      <div class="chart" style="margin-bottom:15px">
        <h3 style="text-align:center">设备硬盘存储状态</h3>
        <disk :picData.sync='diskData' :timeRange.sync="timeRange" :status='serverStatus' :total.sync='diskTotal'></disk>
      </div>
    </el-col>
  </el-row>
</template>
<script>
import percent from '@/components/common/percent'
import memory from '@/components/common/memory'
import disk from '@/components/common/disk'
import currentService from 'services/currentService'
export default {
  components: {
    percent,
    memory,
    disk
  },
  data () {
    return {
      timeRange: 1,
      rangebtn: false,
      cpuData: [{timestamp: 0, value: 0}],
      memoryData: [{timestamp: 0, value: 0}],
      diskData: [{timestamp: 0, value: 0}],
      serverStatus: false,
      timer: null,
      memoryTotal: 0,
      diskTotal: 0,
      ip: '',
      cycle: 1
    }
  },
  mounted: function () {
    $('.timerange').hide()
    this.ip = this.$route.query.ip === undefined ? '10.127.208.76' : this.$route.query.ip
    this.getState(this.timeRange)
  },
  created(){
    // this.getState(this.timeRange)
  },
  watch: {
    timeRange: function () {
      this.serverStatus = false
      this.show(this.timeRange, 'aaa')
      this.getState(this.timeRange)
      this.$emit('update:timeRange', this.timeRange)
    },
    serverStatus: function () {
      // this.getState(this.timeRange)
    }
  },
  methods: {
    getState (index) {
      console.log(this.ip);

      currentService.getState(this.ip, this.timeRange, this.cycle)
        .then((res) => {
          if (res.success) {
            this.cpuData = res.data.map((item, index) => {
              let obj = {
                value: Number(item.cpu_load),
                timestamp: new Date(item.time).getTime()
              }
              return obj
            })
            let memoryTotal = 0
            let memoryData = res.data.map((item, index) => {
              if (memoryTotal < Number(item.mem_total)) {
                memoryTotal = Number(item.mem_total)
              }
              let obj = {
                value: Number(item.mem_total) - Number(item.mem_free),
                timestamp: new Date(item.time).getTime()
              }
              return obj
            })
            this.memoryTotal = memoryTotal
            this.memoryData = memoryData

            let diskTotal = 0
            let diskData = res.data.map((item, index) => {
              if (diskTotal < Number(item.disk_capa)) {
                diskTotal = Number(item.disk_capa)
              }
              let obj = {
                value: Number(item.disk_capa) - Number(item.disk_avail),
                timestamp: new Date(item.time).getTime()
              }
              return obj
            })
            this.diskTotal = diskTotal
            this.diskData = diskData
            // if (this.serverStatus) {
            //   clearTimeout(this.timer)
            //   this.timer = setTimeout(() => {
            //     this.getState(this.timeRange)
            //   }, 5000)
            // }
          }
        })
        .fail((res) => {
          this.serverStatus = false
          clearInterval(this.timer)
        })
    },
    changeRange () {
      this.rangebtn = !this.rangebtn
      if (this.rangebtn) {
        $('.timerange').show()
      } else {
        $('.timerange').hide()
      }
    },
    show (index, lr = '') {

      if (lr === '') {
        this.timeRange = index
        this.rangebtn = !this.rangebtn
        $('.timerange').hide()
      }

      switch (index) {
      case 1:
        this.cycle = 2
        break
      case 2:
        this.cycle = 3
        break
      case 3:
        this.cycle = 3
        break
      case 4:
        this.cycle = 5
        break
      case 5:
        this.cycle = 5
        break
      case 6:
        this.cycle = 6
        break
      case 7:
        this.cycle = 7
        break
      default:
        this.cycle = 1
        break
      }
    },
    rangeType (index) {
      let type = ''
      switch (index) {
      case 1:
        type = '最近1小时'
        break
      case 2:
        type = '最近12小时'
        break
      case 3:
        type = '最近24小时'
        break
      case 4:
        type = '最近3天'
        break
      case 5:
        type = '最近7天'
        break
      case 6:
        type = '最近15天'
        break
      case 7:
        type = '最近30天'
        break
      default:
        type = '最近1小时'
        break
      }
      return type
    },
    prebtn () {
      if (this.timeRange === 1) {
        return
      }
      this.timeRange--
    },
    nextbtn () {
      if (this.timeRange === 7) {
        return
      }
      this.timeRange++
    }
  },
  beforeDestroy () {
    this.serverStatus = false
    clearTimeout(this.timer)
  }
}
</script>

<style scoped lang='scss'>
  .cpuheader{
    display: flex;
    justify-content: space-between;
    span {
      font-size: 15px;
      margin:0 5px;
      cursor: pointer;
      display: flex;
      align-items: center;
      i{
        margin: 0 10px;
      }
    }
    button{
      margin: 0 10px;
    }
    p{
      display: flex;
      align-items: center;
    }
    i {
        width: 20px;
        font-size: 25px;
        cursor: pointer;
        margin: 0 5px;
      }
  }
  .timerange{
    margin-top: 15px;
    padding: 10px 20px;
    box-sizing: border-box;
    p {
      font-size: 15px;
    }
    background: #fff;
    display: flex;
    justify-content: flex-start;
    ul {
      max-width: 500px;
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
      li{
        padding: 5px 15px;
      }
    }
  }
  .chart{
    padding: 20px 0;
    box-sizing: border-box;
    margin-top: 15px;
    background: #fff;
    h3{
      font-size: 15px;
      font-weight: 600;
    }
  }
</style>
