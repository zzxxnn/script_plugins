<template>

    <div class='userlog'>
        <el-row>
          <el-col :span="12">
            <el-card>
              <div class='log-card-top'>
                <div>
                  <img src="/static/img/total.png" width='150'>
                </div>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{totaluser}}<br/>
                登录客户总数
              </div>
            </el-card>
          </el-col>
          <el-col :span="12">
            <el-card>
              <div class='log-card-top'>
                <div>
                  <img src="/static/img/online.png" width='150'>
                </div>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{onlineuser}}<br/>
                目前在线人数
              </div>
            </el-card>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-card>
              <div>
                <el-table
                stripe
                border
                :data="alluserlog">
                  <el-table-column label="用户名" align='center'>
                    <template slot-scope="scope">
                        {{ scope.row.username }}
                    </template>
                  </el-table-column>
                  <el-table-column label="国内IP" align='center'>
                    <template slot-scope="scope">
                        {{ scope.row.in_ip }}
                    </template>
                  </el-table-column>
                  <el-table-column label="私有IP" align='center'>
                    <template slot-scope="scope">
                        {{ scope.row.priv_ip }}
                    </template>
                  </el-table-column>
                  <el-table-column label="伪装IP" align='center'>
                    <template slot-scope="scope">
                        {{ scope.row.switchip }}
                    </template>
                  </el-table-column>
                  <el-table-column label="变换时间" align='center'>
                    <template slot-scope="scope">
                        {{ scope.row.switchtime }}
                    </template>
                  </el-table-column>
                  <el-table-column label="详情" align='center'>
                    <template slot-scope="scope">
                        <div @click="userdesc(scope.row.username, scope.row.priv_ip)"><a>点击查看详情</a></div>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <div class="gstatus-page" style="text-align: center">
                <el-pagination
                  @size-change="handleSizeChange"
                  @current-change="handleCurrentChange"
                  :current-page="currentPage"
                  :page-sizes="[5, 10, 20, 50]"
                  :page-size="pagesize"
                  layout="total, sizes, prev, pager, next, jumper"
                  :total="totalitem">
                </el-pagination>
              </div>
            </el-card>
          </el-col>
        </el-row>
    </div>

</template>
<script>

import logService from 'services/logService'

export default {
    created(){
      this.pagemodify()
    },
    data () {
      return {
        totaluser: 0,
        onlineuser: 0,
        alluserlog: [],
        currentPage: 1,
        totalitem: 10,
        pagesize: 10,
      }
    },
    mounted(){

    },
    methods: {

      pagemodify(){
        logService.getIpChange(this.currentPage,this.pagesize).then(res => {
          if (res.success) {
            this.totalitem = res.data.total
            this.alluserlog = res.data.list.map(item => {
              let ress = []
              ress.username = item.username
              ress.in_ip = item.int_ip
              ress.priv_ip = item.priv_ip
              ress.switchip = item.cam_ip
              ress.switchtime = item.time
              return ress
            })
          }

        }).always()
        logService.getTotal().then(res => {
          if (res.success) {
            this.totaluser = res.data.total_user_counts
            this.onlineuser = res.data.online_user_counts
          }
        }).always()

      },
      handleSizeChange(val) {
        this.pagesize = val
        this.pagemodify()

      },
      handleCurrentChange(val) {
        this.currentPage = val
        this.pagemodify()
      },
      userdesc(username, p_ip) {
        this.$router.push(`user_log_detail?username=${username}&p_ip=${p_ip}`)
      }
    }

}
</script>

<style lang='scss' scoped>
.el-col{
  padding: 10px;
  // border: solid;
  // border-width: 2px;
  // border-color: red;
}
.log-card-top{
  height: 200px;
  // padding: 150px;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  font-size: 30px;
  color: #00C4C2;
  justify-content: space-between;
  padding: 30px;
}
</style>

