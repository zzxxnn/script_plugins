<template>
  <div class="content">

    <statusitem
      v-for = "itemdata in currenttopodata"
      :ip = "itemdata.ip"
      :time = "itemdata.time"
      :status = "itemdata.status"
      :gsets = "itemdata.g_sets"
      :key= "itemdata.ip"
      >
    </statusitem>
		<div class="gstatus-page" style="text-align: center">
			<el-pagination
				@size-change="handleSizeChange"
				@current-change="handleCurrentChange"
				:current-page="currentPage"
				:page-sizes="[5, 10, 20, 50]"
				:page-size="pagesize"
				layout="total, sizes, prev, pager, next, jumper"
				:total="totalitem">
			</el-pagination>
		</div>


  </div>
</template>
<script>

import topoService from 'services/topoService'
import statusitem from './frontstatusitem'

import {formatDate} from '../../../common/date.js';

export default {
  components: {
    statusitem
  },
  data () {
    return {
			topodata: [],
			topodataarr: [],
			currenttopodata: [],
			currentPage: 1,
			totalitem: 10,
			pagesize: 5,
			liveTime: 300000
    }
  },
  created () {
    this._gettopodata()
  },
  methods: {
		handleSizeChange(val) {
			this.pagesize = val
			this.pagemodify()

		},
		handleCurrentChange(val) {
			this.currentPage = val
			this.pagemodify()
		},
		pagemodify(){
      this._gettopodata()

		},
		_gettopodata(){
			topoService.getFrontList(this.currentPage, this.pagesize).then((res) => {
				if(res.success){
          this.totalitem = res.data.total
          this.currenttopodata = res.data.list.map(item => {
            let front = {'ip': item.g_plus_ip, 'time': item.g_plus_time, 'status': item.g_plus_status, 'g_sets': '' }
            let g_sets_arr = item.g_ips.split(',')
            front['g_sets'] = g_sets_arr.map(item => {
              return { 'status': item.split(":")[1], 'ip': item.split(":")[0] }
            })
            return front
          })
          // console.log(this.topodata)
          // console.log(this.currenttopodata)
          // this.pagemodify()
					// this._setGstatus()
				}
			}).always(
			)
		},
		_setGstatus(){
				topoService.getTopoStats().then((res) => {
					if (res.errcode === 0) {
						let data = res['6']
						let serverTime = res['6']['server_time'] || parseInt((+new Date()))
						if (data) {
							for (let frontip in data) {
								if (frontip !== 'server_time') {
									let fip = data[frontip]
									let fstatus = Math.abs(fip.timestamp - serverTime) > this.liveTime ? 'off' : 'on'
									this.topodata[frontip]['status'] = fstatus
									this.topodata[frontip]['time'] = formatDate(new Date(fip.timestamp), 'yyyy-MM-dd hh : mm');
									for (let gip in fip) {
										if (gip !== 'timestamp') {
											this.topodata[frontip]["g_sets"][gip]['status'] = (fstatus === 'off' ? 'off' : (fip[gip]['status'] === 'down' ? 'off' : Math.abs(fip[gip].timestamp - fip.timestamp) > this.liveTime ? 'off' : 'on'))
										}
									}
								}
							}
						}
						this.topodataarr = []
						for (let fip in this.topodata) {
							let g_sets = []
							let g_sets_arr = this.topodata[fip]['g_sets']
							for (let gip in g_sets_arr) {
								g_sets.push(g_sets_arr[gip])
							}
							this.topodata[fip]['g_sets'] = g_sets
							this.topodataarr.push(this.topodata[fip])
						}

						this.totalitem = this.topodataarr.length
						this.pagemodify()
						console.log(res)
					}
				}).always(

				)
		}
  }
}
</script>
<style>
/* .content{
  display: flex;
  flex-direction: column;
  justify-content: center;
} */
</style>

