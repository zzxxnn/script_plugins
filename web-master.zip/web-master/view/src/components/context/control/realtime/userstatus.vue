<template>

    <div class='userlog'>
        <el-row>
          <el-col :span="12">
            <el-card>
              <div class='log-card-top'>
                <div>
                  <img src="/static/img/total.png" width='150'>
                </div>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{totaluser}}<br/>
                登录客户总数
              </div>
            </el-card>
          </el-col>
          <el-col :span="12">
            <el-card>
              <div class='log-card-top'>
                <div>
                  <img src="/static/img/online.png" width='150'>
                </div>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{onlineuser}}<br/>
                目前在线人数
              </div>
            </el-card>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-card>
              <div>
                <el-table 
                stripe
                border
                :data="alluserlog">
                  <el-table-column label="用户名" align='center'>
                    <template slot-scope="scope">
                        {{ scope.row.username }}
                    </template>
                  </el-table-column>
                  <el-table-column label="国内IP" align='center'>
                    <template slot-scope="scope">
                        {{ scope.row.userid }}
                    </template>
                  </el-table-column>
                  <el-table-column label="私有IP" align='center'>
                    <template slot-scope="scope">
                        {{ scope.row.switchip }}
                    </template>
                  </el-table-column>
                  <el-table-column label="伪装IP" align='center'>
                    <template slot-scope="scope">
                        {{ scope.row.switchip }}
                    </template>
                  </el-table-column>
                  <el-table-column label="变换时间" align='center'>
                    <template slot-scope="scope">
                        {{ scope.row.switchtime }}
                    </template>
                  </el-table-column>
                  <el-table-column label="详情" align='center'>
                    <template slot-scope="scope">
                        <div @click="userdesc(scope.row.username)">点击查看详情</div>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <div class="gstatus-page" style="text-align: center">
                <el-pagination
                  @size-change="handleSizeChange"
                  @current-change="handleCurrentChange"
                  :current-page="currentPage"
                  :page-sizes="[5, 10, 20, 50]"
                  :page-size="pagesize"
                  layout="total, sizes, prev, pager, next, jumper"
                  :total="totalitem">
                </el-pagination>
              </div>
            </el-card>
          </el-col>
        </el-row>
    </div>
    
</template>
<script>



export default {
    data () {
      return {
        totaluser: 0,
        onlineuser: 0,
        alluserlog: [],
        currentPage: 1,
        totalitem: 10,
        pagesize: 5,
      }
    },
    mounted(){
      this.alluserlog = [
        {username: 'a1aa', userid: '11.1.1.1', switchip: '1.122.1.1', switchtime: '2018-11-11 10:25'},
        {username: 'aa2a', userid: '1.21.1.1', switchip: '1.1.122.1', switchtime: '2018-11-11 10:25'},
        {username: 'aaa3', userid: '1.13.1.1', switchip: '1.1.1.221', switchtime: '2018-11-11 10:25'},
        {username: 'aaa4', userid: '1.1.41.1', switchip: '1.1.21.1', switchtime: '2018-11-11 10:25'},
        {username: 'aaa5', userid: '1.1.15.1', switchip: '1.1.91.1', switchtime: '2018-11-11 10:25'},
        {username: 'aaa6', userid: '1.1.1.61', switchip: '1.1.81.1', switchtime: '2018-11-11 10:25'},
        {username: 'aaa7', userid: '1.1.1.17', switchip: '1.1.71.1', switchtime: '2018-11-11 10:25'},
        {username: 'aaa8', userid: '1.1.1.18', switchip: '1.41.1.1', switchtime: '2018-11-11 10:25'},
        {username: 'aaa9', userid: '1.1.1.19', switchip: '16.1.1.1', switchtime: '2018-11-11 10:25'}
      ]
    },
    methods: {
      handleSizeChange(val) {
        this.pagesize = val
        this.pagemodify()

      },
      handleCurrentChange(val) {
        this.currentPage = val
        this.pagemodify()
      },
      userdesc(username) {
        this.$router.push(`user_log_detail?username=${username}`)
      }
    }

}
</script>

<style lang='scss' scoped>
.el-col{
  padding: 10px;
  // border: solid;
  // border-width: 2px;
  // border-color: red;
}
.log-card-top{
  height: 200px;
  // padding: 150px;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  font-size: 30px;
  color: #00C4C2;
  justify-content: space-between;
  padding: 30px;
}
</style>

