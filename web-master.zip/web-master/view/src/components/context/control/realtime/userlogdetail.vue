<template>

    <div class='userlog'>
        <el-row>
          <el-col :span="12">
            <div>
              <el-table
              stripe
              border
              :data="userdetaillog">
                  <el-table-column label="伪装IP" align='center'>
                  <template slot-scope="scope">
                      {{ scope.row.switchip }}
                  </template>
                  </el-table-column>
                  <el-table-column label="变换时间" align='center'>
                  <template slot-scope="scope">
                      {{ scope.row.switchtime }}
                  </template>
                  </el-table-column>
              </el-table>
            </div>
        </el-col>
        <el-col :span="12">
            <div>
                <el-table
                stripe
                border
                :data="userdetaillog1">
                    <el-table-column label="伪装IP" align='center'>
                        <template slot-scope="scope">
                            {{ scope.row.switchip }}
                        </template>
                    </el-table-column>
                    <el-table-column label="变换时间" align='center'>
                        <template slot-scope="scope">
                            {{ scope.row.switchtime }}
                        </template>
                    </el-table-column>
                </el-table>
            </div>
        </el-col>
        </el-row>
        <div class="gstatus-page" style="text-align: center">
            <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="currentPage"
                :page-sizes="[10, 20, 50, 100]"
                :page-size="pagesize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalitem">
            </el-pagination>
        </div>

    </div>

</template>
<script>

import logService from 'services/logService'

export default {
    data () {
      return {
        p_ip: '',
        totaluser: 0,
        onlineuser: 0,
        alluserdetaillog: [],
        userdetaillog: [],
        userdetaillog1: [],
        currentPage: 1,
        totalitem: 10,
        pagesize: 20,
      }
    },
    created () {
      this.p_ip = this.$route.query.p_ip
      this.pagemodify()
    },
    mounted(){
      this.userdetaillog = [
      ]
      this.userdetaillog1 = [
      ]
      this.pagemodify()
    },
    methods: {
      pagemodify () {

        logService.getIpChangeDetail(this.currentPage, this.pagesize, this.p_ip).then(res => {
          console.log(res);
          if (res.success) {
            this.totalitem = res.data.total
            this.alluserdetaillog = res.data.list.map(item => {
              let ress = []
              ress.switchip = item.cam_ip
              ress.switchtime = item.time
              return ress
            })
            this.userdetaillog = this.alluserdetaillog.slice(0, this.alluserdetaillog.length/2)
            this.userdetaillog1 = this.alluserdetaillog.slice(this.alluserdetaillog.length/2, this.alluserdetaillog.length)
          }

        }).always()
      },
      handleSizeChange(val) {
        this.pagesize = val
        this.pagemodify()

      },
      handleCurrentChange(val) {
        this.currentPage = val
        this.pagemodify()
      },
      userdesc(username) {
        this.$router.push()
      }

    }

}
</script>

<style lang='scss' scoped>
.el-col{
  padding: 10px;
  // border: solid;
  // border-width: 2px;
  // border-color: red;
}
.log-card-top{
  height: 200px
}
// .userlog{
//     display: flex;
//     flex-wrap: wrap;
// }
</style>

