<template>
  <div class="backlink">
    <div class="content" v-loading="isLoading" :element-loading-text="loadingText" element-loading-background="rgba(255, 255, 255, .8)">
      <div class="content-inner">
        <div class="formtitle">
          <span>
            <!-- <el-form :model="queryForm" :inline='true' ref="queryForm" :rules="rules">
              <el-form-item label="IP:" prop='queryip'>
                <el-input v-model="queryForm.queryip" style="width:220px;"></el-input>
              </el-form-item>
              <el-form-item>
                <el-button type='primary' @click="submitQueryForm" :loading="queryIsSubmitting" icon="el-icon-search">查询</el-button>
              </el-form-item>
            </el-form> -->
          </span>

          <span>
            <el-button type='primary' size='mini' icon='el-icon-circle-plus-outline' @click="visible = true">添 加</el-button>
            <el-button type='primary' size='mini' icon='el-icon-delete' @click='del'>删 除</el-button>
          </span>
           <!-- <el-button icon='el-icon-remove-outline' type='primary' @click="clearAll">清 空</el-button> -->
        </div>
        <el-table border :data='tableData' @selection-change='selectItem'>
          <el-table-column type='selection' align='center' width='50'></el-table-column>
          <el-table-column type='index' label="序号" align='center'></el-table-column>
          <el-table-column label="前端机ip" align='center' width='150'>
            <template slot-scope="scope">
              <div v-show='!scope.row.isEditting'>
                    <span>{{scope.row.g_plus_ip}}</span>
                </div>
                <div v-show='scope.row.isEditting'>
                    <el-input
                        v-model="scope.row.g_plus_ip"
                        placeholder="前端机ip"
                        >
                    </el-input>
                </div>
            </template>
          </el-table-column>
          <el-table-column label="g设备ip" prop="g_ips" align='center'>
            <template slot-scope="scope">
                <div v-show='!scope.row.isEditting'>
                    {{scope.row.g_ips}}
                </div>
                <div v-show='scope.row.isEditting'>
                    <el-input
                        type='textarea'
                        :rows='2'
                        v-model="scope.row.g_ips"
                        placeholder="g设备ip"
                        >
                    </el-input>
                </div>
            </template>
          </el-table-column>
          <el-table-column label="操作" align='center' width="150px">
          <template slot-scope="scope">
            <el-button v-show="!scope.row.isEditting" type="text" size="small" @click="editRow(scope.row)">编辑</el-button>
            <el-button v-show="scope.row.isEditting" type="text" size="small" @click="updateRow(scope.row)">更新</el-button>
            <el-button v-show="scope.row.isEditting" type="text" size="small" @click="editRowCancel(scope.row)">取消</el-button>
          </template>
        </el-table-column>
        </el-table>
        <el-pagination small layout="sizes, prev, pager, next" :total="total"
            @size-change="handleSizeChange" @current-change="handleCurrentChange">
        </el-pagination>

        <el-dialog title='添加配置' width="60%" style="text-align:center" class="backlink-dialog" :visible.sync='visible'  @close='reset'>
          <el-alert  style="margin-top:10px;text-align:left" type="info" :closable="false" show-icon
            title="">
            <template>
              <ul>
                <li>前端机对应的g设备用逗号分隔开。</li>
              </ul>
            </template>
          </el-alert>
            <div style="margin-top:25px;">
                <el-form :model="addFormData" :rules="rules" ref="singleForm" style="width:400px;margin:0 auto">
                    <el-form-item label='前端机IP' label-width="80px" prop='frontip'>
                    <el-input v-model="addFormData.frontip" placeholder="请输入前端机IP"></el-input>
                    </el-form-item>
                    <el-form-item label='g设备ip' label-width="80px" prop='gsets' required>
                    <el-input v-model="addFormData.gsets" placeholder="请输入g设备IP,用逗号分隔开"></el-input>
                    </el-form-item>
                    <div style="text-align:right">
                    <el-button type='primary' @click="submitSingleForm" :loading="isSubmitting">确 定</el-button>
                    <el-button @click='visible=false,reset'>取 消</el-button>
                    </div>
                </el-form>
            </div>
        </el-dialog>
      </div>
    </div>
  </div>
</template>
<script>
import FrontService from 'services/frontService'
export default {
  data () {
    const regHandle = (callback, status) => {
      if (!status) {
        callback(new Error('IP格式错误'))
      }
    }
    const checkIp = (rule, value, callback) => {
      let regIp = /^(((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){3}(2[0-4]\d|25[0-5]|[01]?\d\d?))(\/([1-9]|[1-2][0-9]|3[0-2]))?$/

      // // 192.168.1.1-192.168.2.1
      // if (value.indexOf('-') !== -1) {
      //   let ips = value.split('-')
      //   if (ips.length) {
      //     let status = ips.every((ip) => {
      //       return regIp.test(ip)
      //     })
      //     regHandle(callback, status)
      //     return true
      //   }
      // }

      // 192.168.1.1/32
      if (value.indexOf('/') !== -1) {
        let ips = value.split('/')
        if (ips.length) {
          let status = regIp.test(ips[0]) && /^\d+$/.test(ips[1]) && Number(ips[1]) >= 1 && Number(ips[1]) <= 32
          regHandle(callback, status)
          return true
        }
      }

      // 如果只是一个ip
      let status = regIp.test(value)
      regHandle(callback, status)
    }
    const checkIps = (rule, value, callback) => {
      if (value.indexOf(',') !== -1) {
        let ips = value.split(',')
        ips.map((item) => {
          checkIp(rule, item, callback)
        })
        callback()
      }else{
        checkIp(rule, value, callback)
        callback()
      }
    }

    const checkIp1 = (rule, value, callback) => {
      let regIp = /^(((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){3}(2[0-4]\d|25[0-5]|[01]?\d\d?))(\/([1-9]|[1-2][0-9]|3[0-2]))?$/
      let status = regIp.test(value)
      if (!status) {
          callback(new Error('IP格式错误'))
      }else{
          callback()
      }
    }

    return {
      isSubmitting: false,
      queryIsSubmitting: false,
      isLoading: true,
      loadingText: '',
      type: '3',
      tableData: [],
      total: 0,
      page: 1,
      row: 10,
      visible: false,
      activeName: 'first',
      selectArr: [],
      queryForm: {
        queryip: ''
      },
      addFormData: {
        frontip: '',
        gsets: '',
      },
      rules: {
        queryip: [
          // { required: true, message: '不能为空', trigger: 'blur' },
          // { required: true, message: '不能为空', trigger: 'change' },
          { validator: checkIp1, trigger: '' }
        ],
        frontip: [
          { required: true, message: '不能为空', trigger: 'blur' },
          { required: true, message: '不能为空', trigger: 'change' },
          { validator: checkIp1, trigger: 'blur' }
        ],
        gsets: [
          { required: true, message: '不能为空', trigger: 'blur' },
          { required: true, message: '不能为空', trigger: 'change' },
          { validator: checkIps, trigger: 'blur' }
        ]
      },
      selectedItems: [],
      selectAll: false,
      nextIcon: true,
      usernamelist: []
    }
  },
  created () {
    this._loadData()
  },
  methods: {
    _loadData () {
      FrontService.getFront(this.page, this.row)
      .then((res) => {
        if (res.success) {
          this.tableData = res.data.list.map((item) => {
            let ret = {}
            ret.id = item.id
            ret.g_plus_ip = item.g_plus_ip
            ret.g_ips = item.g_ips
            ret.isEditting = false
            return ret
          })
          this.total = res.data.total
          this.dupTableData = this.tableData
          // JSON.parse(JSON.stringify(this.tableData))

          // this.total = 10
          this.isLoading = false
        }
      })
      .always(() => {
        this.isLoading = ''
      })
    },
    handleSizeChange (val) {
      this.row = val
      this._loadData()
    },
    handleCurrentChange (curpage) {
      this.page = curpage
      this._loadData()
    },

    reset () {
      this.$refs['singleForm'].resetFields()
    },

    close(){

    },

    editRow (row) {
      row.isEditting = true
    },

    updateRow (row) {
      $('.el-message').remove()

      this.isLoading = true
      this.loadingText = '正在更新中...'

      let params = {
        g_plus_ip: row.g_plus_ip,
        g_ips: row.g_ips,
      }

      FrontService.updateFront(params, row.id)
        .then((res) => {
          if (res.success) {
            // row.hide_ip = row.hideIps.slice(0)
            row.isEditting = false
            this.$message({
              showClose: true,
              message: '更新成功',
              type: 'success',
              duration: '1500'
            })
          }
          this.loading = false
          this.loadingText = ''
          this._loadData()
        }, () => {
          this.loading = false
          this.loadingText = ''
          this._loadData()
        })
    },
    editRowCancel (row) {
      row.hideIps = []
      row.isEditting = false
      let originRows = this.dupTableData.filter(item => {
        return item.id === row.id
      })

      if (originRows.length) {
        row.id = originRows[0].id
        row.g_plus_ip = originRows[0].g_plus_ip
        row.g_ips = originRows[0].g_ips
      }
    },

    del () {
      $('.el-message').remove()
      if (!this.selectArr.length) {
        this.$message({
          showClose: true,
          message: '请选择要删除的配置',
          type: 'error',
          duration: 0
        })
        return
      }
      this.$confirm('此操作将删除选中的前端机记录, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.isLoading = true
        this.loadingText = '正在删除中...'

        let idSelect = []
        this.selectArr.map(item => {
          idSelect.push(item.id)
        })

        FrontService.delFront({"ids": idSelect})
        .then((res) => {
          if (res.success) {
            this.$message({
              showClose: true,
              message: '删除成功！',
              type: 'success',
              duration: '1500'
            })
          }
          this._loadData()
        })
        .always(() => {
          this.isLoading = false
          this.loadingText = ''
        })
      })
      .catch(() => {})
    },
    selectItem (item) {
      this.selectArr = item
    },
    submitQueryForm() {
      this.$refs['queryForm'].validate((valid) => {
        if (valid) {
          alert('dfasdfasd')
        }

      })
    },
    submitSingleForm () {
      this.$refs['singleForm'].validate((valid) => {
        // let chkport = this.checkPort(this.singleFormData.protocol, this.singleFormData.dest_port, '.s_err_notice')
        if (valid) {
          this.isSubmitting = true

          let submi = {
              g_plus_ip: this.addFormData.frontip,
              g_ips: this.addFormData.gsets
          }

          FrontService.addFront(submi)
            .then((res) => {
                if (res.success) {
                this.$message({
                    showClose: true,
                    message: '添加成功',
                    type: 'success',
                    duration: '1500'
                })
                this.visible = false
                this.isSubmitting = false
                this._loadData()
                }
            }).always(() => {
                this.isSubmitting = false
            })
        } else {
          this.isSubmitting = false
          return false
        }
      })
    }
  }
}
</script>
<style>
.success-border,
.success-border:hover,
.success-border:focus {
  border-color: #67c23a !important
}
.error-border,
.error-border:hover,
.error-border:focus {
  border-color: #FF8E7A !important
}
.backlink-dialog .el-dialog {
  max-width: 1186px
}
.required-label:before {
  content: '*';
  color: #fa5555;
  margin-right: 4px;
}

.single-select,
.single-select.el-select .el-input {
  width: 100%
}
</style>

<style scoped>
.backlink table {
  width: auto !important;
}
.content-inner {
  margin-top: 20px;
}
.butn{
  width: 300px;
  margin-top: 30px;
  margin-left: 83px;
}
.formtitle {
  display: flex;
  justify-content: space-between;
  margin-bottom: 15px;
}
.el-pagination{
  margin-top: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.green{
  color: #5daf34;
}
.red{
  color: #ff3600;
}
.err{
   position: absolute;
   color: #fa5555;
   text-align: left;
}

th,td{
  padding-left: 10px;
  padding-right: 10px;
}
.batch-form .el-form-item {
  margin-bottom: 0
}
</style>
