<template>
  <div class="content">
    <div>
      <el-form
        :model="formData"
        :rules="rules"
        label-width="135px"
        label-position="right"
        status-icon
        ref="addrFromvpnsetting"
        @keyup.enter.native="setGRule('addrFromvpnsetting')">
        <el-card>
        <div class='card-div'>
        <el-form-item label="虚拟vpnIP" prop="vpnip">
          <div class="f-fw-n">
          <el-input v-model="formData.vpnip" placeholder="请输入虚拟vpn IP"></el-input>
          </div>
        </el-form-item>
        <el-form-item label="虚拟vpn端口" prop="vpnport">
          <div class="f-fw-n">
          <el-input v-model="formData.vpnport" placeholder="请输入虚拟vpn端口"></el-input>
          </div>
        </el-form-item>
        <el-form-item label="虚拟vpn协议" prop="vpnproto">
          <div class="f-fw-n">
            <el-select v-model="formData.vpnproto" placeholder="请选择">
                  <el-option v-for="item in prototype" :key="item" :label="item" :value="item"></el-option>
            </el-select>
          </div>
        </el-form-item>
        <el-form-item>
          <div class="f-fw-n">
            <el-button @click="setVpnIP('addrFromvpnsetting')" type="primary" :loading="isSubmitting" >保  存</el-button>
          </div>
        </el-form-item>
        </div>
        </el-card>
        <el-card>
          <el-form-item label="私有ip段" prop="vpnmask">
            <div class="f-fw-n">
            <el-input v-model="formData.vpnmask" placeholder="请输入私有ip段（掩码格式）"></el-input>
            </div>
          </el-form-item>
          <el-form-item>
            <div class="f-fw-n">
              <el-button @click="setVpnPIP('addrFromvpnsetting')" type="primary" :loading="isSubmitting">保存</el-button>
            </div>
          </el-form-item>
        </el-card>
      </el-form>
    </div>
  </div>
</template>
<script>
import vpnService from 'services/vpnService'
export default {
  data () {
    const checkIP = (rule, value, callback) => {
      let reg = /^((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){3}(2[0-4]\d|25[0-5]|[01]?\d\d?)$/
      let status = reg.test(value)
      if (!status) {
        callback(new Error('IP格式不正确'))
      } else {
        callback()
      }
    }

    const checkPort = (rule, value, callback) => {
      let regPort = /^([1-9]|[1-9]\d{1,3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/
      let status = regPort.test(value)
      if (!status) {
        callback(new Error('端口格式不正确'))
      } else {
        callback()
      }
    }

    const checkMask = (rule, value, callback) => {
      let data = value.split('/')
      let ip = data[0]
      let mask = data[1]
      let regmask = /^(?:[1-9]|[12][0-9]|3[012])$/
      let regip = /^((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){3}(2[0-4]\d|25[0-5]|[01]?\d\d?)$/
      let status = regip.test(ip)
      let maskstatus = regmask.test(mask)

      if (!status || !maskstatus) {
        callback(new Error('掩码格式不正确'))
      } else {
        callback()
      }
    }
    return {
      isSubmitting: false,
      prototype: ['TCP', 'UDP', 'TCP/UDP'],
      formData: {
        vpnip: '',
        vpnmask: '',
        vpnport: '',
        vpnproto: ''
      },
      rules: {
        vpnip: [
          {required: true, message: '不能为空', trigger: 'blur'},
          {validator: checkIP, trigger: 'blur'}
        ],
        vpnport: [
          {required: true, message: '不能为空', trigger: 'blur'},
          {validator: checkPort, trigger: 'blur'}
        ],
        vpnmask: [
          {required: true, message: '不能为空', trigger: 'blur'},
          {validator: checkMask, trigger: 'blur'}]
      }
    }
  },
  created () {
    this.getVPNSetting()
  },
  methods: {
    getVPNSetting () {
      vpnService.getVPNSetting()
      .then(res => {
        if (res.success) {

          this.formData.vpnip = res.data.v_vpn_ip
          this.formData.vpnport = res.data.v_vpn_port
          this.formData.vpnproto = res.data.v_vpn_protocol
          this.formData.vpnmask = res.data.p_ip_range
        }
      })
    },
    setVpnPIP (formName) {
      $('.el-message').remove()
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.$refs[formName].clearValidate() // 清除校验结果
          this.$confirm('此操作将更新所有用户的私有ip设置, 是否继续?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.isSubmitting = true
            vpnService.updatePipSetting({'p_ip_range': this.formData.vpnmask})
            .then(res => {
              this.isSubmitting = false
              if (res.success) {
                this.$message({
                  showClose: true,
                  message: '保存成功',
                  type: 'success',
                  duration: 1500
                })
                this.getGRule()
              }
            }, () => {
              this.isSubmitting = false
            })
          }).catch(() => {})
        }
      })
    },
    setVpnIP (formName) {
      $('.el-message').remove()
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.$refs[formName].clearValidate() // 清除校验结果
          this.$confirm('此操作将更新VPN ip设置, 是否继续?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.isSubmitting = true
            vpnService.updateVPNSetting({'v_vpn_ip': this.formData.vpnip, 'v_vpn_port': this.formData.vpnport, 'v_vpn_protocol': this.formData.vpnproto})
            .then(res => {
              this.isSubmitting = false
              if (res.success) {
                this.$message({
                  showClose: true,
                  message: '保存成功',
                  type: 'success',
                  duration: 1500
                })
                this.getGRule()
              }
            }, () => {
              this.isSubmitting = false
            })
          }).catch(() => {})
        }
      })
    }
  }
}
</script>
<style scoped lang="scss">

.f-fw-n {

}

.el-card {
    display: flex;
    flex-wrap: nowrap;
    // width: 400px;
    // border: solid;
    flex-direction: column;
    align-items: center;
    margin-bottom: 20px;
}

ul {
  display: inline-block;
}
.content{
  display: flex;
  justify-content: center;
}
.content>div{
  width: 500px;
  // margin-top: 20px;
}

li {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  span {
    margin: 0 5px;
  }
  .input {
    width: 200px;
  }
}
</style>
