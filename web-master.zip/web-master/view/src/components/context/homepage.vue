<template>
  <div class="home-wrap">
    <el-row>
      <el-col :span="12">
        <el-card>
          <div class='log-card-top'>
            <div>
              <img src="/static/img/total.png" >
            </div>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{totaluser}}<br/>
            登录客户总数
          </div>
        </el-card>
      </el-col>
      <el-col :span="12">
        <el-card>
          <div class='log-card-top'>
            <div>
              <img src="/static/img/online.png" >
            </div>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{onlineuser}}<br/>
            目前在线人数
          </div>
        </el-card>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="24">
        <el-card>
          <div class="g-status-title" @click="toG()">
            前端机状态
          </div>
          <div class='g-status'>
            <div class='g-status-content'>

              <div v-for="eachstatus in g_status" class='g-status-item' :key="eachstatus.ip">

                <el-popover
                  placement="top-start"
                  title="G设备状态"
                  width="200"
                  trigger="hover"
                  >
                  <div style="display: flex; flex-wrap: wrap;">
                    <div :class="['div-popover', eachstatus.status == 'down' ? 'g-status-item-red' : eachg.status == 'up' ? 'g-status-item-green' : 'g-status-item-red']" v-for="eachg in eachstatus.g_sets" :key="eachg.ip">
                      {{eachg.ip}}
                    </div>
                  </div>
                  <!-- <el-button slot="reference">{{eachstatus.ip}}</el-button> -->
                  <div slot="reference" :class="[eachstatus.status == 'up' ? 'g-status-item-green' : 'g-status-item-red']">{{eachstatus.ip}}</div>
                </el-popover>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import indexService from 'services/indexService'
import LinkInfoService from 'services/linkInfoService'
import topoService from 'services/topoService'
import logService from 'services/logService'

const THRESHHOLD = 5000
export default {
  data () {
    return {
      onlineuser: 999,
      totaluser: 888,
      g_status: []
    }
  },

  created () {

  },

  mounted () {
    this._loadData()
  },

  methods: {
    _loadData () {
      topoService.getFrontList(1, 100).then(res => {
        if (res.success) {
          this.g_status = res.data.list.map(item => {
            let each_front = {ip: item.g_plus_ip, status: item.g_plus_status, g_sets: ''}
            let g_sets_arr = item.g_ips.split(',')
            each_front['g_sets'] = g_sets_arr.map(item => {
              return { 'status': item.split(":")[1], 'ip':item.split(":")[0] }
            })
            return each_front
          })
          console.log(this.g_status);

        }
      }).always()
      logService.getTotal().then(res => {
        if (res.success) {
          this.totaluser = res.data.total_user_counts
          this.onlineuser = res.data.online_user_counts
        }
      }).always()
    },
    toG(){
      this.$router.push("/control/front_status")
    }
  }
}
</script>
<style lang="scss">

.div-popover{
  margin: 5px;
}

.g-status-title{
  padding-bottom: 20px;
  font-size: 25px;
  cursor: pointer;
}

.g-status-content{
  // padding: 20px;
  // margin: 10px;
  background: #E5E5E5;
  font-size: 30;
  display: flex;
  flex-wrap: wrap;

}

.g-status-item{
  margin: 15px;
  padding: 10px;
  width: 150px;
  background: white;
  font-size: 20px;
  text-align: center;
  // color: black;
  cursor: pointer;
}

.g-status-item-red{
  color: red;
}

.g-status-item-green{
  color: springgreen;
}

.el-col{
  padding: 10px;
}

.home-wrap{
  padding: 30px 5%;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  height: 100%;
  overflow: auto;
}

.log-card-top{
  height: 200px;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  font-size: 30px;
  color: #00C4C2;
  justify-content: space-between;
  padding: 30px;
}

</style>


