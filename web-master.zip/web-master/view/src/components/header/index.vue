<template>
    <div class="vd-head">
      <ul class="logo">
        <li> <img src="../img/logo.png"></li>
        <span class="line"></span>               
        <li><h3>XXX综合管理系统</h3></li>    
        <span class="line"></span>               
        <li class="hover-able" @click="JumpTO('/')"><span>设备概况</span></li>     
        <span class="line"></span>               
        <li class="hover-able" @click="JumpTO('/control')"><span>管理控制台</span></li>     
      </ul>
      <ul class="right—list">
        <li class="hover-able" @click="handleCommand('account_manage')">
          <img src="/static/img/icon-user.png" width="14">
          <span>admin</span>
        </li>
        <span class="line"></span>  
        <li class="hover-able" @click="handleCommand('exit')">
          <img src="/static/img/icon-exit.png" width="14">
          <span>退出系统</span>
        </li>
      </ul>    
    </div>
</template>
<script>

import indexService from 'services/indexService'
export default {
  data () {
    return {
      theme: 'red',
      lang: 'ch'
    }
  },
  methods: {
    JumpTO (path) {
      this.$router.push(path)
    },
    handleCommand (command) {
      if (command === 'account_manage') {
        this.$router.push('/control/account_manage')
      } else if (command === 'exit') {
        this.logout()
      }
    },
    logout () {
      indexService.logout().then(recvdata => {
        if (recvdata.success) {
          window.sessionStorage.setItem('login', false)
          this.$store.commit('EDIT_NOTE', false)
          this.$router.push('/login')
        }
      })
    },
    changeTheme (theme) {
      this.theme = theme
      $('#app').attr('class', theme)
      window.localStorage.setItem('theme', theme)
    },
    changeLang (lang) {
      this.lang = lang
    }
  }
}
</script>
