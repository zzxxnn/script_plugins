<template>
	<footer style="text-align: center;">   
			&copy; XXX有限公司
	</footer>
</template>
<style>
footer {
	padding: 10px;
	color: #fff;
	font-size: 12px;	
    max-height:40px; 
}
footer a,footer a:hover {
	color: #fff;
	text-decoration: none;
}
</style>